from sqlalchemy import Column, String
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()

class AesKey(Base):
    __tablename__ = "aes_key"

    keyindex = Column(String(64), primary_key=True)
    keypart = Column(String(32))
