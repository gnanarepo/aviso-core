import logging
import re
import time

from bson import BSON
from pymongo import ASCENDING

from aviso.interface import BaseModel
from aviso.settings import gnana_db, gnana_db2, sec_context
from aviso.utils import GnanaError
from aviso.utils import dateUtils, diff_rec,mailUtils


logger = logging.getLogger('gnana.%s' % __name__)


class BaseBulkOperations(object):

    def __init__(self, collection_name):
        raise NotImplementedError()

    def find(self, criteria):
        raise NotImplementedError()

    def upsert(self):
        raise NotImplementedError()

    def replace_one(self, doc):
        raise NotImplementedError()

    def update_one(self, doc):
        raise NotImplementedError()

    def insert(self, doc):
        raise NotImplementedError()

    def execute(self):
        raise NotImplementedError()


def pref_logger(function):
    def wrapper(*args, **kwargs):
        initial = time.time()
        return_value = function(*args, **kwargs)
        time_consumed = time.time() - initial
        self = args[0]
        logger.info(f'{time_consumed} {"POSTGRES" if getattr(self,"postgres", False) and not self.postgres else "MONGO"} consumed for name:{self.getCollectionName()} function:{function.__qualname__}')
        return return_value
    return wrapper


class Model(BaseModel):
    """Base class for all domainmodel objects and provides the basic ORM
    capabilities and conventions.

    In addition, this class also provides a
    few class level methods that can be used to retrieve objects by keys
    and names.

    This base class adds the following into the collection:

    _id
        Database ID of the object

    _kind
        Type of the object stored in the collection.  Most of the time, a
        collection holds homogeneous kind of objects, however this is not
        guaranteed.

    _version
        Each object will store a schema version used to store the object.
        In the future it is expected that, an upgrade method is called to
        progressively upgrade the data in the collection.

        .. NOTE:: As of now we are storing the version, but no upgrade logic
            is implemented.

    object
        All the attributes of the object are encoded by calling the encode
        method and saved with object key

        During encoding each domainobject should ensure there are no periods
        in any dictionaries.  This is a limitation in document databases.

    Following Class level variables to be defined by each domain object:

    kind
        Kind of the object

    tenant_aware
        If the tenant aware is set to true, when saving the objects,
        collection name is prefixed with the tenant name from security context
        object

    version
        Current object schema version

    index_list
        A dictionary of indexes to be ensured when saving.  When specifying
        the index, additional options can be provided as a subdictionary.

        Examples::

            # Just an index
            'probeid': {}

            # Unique index on object.username field in DB
            'username': {'unique': True}

            # Creating index in descending order, default value is ASCENDING
            "created_time": {'direction': DESCENDING}

            # Index to expire documents after certain age. In this example
            # document expires after 900 sec + value in object.timestamp
            # field
            'timestamp': {
                'expireAfterSeconds': 900
            }

    query_list
        A dictionary in the same format as indexes, that must be searchable
        but not actually created in the DB as indexes.

    collection_name
        Name of the collection in which to store the values.

        .. WARNING: Never use ModelClass.collection_name directly, instead
            use ModelClass.getCollectionName() method.  Using the method ensures
            that tenant prefixing is done properly.
    """
    def save(self, is_partial=False, bulk_list=None, id_field=None, field_list=None, conditional=False):
        """Save the object into the database.
        If the object is initialized with attributes and an _id is found,
        during the object creation, it is overwritten.  If no _id is present
        it is created.
        id_field: Is used to update records based on the given field
        conditional: If true ensures no updates have been made to this record between the read and the write.
                     returns the if of the record if the conditional write was successful, otherwise false
        """
        if getattr(self, 'read_only', None):
            raise GnanaError("Read only object cannot be saved!")

        collection_name = self.getCollectionName()

        # currently database views are used by tenant model
        # To save data to tenant directly removing _view from the collection name
        if '_view' in collection_name:
            collection_name = collection_name.replace('_view', '')

        postgres = getattr(self, "postgres", None)

        self.create_index()

        localattrs = {}
        prev_last_modified_time = self.last_modified_time
        try:
            self.last_modified_time = dateUtils.epoch().as_epoch()
        except:
            self.last_modified_time = None
        self.encode(localattrs)
        localattrs.pop('last_modified_time', None)
        check_sum_value = localattrs.pop('check_sum', None)
        object_doc = {}
        # field_list need to be pass in case of is_partial=True for task and result_cache save.
        # for e.g field_list = ['object.extid', 'object.type'] etc.
        if is_partial and field_list:
            for i in field_list:
                object_doc[i] = localattrs[i.split('.')[1]]
        else:
            object_doc = {'object': localattrs}
        object_doc.update({'_kind': self.kind,
                           '_version': self.version,
                           'last_modified_time': self.last_modified_time})
        if check_sum_value:
            object_doc['check_sum'] = check_sum_value
        if not field_list:
            object_doc = self.update_object_doc(object_doc)
        if bulk_list is not None:
            if conditional:
                raise Exception("Conditionals not supported by bulk saving")

            if not self.id and not id_field:
                bulk_list.insert(object_doc)
            else:
                if self.id:
                    object_doc['_id'] = self.id
                id_field = '_id' if not id_field else id_field
                if isinstance(id_field, str):
                    id_field_list = [id_field]
                else:
                    id_field_list = id_field
                criteria = self.bulk_criteria(id_field_list, object_doc)
                if is_partial:
                    bulk_list.find(criteria).upsert().update_one(object_doc)
                else:
                    bulk_list.find(criteria).upsert().replace_one(object_doc)
            return None
        else:
            if getattr(self, "postgres", None):
                if conditional:
                    raise Exception("Conditionals not implemented for posgres")
                self.id = self.get_db().saveDocument(
                    collection_name, object_doc, self.id, is_partial=is_partial)
            else:
                id_copy = self.id # copy of id incase upload fails, to use in next steps
                self.id = gnana_db.saveDocument(
                    collection_name, object_doc, self.id, is_partial=is_partial,
                    conditional=conditional, prev_last_modified_time=prev_last_modified_time)
                ret_info = self.id
                if isinstance(ret_info,dict) and "Resulting document after update is large" in ret_info.get('error'):
                    self.id = id_copy
                    text_fields = self.fld_config.get('text_fields',[]) # large text fields which occupy more space
                    for field in text_fields:
                        if field in object_doc['object']['history']:
                            for i in range(len(object_doc['object']['history'][field])):
                                if len(object_doc['object']['history'][field]) > 1:
                                    logger.info("Popping out {} for {} in {} dataset".format(object_doc['object']['history'][field][0],field,collection_name))
                                    object_doc['object']['history'][field].pop(0) # remove starting history to have space for new changes
                                    ret_info = gnana_db.saveDocument(
                                        collection_name, object_doc, self.id, is_partial=is_partial,
                                        conditional=conditional, prev_last_modified_time=prev_last_modified_time)
                                    if isinstance(ret_info,dict) and "Resulting document after update is large" in ret_info.get('error'):
                                        pass
                                    else:
                                        return ret_info
                if isinstance(ret_info,dict):
                    message = "Hi All,\n" + "Error while uploading {} for {}. Upload failing with error {}.".format(object_doc['object']['extid'],sec_context.name,ret_info.get('error'))
                    message += "\n\n[NOTE: This is an auto generated email.]"
                    subject = "Error while uploading {}. ".format(object_doc['object']['extid'])
                    mailUtils.send_mail(subject, message, "etl.checker@aviso.com", ["integration@aviso.com"])


            return self.id

    def bulk_criteria(self, id_field, object_doc):
        field_list = []
        for field in id_field:
            if 'object.' in field:
                f = field[len('object.'):]
                field_list.append({field: object_doc['object'][f]})
            else:
                field_list.append({field: object_doc[field]})
        criteria = {'$and': [x for x in field_list]}
        return criteria

    def update_object_doc(self, object_doc):
        localattrs = object_doc['object']
        localattrs = self.check_postgres_typed_fields(localattrs)
        object_doc['object'] = localattrs
        return object_doc

    @classmethod
    def bulk_ops(cls):
        class PostGress_Bulk_Operations(BaseBulkOperations):

            def __init__(self, collection_name, encrypted, id_field):
                self.collection_name = collection_name
                self.encrypted = encrypted
                self.bulk_list = []
                self.bulk_update = []
                self.find_objs = {}
                self.id_field = id_field if id_field else 'extid'

            def execute(self):
                #                     pass
                if self.bulk_list:
                    logger.info("Using postgres bulk insert")
                    cls.get_db().postgres_bulk_execute(
                        self.bulk_list, self.collection_name)
                if self.bulk_update:
                    logger.info("Using postgres bulk update")
                    cls.get_db().postgres_bulk_update(self.bulk_update)

            def insert(self, doc):
                self.bulk_list.append(doc)

            def upsert(self):
                return self

            def _replace(self, doc):
                self.bulk_update.append(
                    cls.get_db().postgres_bulk_update_string(self.collection_name, doc))

            def find(self, criteria):
                if criteria:
                    obj = cls.get_db().findDocument(self.collection_name, criteria)
                    if obj:
                        self.find_objs[obj['object'][self.id_field]] = obj
                return self

            def replace_one(self, doc):
                if (doc['object'][self.id_field] in self.find_objs):
                    saved_rec = self.find_objs.pop(doc['object'][self.id_field])
                    doc['_id'] = saved_rec['_id']
                    self._replace(doc)
                else:
                    self.insert(doc)

            def update_one(self, doc):
                saved_rec = self.find_objs.pop(doc['object'][self.id_field])
                saved_rec.update(doc)
                self._replace(saved_rec)

        class MongoBulkOperations(BaseBulkOperations):

            def __init__(self, collection_name):
                self.bulk_list = gnana_db.db[cls.getCollectionName()].initialize_unordered_bulk_op()

            def execute(self):
                try:
                    self.bulk_list.execute()
                except Exception as e:
                    logger.warning("bulk list failed with error %s", str(e))

            def insert(self, doc):
                self.bulk_list.insert(doc)

            def upsert(self):
                return self.bulk_list.upsert()

            def _replace(self, doc):
                raise Exception('replace is not supported for Mongo, this is specific to postgres')

            def find(self, criteria):
                return self.bulk_list.find(criteria)

            def replace_one(self, doc):
                self.bulk_list.replace_one(doc)

            def update_one(self, doc):
                self.bulk_list.update_one(doc)

        class CompressedMongoBulk(BaseBulkOperations):

            def __init__(self, collection_name):
                self.collection_name = collection_name
                self.bulk_list = list()
                self.bulk_update = dict()

            def find(self, criteria):
                return self

            def upsert(self):
                return self

            def replace_one(self, doc):
                self.bulk_update[doc['object']['extid']] = doc

            def update_one(self, doc):
                return self.replace_one(self, doc)

            def insert(self, doc):
                self.bulk_list.append(doc)

            def execute(self):
                if self.bulk_list:
                    cls.compressedSave(self.bulk_list)
                if self.bulk_update:
                    cls.UpdateAndSave(self.bulk_update)
                del self.bulk_list
                del self.bulk_update
                self.bulk_list = list()
                self.bulk_update = dict()

        if getattr(cls, "postgres", False):
            return PostGress_Bulk_Operations(cls.getCollectionName(), cls.encrypted, getattr(cls, 'id_field', None))
        elif cls.compressed:
            return CompressedMongoBulk(cls.getCollectionName())
        else:
            return MongoBulkOperations(cls.getCollectionName())


    @classmethod
    def bulk_insert(cls, rec_list):
        cls.create_index()
        tenant_details = sec_context.details
        # is_tenant_encrypted = tenant_details.is_encrypted
        docs_to_insert = []
        for rec in rec_list:
            localattrs = {}
            rec.last_modified_time = dateUtils.epoch().as_epoch()
            rec.encode(localattrs)
            localattrs.pop('last_modified_time', None)
            check_sum_value = localattrs.pop('check_sum', None)
            query_fields = []
            postgres = False
            if getattr(cls, "postgres", None):
                query_fields = cls.all_known_fields
                postgres = True
                if cls.typed_fields:
                    localattrs = cls.check_postgres_typed_fields(localattrs)
            object_doc = {'object': localattrs,
                          '_kind': cls.kind,
                          '_version': rec.version if rec.version != cls.version else cls.version,
                          'last_modified_time': rec.last_modified_time}
            if check_sum_value:
                object_doc['check_sum'] = check_sum_value
            # else:
            docs_to_insert.append(object_doc)
        if docs_to_insert:
            if getattr(cls, "postgres", None):
                cls.get_db().insert(cls.getCollectionName(), docs_to_insert)
            else:
                gnana_db.insert(cls.getCollectionName(), docs_to_insert)


    @classmethod
    def copy_collection(cls, newcls, criteria={}, batch_size=5000):
        if getattr(cls, "postgres", None):
            cur = cls.get_db().findDocuments(
                cls.getCollectionName(), criteria, auto_decrypt=True)
        else:
            cur = gnana_db.findDocuments(
                cls.getCollectionName(), criteria, auto_decrypt=True)
        count = cur.count()
        start_size = 0
        while start_size < count:
            to_process = min(count - start_size, batch_size)
            newcls.bulk_insert(cur[start_size:start_size + to_process])
            start_size += to_process


    @classmethod
    def truncate_or_drop(cls, criteria=None):
        if criteria is None:
            if getattr(cls, "postgres", None):
                return cls.get_db().dropCollection(cls.getCollectionName())
            else:
                return gnana_db.dropCollection(cls.getCollectionName())
        else:
            if getattr(cls, "postgres", None):
                return cls.get_db().truncateCollection(cls.getCollectionName(), criteria, cls.typed_fields)
            else:
                return gnana_db.truncateCollection(cls.getCollectionName(), criteria)['n']


    @classmethod
    def renameCollection(cls, new_col_name, overwrite=False):
        if getattr(cls, "postgres", None):
            cls.get_db().renameCollection(
                cls.getCollectionName(), new_col_name, overwrite)
        else:
            gnana_db.renameCollection(
                cls.getCollectionName(), new_col_name, overwrite)

    @classmethod
    def create_index(cls):
        postgres = getattr(cls, "postgres", None)
        collection_name = cls.getCollectionName()
        if '_view' in collection_name:
            collection_name = collection_name.replace('_view', '')
        if 'OppDS._uip' in collection_name:
            # new indexes only for OppDS uip data in etl-service
            new_idxs = {'accountid': {
                'index_spec': [('object.values.AccountID', ASCENDING)],
                'background': True
                },
                'ownerid': {
                    'index_spec': [('object.values.OwnerID', ASCENDING)],
                    'background': True
                },
                'create_term_index': {
                    'index_spec': [('object.created_date', ASCENDING),
                                   ('object.terminal_date', ASCENDING)],
                    'background': True
                },
                'extid_term_index': {
                    'index_spec': [('object.extid', ASCENDING),
                                   ('object.terminal_date', ASCENDING)],
                    'background': True
                }
            }
            cls.index_list.update(new_idxs)
        if not cls.index_checked.get(collection_name, False):
            for x in cls.index_list:
                index_creation_method = None
                if x in cls.typed_fields:
                    typed_field_type = cls.typed_fields[x]['type']
                    is_array = re.search("(ARRA\w+)", typed_field_type) or re.search("[\[]", typed_field_type)
                    if is_array:
                        index_creation_method = 'gin'
                options = cls.index_list[x]
                if 'index_spec' in cls.index_list[x]:
                    options = options.copy()
                    index_spec = options.pop('index_spec')
                else:
                    index_field_list = x.split('~')
                    index_spec = []
                    for f in index_field_list:
                        direction = options.pop('direction', ASCENDING)
                        index_fld = ("object.%s" % f, direction)
                        index_spec.append(index_fld)
                if postgres:
                    cls.get_db().ensureIndex(collection_name, index_spec, options, method=index_creation_method)
                else:
                    gnana_db.ensureIndex(collection_name, index_spec, options, method=index_creation_method)

            # Special indexes that need to be added for all models are to be
            # defined here
            if postgres:
                cls.get_db().ensureIndex(
                    collection_name, "last_modified_time", {})
            else:
                gnana_db.ensureIndex(collection_name, "last_modified_time", {})
            cls.index_checked[collection_name] = True
            # Updating index list of class with last_modified_time to save it to saved_index_info
            cls.index_list.update({"last_modified_time": {}})
            all_query_fields_new = {
                'index_list': loaded_index_list(cls.index_list),
                'query_list': loaded_index_list(cls.query_list)
            }
            all_query_fields_old = None
            try:
                all_query_fields_old = gnana_db.findDocument(
                    sec_context.name + '.saved_index_info',
                    {'collection': collection_name}
                )
            except:
                pass
            
            try:
                if all_query_fields_old is None  or diff_rec(all_query_fields_new, all_query_fields_old['index_info']):
                    if not all_query_fields_old:
                        all_query_fields_old = {'collection': collection_name}
                    all_query_fields_old['index_info'] = all_query_fields_new
                    gnana_db.saveDocument(
                        sec_context.name + '.saved_index_info',
                        all_query_fields_old
                    )
            except Exception as e:
                logger.exception("Got Exception while saving index info %s" % (e))

    @classmethod
    def getCollectionName(cls):
        """
        Return the collection name to be used for the class.

        .. Warning:: Do not cache this value, as it will change based on
            the context.
        """
        if (cls.tenant_aware):
            return sec_context.name + "." + cls.collection_name
        else:
            return cls.collection_name

    def return_as_object_doc(self):
        localattrs = {}
        self.encode(localattrs)
        localattrs.pop('last_modified_time', None)
        check_sum_value = localattrs.pop('check_sum', None)
        object_doc = {'_id': str(self.id),
                      'object': localattrs,
                      '_kind': self.kind,
                      '_version': self.version,
                      'last_modified_time': self.last_modified_time}
        if check_sum_value:
            object_doc['check_sum'] = check_sum_value
        object_doc = self.update_object_doc(object_doc)
        return object_doc

    @classmethod
    def getBySpecifiedCriteria(cls, criteria, check_unique=False):
        """Find an object by given criteria. The caller can specify any
        MongoDB-blessed criteria to find a specific document.

        check_unique
            When multiple objects match the field value, passing check_unique as
            True will explicitly checking nothing else matched.  Otherwise it
            returns the first matching object

            .. NOTE::

                Generally you should use the unique_indexes and not depend
                on this mechanism.
        """
        if getattr(cls, "postgres", None):
            attrs = cls.get_db().findDocument(cls.getCollectionName(),
                                           criteria,
                                           check_unique)
        else:
            attrs = cls.get_db().findDocument(cls.getCollectionName(),
                                          criteria,
                                          check_unique)
        if (attrs):
            return cls(attrs)
        else:
            return None

    @classmethod
    def getByFieldValue(cls, field, value, check_unique=False):
        """Find an object by given field value.  ``object.`` is automatically
        prepended to the field name provided.  An object of the class on which
        this method is called will be created, hence this method will work for
        all domainmodel objects.

        forgive
            When multiple objects match the field value, passing forgive as
            True will return the first matching object.  If it is False, an
            exception is raised.

            TODO: Refactor this - use getBySpecifiedCriteria once the tests pass
        """

        attrs = cls.get_db().findDocument(cls.getCollectionName(),
                                          {'object.' + field:
                                           value},
                                          check_unique
                                          )

        return cls(attrs) if attrs else None


    @classmethod
    def getAllByFieldValue(cls, field, value):
        """Find all objects by given field value.  ``object.`` is automatically
        prepended to the field name provided.  An object of the class on which
        this method is called will be created, hence this method will work for
        all domainmodel objects.


            TODO: Refactor this - use getBySpecifiedCriteria once the tests pass
        """
        try:
            if (getattr(cls, "postgres", None)):
                my_iter = cls.get_db().findAllDocuments(cls.getCollectionName(),
                                                        {'object.' + field: value})
            else:
                my_iter = gnana_db.findAllDocuments(cls.getCollectionName(),
                                                    {'object.' + field: value})
            for attrs in my_iter:
                yield cls(attrs)
        except:
            logger.exception("Exception raised while finding values %s-%s-%s" %
                             (cls.getCollectionName(), field, value))

    @classmethod
    def getAll(cls, criteria=None, fieldList=[], return_dict=False):
        """Find all objects.  An object of the class on which
        this method is called will be created, hence this method will work for
        all domainmodel objects.
        """
        if criteria is None:
            criteria = {}
        # currently we are supporting the fieldList only for postgres as mongo has encrypted data, there are other steps to be
        # done. to support field projection for mongo
        if not getattr(cls, 'postgres', None):
            fieldList = []
        try:
            my_iter = cls.get_db().findAllDocuments(
                cls.getCollectionName(), criteria, cls.typed_fields, fieldList)
            if return_dict:
                for attrs in my_iter:
                    yield attrs['object']
            else:
                for attrs in my_iter:
                    cls_obj = cls(attrs)
                    if fieldList:
                        # Making the class object to be read only if only some fields are requested.
                        setattr(cls_obj, 'read_only', True)
                    yield cls_obj
        except Exception as e:
            logger.exception(e)

    @classmethod
    def getByKey(cls, key):
        """Find an object by key
        """
        try:
            if getattr(cls, "postgres", None):
                attrs = cls.get_db().retrieve(cls.getCollectionName(), key)
            else:
                attrs = gnana_db.retrieve(cls.getCollectionName(), key)
        except StopIteration:
            attrs = None
        return attrs and cls(attrs) or None

    @classmethod
    def getByName(cls, name):
        """Find an object by name.  This is shorthand to getByFieldValue
        """
        return cls.getByFieldValue('name', name)


    @classmethod
    def remove(cls, objid):
        """Remove the object from the database
        """
        if objid:
            if getattr(cls, "postgres", None):
                cls.get_db().removeDocument(cls.getCollectionName(), objid)
            else:
                gnana_db.removeDocument(cls.getCollectionName(), objid)
        else:
            raise ModelError("Can't remove unbound db object")

    def _remove(self):
        self.remove(self.id)

    @classmethod
    def list_all_collections(cls, prefix):
        if getattr(cls, "postgres", None):
            return cls.get_db().collection_names(prefix)
        else:
            return gnana_db.collection_names(prefix)

    @classmethod
    def check_postgres_typed_fields(cls, localattrs):
        if not cls.typed_fields:
            return localattrs
        for key in localattrs:
            if key in cls.typed_fields.keys():
                typed_field_type = cls.typed_fields[key]['type']
                is_array = re.search("(ARRA\w+)", typed_field_type) or re.search("[\[]", typed_field_type)
                if is_array and not isinstance(localattrs[key], list):
                    if localattrs[key]:
                        localattrs[key] = [localattrs[key]]
        return localattrs

    @classmethod
    def _no_tenant_pod(cls):
        """True when there is no GBM pod to route to, so FM/common must be used.

        administrative.domain is not a customer tenant: it has no GBM pod and no
        cred_map entry to resolve one from, so its config stays on the FM/common
        Postgres. Tenant.get_postgres_db_url() special-cases it the same way.

        sec_context.name is 'N/A' before a tenant is in context (startup, admin
        endpoints, anything pre-switch) -- that has no pod either.
        """
        from aviso.settings import ADMIN_DOMAIN
        name = getattr(sec_context, 'name', None)
        return (not name) or name == 'N/A' or name == ADMIN_DOMAIN

    @classmethod
    def get_db(cls):
        if getattr(cls, "postgres", None):
            if getattr(cls, "pg_cluster", None) == 'gbm' and not cls._no_tenant_pod():
                # Routed to the tenant's GBM pod (gbm1_ms / gbm2_ms) rather than
                # the FM/common Postgres. Opt-in per model; unset means unchanged.
                from aviso.settings import gnana_db2_gbm
                return gnana_db2_gbm
            return gnana_db2
        else:
            return gnana_db


    @classmethod
    def getDistinctValues(cls, key, criteria={}):
        encrypted = False
        if getattr(cls, "postgres", None):
            return cls.get_db().getDistinctValues(cls.getCollectionName(), key, criteria=criteria, encrypted=encrypted)
        else:
            return gnana_db.getDistinctValues(cls.getCollectionName(), key, criteria=criteria, encrypted=encrypted)

    @classmethod
    def queryExecutor(cls, statement, return_dict=False):
        if getattr(cls, "postgres", None):
            try:
                my_iter = cls.get_db().postgres_query_executor(cls.getCollectionName(), statement)
                if return_dict:
                    for attrs in my_iter:
                        yield attrs['object']
                else:
                    for attrs in my_iter:
                        yield cls(attrs)
            except Exception as e:
                logger.exception(str(e))
                raise (e)

    @classmethod
    def get_count(cls, criteria=None):
        return cls.get_db().find_count(cls.getCollectionName(), {} if criteria is None else criteria)


class ModelError(Exception):

    def __init__(self, error):
        logger.error(error)
        self.error = error


def loaded_index_list(index_list_class):
    index_list_db = {}
    for k, v in index_list_class.items():
        name = k.replace('.', '~')
        index_list_db[name] = v.copy()
        if 'index_spec' in v:
            index_list_db[name]['key'] = v.get('index_spec')
        else:
            index_field_list = k.split('~')
            index_spec = []
            for f in index_field_list:
                index_fld = ("object.%s" % f, ASCENDING)
                index_spec.append(index_fld)
            index_list_db[name]['key'] = index_spec
    return index_list_db
