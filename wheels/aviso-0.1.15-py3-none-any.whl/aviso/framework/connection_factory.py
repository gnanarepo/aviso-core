import os
import time
import threading
import logging
import psycopg2
import pymysql
import boto3
from urllib.parse import urlparse
from pymongo import MongoClient, MongoReplicaSetClient

from aviso.engine.mongo_conn_engine import MongoConnEngine
from aviso.connector import PostgresConnectionManager, MySQLConnectionManager, S3ConnectionManager
from aviso.framework.tenant_mongo_resolver import MongoTenantConfig

_DEFAULT_TTL = 3600
logger = logging.getLogger(__name__)

_PG_ENV = {
    "fm":  "PG_DB_CONNECTION_URL",
    "gbm": "GBM_PG_DB_CONNECTION_URL",
    "etl": "ETL_PG_DB_CONNECTION_URL",
}


class ConnectionFactory:
    """
    Drop-in replacement for TenantMongoResolver that resolves Mongo URLs
    via Postgres + AESEngine (aviso.engine) instead of AWS Secrets Manager.

    Connections are built lazily from env vars (one PG connection per db_type).
    Results are cached in-process for _DEFAULT_TTL seconds (no Redis).

    Thread safety:
        Per-db_type locks protect the PostgresConnectionManager singleton
        during cache misses. Cache hits (99% of requests) skip locking entirely.

    Usage::

        # Drop-in for: TenantMongoResolver().ms_connection_mongo_client_db(...)
        db = ConnectionFactory.get_mongo_db(tenant="acme.com", db_type="etl", cname="preprod")

        # Drop-in for: TenantMongoResolver().resolve(...)
        cfg = ConnectionFactory.resolve("acme.com", cname="preprod", db_type="gbm")
        # cfg.stack, cfg.db_name, cfg.mongo_url, cfg.replica_set all available

    Required env vars:
        PG_DB_CONNECTION_URL           — FM Postgres (also used for cred_map stack lookups)
        GBM_PG_DB_CONNECTION_URL       — GBM Postgres default (preprod / fallback)
        GBM1_MS_PG_DB_CONNECTION_URL   — GBM pod 1 Postgres (prod, optional, falls back to GBM_PG_DB_CONNECTION_URL)
        GBM2_MS_PG_DB_CONNECTION_URL   — GBM pod 2 Postgres (prod, optional, falls back to GBM_PG_DB_CONNECTION_URL)
        ETL_PG_DB_CONNECTION_URL       — ETL Postgres default (preprod / fallback)
        ETL_MS_PG_DB_CONNECTION_URL    — ETL prod Postgres  (optional, falls back to ETL_PG_DB_CONNECTION_URL)

    Additional env vars (FM db_type only, for MySQL-backed AES key):
        MYSQL_HOST, MYSQL_USERNAME, MYSQL_PASSWORD, MYSQL_DATABASE, MYSQL_PORT (default 3306)
        AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, AWS_REGION (default us-east-1)
    """

    # Maps ms_stack (from cred_map host) -> AES key stack (keyindex prefix in aviso_aeskey).
    # Needed when a stack shares AES keys with another stack.
    # e.g. etl-pre-release host exists but aviso_aeskey stores keys as "etl-qa~<tenant>"
    _AES_STACK_ALIAS = {
        "gbm-pre-release": "gbm-qa",
        "etl-pre-release": "etl-qa",
    }

    # S3 manager (FM AES key only) — cached; boto3 clients are stateless and don't go stale
    _s3_manager = None

    # Per-db_type lock — prevents singleton race on cache miss
    _locks = {
        "fm":  threading.Lock(),
        "gbm": threading.Lock(),
        "etl": threading.Lock(),
    }

    # App-level config cache: (tenant, db_type, cname) -> (MongoTenantConfig, expiry)
    _config_cache: dict = {}

    # MongoClient cache: (mongo_url, replica_set) -> client
    _client_cache: dict = {}

    # ------------------------------------------------------------------ #
    # Internal: lazy connection builders                                   #
    # ------------------------------------------------------------------ #

    @classmethod
    def _get_pg_conn(cls, db_type: str, stack: str = None):
        """
        Return a fresh psycopg2 connection each call.

        No caching — avoids stale connections being reused after the DB server
        drops idle connections (RDS timeout, LB TCP timeout, network blip).
        _config_cache (1-hour TTL) protects performance; this path only runs
        on a config cache miss.

        Stack → env var examples:
            "gbm1-ms" → GBM1_MS_PG_DB_CONNECTION_URL  (fallback: GBM_PG_DB_CONNECTION_URL)
            "gbm2-ms" → GBM2_MS_PG_DB_CONNECTION_URL  (fallback: GBM_PG_DB_CONNECTION_URL)
            "etl-ms"  → ETL_MS_PG_DB_CONNECTION_URL   (fallback: ETL_PG_DB_CONNECTION_URL)
            "gbm-qa"  → GBM_QA_PG_DB_CONNECTION_URL   (fallback: GBM_PG_DB_CONNECTION_URL)
        """
        return psycopg2.connect(cls._pg_url_for_stack(db_type, stack),
                                application_name="aviso-core")

    @classmethod
    def _pg_url_for_stack(cls, db_type: str, stack: str = None) -> str:
        """
        Resolve the Postgres URL for a db_type/stack pair from the environment.

        Pure env lookup — no tenant lookup, no connection. Shared by
        _get_pg_conn and the public get_pg_url so the env-var naming
        convention lives in exactly one place.
        """
        if stack:
            stack_env = f"{stack.upper().replace('-', '_')}_PG_DB_CONNECTION_URL"
            pg_url = os.environ.get(stack_env) or os.environ.get(_PG_ENV[db_type])
        else:
            stack_env = None
            pg_url = os.environ.get(_PG_ENV[db_type])

        if not pg_url:
            raise RuntimeError(
                f"Missing PG URL for db_type={db_type}, stack={stack}. "
                f"Set {stack_env if stack_env else _PG_ENV[db_type]}"
            )
        return pg_url

    @classmethod
    def _get_mysql_manager(cls) -> MySQLConnectionManager:
        conn = pymysql.connect(
            host=os.environ["MYSQL_HOST"],
            port=int(os.environ.get("MYSQL_PORT", 3306)),
            user=os.environ["MYSQL_USERNAME"],
            password=os.environ["MYSQL_PASSWORD"],
            db=os.environ["MYSQL_DATABASE"],
        )
        manager = MySQLConnectionManager()
        manager.initialize(connection=conn)
        return manager

    @classmethod
    def _get_s3_manager(cls) -> S3ConnectionManager:
        if cls._s3_manager is None:
            client = boto3.client("s3", region_name=os.environ.get("AWS_REGION", "us-east-1"))
            cls._s3_manager = S3ConnectionManager()
            cls._s3_manager.initialize(client=client)
        return cls._s3_manager

    # ------------------------------------------------------------------ #
    # Internal: db_name helper                                            #
    # ------------------------------------------------------------------ #

    @staticmethod
    def _tenant_db_name(tenant: str, cname: str = "preprod", stack: str = None, db_type: str = "fm") -> str:
        """
        Compute the Mongo database name for a tenant.

        FM:      <prefix>_cache_<cname>        e.g. netapp_cache_preprod
        ETL/GBM: <prefix>_db_<stack>           e.g. netapp_db_etl-ms
                 (.io tenants get a dash:       netapp-io_db_etl-ms)
        """
        parts = tenant.split(".")
        if len(parts) > 1:
            if parts[-1] != "com" and db_type != "fm":
                tenant_prefix = f"{'_'.join(parts[:-1])}-io"
            else:
                tenant_prefix = "_".join(parts[:-1])
        else:
            tenant_prefix = tenant

        if db_type == "fm":
            return f"{tenant_prefix}_cache_{cname}"
        return f"{tenant_prefix}_db_{stack}"

    # ------------------------------------------------------------------ #
    # Internal: stack lookup from FM Postgres cred_map                    #
    # ------------------------------------------------------------------ #

    _stack_cache: dict = {}  # (tenant, db_type) -> (stack, expiry)

    @staticmethod
    def _get_subdomain(host: str) -> str:
        """Extract first subdomain segment: 'gbm-qa.aviso.com' -> 'gbm-qa'"""
        if not host:
            return ""
        parsed = urlparse(host if host.startswith(('http://', 'https://')) else f'http://{host}')
        return (parsed.hostname or host).split('.')[0]

    @classmethod
    def _get_ms_stack(cls, tenant: str, db_type: str) -> str:
        """
        Derive the ms stack identifier for a tenant from FM Postgres tenant.cred_map:
            microservices_info.gbm_service.host      -> 'gbm-qa.aviso.com' -> 'gbm-qa'
            microservices_info.etl_data_service.host -> 'etl-ms.aviso.com' -> 'etl-ms'

        Cached for _DEFAULT_TTL seconds.
        Must be called inside _locks[db_type] — no separate lock needed.
        """
        cache_key = (tenant, db_type)
        now = time.time()
        entry = cls._stack_cache.get(cache_key)
        if entry and entry[1] > now:
            return entry[0]

        # Use FM PG for cred_map lookup (re-initializes singleton with FM conn, no stack needed)
        service_name = "etl_data_service" if db_type == "etl" else "gbm_service"
        pg_conn = cls._get_pg_conn("fm", stack=None)
        try:
            PostgresConnectionManager.initialize(connection=pg_conn)
            with PostgresConnectionManager.get_cursor() as cursor:
                cursor.execute("SELECT cred_map FROM tenant WHERE name = %s", (tenant,))
                row = cursor.fetchone()
        finally:
            PostgresConnectionManager.close_connection()

        if not row:
            raise RuntimeError(f"Tenant '{tenant}' not found in FM Postgres tenant table")

        cred_map = row[0] if not isinstance(row, dict) else row['cred_map']
        if isinstance(cred_map, str):
            import json as _json
            cred_map = _json.loads(cred_map)

        host = cred_map.get('microservices_info', {}).get(service_name, {}).get('host', '')
        ms_stack = cls._get_subdomain(host)

        if not ms_stack:
            raise RuntimeError(
                f"Cannot derive stack from host='{host}' for tenant='{tenant}', service='{service_name}'"
            )

        cls._stack_cache[cache_key] = (ms_stack, now + _DEFAULT_TTL)
        logger.info("[ConnectionFactory] %s stack=%s for %s", db_type, ms_stack, tenant)
        return ms_stack

    # ------------------------------------------------------------------ #
    # Internal: decrypt — called only on cache miss, inside db_type lock   #
    # ------------------------------------------------------------------ #

    @classmethod
    def _fetch_config(cls, tenant: str, cname: str, db_type: str) -> MongoTenantConfig:
        if db_type in ("etl", "gbm"):
            # Step 1: derive stack from FM Postgres cred_map (re-initializes PG with FM conn)
            ms_stack = cls._get_ms_stack(tenant, db_type)   # e.g. "gbm1-ms", "gbm2-ms", "etl-ms"
            # Step 2: get stack-specific PG conn and re-initialize singleton for AES decryption
            # "gbm1-ms" -> GBM1_MS_PG_DB_CONNECTION_URL, fallback GBM_PG_DB_CONNECTION_URL
            # "gbm2-ms" -> GBM2_MS_PG_DB_CONNECTION_URL, fallback GBM_PG_DB_CONNECTION_URL
            pg_conn = cls._get_pg_conn(db_type, stack=ms_stack)
            try:
                PostgresConnectionManager.initialize(connection=pg_conn)
                # Use AES key alias if this stack shares keys with another stack
                # e.g. etl-pre-release stores keys as "etl-qa~<tenant>" in aviso_aeskey
                aes_stack = cls._AES_STACK_ALIAS.get(ms_stack, ms_stack)
                engine = MongoConnEngine(tenant_name=tenant, cname=aes_stack)
                mongo_url = engine.get_decrypted_ms_mongo_url()
                replica_set = engine.get_replica_set_name()
            finally:
                PostgresConnectionManager.close_connection()

            # Parse db_name and stack from the decrypted URL path.
            # e.g. ".../netapp_db_etl-ms" -> db_name="netapp_db_etl-ms", stack="etl-ms"
            path = urlparse(mongo_url).path.lstrip("/").split("?")[0]
            db_name = path if path else cls._tenant_db_name(tenant, cname=cname, stack=ms_stack, db_type=db_type)
            stack = db_name.split("_db_", 1)[1] if "_db_" in db_name else ms_stack

        elif db_type == "fm":
            pg_conn = cls._get_pg_conn("fm")
            mysql_manager = cls._get_mysql_manager()
            try:
                PostgresConnectionManager.initialize(connection=pg_conn)
                engine = MongoConnEngine(
                    tenant_name=tenant,
                    mysql_connection=mysql_manager._conn,
                    boto3_client=cls._get_s3_manager()._client,
                    cname=cname,
                )
                mongo_url = engine.get_decrypted_fm_mongo_url()
            finally:
                PostgresConnectionManager.close_connection()
                mysql_manager.close_connection()
            replica_set = None
            stack = None

            # FM URLs have /admin in the path — compute db_name from tenant name.
            db_name = cls._tenant_db_name(tenant, cname=cname, db_type="fm")

        else:
            raise ValueError(f"Unsupported db_type: {db_type}")
        
        return MongoTenantConfig(
            mongo_url=mongo_url,
            db_name=db_name,
            replica_set=replica_set,
            stack=stack,
        )

    # ------------------------------------------------------------------ #
    # Public API                                                           #
    # ------------------------------------------------------------------ #

    @classmethod
    def get_pg_stack(cls, tenant: str, db_type: str = "gbm") -> str:
        """
        Return the ms stack serving this tenant, e.g. "gbm1-ms" / "gbm2-ms" / "etl-ms".

        Derived from microservices_info.<service>.host in the FM Postgres
        tenant.cred_map, and cached for _DEFAULT_TTL seconds.
        """
        if db_type not in ("gbm", "etl"):
            raise ValueError(f"No per-stack split for db_type={db_type}")
        with cls._locks[db_type]:
            return cls._get_ms_stack(tenant, db_type)

    @classmethod
    def get_pg_url(cls, tenant: str = None, db_type: str = "gbm", stack: str = None) -> str:
        """
        Return the Postgres URL for a tenant's GBM (or ETL) pod, from the environment.

        Resolution:
            stack given      -> <STACK>_PG_DB_CONNECTION_URL, else <DB_TYPE>_PG_DB_CONNECTION_URL
            tenant given     -> stack looked up via cred_map, then as above
            neither          -> <DB_TYPE>_PG_DB_CONNECTION_URL (the preprod / fallback default)

        Does not connect — it only reads env, so it is safe to call for
        diagnostics. Raises RuntimeError naming the variable to set when the
        URL is missing.

        Usage::

            url = ConnectionFactory.get_pg_url(tenant="acme.com")            # gbm1-ms or gbm2-ms
            url = ConnectionFactory.get_pg_url(stack="gbm2-ms")              # skip the lookup
            url = ConnectionFactory.get_pg_url(db_type="etl", tenant="acme.com")
        """
        if stack is None and tenant is not None:
            stack = cls.get_pg_stack(tenant, db_type)
        return cls._pg_url_for_stack(db_type, stack)

    @classmethod
    def resolve(cls, tenant: str, cname: str = "preprod", db_type: str = "etl") -> MongoTenantConfig:
        """
        Return MongoTenantConfig for the given tenant/db_type/cname.
        Results are cached in-process for _DEFAULT_TTL seconds.

        Drop-in for:
            TenantMongoResolver().resolve(tenant, cname=cname, db_type=db_type)
        """
        cache_key = (tenant, db_type, cname)
        now = time.time()

        # Fast path: no lock needed for reads
        entry = cls._config_cache.get(cache_key)
        if entry and entry[1] > now:
            return entry[0]

        # Cache miss: acquire per-db_type lock to prevent singleton race
        with cls._locks[db_type]:
            # Double-check after acquiring lock (another thread may have populated)
            entry = cls._config_cache.get(cache_key)
            if entry and entry[1] > now:
                return entry[0]

            cfg = cls._fetch_config(tenant, cname, db_type)
            cls._config_cache[cache_key] = (cfg, now + _DEFAULT_TTL)
            logger.info("[ConnectionFactory] resolved %s config for %s/%s", db_type, tenant, cname)
            return cfg

    @classmethod
    def get_mongo_db(cls, tenant: str, db_type: str = "etl", cname: str = "preprod"):
        """
        Return a live pymongo Database object.
        MongoClient instances are cached by (url, replica_set).

        Drop-in for:
            TenantMongoResolver().ms_connection_mongo_client_db(tenant=..., db_type=..., cname=...)
        """
        cfg = cls.resolve(tenant, cname=cname, db_type=db_type)
        client_key = (cfg.mongo_url, cfg.replica_set)

        client = cls._client_cache.get(client_key)
        if client is None:
            if cname == "app" and cfg.replica_set:
                client = MongoReplicaSetClient(
                    cfg.mongo_url,
                    unicode_decode_error_handler="ignore",
                    replicaSet=cfg.replica_set,
                )
            else:
                client = MongoClient(cfg.mongo_url, unicode_decode_error_handler="ignore")
            cls._client_cache[client_key] = client

        return client[cfg.db_name]
