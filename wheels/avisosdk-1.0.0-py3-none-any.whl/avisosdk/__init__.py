"""Module to inject sdk functions along with the SDK connection"""
from __future__ import print_function
import atexit
import zipimport
import base64
import functools
import gzip
import imp
import inspect
import itertools
import json
import logging
import mimetypes
import mmap
import os
import pkgutil
import re
import sys
import threading
import uuid
import time
import traceback
import urllib
from contextlib import contextmanager
from email import generator
import getpass
from ssl import SSLError
from tempfile import NamedTemporaryFile
from time import sleep
import functools

import requests
import six
from Crypto.Hash import SHA
from Crypto.PublicKey import RSA
from Crypto.Signature import PKCS1_PSS
from six import print_ as print_out

from avisosdk.mylogger import log
from requests_toolbelt.multipart.encoder import MultipartEncoder
from avisosdk.utils import diff_rec
import urllib3

urllib3.disable_warnings()

if six.PY2:
    import urllib2 as urllib
    import cookielib as cookiejar
    from urllib2 import HTTPError, URLError
    from urllib import urlencode
    from urllib2 import build_opener, HTTPRedirectHandler, HTTPHandler
    from urllib2 import HTTPSHandler, HTTPCookieProcessor
    from urllib2 import Request
    from urlparse import urlparse, parse_qs
    from StringIO import StringIO
    from httplib import HTTPException
    import httplib

    httplibclient_read = httplib.HTTPResponse.read
else:
    basestring = str
    from http import cookiejar
    import urllib
    from urllib.error import HTTPError, URLError
    from http.client import HTTPException
    from urllib.parse import urlencode, urlparse, parse_qs
    from urllib.request import build_opener
    from urllib.request import HTTPCookieProcessor, HTTPSHandler
    from urllib.request import HTTPHandler, HTTPRedirectHandler
    from urllib.request import Request
    import http.client

    httplibclient_read = http.client.HTTPResponse.read
    raw_input = input

NOT_DEFINED = "NOT_DEFINED"


def patch_http_response_read(func):
    def inner(*args):
        try:
            return func(*args)
        except httplib.IncompleteRead as e:
            return e.partial

    return inner


httplibclient_read = patch_http_response_read(
    httplibclient_read)

logger = logging.getLogger()

retry_codes = [
    502,  # Bad Gateway
    503,  # Service unavailable
    504,  # Gateway timeout
]

allowed_retry_urls = ['/account/switch', '/account/whoAmI',
                      'tasks/cached_result', 'tasks/result',
                      'tasks/status']

sdk_debug = os.environ.get('sdk_debug', 'false').lower() == 'true'

in_test_mode = os.environ.get('gnana_test_mode', 'false').lower() == 'true'

os.umask(0)


def gzip_decompress(data):
    if six.PY2:
        return gzip.GzipFile(fileobj=StringIO(data)).read()
    else:
        return gzip.decompress(data)


class GnackerLibError(Exception):

    def __init__(self, message):
        self.message = message
        super(GnackerLibError, self).__init__()


def gzip_handler(resp):
    buf = resp.read()
    if resp.info().get('Content-Encoding') == 'gzip':
        buf = gzip_decompress(buf)
    return buf


class MultiPartForm(object):
    """Accumulate the data to be used when posting a form."""

    def __init__(self):
        self.form_fields = []
        self.files = []
        self.boundary = generator._make_boundary()
        return

    def get_content_type(self):
        return 'multipart/form-data; boundary=%s' % self.boundary

    def add_field(self, name, value):
        """Add a simple field to the form data."""
        self.form_fields.append((name, value))
        return

    def add_file(self, fieldname, filename, fileHandle, mimetype=None):
        """Add a file to be uploaded."""
        body = fileHandle.read()
        if mimetype is None:
            mimetype = mimetypes.guess_type(
                filename)[0] or 'application/octet-stream'
        self.files.append((fieldname, filename, mimetype, body))
        return

    def __str__(self):
        """Return a string representing the form data, including attached files."""
        # Build a list of lists, each containing "lines" of the
        # request.  Each part is separated by a boundary string.
        # Once the list is built, return a string where each
        # line is separated by '\r\n'.
        parts = []
        part_boundary = '--' + self.boundary

        # Add the form fields
        parts.extend(
            [part_boundary,
             'Content-Disposition: form-data; name="%s"' % name,
             '',
             value]
            for name, value in self.form_fields
        )

        # Add the files to upload
        parts.extend(
            [part_boundary,
             'Content-Disposition: file; name="%s"; filename="%s"' % (
                 field_name, filename),
             'Content-Type: %s' % content_type,
             '',
             body]
            for field_name, filename, content_type, body in self.files
        )

        # Flatten the list and add closing boundary marker,
        # then return CR+LF separated data
        flattened = list(itertools.chain(*parts))
        flattened.append('--' + self.boundary + '--')
        flattened.append('')
        return '\r\n'.join(flattened)


class AsyncResponsePoller(threading.Thread):

    def __init__(self, jobid, opener, url, csrf_token, trace_id, callback, check_loggly=False,
                 probe_handler=None, poll_interval=5, additional_data=None):
        self.jobid = jobid
        self.opener = opener
        self.url = url
        self.csrf_token = csrf_token
        self.trace_id = trace_id
        self.callback = callback
        self.poll_interval = poll_interval
        self.ProbeHandler = probe_handler
        self._check_loggly = check_loggly
        self.additional_data = additional_data
        threading.Thread.__init__(self)

    def run(self):
        # Wait one second before we poll. If something happens in a second
        # It should come back right away
        prev = 0
        count = 0
        failures = 0

        last_wait_time1 = 1
        last_wait_time2 = 0

        data = {'ready': False}
        while not data['ready']:

            # We wait in a fibbonacci series
            new_wait_time = last_wait_time1 + last_wait_time2
            time.sleep(min(new_wait_time, self.poll_interval))
            last_wait_time2 = last_wait_time1
            last_wait_time1 = new_wait_time

            try:
                data = json.loads(self.opener.open(self.url +
                                                   "/tasks/status?id=" + self.jobid).read())
                failures = 0
            except Exception as ex:
                data = {'ready': False}
                failures += 1
                if failures > 10:
                    raise
                else:
                    print(
                        "Exception %s during the polling.  Retrying attempt - %d . . . " % (str(ex), failures))
                continue

            if data.get('percent') is not None:
                dots = int(data['percent'] / 10)
                dif = dots - prev
                if dif > 0:
                    prev = dots
                    for i in range(dif):
                        if count == 0:
                            sys.stdout.write("[* ")
                        elif count == 9:
                            sys.stdout.write("*]")
                        else:
                            sys.stdout.write("* ", )
                        sys.stdout.flush()
                        count += 1
                    print()
        try:
            data = self.opener.open(self.url +
                                    "/tasks/cached_result?task_id=%s&action=fetch" %
                                    self.jobid).read()
        except:
            data = self.opener.open(self.url + "/tasks/result?id=" +
                                    self.jobid).read()

        try:
            data = json.loads(data)
        except ValueError:
            pass

        if self.ProbeHandler:
            self.ProbeHandler.stop_now()

        if self.callback:
            self.callback(data, additional_data=self.additional_data)
        elif self._check_loggly:
            server = self.url
            url = '/loggly/getLog?trace_id=%s' % self.trace_id
            val = None
            try:
                con = call_opener(self.opener, server, self.csrf_token, url)
                val = gzip_handler(con)
                logs = json.loads(val)
                if not logs:
                    print("No warnings or errors from Loggly...")
                else:
                    print(logs)
            except (Exception, SSLError) as ex:
                logger.warning(
                    "Failed to open a connection when retrieving loggly messages: " + str(ex))
                logger.warning("Check loggly manually for possible warnings")

        return data


def get_csrf_token(server, opener):
    data = opener.open(server + "/csrfform")
    response = data.read()
    token = re.search("value='(.*)'", response.decode())
    csrf_token = token.group(1)
    return csrf_token


class RetryOpener(object):

    def __init__(self, opener, retries=5, wait_for_pool=True, tracer=None):
        self.opener = opener
        self.retries = retries
        self.wait_for_pool = wait_for_pool
        self.event_id = None
        self._access_token = None
        self._sandbox = None
        self.tracer = tracer

    def open(self, request_loc, count=0):
        last_exception = None

        # TODO - Add the wait_for_pool to the request, if not present in req
        for dummy in range(self.retries + 1):
            #             timeout_val = 120 if dummy == 0 else 240
            timeout_val = 6000
            if isinstance(request_loc, basestring):
                request_loc = Request(request_loc)
            if self.tracer:
                request_loc.add_header('X-AVISO-TRACE', self.tracer.trace)
            request_loc.add_header('User-Agent', b'Gnana SDK/1.0')
            if self.event_id:
                request_loc.add_header('Event_Id', self.event_id)
            if self._access_token:
                request_loc.add_header('Access-Token', self._access_token)
            if self._sandbox:
                request_loc.add_header('sandbox', self._sandbox)
            # adding default header to keep connection until everything is loaded
            request_loc.add_header("Connection", "keep-alive")
            try:
                return self.opener.open(request_loc, timeout=timeout_val)
            except HTTPError as e:
                if e.code in retry_codes:
                    time.sleep(5)
                else:
                    raise e
            except URLError as e:
                if request_loc.get_full_url().endswith("/account/logout"):
                    break
                last_exception = e
                logger.error("(%s) in opening connection. Attempt %d" %
                             (e.reason, dummy))
                time.sleep(5)

            except SSLError as e:
                last_exception = e
                req_url = request_loc.get_full_url()
                for _url in allowed_retry_urls:
                    if _url in req_url:
                        logger.error("requested URL is %s" % req_url)
                        logger.error("(%s). Attempt %d" % (e, dummy))
                        time.sleep(5)
                        break
                else:
                    print(e)
                    raise
            except HTTPException as e:
                if request_loc.data:
                    raise e
                logger.error("got exception %s. retrying" % e)
                time.sleep(5)
            except Exception as e:
                print(e)
                raise
        else:
            raise GnackerLibError("request opening failed even after 3 retrys")


class GnackerLib(object):

    def __init__(self, username, password, server="https://app.aviso.com",
                 check_loggly=False, retries=2, wait_for_pool=True, tracer=None, tenant_name=None, this_shell=None):
        self.cookies = cookie_jar = cookiejar.LWPCookieJar()
        self._check_loggly = check_loggly
        self._this_shell = this_shell
        self.event_id = None
        self.version_mismatch = False
        opener = RetryOpener(build_opener(
            HTTPRedirectHandler(),
            HTTPHandler(debuglevel=0),
            HTTPSHandler(debuglevel=0),
            HTTPCookieProcessor(cookiejar=cookie_jar)
        ), retries=retries, wait_for_pool=wait_for_pool, tracer=tracer)
        csrf_token = get_csrf_token(server, opener)
        post_data = {'username': username,
                     'password': password}
        headers = {'X-CSRFToken': csrf_token.encode('utf-8'),
                   'REFERER': server.encode('utf-8')}
        req_post_data = urlencode(post_data).encode('utf-8')
        login_url = server + "/account/login"
        if tenant_name:
            post_data['tenant'] = tenant_name
            login_url = server + "/loginswitchbypass"
            req_post_data = json.dumps(post_data).encode('utf-8')
        req = Request(login_url, req_post_data, headers)
        try:
            login_response = opener.open(req)
            if (login_response.getcode() == 200):
                self.opener = opener
                self.server = server
                self.csrf_token = csrf_token
            else:
                raise Exception("Unable to login")
            timezone = json.load(login_response).get('timezone', None)
            self._timezone = timezone
        except HTTPError as err:
            if (err.code == 430):
                try:
                    data = json.loads(err.read())
                    print("Login token for this validation attempt is: %s" %
                          data['login_token'])
                except Exception:
                    data = {}
                    print('Unable to read the data. May be connecting to old server')
                # validate_ip has been removed since long time
                validation_code = raw_input("Enter validation code: ")
                csrf_token = get_csrf_token(server, opener)
                req = Request(
                    server + "/account/validate_ip",
                    urlencode({
                        'validation_code': validation_code,
                        'login_token': data.get('login_token', '')
                    }).encode('utf-8'),
                    {'X-CSRFToken': csrf_token.encode('utf-8'),
                     'REFERER': server.encode('utf-8')}
                )
                validation_response = opener.open(req)
                if (validation_response.code == 200):
                    self.opener = opener
                    self.server = server
                    self.csrf_token = csrf_token
                    logger.info("Connected to %s" % self.server)
                else:
                    raise GnackerLibError("Unable to validate code")
            else:
                response_errors = handle_httperror(err)
                raise GnackerLibError(response_errors)
        except Exception as ex:
            print(ex)
            logger.error(
                "Unable to login using the provided username and password")
            raise GnackerLibError("Unable to login")
        self.ProbeHandler = None
        self.poll_interval = 3
        self.wait_for_pool = wait_for_pool

    def set_retries(self, retries):
        self.opener.retries = retries

    def get_retries(self):
        return self.opener.retries

    retries = property(get_retries, set_retries)

    def set_wait_for_pool(self, wait_for_pool):
        self.opener.wait_for_pool = wait_for_pool

    def get_wait_for_pool(self):
        return self.opener.wait_for_pool

    wait_for_pool = property(get_wait_for_pool, set_wait_for_pool)

    def handle_async_and_probe(self, val, callback, **additional_data):
        if isinstance(val, dict) and 'jobid' in val:
            probe_handler = None
            if 'trace' in val:
                server_url = self.server
                try:
                    if re.search(":\/\/(.*?)\.", server_url).group(1) not in ["localhost", "127"]:
                        server_url = re.sub(
                            ":\/\/", "://administrative.", server_url)
                except:
                    pass
                print("Log trace ID for this call is: %s" % val['trace'])
                print("you can view the task tree at %s/tasks/status?id=%s&gui=True "
                      "\nMake sure to have a active server login session" % (server_url, val["jobid"]))
                #                 kwargs = dict(terms=val['trace'], until="now")
                #                 kwargs['from'] = "-8h"
                #                 print("loggly api is https://gnana.loggly.com/search#%s" %
                #                       urlencode(kwargs))
                kwargs = {}
                dt_now = int((time.time() - 60) * 1000)
                kwargs['from_ts'] = dt_now
                kwargs['query'] = '@Trace:%s' % val['trace']
                kwargs['cols'] = '["core_service"]'
                kwargs['to_ts'] = dt_now + 28800000  # 1000ms*60s*60m*8h
                # datadog_flag = self._this_shell.tenant('get_flag', category='Datadog', config_name='enabled',
                #                                        default='True')
                # datadog_flag = False if datadog_flag.lower() == 'false' else True
                # if datadog_flag:
                #     print("LOGS URL is ",
                #           'https://app.datadoghq.com/logs?event&index=main&live=true&stream_sort=asc&%s' %
                #           urlencode(kwargs))
                # else:
                print("NewRelic LOGS URL is ", 'https://one.newrelic.com/logger?account=3942171&duration=21600000')
                print("Trace Id : %s" % val['trace'])
                if val.get('worker_status', None):
                    if 'worker_pool' in val:
                        logger.warn("Worker pool (%s) is not found. Execution starts after it is launched" %
                                    val['worker_pool'])
                    else:
                        logger.warn(
                            "Worker pool is not found. Execution starts after it is launched")
                sys.stdout.flush()
            if 'probeid' in val and self.ProbeHandler is not None:
                probe_handler = self.ProbeHandler(val['probeid'])
            response_poller = AsyncResponsePoller(
                val['jobid'],
                self.opener,
                self.server,
                self.csrf_token,
                val['trace'],
                callback,
                check_loggly=self._check_loggly,
                poll_interval=self.poll_interval,
                probe_handler=probe_handler,
                additional_data=additional_data)

            if (callback):
                return response_poller.start()
            else:
                return response_poller.run()
        else:
            return val

    def version_validation(self, con):
        info = con.info()
        version = info.get('SDK_VERSION', None)
        # This happens in streaminghttpresponse where response started so server cannot set header
        # in StreamingHttpResponse case Transfer-Encoding header will be sent with `chunked` value, but dev servers won't do,
        # we are letting go if not available
        if self.version == NOT_DEFINED or self.version is None or version is None or version == '':
            return
        if version != self.version:
            logger.warn('sdk version mismatch for %s, version from server %s current version %s' % (
            self.server, version, self.version))
            self.version_mismatch = True

    def getJSONResult(self, url, callback=None, return_trace_id=False, is_async=False):
        con = call_opener(self.opener, self.server, self.csrf_token, url)
        if con is None:
            return None
        self.version_validation(con)
        buf = gzip_handler(con)
        val = json.loads(buf)
        res = None
        if not is_async:
            try:
                res = self.handle_async_and_probe(val, callback)
                return res
            except ValueError:
                print("Unable to decode the content for URL %s" % url)
                print_256(res, filename='response.json')
                raise

        if return_trace_id:
            res = {"trace_id": val.get("trace", None),
                   "res": res}
        return res

    def getCSVResult(self, url, return_stream=False):
        """
        Retrieve the CSV Streaming data.  We assume that CSV data is
        always streamed and it is never a job

        :param url:
        :param return_stream:
        :return:
        """
        con = call_opener(self.opener, self.server, self.csrf_token, url, return_stream)
        self.version_validation(con)
        if return_stream:
            return con
        buf = gzip_handler(con)
        if con is None:
            return None
        return buf

    def postData(
            self,
            url,
            data=None,
            content_type="application/json",
            callback=None,
            return_trace_id=False,
            is_async=False
    ):
        """
        Args:
                url: url to be called without the server. server will be appended automatically
                data: post data if it is post request else None
                content_type: type of data we are sending, default to application/json
                callback: callback function to be called after the request.
                return_trace_id: passing true value will return the trace id
                async:

        """

        req = None
        f = None

        if data is None:
            req = Request(self.server + url, "")
        # Try the data to be a dictionary
        if not req and (isinstance(data, dict) or
                        isinstance(data, list)):
            req = Request(self.server + url,
                          json.dumps(data).encode('utf-8'))

        # If it is not a request, but a string, try it as a filename.
        if not req and isinstance(data, basestring):
            try:
                f = open(data, 'rb')
                mmap_as_string = mmap.mmap(f.fileno(),
                                           0, access=mmap.ACCESS_READ)
                req = Request(self.server + url,
                              b''.join([x for x in mmap_as_string]))
            except Exception as e:
                req = None
                pass
        # Not a dict, and not a file.  Try as basic json data
        if not req and isinstance(data, basestring):
            theData = json.loads(data)
            req = Request(self.server + url,
                          json.dumps(theData).encode('utf-8'))

            
        if not req and isinstance(data, MultipartEncoder):
            req = Request(self.server + url)
            body = data.to_string()
            content_type = data.content_type
            req.add_header('Content-length', len(body))
            req.data = body

        if not req and isinstance(data, MultiPartForm):
            req = Request(self.server + url)
            body = str(data)
            content_type = data.get_content_type()
            req.add_header('Content-length', len(body))
            if six.PY2:
                try:
                    req.add_data(body.encode('utf-8'))
                except:
                    req.add_data(body)
            else:
                req.data = body.encode('utf-8')
        # We are not able to understand the data. Let the caller know
        if not req:
            raise GnackerLibError("Unknown type of data passed in")
        if not (isinstance(data, basestring) and in_test_mode):
                req.add_header("Content-Type", content_type.encode('utf-8'))
        req.add_header('Accept-encoding', 'gzip')
        csrf_token = get_csrf_token(self.server, self.opener)
        req.add_header('X-CSRFToken', csrf_token.encode('utf-8'))
        req.add_header('REFERER', self.server.encode('utf-8'))
        resp = request_opener(req, self.opener)
        if not resp:
            raise Exception("http error")
        resp_str = ""
        try:
            self.version_validation(resp)
            resp_str = gzip_handler(resp)
            resp = json.loads(resp_str)
            res = resp
            if not is_async:
                res = self.handle_async_and_probe(resp, callback)
            if return_trace_id:
                res = {"trace_id": None if not isinstance(resp, dict) else resp.get("trace"),
                       "res": res}
            return res
        except ValueError:
            print("Unable to decode JSON object")
            print(resp_str)
            raise
        finally:
            if f:
                f.close()

    def close(self):
        data = self.opener.open(self.server + "/account/logout")
        data.read()


def print_256(error_str, filename='http_error.html'):
    if len(error_str) > 256:
        logger.info("%s \n. . . response truncated . . . see %s . . ." %
                    (error_str[0:256], filename))
        with open(filename, "w") as f:
            if isinstance(error_str, bytes):
                error_str = str(error_str)
            f.write(error_str)
    else:
        logger.error("%s" % error_str)


def handle_httperror(http_error):
    sys.stderr.write(getattr(http_error, "reason",
                             "No reason found in the HttpError"))
    sys.stderr.write('\n')
    try:
        output = gzip_handler(http_error)
    except:
        output = "incomplete response from server, gzip decode error"
    print_256(output)
    return output


class AuthenticationError(Exception):
    pass


class AuthorizationError(Exception):
    pass


logger = log('INFO')


def request_opener(req, opener):
    try:
        con = opener.open(req)
        return con
    except HTTPError as http_error:
        output = handle_httperror(http_error)
        if http_error.msg.lower() == "unauthorized" or http_error.code == 401:
            raise AuthenticationError("Authentication", http_error)
        if http_error.code == 403:
            raise AuthorizationError(output, http_error)
        if sdk_debug == True:
            if http_error.code != 404:
                logger.exception("http_error while opening requesst")
                traceback.print_exc()


def call_opener(opener, server, csrf_token, url, count=0, return_stream=False):
    req = Request(server + url)
    if not return_stream:
        req.add_header('Accept-encoding', 'gzip')
    csrf_token_server = get_csrf_token(server, opener)
    req.add_header('X-CSRFToken', csrf_token_server.encode('utf-8'))
    req.add_header('REFERER', server.encode('utf-8'))
    return request_opener(req, opener)


def try_except(func):
    def wrapper(*args, **kwargs):
        output = None
        try:
            output = func(*args, **kwargs)
        except Exception as e:
            traceback.print_exc()
        return output
    return wrapper


def shell_function_old(shell, fn):
    """ Bind the shell created for all the functions """
    def new_functin(*args, **kwargs):
        time_profiling = shell._time_profile and getattr(fn, '_time_profile', True)
        try:
            actual_fn = None
            is_base = getattr(fn, 'is_base', False)
            if time_profiling:
                start_time = time.time()
                shell.logger.info("[TIME PROFILE] Running %s . . . " % fn.__name__)
            if is_base or inspect.isfunction(fn):
                return fn(shell, *args, **kwargs)
            actual_fn = getattr(fn, args[0], False)
            return actual_fn(shell, *args[1:], **kwargs)
        finally:
            if time_profiling:
                end_time = time.time()
                shell.logger.info("[TIME PROFILE] %s took %0.2f seconds" % (fn.__name__, end_time - start_time))
    return new_functin


def shell_function(shell, fn):
    """ Bind the shell created for all the functions """

    class new_func:
        fun = fn

        def __call__(self, *args, **kwargs):
            try:
                time_profiling = shell._time_profile and getattr(fn, '_time_profile', True)
                actual_fn = None
                is_base = getattr(fn, 'is_base', False)
                if time_profiling:
                    start_time = time.time()
                    shell.logger.info("[TIME PROFILE] Running %s . . . " % fn.__name__)
                if is_base or inspect.isfunction(fn):
                    return fn(shell, *args, **kwargs)
                actual_fn = getattr(fn, args[0], False)
                return actual_fn(shell, *args[1:], **kwargs)
            finally:
                if time_profiling:
                    end_time = time.time()
                    shell.logger.info("[TIME PROFILE] %s took %0.2f seconds" % (fn.__name__, end_time - start_time))
        def __getattr__(self, arg):
            if arg == 'help':
                return getattr(fn, arg)
            try:
                resulting_function = getattr(fn, arg)
                return functools.partial(resulting_function, shell)
            except AttributeError:
                raise
        def unpartialed(self, arg):
            return getattr(fn, arg)
    return new_func()

class Shell(object):
    """Shell class to provide basic functionality like login and api"""
    host = None
    def __init__(self, server=None, shell_methods={}, tracer=None):
        self.headers = {}
        self.cookies = None
        # self.server = 'http://localhost:8000'
        # TODO: This is stupid. Remove this later
        self.set_defnitions(shell_methods)
        self.logged_in = False
        self._session = None
        self.server = server
        self.diff_rec = diff_rec
        self.tracer = tracer
        try:
            # Setting all the default preferences
            self._dataset = None
            self._model = None
            self._file_type = None
            self._stage = None
            self._session = None
            self._probe_directory = None
            self._last_result = None
            self._history_file = os.path.expanduser("~/.gnana-sdk-history")

            # We will poll in 1, 2, 3, 5, 8, 13, 20, 20, 20 . . . . intervals
            # This is the maximum allowed interval
            self._poll_interval = 20
            self._retries = 5
            self._tz_preference = 'tenant'
            self._tenant = None
            self._logger_level = 'INFO'
            self._time_profile = False
            self._show_url = False
            self._show_post_data = False
            self._wait_for_pool = True
            self._sandbox = None
            self.entered_sandbox = None
            self.timezone('tenant')
            self.register_exit()
            self.logger = log(self._logger_level)
            self.is_async = False
        #             shellDateUtils.timezone(self, 'tenant')
        except OSError as e:
            if e.errno == 17:
                print(e)
                return None
            else:
                raise

    def register_exit(self):
        atexit.register(self.logout)

    def __repr__(self):
        if self._server and self._session:
            return "Connected to url: %s tenant: %s" % (self._server, self._tenant)
        else:
            return "Disconnected to %s" % self._server

    def logout(self):
        if self._session:
            print('logging out shell')
            print(self.api('/account/logout', None))
            self._session = None
        else:
            return
    
    def save_profile(shell, fn):

        default_folder = os.path.expanduser("~") + "/.gsh"
        if not os.path.exists(default_folder):
            os.makedirs(default_folder)
        file = "%s/%s" % (default_folder, fn)

        try:
            with open(file, 'w') as f:
            
                f.write("%s.%s(%s,%s)\n" % ("shell", "show_urls", shell._show_url, shell._show_post_data))
                f.write("%s.%s(%s)\n" % ("shell", "probe_directory", shell._probe_directory))
                f.write("%s.%s(%s)\n" % (
                "shell", "poll_interval", shell._session.poll_interval if shell._session else shell.poll_interval))
                f.write(
                    "%s.%s(%s)\n" % ("shell", "retries", shell._session.retries if shell._session else shell._retries))
                f.write("%s.%s(%s)\n" % ("shell", "logger_level", logging._checkLevel(shell._logger_level)))
                f.write("%s.%s(%s)\n" % ("shell", "time_profile", shell._time_profile))
                f.write("%s.%s(%s)\n" % ("shell", "wait_for_pool", shell._session.wait_for_pool if shell._session else shell._wait_for_pool))

                print ("Profile %s is created with current preferences." % file)
        except IOError:
            logger.error("Unable to open file: %s" % file)
        except Exception as e:
            logger.error("Unable to write file: %s due to %s" % (file, str(e)))

    def change_password(self, old_password=None, new_password=None):
        """
        Change password.  If old and new passwords are not provided, they will
        be prompted for.
        """
        if not old_password:
            old_password = getpass.getpass("Gnana Password: ")
        if not new_password:
            new_password = getpass.getpass("New Password: ")
            conf_password = getpass.getpass("Confirm Password: ")
            if (new_password != conf_password):
                logger.warn("Passwords do not match")
                return
        data = {'oldpassword': old_password,
                    'newpassword': new_password,
                    'confirmpassword': new_password}
        return self.api("/account/change_password", data)

    def logger_level(self, l):
        self._logger_level = l
        self.logger.setLevel(l)

    def time_profile(shell, t):
        if t and not shell.logger.isEnabledFor(logging.INFO):
            shell.logger.error('Time profile is enabled, however it will not show due to loglevel.')
            shell.logger.error('Please set the loglevel to at least INFO, using logger_level.')
        shell._time_profile = t

    def time_me(self, f, *args, **kvargs):
        try:
            print(f.__name__)
        except:
            pass
        t1 = time.time()
        res = f(*args, **kvargs)
        t2 = time.time()
        print("took {0:,.6f} seconds.".format(t2-t1))
        return res
    
    def last_result(self):
        return self._last_result

    def login(self, username, tenant_name=None,  authorization_token=None, sandbox=None):
        password = getpass.getpass("password?")
        return self.login_internal(username, password, tenant_name, authorization_token=authorization_token, sandbox=sandbox)

    def url_encode_params(self, params={}):
        if not isinstance(params, dict):
            raise Exception("You must pass in a dictionary!")
        params_list = []
        for k, v in six.iteritems(params):
            if isinstance(v, list):
                params_list.extend([(k, x) for x in v])
            else:
                params_list.append((k, v))
        return urlencode(params_list)

    def massage_url_params(self, url):
        if not self._sandbox:
            return url
        parse_result = urlparse(url)
        all_url_params_ = dict((k, v if len(v) > 1 else v[0]) for k, v in six.iteritems(
            parse_qs(parse_result.query)))
        all_url_params = all_url_params_.copy()
        # for k, v in six.iteritems(all_url_params_):
        #     if v == 'None':
        #         all_url_params[k] = ''
        #         continue
        #     all_url_params[k] = v
        url_ = parse_result.path
        # update the params with default params
        if self._sandbox:
            all_url_params.update({'sandbox': self._sandbox})
        if all_url_params:
            url_ += '?' + self.url_encode_params(all_url_params)
        return url_

    def api(self, url, data, return_trace_id=False, return_as='json', is_async=False):
        try:
            if self._show_url:
                logger.info("[URL PROFILE] Making %s request for %s" %
                            ('GET' if data is None else 'POST', url))
            # adding sandbox info in the url
            url = self.massage_url_params(url)
            # if api is post add sandbox to post parameters
            if data:
                if isinstance(data, dict):
                    if self._sandbox and 'sandbox' not in list(data.keys()):
                        data['sandbox'] = self._sandbox
                # post data could be json string
                try:
                    if isinstance(data, str):
                        unpacked_data = json.loads(data)
                        if isinstance(unpacked_data, dict):
                            if self._sandbox and 'sandbox' not in unpacked_data:
                                unpacked_data['sandbox'] = self._sandbox
                        packed_data = json.dumps(unpacked_data)
                        data = packed_data
                except:
                    pass
            if not self._session:
                print("Please login to make any api calls")
                return False

            if data is not None:
                if return_as != 'json':
                    raise Exception('POST calls are always returned as json')
                try:
                    self._last_result = self._session.postData(url=url,
                                                               data=data,
                                                               return_trace_id=return_trace_id,
                                                               is_async=self.is_async or is_async)
                except Exception as e:
                    print(e, url)
                    raise

            else:
                if return_as == 'json':
                    self._last_result = self._session.getJSONResult(
                        url, return_trace_id=return_trace_id, is_async=is_async)
                elif return_as == 'csv':
                    logger.info(
                        'CSV Result is not saved in the last_result. Please be aware of this limitation')
                    return self._session.getCSVResult(url, return_stream=False)
                elif return_as == 'csv_stream':
                    logger.info(
                        'CSV Result is not saved in the last_result. Please be aware of this limitation')
                    self._last_result = self._session.getCSVResult(url, return_stream=True)
        except Exception as e:
            raise
        if self._session.version_mismatch == True:
            self._session.version_mismatch = False
            self.update_defnitions()
        return self._last_result

    def set_defnitions(self, shell_methods):
        my_locals = {}
        for name, fn in shell_methods.items():
            shell_fn = shell_function(self, fn)
            setattr(self, name, shell_fn)
            my_locals[name] = shell_fn
        my_locals['this_shell'] = self
        self._locals = my_locals

    def update_defnitions(self, url=None, sdk_path=None):
        if not url:
            url = self._server
        connector = SDKConnection(url)
        if not sdk_path:
            sdk_path = connector._fetch_sdk_package()
        methods = connector._fetch_methods(sdk_path)
        self.set_defnitions(methods)
        self.version = connector.version
        self._session.version = connector.version

    def reload_sdk(self):
        return self.update_defnitions()

    def remove_authorization_token(self):
        try:
            self._session.opener._access_token = None
            self._session.opener._sandbox = None
            self._sandbox = None
        except:
            pass

    def switch_to(self, new_tenant, return_shell=False, authorization_token=None, sandbox=None):
        # remove authorization token as it is different for different tenant
        self.remove_authorization_token()
        shell = self
        res = self.api('/account/switch', json.dumps(new_tenant))
        self.set_authorization_token(authorization_token, sandbox)
        if isinstance(res, dict) and res.get('success', False):
            if new_tenant == 'SELF':
                new_tenant = self.api('/account/whoAmI', None)['username']

            if '@' in new_tenant:
                self._tenant = new_tenant.split('@')[1]
            else:
                self._tenant = new_tenant
            # TODO
            if self._tz_preference == 'tenant':
                timezone = res.get('timezone', None)
                logger.info("Trying to switch to new tenant timezone")
                if timezone is None:
                    shell.timezone('tenant', period_info=True)
                else:
                    self._tz_name = timezone
                if return_shell:
                    return shell
            logger.info("Switched to: %s", new_tenant)
        else:
            logger.warn("Failed to switch")
            print(res)

    def set_authorization_token(self, authorization_token, sandbox):
        self._session.opener._access_token = authorization_token
        self._session.opener._sandbox = sandbox
        self._sandbox = sandbox

    def get_authorization_token(self):
        try:
            token = self._session.opener._access_token
        except:
            token = None
        return token

    def me(self):
        """
        Returns the details of the logged in user
        """
        if getattr(self, '_session', None):
            logger.info("Connected to the server at: %s " %
                        self._session.server)
        else:
            logger.info("No logged in session. Login first")
            return  # In case of not connected, why to print unnecessary stuffs
        #
        #         logger.debug("Retry count          : %s" % self._retries)
        #         logger.debug("Polling interval     : %s" % self._poll_interval)
        #         logger.debug("Time zone preference : %s" % self._tz_preference)
        #         logger.debug("Time Profiling       : %s" % self._time_profile)
        #         logger.debug("Show API URLs        : %s %s" % (self._show_url,
        #                                                  "[POST DATA = %s]" % self._show_post_data if self._show_url else ""))
        res = self.api('/account/whoAmI', None)
        if res:
            res[u'server'] = self._session.server
            res['timezone'] = res.get('timezone', self.tenant('get_config',
                                                              category='forecast', config_name='timezone'))
            logger.info("Current timezone     : %s" % res['timezone'])
        return res

    def get_server(self):
        return self._server

    def set_server(self, server):
        if server:
            self._server = server
        else:
            self._server = os.environ.get(
                'GNANA_SERVER', 'https://app.aviso.com')

    server = property(get_server, set_server)

    def server_info(self, server=None):

        if server is None:
            # to retrieve the server name
            if not self._session:
                logger.info('Unconnected Session')
        else:
            if self._session and self.server != server:
                logger.info(
                    'Found an existing login session.  Missing logout???')
                self.logout()
                self._session = None
            self.server = server

        return self.server

    def signin(self, key=None, username=None, tenant_name=None,  authorization_token=None, sandbox=None):
        if not key:
            pub_key_file = os.path.expanduser('~/.ssh/id_rsa.pub')
        else:
            pub_key_file = key + ".pub"

        if not username:
            username = os.environ.get('GNANA_USER',  None)

        if not username:
            username = os.environ.get('USERNAME',  None)

        if not username:
            try:
                with open(pub_key_file) as f:
                    username = f.read().split()[2]
            except:
                logger.warn(
                    "Unable to get the default username from the id_rsa.pub file")
                return

        logger.info("signing in as %s" % username)
        return self.login_internal(username, self.signature(key), tenant_name, authorization_token=authorization_token, sandbox=sandbox)

    def login_internal(self, username, password, tenant_name=None, authorization_token=None, sandbox=None, server=None):
        """
        Login using the username and password supplied.  If a password is
        not supplied, it will be prompted for.
        """
        if server and self.server != server:
            logger.warning(
                "ERROR: Use server_info to switch before calling login.")
            raise Exception('Invalid switch during login')
        try:

            self._session = GnackerLib(username, password, self.server, tracer=self.tracer,
                                       # check_loggly=self._check_loggly,
                                       # retries=self._retries,
                                       # wait_for_pool=self._wait_for_pool
                                       tenant_name=tenant_name,
                                       this_shell=self
                                       )
            self._tz_name = self._session._timezone
            if tenant_name:
                self._tenant = tenant_name
            else:
                self._tenant = username.split('@', 1)[1]
            self._session.version = self.version
        except GnackerLibError as ex:
            message = ex.message
            if isinstance(message, bytes):
                if six.PY3:
                    message = str(message, 'utf-8')
                else:
                    message = str(message)
            lock_message = "if account is locked, please run `shell.create_password_for_created_user()` to unlock"
            if message.find('locked') != -1 :
                message = lock_message
            e = Exception(message)
            e.__suppress_context__ = True
            raise e
        # setting a passthorugh for administrative login
        self._session.opener._access_token = 'pass_through'
        ProbeHandler.shell = self
        self._session.ProbeHandler = ProbeHandler
        self.set_authorization_token(authorization_token, sandbox)
        #self._session.poll_interval = self._poll_interval
        #self._session.wait_for_pool = self._wait_for_pool
        return self

    def signature(self, filename=None):
        '''
        Sign the current time with the private key provided.  If no private key is provided
        it is assumed to be present in ~/.ssh/id_rsa
        '''
        file_to_use = filename or os.path.expanduser('~/.ssh/id_rsa')
        with open(file_to_use) as f:
            return self.signature_from_key_data(f.read())

    def signature_from_key_data(self, data):
        message = str(time.time())
        key = RSA.importKey(data)
        h = SHA.new()
        message = message.encode('utf-8')
        h.update(message)
        signer = PKCS1_PSS.new(key)
        signature = base64.b64encode(signer.sign(h))
        return "SIGNATURE::%s::%s" % (message.decode(), signature.decode())

    def enter(self, name=None, dataset=None, file_type=None, stage=None,
              model=None, sandbox=None):
        """
        Setup the default values to be used for all functinal commands, such as
        dataset, result.

        If a generic name is provided, it will be treated as dataset name if one is
        not present.  If a dataset is already present it will be treated as stage.
        If both are present, an error is reported.

        You can set other defaults by passing appropriate keyword arguments.

        Prompt will be changed to show the defaults. For of the prompt is as
        follows:

            ``g/dataset/stage/f=file_type/m=model>``

        """
        shell = self
        if (not (name or dataset or file_type or stage or model or sandbox)):
            print ("Enter Where?")
            return

        if (name):
            if (not shell._dataset):
                shell._dataset = name
            elif(not shell.entered_sandbox):
                # considering sandbox and stage as same
                shell.entered_sandbox = name
                shell._stage = name
            elif (not shell._stage):
                shell._stage = name
            else:
                logger.warn("Already entered dataset and stage")

        if (not dataset is None):
            if dataset:
                shell._dataset = dataset
            else:
                shell._dataset = None

        if (not file_type is None):
            if file_type:
                shell._file_type = file_type
            else:
                shell._file_type = None

        if (not stage is None):
            if stage:
                shell._stage = stage
            else:
                shell._stage = None

        if sandbox is not None:
            if sandbox:
                shell.entered_sandbox = sandbox
            else:
                shell._sandbox = None

        if (not model is None):
            if model:
                shell._model = model
            else:
                shell._model = None

        sys.ps1 = self.compute_prompt()
        print(sys.ps1)

    def leave(self, name=None):
        """
        Remove the defaults

        Specify which default to remove specifically.  If nothing is specified
        last default in the list (you can see in the prompt) is removed.

        If all or * is specified as name, all defaults are removed.
        """
        shell = self
        if name:
            if name == 'all' or name == '*':
                shell._dataset = None
                shell._model = None
                shell._stage = None
                shell._file_type = None
                shell.entered_sandbox = None
            elif name == 'dataset':
                shell._dataset = None
            elif name == 'model':
                shell._model = None
            elif name == 'stage':
                shell._stage = None
            elif name == 'file_type':
                shell._file_type = None
            elif name == 'sandbox':
                shell.entered_sandbox = None
            else:
                logger.warn("Didn't know such a place existed")
        else:
            if (shell._file_type):
                shell._file_type = None
            elif (shell._model):
                shell._model = None
            elif (shell._stage):
                shell._stage = None
            elif (shell._dataset):
                shell._dataset = None
            elif (shell.entered_sandbox):
                shell.entered_sandbox = None
            else:
                logger.debug("Nothing to leave :-( Broke Completely.")

        sys.ps1 = self.compute_prompt()
        print(sys.ps1)

    def compute_prompt(self):
        shell = self
        e = []
        e.append('g')
        if shell._dataset:
            e.append('/')
            e.append(shell._dataset)
        if shell._stage or shell.entered_sandbox:
            e.append('/')
            if not shell._dataset:
                e.append('sandbox=')
            if shell._stage:
                e.append(shell._stage)
            elif shell.entered_sandbox:
                e.append(shell.entered_sandbox)
        if shell._file_type:
            e.append('/f=')
            e.append(shell._file_type)
        if shell._model:
            e.append('/m=')
            e.append(shell._model)
        e.append('> ')
        return "".join(e)

    def confirm(self, prompt, kwargs):
        if 'confirm' in kwargs:
            # This is to support automated scripts
            if not kwargs['confirm']:
                print ("Confirm is not true.")
                return False
            else:
                print (
                    "Confirm is passed as argument. Proceed to the desired operation.")
                return True
        else:
            # Manual confirmation
            print (prompt)
            confirmation = raw_input("Are you sure yes/no? ")
            if confirmation.lower() != 'yes':
                print ("Aborting. Please enter 'yes' to proceed")
                return False
            else:
                print ("Confirmed, proceeding.")
                return True

    def retries(self, retries):
        shell = self
        """
        Number of times to retry connection errors.  Only connection errors (URLError) are
        retried.  HTTPError is not retired at this time. Some of them might be
        eligible for retries.
        """
        retries = int(retries)
        shell._retries = retries
        if shell._session:
            shell._session.retries = retries

    def show_urls(self, show_no_show, post_data=False):
        shell = self
        if show_no_show and not shell.logger.isEnabledFor(logging.INFO):
            shell.logger.error(
                'Config is enabled, however current log level will not show the URLs. Use logger_level() to change it.')
        shell._show_url = show_no_show
        shell._show_post_data = post_data

    def poll_interval(self, interval):
        shell = self
        """
        Set the interval at which to check for response from the server. Default poll
        interval is 3 seconds.  If you are running shorter tasks, reducing the interval
        will help in reducing the wait times.  However, higher polling will waste
        computing resources, especially if multiple threads are running.
        """
        interval = float(interval)
        shell._poll_interval = interval
        if shell._session:
            shell._session.poll_interval = interval

    def create_user(self, username, details):
        """
        example details = {"roles":["user","gnacker","administrator"],
          "email":"ranga@aviso.com",
          "linked_account":"",
          "user_role":"ceo",
          "name":"ranga",
          "retain_roles":["user","gnacker","administrator"],
          "is_customer":false}
        """
        return self.api("/tenant/%s/user/%s?action=create"% (self._tenant, username), details)
    def create_password_for_created_user(self):
        url = self.server_info()
        username = raw_input("username:???")
        if url:
            session = requests.session()
            session.post("/".join([url, 'account', 'forgot_pwd']),
                         {'username': username})
            validation_url = raw_input("email sent to user from server"
                                    ". Enter the exact url specified in ")
            session.get(validation_url.replace('administrative.', ""))
            newpassword = getpass.getpass('password: ')
            confirmpassword = getpass.getpass('confirm password: ')
            output = session.post("/".join([url, "account", "setpassword"]), {
                                  "username": username, "newpassword": newpassword, "confirmpassword": confirmpassword})
            print(output)
            return output.text
        else:
            return 'please set url'

    @contextmanager
    def get_async(self):
        self.is_async = True
        yield self
        self.is_async = False


class ProbeHandler(threading.Thread):
    """
    When a probe is detected, this class is invoked automatically.
    When a Gnacker Session is created, we attach this handler to the session
    """

    def __init__(self, probeid):
        self.probeid = probeid
        self.after = None
        self.stopped = False
        super(ProbeHandler, self).__init__()
        self.start()

    def run(self):
        logger.debug("Starting the probe data collection for %s" %
                     self.probeid)
        self.shell._last_probe = self.probeid
        if (self.shell._probe_directory):
            filename = os.path.join(self.shell._probe_directory,
                                    self.probeid)
        else:
            filename = None
        while not self.stopped:
            time.sleep(1)
            self.after = tail_probe(self.shell, self.probeid,
                                    self.after, filename=filename)

    def stop_now(self):
        self.stopped = True


class SDKError(Exception):
    pass

class SDKDownloadError(SDKError):
    pass

class ZipError(SDKError):
    pass

class SDKConnection(object):
    """Connection class to connect to a service and pull the sdk functions from it"""
    tmp_file_path = '/tmp/avisosdk'

    def _get_latest_sdk_version(self):
        """get the version of sdk from server"""
        response = requests.get(self.url + '/sdk/version')
        if response.status_code == 200:
            return response.headers.get('SDK_VERSION', NOT_DEFINED)
        else:
            return None

    def _fetch_sdk_package(self):
        """fetch sdk package from server as a zip file"""
        try:
            already_exists = False
            if sdk_debug:
                url = os.path.join(self.url, "sdk/latest")
                response = requests.get(url, stream=True)
                header = response.headers['content-disposition']
                filename = re.search(
                    r'filename="(?P<filename>.*)"', header).groups()[0]
                self.version = response.headers.get('SDK_VERSION', NOT_DEFINED)
            else:
                self.version = self._get_latest_sdk_version()
                filename = self.version + '.zip'
                url = os.path.join(self.url, 'static', filename)
                if os.path.isfile(os.path.join(self.tmp_file_path, filename)) and not self.use_different_name:
                    already_exists = True
                else:
                    response = requests.get(url, stream=True)
                if self.use_different_name :
                    filename = self.version + "_" + str(uuid.uuid4()) + ".zip"
                    logger.info('using %s name for sdk path', filename)
            if not os.path.isdir(self.tmp_file_path):
                os.makedirs(self.tmp_file_path)
            fullname = os.path.join(self.tmp_file_path, filename)
            if not already_exists:
                with open(fullname, 'wb') as fp:
                    for chunk in response.iter_content(chunk_size=128):
                        fp.write(chunk)
            return fullname
        except Exception as e:
            raise SDKDownloadError("not able to download shell " + str(e))

    def _fetch_methods(self, fname):
        try:
            importer = zipimport.zipimporter(fname)
            sys.meta_path.append(importer)
            package_exists = True
            try:
                package_name = json.loads(importer.get_data('__package__'))
                modules = json.loads(importer.get_data('%s/meta.txt' % package_name))
            except:
                self.version = NOT_DEFINED
                package_exists = False
                modules = json.loads(importer.get_data('meta.txt'))
                pass
            methods = {}
            for module in modules:
                try:
                    if package_exists:
                        module_name = "%s.%s.sdk.shell" % (package_name, module)
                        methods.update(getattr(__import__(module_name), module).sdk.shell.shell_methods)
                    else:
                        module_name = "%s.sdk.shell" % module
                        methods.update(__import__(module_name).sdk.shell.shell_methods)
                except Exception as e:
                    logger.error("Error while injecting SDK %s" % str(e))
                    raise e
            return methods
        except zipimport.ZipImportError as e:
            raise ZipError("not able to inject sdk to shell. zipimport error!!! %s" % e)
            try:
                os.remove(fname)
            except:
                pass

    def _inject_sdk(self, methods, tracer):
        shell = Shell(self.url, methods, tracer=tracer)
        shell.tracer = tracer
        return shell

    def __init__(self, url, sdk_path=None, use_different_name=False):
        self.url = url
        self.loaded_apps = []
        self.sdk_path = sdk_path
        self.version = None
        self.use_different_name = use_different_name

    def setup(self, tracer):
        if not self.sdk_path or self.use_different_name:
            sdk_gzip = self._fetch_sdk_package()
        else:
            self.version = NOT_DEFINED
            sdk_gzip = self.sdk_path
        methods = self._fetch_methods(sdk_gzip)
        self.shell = self._inject_sdk(methods, tracer=tracer)
        self.shell.version = self.version


def connect_sdk(url, sdk_path=None, tracer=None):
    """Methood to initialize an sdk per service"""
    retry = 8
    exception = SDKError()
    use_different_name = False
    while retry:
        try:
            connection = SDKConnection(url, sdk_path, use_different_name)
            connection.setup(tracer=tracer)
            return connection.shell
        except (ZipError, EOFError, EnvironmentError) as e:
            logger.warning("sdk import error happened %s", e)
            if sdk_debug:
                raise e
            else:
                use_different_name = True
                exception = e
        except SDKDownloadError as e:
            exception = e
        finally:
            sleep(2)
            retry = retry - 1
            if retry == 0:
                raise exception
