import requests
import re



def get_csrf_token(form):
    token = re.search("value='(.*)'", form)
    csrf_token = token.group(1)
    return csrf_token

url = "http://localhost:8000"

login_url = '/account/login'

csrf_url = '/csrfform'

jar = requests.cookies.RequestsCookieJar()

csrf_req = requests.get(url+csrf_url, cookies=jar)

new_cookies = csrf_req.cookies

csrf_token = get_csrf_token(csrf_req.text)

headers = {'X-CSRFToken': csrf_token,
                               'REFERER': url+login_url}

inputs = {'username':'ratanraj@administrative.domain','password':'password123'}

req_post = requests.post(url+login_url, data=inputs,headers=headers,cookies=new_cookies)

response = req_post.json()
if response['success']:
    tenant = requests.get(url+'/tenant', headers=headers, cookies=req_post.cookies)
    print(tenant.text)
