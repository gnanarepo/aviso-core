import urllib
import re
import requests

def get_csrf_token(server):
    data = requests.get(server + "/csrfform")
    response = data.text
    token = re.search("value='(.*)'", response)
    csrf_token = token.group(1)
    return csrf_token


server = 'http://localhost:8000'

session = requests.Session()

csrf_token = get_csrf_token(server)
headers = {'X-CSRFToken': csrf_token,
                       'REFERER': server, 'User-Agent':'Gnana SDK/1.0'}

session.headers.update(headers)

req = session.post(server + "/account/login",
                      data={'username': 'ratanraj@administrative.domain',
                                        'password': 'password123', 'csrfmiddlewaretoken':csrf_token})


print(f'req = {req.text}')

r = session.get(f'{server}/tenant')
print(f'response = {r.text}')
