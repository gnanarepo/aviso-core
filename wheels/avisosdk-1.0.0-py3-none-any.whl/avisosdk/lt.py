from threading import Thread, currentThread
from avisosdk import connect_sdk
import time
# from gnanasdk.shell_cmds.shellMiscUtils import safe_str
import traceback


def safe_str(my_str):
    try:
        if isinstance(my_str, unicode):
            return my_str.encode('utf-8')
        elif isinstance(my_str, basestring):
            return my_str.decode('utf-8').encode('utf-8')
        else:
            return str(my_str)
    except Exception as e:
        logger.error("string conversion failed! %s" % (e))
        print(traceback.print_exc())
        return my_str

lt_jobs = {}
if 'lt_jobs' not in __builtins__:
    __builtins__['lt_jobs'] = lt_jobs
if 'lt_last_jobs' not in __builtins__:
    __builtins__['lt_last_jobs'] = []
    
    

class LightThread(Thread):
    ''' Start a thread and update information about self in the jobs variable j passed as arguments.
    All variables passed as globals in g are set as local variables available inside the code passed in as lines. 
    arg is set as a local variable lt_args.  lt_result and lt_progress are added into local variables as
    pointers into the jobs environment variable j
    '''
    def __init__(self, lines, args, j, g, fn=None, category=None):
        if lines and fn:
            raise Exception("Can't use both lines and fn at the same time")
        if not lines and not fn:
            raise Exception("Need either lines or a function")
        sh = connect_sdk(category)
        self._jobs = j
        # Get all the locals, but change the shell functions
        self._locals = g.copy()
        self._locals.update(sh._locals)
        # Update the lt_result and lt_args special variables
        self._locals['lt_result'] = {}
        self._locals['lt_args'] = args
        if fn:
            self._locals['lt_fn'] = fn
            self._lines = ["lt_result['res'] = lt_fn(lt_args)"]
        else:
            self._lines = lines
        # Save the shell so that we can call logout at the end
        self._shell = sh
        # Support progress updates
        self._progress = []
        self._locals['lt_progress'] = self._progress
        self._category = category
        Thread.__init__(self)

    def run(self):
        job_data = {'done':False,
                    'result':None,
                    'args': self._locals['lt_args'],
                    'output':[],
                    'category': self._category,
                    'progress':self._progress}
        self._jobs[self.ident] = job_data
        # Sleep half a second to make sure everything starts first
        time.sleep(0.5)
        try:
            exec(str("".join(self._lines)),self._locals)
        except:
            import sys
            job_data['error'] = sys.exc_info()
            traceback.print_exc()
        else:
            job_data['result'] = self._locals['lt_result']
        finally:
            job_data['done'] = True
            job_data['output'] = "".join([safe_str(x) for x in job_data['output']])
            self._shell.logout()

def lt_map(fn, values, category=None, progress=None, auto_clear=True):
    # Start the threads
    threads = []
    for arg in values:
        threads.append(LightThread(None, arg, lt_jobs, globals(), fn=fn, category=category))
        threads[-1].start()

    # Wait for all threads to start
    time.sleep(1)
    jobs = []
    for t in threads:
        jobs.append(lt_jobs[t.ident])

    # Wait until complete
    iter_count = 0
    while True:
        for x in jobs:
            if not x['done']:
                break
        else:
            break
        if progress:
            progress(jobs, iter_count)
        time.sleep(1)
        iter_count += 1

    # Collect the results
    result = []
    exc_info = []
    failures = False
    for j in jobs:
        exc_info.append(j.get('error', None))
        if exc_info[-1]:
            failures = True
            result.append(None)
        else:
            result.append(j['result']['res'])

    # Remove tall the threads from lt_jobs to conserver memory
    if auto_clear:
        for t in threads:
            del lt_jobs[t.ident]

    # Raise an exception on failures.  Otherwise return the result
    if failures:
        raise LTException(exc_info, result)

    return result

class LTException(Exception):
    def __init__(self, errors, results):
        self.errors = errors
        self.results = results

if not 'lt_map' in __builtins__:
    __builtins__['lt_map'] = lt_map

class ThreadPrinter:
    def __init__(self, normal_out):
        self.normal_out = normal_out

    def write(self, value, *args, **kwargs):
        t = currentThread().ident
        if t in lt_jobs:
            lt_jobs[t]['output'].append(value)
        else:
            self.normal_out.write(value, *args, **kwargs)

    def __getattr__(self, item):
        if item == 'write':
            return self.write
        return getattr(self.normal_out, item)
