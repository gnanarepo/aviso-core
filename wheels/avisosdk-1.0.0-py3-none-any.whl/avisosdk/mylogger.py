import os
LOGGING = {

    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "default": {
            "format": "[PID] %(asctime)s - %(levelname)s - %(message)s",
            "datefmt": "%Y-%b-%d %H:%M:%S"
        }
    },

    "handlers": {
        "console": {
            "class": "logging.StreamHandler",
            "level": "DEBUG",
            "formatter": "default",
            "stream": "ext://sys.stdout"
        }
    },

    "loggers": {
        "": {
            "level": "DEBUG",
            "handlers": ["console"]
        }
    }
}
ANSI_COLOR_RED = "\x1b[31m"
ANSI_COLOR_YELLOW = "\x1b[33m"
ANSI_COLOR_GREEN = "\x1b[32m"
ANSI_COLOR_MAGENTA = "\x1b[35m"
ANSI_COLOR_NORMAL = "\x1b[0m"


def add_coloring_to_emit_ansi(fn):
    # add methods we need to the class

    def new(*args):
        levelno = args[1].levelno
        if(levelno >= 50):
            color = ANSI_COLOR_RED
        elif(levelno >= 40):
            color = ANSI_COLOR_RED
        elif(levelno >= 30):
            color = ANSI_COLOR_YELLOW
        elif(levelno >= 20):
            color = ANSI_COLOR_GREEN
        elif(levelno >= 10):
            color = ANSI_COLOR_MAGENTA
        else:
            color = ANSI_COLOR_NORMAL
        args[1].msg = "%s%s%s" % (color, args[1].msg, ANSI_COLOR_NORMAL)
        return fn(*args)
    return new

import logging
from logging.config import dictConfig
if os.environ.get('mode', 'development') == 'development':
    logging.StreamHandler.emit = add_coloring_to_emit_ansi(logging.StreamHandler.emit)



def log(l):
    logger = logging.getLogger()
    dictConfig(LOGGING)
    logger.setLevel(l)
    return logger
