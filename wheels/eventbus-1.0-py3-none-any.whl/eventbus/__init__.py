import json
import time
import os
import signal
try:
    from urllib.parse import urlsplit
except ImportError:
    from urlparse import urlsplit

from redis.client import Redis

REDIS_URL = os.environ.get('REDIS_URL','redis://localhost:6379')
EVENTBUS_REDIS_URL = os.environ.get('EVENTBUS_REDIS_URL',REDIS_URL)

parsed = urlsplit(EVENTBUS_REDIS_URL)

shall_i_stop = False


def inturrept_handler(*args, **kwargs):
    print('hahah')
    global shall_i_stop
    shall_i_stop = True


class EventBusProvider:

    def publish(self, event, payload):
        raise NotImplementedError

    def get_next_event(self):
        raise NotImplementedError


class RedisProvider(EventBusProvider):

    def __init__(self):
        self.client = Redis(host=parsed.hostname, port=parsed.port, db=parsed.path.strip('/') ,password=parsed.password)

    def publish(self, event, payload):
        self.client.lpush(event, payload)

    def get_next_event(self, event):
        x = self.client.rpop(event)
        if x is not None:
            return json.loads(x)
        return None


class EventBus(object):
    providers = {
        "RedisProvider": RedisProvider
    }

    subscriptions = []

    def __init__(self, provider='RedisProvider'):
        self.provider = self.providers[provider]()

    def publish(self, event, **params):
        event_payload = {
            'eventname': event,
            'params': params,
        }
        self.provider.publish(event, json.dumps(event_payload))

    def subscribe(self, event, callback):
        subscription = {
            "event": event,
            "callback": callback
        }
        self.subscriptions.append(subscription)

    def get_next_event(self, event):
        return self.provider.get_next_event(event)


class SubscriptionDaemon(object):

    def __init__(self, event_bus):
        self.event_bus = event_bus

    def add_subscription(self, event, callback):
        self.event_bus.subscribe(event, callback)

    def run(self):
        signal.signal(signal.SIGINT, inturrept_handler)
        while not shall_i_stop:
            for subscription in self.event_bus.subscriptions:
                event = self.event_bus.get_next_event(subscription['event'])
                if event is not None:
                    subscription['callback'](**event)


if __name__ == '__main__':
    bus = EventBus('RedisProvider')
    bus.publish("SampleEvent", name='test', amount=1000)
    d = SubscriptionDaemon(bus)

    def printall(*args, **kwargs):
        print(args)
        print(kwargs)

    d.add_subscription('SampleEvent', printall)
    d.run()
