import logging

from aviso.ssoUtils import findIdP
from aviso.utils.mailUtils import send_mail2
from aviso.domainmodel.app import User as AppUser
from aviso.framework import LoginUserContext, NewSecContext
from aviso.settings import sec_context

logger = logging.getLogger(__name__)

class User(object):
    """
    A standalone Python class replacing the Django AbstractUser.
    Since the original implementation raised an exception on save,
    this serves mostly as a placeholder for structure.
    """

    def __init__(self, **kwargs):
        self.myid = kwargs.get('myid', None)
        self.pk = self.myid

    def save(self, *args, **kwargs):
        raise Exception("Trying to save data to legacy user model which is not supported!!")


class Pk(object):
    """
    Helper class to mimic Primary Key behavior for serialization.
    """

    def __init__(self, val):
        self.val = val

    def value_to_string(self, obj):
        return self.val


class GnanaUser(object):
    ''' 
    This class acts as a wrapper/adapter for the User object.
    Refactored to remove Django dependencies while keeping business logic.
    '''

    def __init__(self, user):
        # Map attributes from the AppUser object
        self.is_active = not getattr(user, 'is_disabled', False)
        self.is_superuser = False
        self.username = getattr(user, 'username', '')
        self.email = getattr(user, 'email', '')

        # Safe extraction of domain
        if self.username and '@' in self.username:
            self.domain = self.username.rsplit('@', 1)[1]
        else:
            self.domain = 'unknown'

        self.valid_ips = getattr(user, 'valid_ips', [])
        self.bson_id = getattr(user, 'id', None)
        self.user_timeout = getattr(user, 'user_timeout', None)
        self.user_role_label = getattr(user, 'user_role_label', None)

        valid_devices_dict = getattr(user, 'valid_devices', {})
        self.valid_devices = set(valid_devices_dict.keys()) if valid_devices_dict else set()

        # Initialize last_login (often needed by save logic)
        self.last_login = getattr(user, 'last_login', None)

    @property
    def pk(self):
        """Property to mimic Django PK access"""
        return Pk(str(self.bson_id) + '@' + self.domain)

    def save(self, update_fields=None):
        """
        Saves user login details and handles 'Welcome' emails.
        'update_fields' is kept in signature for compatibility but unused.
        """
        tenant_added = False
        try:
            # Check if context name is available
            dummy = sec_context.name
        except AttributeError:
            # Set context if missing
            sec_context.set_context(None, self.domain, self.domain)
            tenant_added = True

        try:
            u = AppUser.getUserByLogin(self.username)
            tenant_name = self.username.split('@')[1] if '@' in self.username else ''

            if not u.last_login:
                # First time login logic
                if not findIdP(tenant_name):
                    send_mail2('welcome_mail_from_kv.txt',
                               "Aviso <notifications@aviso.com>", [u.email],
                               reply_to='Aviso Support <support@aviso.com>',
                               is_html=True,
                               name=u.username)
                else:
                    u.is_second_login = True
            else:
                # Subsequent login logic
                if getattr(u, 'is_second_login', False) and findIdP(tenant_name):
                    u.is_second_login = False
                    send_mail2('welcome_mail_from_kv.txt',
                               "Aviso <notifications@aviso.com>", [u.email],
                               reply_to='Aviso Support <support@aviso.com>',
                               is_html=True,
                               name=u.username)

            # Sync the wrapper's last_login to the AppUser object
            u.last_login = self.last_login
            u.save()
        finally:
            if tenant_added:
                sec_context.reset_context()

    def is_authenticated(self):
        return True

    @property
    def roles(self):
        """
        Retrieves user roles based on the current security context.
        """
        current_context = sec_context.peek_context()
        # current_context structure: (user_name, name, login_tenant, login_user, switch_type, ...)

        if current_context[4] == 'user':
            context_to_use = NewSecContext(current_context[0], current_context[1], current_context[2])
        else:
            context_to_use = LoginUserContext(self.username)

        with context_to_use:
            # Construct full username for lookup
            full_username = "%s@%s" % (sec_context.user_name, sec_context.name)
            u = AppUser.getUserByLogin(full_username)

            # Add all-users role to every logged in user
            user_roles = getattr(u, 'roles', [])
            # Convert list/dict keys to set for union operation
            all_roles = set(user_roles) | {'all-users'}
            return all_roles

    def has_module_perms(self, module):
        ''' AvisoView base class will take care of permissions '''
        return True

    def has_perm(self, permission):
        ''' Stub for permission checks '''
        return True

    # Custom Methods (Non-Standard)
    def set_last_login(self, device, ip, user_agent):
        with LoginUserContext():
            u = AppUser.getUserByLogin(self.username)
            u.set_last_login(device, ip, user_agent)
            u.save()