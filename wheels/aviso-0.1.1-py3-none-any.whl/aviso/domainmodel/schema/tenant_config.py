"""
Contains the schema for tenant data
"""

# ---- date format section ---- #
from copy import deepcopy
from aviso.settings import sec_context

deprecated_float_dates = {
    'display_name': 'Using Depricated Dates',
    'description': ' TO BE DOCUMENTED BY DS-TEAM/RAVI B',
    'known_children': {
        'enable': {
            'type': 'boolean',
            'display_name': 'Is Enabled'
        }
    }
}

date_format = {
    'display_name': 'Date Format',
    'description': 'Date formars in the datasets',
    'known_children': {
        'deprecated_float_dates': deprecated_float_dates
    }
}

# ---- csv data section ---- #

static_field_list = {
    'display_name': 'static fields',
    'type': 'list',
    'value_schema': {
        'type': 'string',
        'display_name': 'Fields Names',
    }
}

dynamic_field_list = {
    'display_name': 'static fields',
    'type': 'list',
    'value_schema': {
        'type': 'string',
        'display_name': 'Fields Names',
    }
}

index_field_sets = {
    'display_name': 'index fields',
    'type': 'list',
    'value_schema': {
        'type': 'string',
        'display_name': 'Fields Names',
    }
}

field_ddl_def = {
    'display_name': 'fields',
    'type': 'map',
    'allow_unknown_children': True,
    'value_schema': {
        'type': 'map',
        'known_children': {
            'type': {
                'type': 'string',
                'display_name': 'Data types name'
            },
            'return_individual': {
                'type': 'boolean',
                'display_name': 'Return Individual'
            }
        },
        'display_name': 'Fields Names',
    }
}

unique_fields_list = {
    'display_name': 'unique fields',
    'type': 'list',
    'value_schema': {
        'type': 'string',
        'display_name': 'Fields Names',
    }
}

csv_data = {
    'display_name': 'CSV Types',
    'description': 'Metadata for CSV Data stored in caches etc',
    'known_children': {
        'epf_cache': None,
        'fcst_cache': None,
        'fm_data': None,
        'dtfo_cache': None,
        'forecast_drilldown': None,
        'forecast_targets': None,
        'reports_drilldown': None,
        'algorithm_params': None,
        'dlf_config': None

    },
    'value_schema': {
        'display_name': 'CSV data Fields',
        'known_children': {
            'static_fields': static_field_list,
            'dynamic_fields': dynamic_field_list,
            'indexes': index_field_sets,
            'fields': field_ddl_def,
            'unique_fields': unique_fields_list,
            'versioned': {
                'type': 'boolean',
                'display_name': 'Is Versioned'
            },
            'quarter_enabled': {
                'type': 'boolean',
                'display_name': 'Is Versioned'
            },
            'quarter_field': {
                'type': 'string',
                'display_name': "Quarter field"
            },
            'postgres_enabled': {
                'display_name': 'POSTGRES enabled??',
                'type': 'boolean'
            }
        }
    },
    'allow_unknown_children': True
}

# Dataset config

file_type_list = {
    'display_name': 'file types of a dataset',
    'type': 'list',
    'value_schema': {
        'type': 'any',
        'display_name': 'filetypes config'
        }
}
stages = {
    'display_name': 'stages of a dataset',
    'type': 'any'
}

dataset_models_list = {
    'display_name': 'models for a dataset',
    'type': 'list',
    'value_schema': {
        'type': 'any',
        'display_name': 'list of model types'
        }
}


datasets = {
    'display_name': 'Datasets',
    'description': 'Metadata for Different (source and UIP ) datasets ',
    'known_children': {
        'Opportunity': None,
        'OppDS': None,
        'Account': None,
        'OppliDS': None,
        'User': None,
        'UserRole': None,
        'AvisoTaskDS': None,
        'CustomUserDS': None,
        'Opp_tmp': None,
        'Lead': None,
        'LeadRepo': None,
        'Contact': None,
        'OpportunityContactRole': None,
        'RecordType': None,
        'Account_ms': None,
        'Opportunity_ms': None,
        'User_ms': None,
        'OpportunitySplit': None,
        'OpportunitySplitType': None,
        'EmailDS': None,
        'TeamDS': None,
        'UserDS': None,
        'scenarios': None
        },
    'value_schema':{
        'display_name': 'Dataset Fields',
        'known_children': {
            'name':{
                'display_name': 'Dataset Name',
                'type': 'string'
                },
            'ds_type': {
                'display_name': 'Dataset type either SOURCE or UIP',
                'type': 'string',
                'allow_none': True
                },
            'params': {
                'display_name': 'Params of the Dataset',
                'type': 'map',
                'allow_unknown_children': True,
                'value_schema': {
                    'display_name': 'params children',
                    'type': 'any'
                    }
                },
            'models': dataset_models_list,
            'fields': {
                'display_name': 'Datset fields',
                'type': 'map',
                'allow_unknown_children': True,
                'value_schema': {
                    'display_name': 'fields children',
                    'type': 'any'
                    }
                },
            'maps': {
                'display_name': 'Datset maps',
                'type': 'map',
                'allow_unknown_children': True,
                'value_schema': {
                    'display_name': 'map children',
                    'type': 'any'
                    }
                },
            'filetypes': file_type_list,
            'data_source': {
                'display_name': 'source of data from which we need to read data',
                'type': 'string'
                },
            'sandbox_to_use': {
                'display_name': 'name of the sandbox of data_source to read data instead of data_source uip',
                'type': 'string',
                'allow_none': True
                },
            'discrepancy': {
                'display_name': 'Discrepancy Detection Fields',
                'type': 'map',
                'allow_unknown_children': True,
                'value_schema': {
                    'display_name': 'Discrepancy children',
                    'type': 'any'
                    }
                },
            'stages': stages
            }
        },
    'allow_unknown_children': True
    }

# ---- target_spec ---- #
drilldowns_list = {
    'display_name': 'drilldowns of a target_spec',
    'type': 'list',
    'value_schema': {
        'type': 'any',
        'display_name': 'drilldowns config'
        }
}

target_spec = {
    'display_name': 'TargetSpec',
    'description': 'Metadata for target_specs ',
    'known_children': {
        'bookings': None,
        'pipelinesnapshots': None,
        'fwd_bookings': None,
        'winratios': None,
        'pipelinesnapshots_rtfm': None,
        'bookings_rtfm': None,
        'bookings': None,
        },
    'value_schema':{
        'display_name': 'target_spec Fields',
        'known_children': {
            'name':{
                'display_name': 'target_spec Name',
                'type': 'string'
                },
            'models': {
                'display_name': 'Models of the target_spec',
                'type': 'map',
                'allow_unknown_children': True,
                'value_schema': {
                    'display_name': 'models children',
                    'type': 'any'
                    }
                },
            'drilldowns': drilldowns_list,
            'report_spec': {
                'display_name': 'report_spec fields',
                'type': 'map',
                'allow_unknown_children': True,
                'value_schema': {
                    'display_name': 'report_spec children',
                    'type': 'any'
                    }
                },
            'keys': {
                'display_name': 'Target_spec keys',
                'type': 'map',
                'allow_unknown_children': True,
                'value_schema': {
                    'display_name': 'keys children',
                    'type': 'any'
                    }
                },
            'module': {
                'display_name': 'source of data from which we need to read data',
                'type': 'string',
                'allow_none': True
                },
            'task_v2': {
                'display_name': 'task_v2 value for the target_spec',
                'type': 'any',
                },
            'sandbox_to_use': {
                'display_name': 'name of the sandbox',
                'type': 'string'
                }
            }
        },
    'allow_unknown_children': True
    }

# ---- security section ---- #

invitation_validity = {
    'type': 'number',
    'display_name': 'Invitation Validity (Hours)',
    'description': 'How many hours each invitation to login is valid for',
    'maximum_value': 7 * 24,
    'minimum_value': 24
}

factors = {
    'known_children': {
        'hard_limit': {
            'display_name': 'Hard LIMIT',
            'type': 'number',
        },
        'soft_limit': {
            'display_name': 'Soft LIMIT',
            'type': 'number'
        },
        'maximum_entries': {
            'display_name': 'Maximum Entries',
            'type': 'number'
        }
    }
}

device_factors = deepcopy(factors)
device_factors.update({'display_name': 'Device Factors'})
ip_factors = deepcopy(factors)
ip_factors.update({'display_name': 'IP Factors'})

ip_list = {

}
allowed_ip_list = ip_list.copy()
allowed_ip_list.update({
    'display_name': 'Allowed IP List',
    'description': 'IPs from which access is allowed for this tenant.  Use the CIRD format',
    'type': 'list',
    'value_schema': {
        'type': 'string',
        'display_name': 'ip address'
    }
}
)
denied_ip_list = ip_list.copy()
denied_ip_list.update({
    'display_name': 'Denied IP List',
    'description': 'IPs from which access is denied for this tenant.  Use the ' +
                   'CIRD format. Denied takes more precedence than allowed list.'
})

max_login_attempts = {
    'type': 'number',
    'minimum_value': 2,
    'maximum_value': 10,
    'display_name': 'Max Invalid Attempts',
    'description': 'Maximum number of invalid attempts before account is locked. ' +
                   ' Note that user can unlock himself using forgot password flow'
}

allowed_domains = {
    'type': 'list',
    'display_name': 'Allowed Domains',
    'description': 'Which email domains are allowed for this client',
    'value_schema': {
        'type': 'string',
        'display_name': 'Domain Name or Email address'
    }
}

sso_match = {
    'type': 'string',
    'display_name': 'Matching field for SSO',
    'description': 'Incoming principals through SAML are matched using the field specified in this settings on the Aviso side.',
    'allowed_values': ['username', 'email']
}

security = {
    'display_name': 'Security Settings',
    'description': 'Settings related to login and IP Validation',
    'known_children': {
        'invitation_validity': invitation_validity,
        'ip_factors': ip_factors,
        'device_factors': device_factors,
        'max_login_attempts': max_login_attempts,
        'allowed_ip_list': allowed_ip_list,
        'denied_ip_list': denied_ip_list,
        'allowed_domains': allowed_domains,
        'match_sso_user': sso_match,
        'sso_grace_time': {
            'type': 'number',
            'display_name': 'SSO Grace Time'
        },
        'no_account_message': {
            'type': 'string',
            'display_name': 'Message on No Match'
        },
        'session_timeout': {
            'type': 'number',
            'display_name': 'Session Timeout (minutes)',
            'minimum_value': 30,
            'maximum_value': 300
        }
    }
}

# ---- forecast section ---- #

forecast = {
    'type': 'any',
    'display_name': 'FORECAST'
}

# ---- tenant_health section ---- #


def string_or_dict(val):
    if isinstance(val, (str, dict)):
        return []
    return ['Unexpected type for the health check value']


tenanthealth = {
    'display_name': 'Tenant Health',
    'known_children': {
        'checks': {
            'display_name': 'Health Checks',
            'type': 'map',
            'allow_unknown_children': True,
            'value_schema': {
                'display_name': 'Is Applicable',
                'type': 'any',
                'custom_validation': string_or_dict
            }
        }
    }
}

# ---- Receivers and reps ---- #


def check_mail(mail_address_list):
    """ Validates that all email addresses ends with @aviso.com as a safety
    precaution. Also value itself has to be a string or a list of strings. If
    the value is a string, it is split using ',' for validating individual emails. """
    if not isinstance(mail_address_list, (str, list, tuple, set)):
        return ['Email list must be an actual list or a string']
    if isinstance(mail_address_list, str):
        mail_address_list = mail_address_list.split(',')

    errors = []
    for mail_address in mail_address_list:
        mail_address = mail_address.strip()
        if mail_address and not mail_address.endswith('@aviso.com') and not mail_address.endswith('@aviso.moxtra.com') and not mail_address.endswith('@aviso.moxo.com'):
            errors.append('email address %s done not end with @aviso.com' % mail_address)
    return errors

email_list = {
    'type': 'any',
    'display_name': 'Email List',
    'custom_validation': check_mail
}


def validate_email(mail_address_list):
    """ Validates that all email addresses ends with tenant name or aviso.com or any of allowed domains as a safety
    precaution. Also value itself has to be a string or a list of strings. If
    the value is a string, it is split using ',' for validating individual emails. """
    if not isinstance(mail_address_list, (str, list, tuple, set)):
        return ['Email list must be an actual list or a string']
    errors = []
    print ("tested")
    for mail_address in mail_address_list:
        mail_address = mail_address.strip()
        if mail_address:
            allowed_ = sec_context.details.get_config('security', 'allowed_domains', []) + [sec_context.name, 'aviso.com']
            valid = False
            for allowed_domain in allowed_:
                if mail_address.endswith('@%s' % allowed_domain):
                    valid = True
            if not valid:
                errors.append('email address %s should end with any of %s' % (mail_address, allowed_))
    return errors

customer_email_list = {
    'type': 'any',
    'display_name': 'cusotmer email List',
    'custom_validation': validate_email
    }


receivers = {
    'display_name': 'Emails',
    'known_children': {
        'endpoint_changes': None,
        'dataset_changes': None,
    },
    'allow_unknown_children': True,
    'value_schema': email_list
}

reps = {
    'display_name': 'Representatives',
    'type': 'map',
    'known_children': {
        'dd': None,
        'ds': None,
        'cs': None,
        'access_report': customer_email_list
    },
    'allow_unknown_children': True,
    'value_schema': email_list
}

interaction = {
    'display_name': 'Interactions config',
    'type': 'map',
    'allow_unknown_children': True,
    'value_schema': {
        'display_name': 'User details',
        'type': 'any'
    }
}

delete_detection = {
    'display_name': 'delete_detection_emails',
    'type': 'map',
    'known_children': {
        'email_ids': None,
        'access_report': customer_email_list
    },
    'allow_unknown_children': True,
    'value_schema': email_list
}

endpoint_reset = {
    'display_name': 'endpoint_reset_emails',
    'type': 'map',
    'known_children': {
        'email_ids': None,
        'access_report': customer_email_list
    },
    'allow_unknown_children': True,
    'value_schema': email_list
}


# ---- results section ---- #

results = {
    'display_name': 'Result Management',
    'known_children': {
        'retention_days': {
            'type': 'number',
            'display_name': 'Retention Days'
        }
    }
}

# ---- Chipotle molecules ---- #

atom_schema = {
    'display_name': 'Atom',
    'known_children': {
        'name': {
            'display_name': 'Name of the Atom',
            'type': 'string'
        },
        'type': {
            'display_name': 'Type of the Atom',
            'type': 'string'
        }
    },
    'allow_unknown_children': True,
    'mandatory_children': ['name'],
    'value_schema': {
        'display_name': 'Any Atom Value',
        'type': 'any',
    }
}

molecule = {
    'display_name': 'Molecules (RTFM)',
    'known_children': {
        'rtfm': None
    },
    'value_schema': {
        'display_name': 'Molecule',
        'type': 'list',
        'minimum_size': 1,
        'value_schema': atom_schema
    }
}

# ---- datapipeline section ---- #

datapipeline = {
    'allow_unknown_children': False,
    'display_name': 'Data Pipeline Configuration',
    'value_schema': {
        'display_name': 'Data Pipeline Configuration',
        'known_children': {
            'daily_refresh': {
                'type': 'boolean',
                'display_name': 'Daily Refresh'
            },
            'hourly_refresh': {
                'type': 'boolean',
                'display_name': 'Hourly Refresh'
            },
            'pre_refresh': {
                'display_name': 'PRE REFRESH',
                'type': 'boolean'
            },
            'time_limit': {
                'display_name': 'Time Limit (mins)',
                'type': 'number'
            },
            'ui_items': {
                'display_name': 'UI Items',
                'type': 'any'
            },
            'uipcopy': {
                'display_name': 'UIP Copy',
                'type': 'boolean'
            },
            'run_eom': {
                'display_name': 'Run EOM',
                'type': 'boolean'
            },
            'reports': {
                'display_name': 'Reports',
                'type': 'any'
            },
            'results_validation': {
                'display_name': 'Results Validation',
                'type': 'any'
            },
            'instance_type': {
                'display_name': 'Instance Type',
                'type': 'string'
            },
            'etl_list': {
                'type': 'map',
                'display_name': "Datasets to be ETl'ed",
                'allow_unknown_children': True,
                'value_schema': {
                    'type': 'map',
                    'display_name': 'Dataset Name',
                    'known_children': {
                        'partial_dd': {
                            'type': 'boolean',
                            'display_name': 'Partial Delete Detection'
                        },
                        'full_dd': {
                            'type': 'boolean',
                            'display_name': 'Full Delete Detection'
                        },
                        'bypassdd': {
                            'type': 'boolean',
                            'display_name': 'Bypass Delete Detection'
                        },
                        'file_type': {
                            'type': 'string',
                            'display_name': 'File Type'
                        },
                        'exec_rank': {
                            'type': 'number',
                            'display_name': 'Exec Rank'
                        },
                        'etl_interval': {
                            'type': 'number',
                            'display_name': 'ETL Interval'
                        }
                    },
                }
            },
            'prepare': {
                'display_name': 'Prepare',
                'known_children': {
                    'v2': {
                        'type': 'string',
                        'display_name': 'V2 datasets',
                        # TODO: Add custom validation to validate the datasets provided
                        'description': 'List of v2 datasets comma separated'
                    },
                    'v1': {
                        'type': 'string',
                        'display_name': 'V1 datasets (deprecated)',
                        'description': 'List of v1 datasets comma separated'
                    }
                }
            },
            'result_validation': {
                'display_name': 'Result Validation',
                'type': 'boolean'
            },
            'uip_copy': {
                'display_name': 'UIP Copy',
                'type': 'boolean'
            },
            'has_rtfm': {
                'display_name': 'HAS RTFM',
                'type': 'boolean'
            },
            'trend_alert': {
                'type': 'map',
                'display_name': 'Trend Alert',
                'value_schema': {
                    'display_name': 'Model Trend Alert',
                    'type': 'map',
                },
                'known_children': {
                    'ep': {
                        'display_name': 'Existing Pipe Forecast',
                        'type': 'map',
                        'known_children': {
                            'boq_fc_threshold': None,
                            'daily_fc_threshold': None,
                            'entire_q_fc_threshold': None
                        },
                        'value_schema': {
                            'display_name': 'Threshold Value',
                            'type': 'number',
                        }
                    },
                    'np': {
                        'display_name': 'New Pipe Forecast',
                        'type': 'map',
                        'known_children': {
                            'boq_fc_threshold': None,
                            'daily_fc_threshold': None,
                            'entire_q_fc_threshold': None
                        },
                        'value_schema': {
                            'display_name': 'Threshold Value',
                            'type': 'number',
                        }
                    },
                },
            }
        },
    },
    'known_children': {
        'daily': None,
        'hourly': None,
        'weekly': None,
        'predaily': None,
        'monthly': None
    }
}

# ---- report generation section ---- #

reportgeneration = {
    'allow_unknown_children': False,
    'display_name': 'Report Generation',
    'description': 'Reports to be executed by the report_tools script',
    'value_schema': {
        'display_name': 'Reports and days configuration',
        'allow_list': True,
        'known_children': {
            'days': {
                'type': 'list',
                'display_name': 'Weekdays allowed',
                'description': 'Pick the days in which these reports are to be executed',
                'value_schema': {
                    'type': 'string',
                    'display_name': 'Day of the week',
                    'allowed_values': ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN']
                },
                'minimum_size': 1,
                'maximum_size': 7
            },
            'ui_items': {
                'display_name': 'UI Items',
                'type': 'any'
            },
            'reports': {
                'type': 'list',
                'display_name': 'Reports to be executed',
                'description': 'See https://avisoplan.atlassian.net/wiki/display/AD/List+of+reports ' +
                               'for details on each report',
                'value_schema': {
                    'type': 'string',
                    'display_name': 'Report name',
                    'allowed_values': [
                        'bookings_monthly',
                        'FM_rollup',
                        'bookings_cache',
                        'deals_cache',
                        'dtfo_cache',
                        'bookings_monthly_rtfm',
                        'bookings',
                        'all_caches',
                        'next_quarter_bookings',
                        'next_quarter_bookings2',
                        'bookings_rtfm',
                    ]
                },
                'minimum_size': 0,
            },
            'run_eom': {
                'type': 'boolean',
                'display_name': 'Run End of Month Scripts',
                'description': 'Should we run end of the month scripts.  Enable only for monthly'
            }
        }
    },
    'known_children': {
        'daily': None,
        'hourly': None,
        'weekly': None,
        'monthly': None
    }
}

# --------- timezoneoffset ------ #

timezoneoffset = {
    'type': 'number',
    'display_name': "Time zone Offset",
    'description': "Time zone information "
}
# ---- microservices section ---- #

# ETL DATA SERVICE SCHEMA #
etl_data_service = {
    'display_name': "ETL DATA SERVICE",
    'description': 'etl data microservice which provide all the etl services for analytics-server',
    'known_children': {
        'host': {
            'display_name': "Host",
            'description': 'Host url for communicating with etl-data-service',
            'type': 'string'
        },
        'source_tenant': {
            'display_name': 'source tenant',
            'description': 'Name of the source tenant inside etl-data-service for which this tenant is subscribed\
                             to get the etl data',
            'type': 'string'
        },
        'sandbox_to_use': {
            'display_name': 'sandbox to use',
            'description': 'Name of the sandbox of a source tenant from which etl data is pulled for this tenant',
            'type': 'string',
            'allow_none': True
        }
    }
}

# GBM SERVICE SCHEMA #
gbm_service = {
    'display_name': "GBM SERVICE",
    'description': 'gbm microservice which provide all the result generation services for analytics-server',
    'known_children': {
        'host': {
            'display_name': "Host",
            'description': 'Host url for communicating with gbm-service',
            'type': 'string'
        },
        'source_tenant': {
            'display_name': 'source tenant',
            'description': 'Name of the source tenant inside gbm-service for which this tenant is subscribed\
                             to get the results data',
            'type': 'string'
        },
        'sandbox_to_use': {
            'display_name': 'sandbox to use',
            'description': 'Name of the sandbox of a source tenant from which results data is pulled for this tenant',
            'type': 'string'
        },
        'authorization_token':{
            'display_name': 'Authorization token',
            'description': 'authorization token for internal communication between services',
            'type': 'string'
        }
    }
}

# GBM SERVICE SCHEMA #
forecast_app_service = {
    'display_name': "FORECAST APP SERVICE",
    'description': 'Forecacst App microservice which provide all the csv and mail activity services',
    'known_children': {
        'host': {
            'display_name': "Host",
            'description': 'Host url for communicating with forecast-app-service',
            'type': 'string'
        },
        'source_tenant': {
            'display_name': 'source tenant',
            'description': 'Name of the source tenant inside forecast app -service for which this tenant is subscribed\
                             to get the results data',
            'type': 'string'
        },
        'sandbox_to_use': {
            'display_name': 'sandbox to use',
            'description': 'Name of the sandbox of a source tenant from which results data is pulled for this tenant',
            'type': 'string'
        },
        'authorization_token':{
            'display_name': 'Authorization token',
            'description': 'authorization token for internal communication between services',
            'type': 'string'
        }
    }
}


services_info = {
    'display_name': "Microservices info",
    'description': 'Information related to microservices for which this tenant is subscribed to',
    'known_children': {
        'etl_data_service': etl_data_service,
        'gbm_service': gbm_service,
        'forecast_app_service': forecast_app_service
    }
}

allowed_dd = {
            'display_name': 'Allowed_dd',
            'allow_unknown_children': True,
            'value_schema': {
                'type': 'any',
                'display_name': 'Dataset name/value '
            },
            'description': 'This is used to auto approve the the percentage of deleted found.'
        }

# ---- Final Schema ---- #

schema = {
    'display_name': 'Tenant Configuration',
    'description': 'Tenant configuration follows the schema here.  Everytime set_config is called, it is validated based on this schema.',
    'known_children': {
        'dateformat': date_format,
        'security': security,
        'forecast': forecast,
        'tenant_health': tenanthealth,
        'csv_data': csv_data,
        'receivers': receivers,
        'reps': reps,
        'interaction': interaction,
        'delete_detection':delete_detection,
        'endpoint_reset':endpoint_reset,
        'results': results,
        'molecule': molecule,
        'datapipeline': datapipeline,
        'reports_generation': reportgeneration,
        'timezoneoffset': timezoneoffset,
        'datasets': datasets,
        'microservices_info': services_info,
        'allowed_dd': allowed_dd,
        'status':{
            'type': 'any',
            'display_name': 'Tenant_satus'
        },
        'target_spec': target_spec,
        'es': {
            'allow_unknown_children': True,
            'display_name': 'Reporting',
            'value_schema': {
                'type': 'any',
                'display_name': 'ES Keys'
            }
        },
        'etl_prepare': {
            'type': 'any',
            'display_name': 'ETL Prepare'
        },
        'compressed_model': {
            'type': 'any',
            'display_name': 'compressed model'
        },
        'writeback': {
            'type': 'any',
            'display_name': 'Writeback'
        },
        'wsdl_location':{
            'allow_unknown_children': True,
            'display_name': 'wsdl_location',
            'known_children': {
                'enabled': {
                    'type': 'boolean',
                    'display_name': "Enabled"
                }
            },
            'value_schema': {
                'type': 'any',
                'display_name': 'wsdl_location components'
            }
        },
        'new_category': {
            'display_name': 'New Category',
            'known_children': {
                'new_config': {
                    'type': 'any',
                    'display_name': 'New Config'
                }
            },
            'description': 'This is used for testing the API.  Hence adding it into schema.  Please do not use this as a back door to add new entries.'
        },
        'pushetl': {
            'allow_unknown_children': True,
            'display_name': 'PushEtl',
            'known_children': {
                'enabled': {
                    'type': 'boolean',
                    'display_name': "Enabled"
                }
            },
            'value_schema': {
                'type': 'any',
                'display_name': 'PushEtl components'
            }
        },
        'notifications':{
            'display_name': "Notification Service",
            'type':'any'
        },
        'uip_data': {
            'display_name': 'UIP_DATA',
            'known_children': {
                'version': {
                    'type': 'any',
                    'display_name': "Version"
                }
            }
        }
    }
}

if __name__ == '__main__':
    from pyschema.core import Record as Schema
    s = Schema(schema)
    s.realize()
