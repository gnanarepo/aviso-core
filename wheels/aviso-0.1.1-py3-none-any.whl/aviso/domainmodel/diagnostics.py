'''
This package contains domain objects related to logging and other
diagnostic storage

Created on Feb 18, 2013

@author: eswar
'''
from aviso.domainmodel import Model, ModelError
import pytz


class ProbeRecord(Model):
    """ Stores the result of a probe operations into Mongo DB """
    tenant_aware = True
    collection_name = "probe"
    index_list = {
            'probeid': {},
            'message_key': {},
            'trace':{},
            'timestamp': {
                'expireAfterSeconds': 1800
            }
        }
    version = 1.0
    kind = 'domainmodel.probe.Probe'

    def __init__(self, attrs=None):
        self.probeid = None
        self.message = None
        self.location = None
        self.trace = None
        self.params = {}
        self.timestamp = None
        super(ProbeRecord, self).__init__(attrs)

    def encode(self, attrs):
        if not self.probeid:
            raise ModelError("probeid is mandatory")
        attrs['probeid'] = self.probeid
        attrs['params'] = self.params
        attrs['message'] = self.message
        attrs['location'] = self.location
        attrs['trace'] = self.trace
        attrs['timestamp'] = self.timestamp
        if(self.message_key):
            attrs['message_key'] = self.message_key
        return

    def decode(self, attrs):
        self.probeid = attrs['probeid']
        self.params = attrs['params']
        self.message = attrs['message']
        self.location = attrs['location']
        self.trace = attrs['trace']
        self.timestamp = pytz.utc.localize(attrs['timestamp'])
        self.message_key = attrs.get('message_key',None)
        return