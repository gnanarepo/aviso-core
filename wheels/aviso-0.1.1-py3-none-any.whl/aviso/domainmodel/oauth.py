# This file will contain the model and parameters required for
# OAuth for tenants that have writeback enabled.
import re
import logging
from aviso.domainmodel import Model
from aviso.settings import postgres_common_db_enabled, gnana_db2

logger = logging.getLogger('gnana.%s' % __name__)


class Oauth(Model):
    '''
    Oauth model to get the session id from sfdc
    '''
    collection_name = "oauth"
    tenant_aware = False
    kind = "domainmodel.oauth.oauth"
    version = 1
    index_list = {'tenant_name': {'unique': True}}
    postgres = bool(postgres_common_db_enabled)

    def __init__(self, attrs=None):
        self.tenant_name = None
        super(Oauth, self).__init__(attrs)

    def encode(self, attrs):
        attrs['tenant_name'] = self.tenant_name.lower()
        attrs['customer_secret'] = self.customer_secret
        attrs['customer_key'] = self.customer_key
        attrs['callbackurl'] = self.callbackurl
        attrs['authorize_url'] = self.authorize_url
        attrs['token_url'] = self.token_url
        return super(Oauth, self).encode(attrs)

    def decode(self, attrs):
        self.tenant_name = attrs.get('tenant_name').lower()
        self.customer_secret = attrs.get('customer_secret')
        self.customer_key = attrs.get('customer_key')
        self.callbackurl = attrs.get('callbackurl')
        self.authorize_url = attrs.get('authorize_url')
        self.token_url = attrs.get('token_url')
        super(Oauth, self).decode(attrs)

    def tenantName(self):
        return self.tenant_name

    @classmethod
    def getByTenantName(cls, name):
        try:
            return cls.getByFieldValue('tenant_name', name.lower())
        except Exception as e:
            no_relation = re.match(r"^relation .+ does not exist", str(e))
            if no_relation:
                 return None
            else:
                raise e

    @classmethod
    def create_postgres_table(self):
        table_name = str(self.getCollectionName()).replace(".", "$")
        schema = 'create table "{table_name}"(\
                  _id                       bigserial primary key,\
                  _version                  int,\
                  _kind                     varchar,\
                  last_modified_time        bigint,\
                  authorize_url             varchar,\
                  callbackurl               varchar,\
                  customer_key              varchar,\
                  customer_secret           varchar,\
                  tenant_name               varchar,\
                  token_url                 varchar\
                 )'

        return gnana_db2.postgres_table_creator(schema.format(table_name=table_name),
                                                collection_name=Oauth.getCollectionName())