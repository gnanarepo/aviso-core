# SAML SSO for tenants that have SSO enabled. The model encapsulates the Identity Provider (IdP) metadata.
import logging
from aviso.domainmodel import Model
from aviso.settings import postgres_common_db_enabled

logger = logging.getLogger('gnana.%s' % __name__)

class IdP(Model):
    ''' Encapsulates IdP metadata. Since we need this information *before* the user is authenticated, it is not stored either
    as tenant aware or part of tenant config itself. Currently, we support okta and onelogin as identity providers and we may possibly
    integrate with SFDC as well. Each tenant is likely have just one identity provider, so the metadata is keyed on tenant_name.
    '''
    collection_name = "saml_idp"
    tenant_aware = False
    kind = "domainmodel.saml_idp.IdP"
    version = 1
    index_list = {'tenant_name':{'unique': True}}
    postgres = bool(postgres_common_db_enabled)

    def __init__(self, attrs=None):
        self.tenant_name = None
        super(IdP, self).__init__(attrs)

    def encode(self, attrs):
        attrs['tenant_name'] = self.tenant_name.lower()
        attrs['idp'] = self.idp
        attrs['issuer'] = self.issuer
        attrs['name_identifier_format'] = self.name_identifier_format
        attrs['assertion_consumer_service_url'] = self.assertion_consumer_service_url
        attrs['idp_sso_target_url'] = self.idp_sso_target_url
        attrs['idp_cert'] = self.idp_cert
        return super(IdP, self).encode(attrs)

    def decode(self, attrs):
        self.tenant_name = attrs.get('tenant_name').lower()
        self.idp = attrs.get('idp')
        self.issuer = attrs.get('issuer')
        self.name_identifier_format = attrs.get('name_identifier_format')
        self.assertion_consumer_service_url = attrs.get('assertion_consumer_service_url')
        self.idp_sso_target_url = attrs.get('idp_sso_target_url')
        self.idp_cert = attrs.get('idp_cert')
        super(IdP, self).decode(attrs)
        
    def tenantName(self):
        return self.tenant_name
    
    @classmethod
    def getByTenantName(cls, name):
        return cls.getByFieldValue('tenant_name', name.lower())