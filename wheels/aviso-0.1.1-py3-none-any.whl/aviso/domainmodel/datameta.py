import pytz
import logging
import datetime


from aviso.domainmodel import Model
from aviso.domainmodel import ModelError
from aviso.utils import GnanaError
from aviso.settings import gnana_db
from aviso.settings import sec_context
from aviso.utils import update_dict
from aviso.utils.configUtils import config_pattern_expansion
from aviso.utils.dateUtils import datetime2epoch, get_a_date_time_as_float_some_how
from aviso.utils.mathUtils import excelToFloat
from aviso.utils.stringUtils import first15

logger = logging.getLogger('gnana.%s' % __name__)

old_value_delay = 10.0 / 60 / 60 / 24   # 5 seconds
ALGORITHM_PARAMS = 'algorithm_params'
default_stage = "__default__"
attrset_names = ('file_types', 'models', 'params', 'fields', 'maps', 'discrepancy')


class ModelDescription:

    """ Value object class to store the model configuration.
    """

    def __init__(self, name=None, type=None, config={}, field_map={}, record_filter={}, history_filter={}):
        self.name = name
        self.type = type
        self.config = config
        self.field_map = field_map
        self.record_filter = record_filter
        self.history_filter = history_filter

    def encode_to_save(self):
        return [
            self.name,
            self.type,
            self.config,
            self.field_map,
            self.record_filter,
            self.history_filter
        ]

    def get_as_dict(self):
        config = self.config.copy()
        algorithm_params = config.pop(ALGORITHM_PARAMS, {})

        return {
            'name': self.name,
            'type': self.type,
            'config': config,
            ALGORITHM_PARAMS: algorithm_params,
            'field_map': self.field_map,
            'record_filter': self.record_filter,
            'history_filter': self.history_filter
        }

    def apply_config(self, module_path, params):
        if module_path == 'config':
            update_dict(self.config, params)
        elif module_path == 'field_map':
            update_dict(self.field_map, params)
        elif module_path == 'record_filter':
            update_dict(self.record_filter, params)
        elif module_path == 'history_filter':
            if params == 'record_filter':
                self.history_filter = params
            elif isinstance(params, dict):
                update_dict(self.history_filter, params)
            else:
                raise GnanaError(
                    "Unable to understand the history_filter value")
        elif module_path == ALGORITHM_PARAMS:
            update_dict(self.config[ALGORITHM_PARAMS], params)
        else:
            raise GnanaError(
                "Unknwon module_path (%s) for model" % module_path)


blank_common = ModelDescription('common', 'common')


class BasicFileType:

    """
    ignore_not_tranlated - if True will ignore fields not in `field_name_translation` for UIP
    """

    def __init__(self, dataset, config):
        self.ds = dataset
        self.prefix = self.ds.params.get('general', {}).get('prefix')
        self.last_approved_time = None
        self.last_dd_time = None
        self.field_name_translation = config.pop('field_name_translation', {})
        if 'ignore_not_translated' in config:
            self.ignore_not_translated = config.pop(
                'ignore_not_translated', False)
        elif 'ignore_not_tranlated' in config:
            self.ignore_not_translated = config.pop(
                'ignore_not_tranlated', False)
        else:
            self.ignore_not_translated = False
        self.id_fields = config.pop('id_fields', [])

        # To satisfy static code checking
        self.ctr_config = {}
        self.field_name = None
        self.modified_date_field = None

        self.__dict__.update(config)
        # Fix for box.  If last_approved time is saved as epoch for whatever
        # reason convert it into datetime.
        if isinstance(self.last_approved_time, (int)):
            #self.last_approved_time = epoch2datetime(self.last_approved_time)
            from datetime import datetime
            self.last_approved_time = datetime.utcfromtimestamp(self.last_approved_time / 1000.0)
            pass
        return

    def validate_header(self, fieldnames):
        return True

    def validate_record(self, extid, record, ts):
        if(self.prefix and not extid.startswith(self.prefix)):
            return self.ds.INVALID
        return self.ds.VALID

    def get_inbox_record(self, extid, record, ts):
        raise NotImplementedError()

    def apply_inbox_record(self, uip_record, inbox_record, fld_config={}, return_rec_modified=None):
        raise NotImplementedError()

    def get_as_dict(self):
        ret = self.__dict__.copy()
        ret.pop('ds')
        return ret

    def apply_config(self, module_path, params):
        if(module_path == 'ctr_config' and
           getattr(self, 'ctr_config', None)):
            update_dict(self.ctr_config, params)
        else:
            if(isinstance(params, dict)):
                if(hasattr(self, module_path)):
                    update_dict(getattr(self, module_path), params)
                else:
                    setattr(self, module_path, params)
            else:
                setattr(self, module_path, params)


class SnapShotFileType(BasicFileType):

    def get_inbox_record(self, extid, record, ts):
        for field_name in self.id_fields:
            try:
                record[field_name] = first15(record[field_name])
            except KeyError:
                pass
        return {'extid': extid, 'when': ts, 'values': record}

    def apply_inbox_record(self, uip_record, inbox_record, fld_config={}, return_rec_modified=None):
        record_modified = False
        # Sometimes salesforce is not returning the correct history, which is effecting the current value of the record
        # Just inserting the latest value without comparing the current latest value.
        for name, value in inbox_record.values.items():
            record_modified = True
            uip_record.add_feature_value(
                inbox_record.ts, name, value, fld_config=fld_config)
        if return_rec_modified:
            return record_modified

class HistoryFileType(BasicFileType):

    def get_inbox_record(self, extid, record, ts):
        modified_date = get_a_date_time_as_float_some_how(
            record[self.modified_date_field])
        if not modified_date:
            return None
        field_name_field = getattr(self, 'field_name_field', None)
        if field_name_field:
            value_field = getattr(self, 'value_field', 'New Value')
            old_value_field = getattr(self, 'old_value_field', None)

            field_name = record[field_name_field]
            try:
                field_name = self.field_name_translation[field_name]
            except KeyError:
                if self.ignore_not_translated:
                    raise KeyError('{} field is ignored'.format(field_name))
            values = []
            values.append({
                'extid': extid,
                'when': modified_date,
                'values': {
                    field_name: record[value_field]
                }
            })

            if old_value_field is not None:
                values.append({
                    'extid': extid,
                    'when': modified_date - old_value_delay,
                    'values': {
                        field_name: record[old_value_field]
                    }
                })

            return values
        else:
            new_record = record.copy()
            new_record.pop(self.modified_date_field)
            return {'extid': extid,
                    'when': modified_date,
                    'values': new_record}

    def apply_inbox_record(self, uip_record, inbox_record, fld_config={}, return_rec_modified=None):
        for name, value in inbox_record.values.items():
            uip_record.add_feature_value(
                inbox_record.ts, name, value, fld_config=fld_config)


class UsageFileType(BasicFileType):

    def get_inbox_record(self, extid, record, ts):
        field_name_field = getattr(self, 'field_name_field', None)
        if not field_name_field:
            field_name = getattr(self, 'field_name')
            if not field_name:
                raise GnanaError(
                    'Either field_name_field or field_name is required')
        else:
            field_name = record.pop(field_name_field, None)
            if not field_name:
                raise GnanaError('No field name found in the record')

        for k in record.keys():
            val = 0
            try:
                val = float(k)
            except ValueError:
                pass

            if not val:
                record.pop(k)
            else:
                record[k] = excelToFloat(record[k])

        return {'extid': extid, 'when': ts, 'values': [field_name, record.items()]}

    def apply_inbox_record(self, uip_record, inbox_record, fld_config={}, return_rec_modified=None):
        for name, value in inbox_record.values[1]:
            uip_record.add_feature_value(name,
                                         "usage_" + inbox_record.values[0],
                                         value,
                                         fld_config=fld_config)


FileTypeTypes = {
    'snapshot': SnapShotFileType,
    'history': HistoryFileType,
    'usage': UsageFileType,
    # 'tree': None,
}

idx_list = {'extid': {},
            'when': {},
            'filename': {},
            'partition_uniqueness': {'unique': True,
                                     'sparse': True}}


class InboxEntry(Model):
    tenant_aware = True
    version = 1.0
    kind = "domainmodel.uip.InboxEntry"
    # All kinds sharing the same collection must declare all indexes for the
    # collection, since collections are checked only once
    index_list = idx_list

    def __init__(self, attrs=None):
        self.extid = None
        self.ts = None
        self.values = {}
        self.filetype = None
        super(InboxEntry, self).__init__(attrs)

    def encode(self, attrs):
        attrs['extid'] = self.extid
        attrs['when'] = self.ts
        attrs['values'] = self.values
        attrs['filetype'] = self.filetype
        return super(InboxEntry, self).encode(attrs)

    def decode(self, attrs):
        self.extid = attrs['extid']
        self.ts = attrs['when']
        if isinstance(self.ts, datetime.datetime) and not self.ts.tzinfo:
            self.ts = pytz.utc.localize(self.ts)
            # Mongo DB is returning naive date time objects.
            # This is a temporary fix.
            # LATER: Check the decode of all objects and make sure datatimes are localized
            # in the encode and not everywhere in the code.
            self.ts.tzinfo = None
        self.values = attrs['values']
        self.filetype = attrs.get('filetype')
        return super(InboxEntry, self).decode(attrs)

    update = decode


class InboxFileEntry(Model):
    tenant_aware = True
    version = 1.0
    kind = "domainmodel.uip.InboxFileEntry"
    index_list = idx_list.copy()

    def __init__(self, attrs=None):
        self.filename = None
        self.filetype = None
        self.when = None
        super(InboxFileEntry, self).__init__(attrs)

    def encode(self, attrs):
        attrs['filename'] = self.filename
        attrs['filetype'] = self.filetype
        attrs['when'] = self.when
        return super(InboxFileEntry, self).encode(attrs)

    def decode(self, attrs):
        self.filename = attrs['filename']
        self.filetype = attrs['filetype']
        self.when = attrs['when']
        return super(InboxFileEntry, self).decode(attrs)


def InboxEntryClass(dataset_name, inbox_name):
    class CustomerSpecificDatasetInboxClass(InboxEntry):
        collection_name = ".".join([dataset_name, "_uip", inbox_name])
        # We are just following patternhere.  Most likely there is no
        # customization needed for this

    return CustomerSpecificDatasetInboxClass


def InboxFileEntryClass(dataset_name, inbox_name):
    class CustomerSpecificDatasetInboxClass(InboxFileEntry):
        collection_name = ".".join([dataset_name, "_uip", inbox_name])
        # We are just following patternhere.  Most likely there is no
        # customization needed for this

    return CustomerSpecificDatasetInboxClass


class DSClass:
    """New Dataset class to support microservices architecture"""
    INVALID = 1
    VALID = 2
    PARTIAL = 3
    # --- ORM related methods ---
    def filetype(self, name):
        """get the specific file object

        Args:

                name: name of the filetype
        Return:

                object: filetype object if found in filetypes else none
        """
        if name in self.file_types:
            return self.file_types[name]
        else:
            return None

    def __init__(self, attrs=None):
        self.name = None
        self.fields = {}
        self.file_types = {}
        self.params = {'general': {}}
        self.models = {'common': blank_common}
        self.maps = {}
        self.discrepancy = {}
        self.stages = {}
        # If the attribute sets come from a requested stage,
        # the stage_ysed is set. This is transient value and is not
        # persisted into DB
        self.stage_used = None
        self.ds_type = None
        # Transient fields, no need to encode and decode
        self.id_sources = {}
        self.map_objs = {}
        self.map_version_checksum = None
        if attrs:
            self.decode(attrs)

    def remove(self):
        # remove config from tenant
        tenant = sec_context.details
        tenant.remove_config('datasets', self.name)

    def encode(self, attrs):
        """Loads the dataset object attributes to a dictionary

        Args:

                attrs: A dict
        Return:

                None
        """
        if not self.name:
            raise ModelError('Name is mandatory')

        attrs['name'] = self.name
        attrs['params'] = self.params

        attrs['fields'] = self.fields

        attrs['filetypes'] = []
        for f in self.file_types.values():
            file_type_values = f.__dict__.copy()
            lat = file_type_values.get('last_approved_time', None)
            if lat and isinstance(lat, datetime.datetime):
                utc = pytz.utc
                lat = lat.replace(tzinfo=utc)
                file_type_values['last_approved_time'] = datetime2epoch(lat)
            file_type_values.pop('ds')
            attrs['filetypes'].append(file_type_values)

        attrs['models'] = [v.get_as_dict() for v in self.models.values()]
        attrs['discrepancy'] = self.discrepancy
        attrs['maps'] = {}
        for map_name, map_dict in self.maps.items():
            attrs['maps'][map_name] = list(map_dict.items())

        # stages wont be there, only sandboxes
        attrs['stages'] = {}
        for stage_name, stage_dict in self.stages.items():
            attrs['stages'][stage_name] = stage_dict

        attrs['ds_type'] = self.ds_type

        return

    def decode(self, attrs):
        """Loads the DSClass object with the attributes avaliable from a dict

        Args:

                attrs: A dictionary with DSClass related attributes
        Return:

                None
        """
        self.name = attrs['name']
        uip_version = sec_context.details.get_config('uip_data', 'version', 1.0)
        if 'params' in attrs:
            self.params = attrs.get('params', {})
            self.params['general']['uip_version'] = uip_version

        if 'fields' in attrs:
            self.fields = attrs['fields']
        if 'filetypes' in attrs:
            for f in attrs['filetypes']:
                type_info = FileTypeTypes[f["type"]](self, f)
                self.file_types[type_info.name] = type_info

        if 'models' in attrs:
            for f in attrs.get('models', {}):
                # For backward compatibility
                f['config'][ALGORITHM_PARAMS] = f.pop(ALGORITHM_PARAMS, None)
                self.models[f['name']] = ModelDescription(**f)
        if 'discrepancy' in attrs:
            self.discrepancy = attrs['discrepancy']
        if 'maps' in attrs:
            self.maps = {}
            for map_name, map_items in attrs['maps'].items():
                self.maps[map_name] = dict(map_items)


        if 'ds_type' in attrs:
            self.ds_type = attrs['ds_type']

        return

    def get_as_map(self):
        attrs = {}
        attrs['name'] = self.name
        attrs['ds_type'] = self.ds_type

        for attr_set in attrset_names:
            attrs[attr_set] = {}

            for attr_name, attr_value in (getattr(self, attr_set, {}) or {}).items():
                # String or list.  Nothing much we can do
                if(isinstance(attr_value, str) or
                   isinstance(attr_value, list) or
                   isinstance(attr_value, dict)):
                    attrs[attr_set][attr_name] = attr_value
                elif(hasattr(attr_value, 'get_as_dict')):
                    attr_value = attr_value.get_as_dict()
                    attrs[attr_set][attr_name] = attr_value
                else:
                    logger.debug(
                        "Error in getting specific values for dataset %s[%s]" % (attr_set, attr_name))
                    raise GnanaError("String, list or get_as_dict() required")

                if(isinstance(attr_value, dict)):
                    for k, v in attr_value.items():
                        if(isinstance(v, datetime.datetime)):
                            if not v.tzinfo:
                                v = pytz.utc.localize(v)
                            attr_value[k] = datetime2epoch(v)
        return attrs

    @classmethod
    def getByName(cls, name, sandbox=None):
        try:
            if not sandbox:
                ten = sec_context.details
                attrs = ten.get_config('datasets', name)
                if not attrs:
                    return None
                return cls(attrs)
            ten = sec_context.details
            logger.warning("Trying to get the sandboxed data")
            logger.warning(f"sandbox is {sandbox}")
            attrs = ten.get_config('datasets', name, sandbox=sandbox)
            if attrs and 'datasets' in attrs:
                attrs = attrs['datasets'][name]
            if not attrs and not sandbox:
                return None
            if not attrs and sandbox:
                # probably it could be data stage
                attrs = ten.get_config('datasets', name)
            return cls(attrs)
        except Exception as e:
            logger.exception(e)
            return None

    @classmethod
    def getAllDatasets(cls, fields_to_find={}):
        ten = sec_context.details
        attrs = ten.get_config('datasets')
        if attrs:
            return attrs

    def save(self, is_partial=False, bulk_list=None, id_field=None, sandbox=None, sandbox_comment=None):
        rec = {}
        self.encode(rec)
        ten = sec_context.details
        if not sandbox_comment:
            sandbox_comment = self.name + ' new sandbox'
        if sandbox:
            ten.set_config('datasets', self.name, rec, sandbox_name=sandbox, sandbox_comment=sandbox_comment)
        else:
            ten.set_config('datasets', self.name, rec)

    @classmethod
    def getByNameAndStage(cls, name, sandbox=None, target='_data', full_config=True):
        """get the dataset object by name and stage
        Args:
                name: name of the dataset
                stage: name of the stage
                target: target name for data stage
                full_config: boolean to check config pattern expansion
        Return:

                object: dataset instance
        """
        dataset = cls.getByName(name, sandbox=sandbox)
        if not dataset:
            return dataset
        dataset.stage_used = sandbox
        # we should do this for opportunity stages only 
        if dataset.ds_type != 'uip' and sandbox:
            InboxFileEntryClassToUse = InboxFileEntryClass(name, sandbox)
            all_file_entries = gnana_db.findDocuments(
                InboxFileEntryClassToUse.getCollectionName(),
                {'_kind': InboxFileEntryClassToUse.kind})
            for x in all_file_entries:
                file_entry = InboxFileEntryClassToUse(attrs=x)
                ft_def = dataset.filetype(file_entry.filetype)
                if ft_def.last_approved_time:
                    ft_def.last_approved_time = max(ft_def.last_approved_time,
                                                    file_entry.when or datetime.datetime(1970, 1, 1))

                else:
                    ft_def.last_approved_time = file_entry.when
            dataset.InboxEntryClass = InboxEntryClass(name, sandbox)
            dataset.InboxFileEntryClass = InboxFileEntryClassToUse
        else:
            dataset.InboxEntryClass = None
            dataset.InboxFileEntryClass = None
        if full_config and dataset:
            attrs = {}
            dataset.encode(attrs)
            res = config_pattern_expansion(attrs)
            dataset_attrs = res.get('attrs', None)
            eval_errs = res.get('eval_errs', None)
            tdetails = sec_context.details
            if eval_errs:
                for key in eval_errs.keys():
                    if (key in tdetails.get_flag('save_on_error', dataset.name + '~' + sandbox, {}) or
                            key in tdetails.get_flag('save_on_error', dataset.name, {})):
                        eval_errs.pop(key)
                if eval_errs:
                    raise GnanaError(eval_errs)
            dataset.decode(dataset_attrs)
        return dataset
