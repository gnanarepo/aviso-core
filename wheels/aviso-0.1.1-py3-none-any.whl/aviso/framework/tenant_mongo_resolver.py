from dataclasses import dataclass
from urllib.parse import urlparse
import boto3, json, os, time
from logging import Formatter, getLogger
from pymongo import MongoClient, MongoReplicaSetClient

logger = getLogger('gnana.%s' % __name__)


@dataclass(frozen=True)
class MongoTenantConfig:
    mongo_url: str
    db_name: str
    replica_set: str


class TenantMongoResolver:
    _cache = {}

    def __init__(self, region="us-east-1", ttl=3600):
        self.client = boto3.client(
            "secretsmanager",
            region_name=os.environ.get("AWS_REGION", region),
        )
        self.ttl = ttl

    def _secret_name(self, tenant, cname):
        return f"aviso/mongo/{cname}/{tenant}"

    def _load_secret(self, tenant, cname):
        try:
            key = (tenant, cname)
            now = time.time()

            if key in self._cache:
                data, expiry = self._cache[key]
                if expiry > now:
                    return data

            secret_name = self._secret_name(tenant, cname)
            resp = self.client.get_secret_value(
                SecretId=secret_name
            )
            data = json.loads(resp["SecretString"])

            creds = json.loads(data.get(secret_name, {}))

            self._cache[key] = (creds, now + self.ttl)
            
            return creds
        except Exception as e:
            logger.error(f"Error loading secret for {tenant}/{cname}: {e}")
            raise
            # return {'fm_mongo_url': os.environ.get("DEFAULT_FM_MONGO_URL"),
            #         'gbm_mongo_url': os.environ.get("DEFAULT_GBM_FM_MONGO_URL"),
            #         'etl_mongo_url': os.environ.get("DEFAULT_ETL_MONGO_URL"),
            #         'replica_set': os.environ.get("DEFAULT_GBM_FM_MONGO_REPLICA_SET"),
            #         'gbm_stack': os.environ.get("DEFAULT_GBM_STACK"),
            #         'etl_stack': os.environ.get("DEFAULT_ETL_STACK")
            #         }

    def _tenant_db_name(self, tenant, cname="preprod", stack="fm", db_type="fm"):
        parts = tenant.split(".")
        # remove TLD only (last part)
        if len(parts) > 1:
            tenant_prefix = "_".join(parts[:-1])
        else:
            tenant_prefix = tenant

        
        if db_type == "fm": 
            return f"{tenant_prefix}_cache_{cname}"
        else:
            return f"{tenant_prefix}_db_{stack}"

    def resolve(self, tenant, cname="preprod", db_type="fm") -> MongoTenantConfig:
        try:
            data = self._load_secret(tenant, cname)
            replica_set = None
            if db_type == "fm":
                key = "fm_mongo_url"
                mongo_url = data.get(key)
                if not mongo_url:
                    raise RuntimeError("Mongo URL not found in secrets or env")
                
                parsed = urlparse(mongo_url)
                if parsed.path and parsed.path != "/admin":
                    db_name = parsed.path.lstrip("/")
                else:
                    db_name = self._tenant_db_name(tenant, cname=cname, db_type=db_type)
                    
            elif db_type == "gbm":
                key = "gbm_mongo_url"
                mongo_url = data.get(key)
                if not mongo_url:
                    raise RuntimeError("Mongo URL not found in secrets or env")
                
                replica_set = data.get("replica_set", os.environ.get("DEFAULT_GBM_FM_MONGO_REPLICA_SET"))
                stack = data.get("gbm_stack", os.environ.get("DEFAULT_GBM_STACK"))
                db_name = self._tenant_db_name(tenant, cname=cname, stack=stack, db_type=db_type)
            
            elif db_type == "etl":
                key = "etl_mongo_url"
                mongo_url = data.get(key)
                if not mongo_url:
                    raise RuntimeError("Mongo URL not found in secrets or env")
                
                replica_set = data.get("replica_set", os.environ.get("DEFAULT_GBM_FM_MONGO_REPLICA_SET"))
                stack = data.get("etl_stack", os.environ.get("DEFAULT_ETL_STACK"))
                db_name = self._tenant_db_name(tenant, cname=cname, stack=stack, db_type=db_type)

            
            return MongoTenantConfig(
                mongo_url=mongo_url,
                db_name=db_name,
                replica_set=replica_set,
            )
        except Exception as e:
            logger.error(f"Error resolving MongoDB config for {tenant}/{cname}: {e}")
            raise

    def ms_connection_mongo_client_db(self, tenant=None, db_type=None, cname=None):

        if not tenant:
            raise RuntimeError("TENANT_NAME not found in environment")

        resolver = TenantMongoResolver()

        # Get GBM Mongo URL (NOT client)
        cfg = resolver.resolve(
            tenant=tenant,
            db_type=db_type,
            cname=cname
        )
        if cname == "app" and cfg.replica_set:
            client = MongoReplicaSetClient(
                cfg.mongo_url,
                unicode_decode_error_handler="ignore",
                replicaSet=cfg.replica_set
                )

            db = client[cfg.db_name]
        else:
            client = MongoClient(cfg.mongo_url, unicode_decode_error_handler="ignore")
            db = client[cfg.db_name]
            
        return db