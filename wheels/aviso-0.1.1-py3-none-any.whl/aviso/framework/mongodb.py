
import time
import zlib
import base64
import logging
import pymongo
import os
from bson import BSON
from bson.objectid import ObjectId
from pymongo import MongoReplicaSetClient
from pymongo.collection import ReturnDocument
from pymongo.errors import (DocumentTooLarge)
from pymongo.read_preferences import ReadPreference

from aviso.utils import GnanaError
from aviso.framework import GnanaDB, TooManyMatches, TenantMongoResolver

logger = logging.getLogger('gnana.%s' % __name__)

def empty_criteria_modifier(criteria):
    # TODO remove until backend is optimized
#     if criteria == dict():
#         criteria = {'_id':{'$type':7}}
    return criteria

# class GnanaMongoDB(GnanaDB):
#     is_prod = False
#     sec_context = None

#     def __init__(self, db):

#         class DbSwitcher:

#             def __init__(self, parent):
#                 self.parent = parent

#             def __getattr__(self, attr):
#                 if attr is not '__getitem__':
#                     return getattr(db, attr)

#             def __getitem__(self, collection):
#                 if self.parent.is_prod:
#                     if collection.startswith(self.parent.sec_context.name):
#                         tenant_db = self.parent.sec_context.tenant_db
#                         # If there is no tenant_db we are defaulting to the standard DB
#                         # Just to prevent internal server errors
#                         return tenant_db[collection] if tenant_db else self.db[collection]
#                 return db[collection]
#         self.db = DbSwitcher(self)

class GnanaMongoDB(GnanaDB):
    sec_context = None

    def __init__(self):
        class DbSwitcher:
            def __init__(self, parent):
                self.parent = parent
                self._cached_db = None

            def _get_db(self):
                if self._cached_db:
                    return self._cached_db

                if not self.parent.sec_context:
                    raise RuntimeError("Security context not set")

                tenant = self.parent.sec_context.name
                cname = os.environ.get("CNAME", "preprod")

                self._cached_db = TenantMongoResolver().ms_connection_mongo_client_db(
                    tenant=tenant,
                    db_type='gbm',
                    cname=cname
                )

                return self._cached_db

            def __getattr__(self, attr):
                return getattr(self._get_db(), attr)

            def __getitem__(self, collection):
                return self._get_db()[collection]

        self.db = DbSwitcher(self)

    def saveDocument(self, collection, document, objid=None, is_partial=False, conditional=False, prev_last_modified_time=None):
        if(objid):
            doc = document.copy()
            doc['_id'] = objid
        else:
            doc = document
        identity = doc.get('_id', None)
        if is_partial and identity:
            doc.pop('_id')
            try:
                if not conditional:
                    self.db[collection].update({'_id': identity}, {'$set': doc})
                else:
                    if prev_last_modified_time is None:
                        raise Exception('preexisting last_modified_time is required for this operation')
                    response = self.db[collection].find_one_and_update(
                        {'_id': identity, 'last_modified_time': prev_last_modified_time},
                        {'$set': doc},
                        return_document=ReturnDocument.BEFORE
                    )
                    if response is not None and response['last_modified_time'] == prev_last_modified_time:
                        return identity
                    return None

                return identity
            except DocumentTooLarge as ex:
                logger.error(
                    "Error while uploading {}. Upload failing with error {}".format(doc['object'].get('extid'), str(ex)))
                return {'success': False, 'error': str(ex)}
            except Exception as ex:
                logger.error(
                    "Error while uploading {}. Upload failing with error {}".format(doc['object'].get('extid'), str(ex)))
                return {'success': False, 'error': str(ex)}
        else:
            try:
                return self.db[collection].save(doc)
            except Exception as ex:
                logger.error("Error while uploading {}. Upload failing with error {}".format(doc['object'].get('extid'),str(ex)))
                return {'success':False,'error':str(ex)}


    def findDocument(self, collection, criteria, check_unique=False):
        collection.split('.')
        matches = self.db[collection].find(criteria)
        try:
            ret = next(matches)
        except StopIteration:
            return None

        if check_unique:
            try:
                next_val = next(matches)
                raise TooManyMatches()
            except StopIteration:
                pass
        if '_encdata' in ret:
            from aviso.settings import sec_context
            ret[u'object'] = BSON(sec_context.decompress(
                ret.pop('_encdata'))).decode()
        return ret

    def findAll(self, collection, no_cursor_timeout=False):
        matches = self.db[collection].find(
            {}, no_cursor_timeout=no_cursor_timeout)
        for c in matches:
            yield c

    def find_count(self, collection, criteria={}):
        criteria = empty_criteria_modifier(criteria)
        return self.db[collection].count(criteria)

    def dropCollection(self, name):
        self.db[name].drop()

    def renameCollection(self, name, new_name, overwrite=False):
        self.db[name].rename(new_name, dropTarget=overwrite)

    def renameCollectionsInNamespace(self, name, new_name, overwrite=False):
        namespace = name + "."
        for col_name in (self.sec_context.tenant_db if self.is_prod else self.db).collection_names():
            if(col_name.startswith(namespace)):
                new_col_name = new_name + col_name[len(namespace) - 1:]
                self.db[col_name].rename(new_col_name, dropTarget=overwrite)

    def removeDocument(self, collection, objid):
        if(type(objid) == str):
            objid = ObjectId(objid)
        self.db[collection].remove({'_id': objid})

    def retrieve(self, collection, objid):
        if(type(objid) == str):
            objid = ObjectId(objid)
        return self.db[collection].find_one({'_id': objid})

    def ensureIndex(self, collection, index_field, options, method=None):
        try:
            if isinstance(index_field, list):
                # When index_spec is a list, ensure that the sort direction is
                # integer and not float
                for i in range(len(index_field)):
                    if isinstance(index_field[i][1], float):
                        index_field[i] = list(index_field[i])
                        index_field[i][1] = int(index_field[i][1])
                        index_field[i] = tuple(index_field[i])
            index_field_as_list = index_field
            if isinstance(index_field, dict):
                index_field_as_list = index_field.items()
            index_name_given_by_mongo = ".".join(
                ["_".join(i[0] for i in index_field_as_list)])

            options['background'] = True

            if len(self.db[collection].database.name + collection + index_name_given_by_mongo) > 120:
                compressed_index_name = str(base64.b64encode(
                    zlib.compress(bytes(index_name_given_by_mongo + "_" + '' if 'name' not in options else options.pop('name'), 'utf-8'))), 'utf-8')
                if len(self.db[collection].database.name + collection + compressed_index_name) > 120:
                    compressed_index_name = compressed_index_name[
                        :120 - len(self.db[collection].database.name + collection)]
                self.db[collection].ensure_index(
                    index_field, name=compressed_index_name, ** options)
            else:
                self.db[collection].ensure_index(index_field, **options)
        except Exception as ex:
            logger.exception('Failed to ensure index on %s for %s with options %s' %
                             (collection, str(index_field), str(options)))
            raise ex

    def truncateCollection(self, name, criteria=None):
        if criteria is None:
            criteria = {}
        return self.db[name].remove(criteria)

    def insert(self, name, rec_list):
        retry = False
        for i in range(3):
            try:
                if not retry:
                    return self.db[name].insert(rec_list)
                else:
                    if isinstance(rec_list, list):
                        for d in rec_list:
                            try:
                                self.db[name].insert(d)
                            except Exception as e:
                                logger.info(
                                    'retry failed  for a particular insert - %s extid - %s' % (e, getattr(d, 'extid', 'No Extid')))
                        return len(rec_list)
                    else:
                        return self.db[name].insert(rec_list)
            except pymongo.errors.AutoReconnect as e:
                retry = True
                time.sleep(5)
                logger.info('Reconnecting .... %s' % i)

    def getSecondaryDB(self):
        """
            getconnection from secondary mongodb if available else return normal primary connection
        """
        from aviso.settings import sec_context
        t_db_url = sec_context.details.get_tenant_db()
        rs_name = sec_context.details.get_replica_set_name()
        db_name = t_db_url.split('/')[-1]
        if rs_name is not None:
            client = MongoReplicaSetClient(t_db_url, replicaSet=rs_name)
            # [AV-7170]
            try:
                # SECONDARY_PREFERRED: Read from a secondary if available, otherwise from the primary.
                db_con = client.get_database(db_name, read_preference=ReadPreference.SECONDARY_PREFERRED)
                # FIXME: shall we set max_staleness here for non-prod tenants? by default it's -1(No max)
            except Exception:
                # PRIMARY: Read from the primary. If primary is also not available, raise AutoReconnect
                db_con = client.get_database(db_name, read_preference=ReadPreference.PRIMARY)
        else:
            db_con = self.db
        return db_con

    def findDocuments(self, name, criteria,
                      fieldlist=None,
                      sort=None,
                      batch_size=None,
                      hint=None,
                      auto_decrypt=True,
                      read_from_tertiary=False,
                      query=None, no_cursor_timeout=False):
        criteria = empty_criteria_modifier(criteria)
        if read_from_tertiary:
            db = self.getSecondaryDB()
            if fieldlist:
                ret_cursor = ret_cursor = db[name].find(
                criteria, fieldlist, sort=sort, no_cursor_timeout=no_cursor_timeout)
            else:
                ret_cursor = db[name].find(criteria, sort=sort, no_cursor_timeout=no_cursor_timeout)
        else:
            if fieldlist:
                ret_cursor = self.db[name].find(criteria, fieldlist, sort=sort,
                                                no_cursor_timeout=no_cursor_timeout)
            else:
                ret_cursor = self.db[name].find(criteria, sort=sort,
                                                no_cursor_timeout=no_cursor_timeout)
        if hint:
            ret_cursor = ret_cursor.hint(hint)

        if batch_size:
            ret_cursor = ret_cursor.batch_size(max(2, batch_size))

        return MongoDBCursorIterator(ret_cursor, auto_decrypt)

    findAllDocuments = findDocuments

    def getDistinctValues(self, name, key, criteria=None, encrypted=False):
        from aviso.settings import sec_context
        if criteria is None:
            criteria = {}
        try:
            if criteria:
                return [sec_context.decompress(val) if encrypted else val for val in self.db[name].find(criteria).distinct(key)]
            else:
                return [sec_context.decompress(val) if encrypted else val for val in self.db[name].distinct(key)]
        except Exception as ex:
            if 'distinct too big' in str(ex):
                def get_nested_value(d, key):
                    x = d
                    for c in key.split("."):
                        x = x.get(c, {})
                    return x if x else None

                def None_filter(l):
                    for d in l:
                        v = get_nested_value(d, key)
                        if v is not None:
                            yield v

                all_docs = self.findDocuments(name, criteria, {key: 1})
                return list(set(sec_context.decompress(x) if encrypted else x for x in None_filter(all_docs)))
            else:
                raise ex

    def dropCollectionsInNamespace(self, name):
        namespace = name + "."
        for col_name in (self.sec_context.tenant_db if self.is_prod else self.db).collection_names():
            if(col_name.startswith(namespace)):
                self.db[col_name].drop()

    def collection_names(self, prefix):
        for col_name in (self.sec_context.tenant_db if self.is_prod else self.db).collection_names():
            if(col_name.startswith(prefix)):
                yield col_name

    def indexInformation(self, collection):
        return self.db[collection].index_information()

    def getAggregateValues(self, collection, pipeline):
        result = self.db[collection].aggregate(pipeline, allowDiskUse=True)
        return result

    def updateAll(self, collection, criteria, set_to_criteria, upsert=False):
        self.db[collection].update(
            criteria, set_to_criteria, upsert=upsert, multi=True)


class MongoDBCursorIterator(object):

    def __init__(self, cursor, auto_decrypt):
        from aviso.settings import sec_context
        self.cursor = cursor
        self.auto_decrypt = auto_decrypt
        self.sec_context = sec_context

    def hint(self, hint):
        self.cursor.hint(hint)
        return self

    def limit(self, limit):
        self.cursor.limit(limit)
        return self

    def skip(self, limit):
        self.cursor.skip(limit)
        return self

    def count(self):
        return self.cursor.count()

    def batch_size(self, size):
        self.cursor.batch_size(size)
        return self

    def next(self):
        x = self.cursor.next()
        if self.auto_decrypt and '_encdata' in x:
            x['object'] = BSON(self.sec_context.decompress(
                x.pop('_encdata'))).decode()
        return x

    def __iter__(self):
        for x in self.cursor:
            if self.auto_decrypt and '_encdata' in x:
                x['object'] = BSON(self.sec_context.decompress(
                    x.pop('_encdata'))).decode()
            yield x

    def close(self):
        self.cursor.close()


class CompressedMongoDBCursorIterator(MongoDBCursorIterator):

    def hint(self, hint):
        raise GnanaError("cannot be implemented")

    def limit(self, limit):
        raise GnanaError("cannot be implemented")

    def skip(self, limit):
        raise GnanaError("cannot be implemented")

    def count(self):
        num = 0
        for doc in self.docs:
            num += doc['object']['no_of_records']
        return num

    def batch_size(self, size):
        raise GnanaError("cannot be implemented")

    def next(self):
        raise GnanaError("cannot be implemented")

    def __iter__(self):
        for doc in self.cursor:
            for record in doc['object']['records']:
                yield record

    def close(self):
        self.cursor.close()