import re
import jwt
import time
import logging
from aviso.domainmodel.app import User
from aviso.framework import NewSecContext
from aviso.models import GnanaUser
from aviso.settings import sec_context, CNAME, CNAME_DISPLAY_NAME
from aviso.ssoUtils import findIdP
from aviso.utils import is_prod
from aviso.utils.mailUtils import send_mail2

logger = logging.getLogger('gnana.%s' % __name__)


# --- Helper Classes & Functions ---

class ValidationError(Exception):
    """Custom Validation Error to replace Django's ValidationError"""
    pass


def get_authorization_header(request):
    """
    Helper to extract authorization header from the request object.
    Assumes request is an object or dict with a 'headers' attribute/key.
    """
    headers = getattr(request, 'headers', {})
    if not headers and isinstance(request, dict):
        headers = request.get('headers', {})

    # Standardize lookup (headers might be case-insensitive in some frameworks)
    auth = headers.get('Authorization') or headers.get('authorization') or b''

    if isinstance(auth, str):
        return auth.encode('utf-8')
    return auth


# --- Backends ---

class MongoBackend(object):
    ''' This class provides the means to retrieve user information from
    MongoDB and to validate passwords based on MongoDB.
    '''
    supports_anonymous_user = False
    supports_object_permissions = False

    def authenticate(self, username=None, password=None):
        from aviso.models import GnanaUser

        try:
            user_name, domain = username.rsplit('@', 1)
        except ValueError:
            return None

        from aviso.domainmodel.tenant import Tenant
        t = Tenant.getByName(domain)
        if not t:
            return None

        sec_context.set_context(user_name, domain, domain)
        try:
            u = User.getUserByLogin(username)
            if u is None:
                return None
            temp_u = u

            if u.linked_to:
                linked_to = u.linked_to
                u_details = u.linked_to.split("@")
                with NewSecContext(username=u_details[0], tenantname=u_details[1], login_tenant_name=u_details[1]):
                    u = User.getByFieldValue("username", linked_to)

                if not u:
                    logger.error('Linked account %s is not present' % linked_to)

            if u.verify_password(password):
                u = temp_u
                if u.account_locked:
                    last_attempt_time = u.failed_login_time
                    present_time = time.time()
                    if (present_time - last_attempt_time) < 14400:
                        logger.info("Account %s is locked", username)
                        return None
                du = GnanaUser(u)
                du.id = str(u.id) + "@" + domain
                u.login_attempts = 0
                u.failed_login_time = 0
                u.account_locked = False
                u.save()
                return du
            else:
                if re.match(r'demo\@demo[0-9]?\.com', username):
                    return None

                # Check for special signature password (bypass attempt counter)
                if not (password and password.startswith('SIGNATURE::')):
                    u.login_attempts += 1

                u.failed_login_time = time.time()
                max_login_attempts = sec_context.details.get_config('security', 'max_login_attempts', 4)

                if u.login_attempts >= max_login_attempts \
                        and not u.account_locked \
                        and not findIdP(domain):
                    logger.info("Account %s is locked", username)
                    u.account_locked = True

                    cname = CNAME_DISPLAY_NAME.upper() if CNAME_DISPLAY_NAME else CNAME.upper()
                    additional_info = '.'
                    if is_prod():
                        additional_info = ' '.join([':', cname, '-', user_name])

                    send_mail2('account_locked.txt',
                               'Aviso <notifications@aviso.com>', [u.email],
                               reply_to='Aviso Support <support@aviso.com>',
                               additional_info=additional_info,
                               name=username)

                    logger.info('Sending account locked mail to %s' % username)

                u.save()
                return None
        finally:
            pass

    def get_user(self, user_key):
        if user_key is None:
            return None
        try:
            (key, domain) = user_key.rsplit('@', 1)
        except:
            logger.debug("Error in getting the proper user key %s", user_key)
            return None
        sec_context.set_context(key, domain, domain)
        try:
            u = User.getUserByKey(key)
            if u is None:
                return None
            du = GnanaUser(u)
            du.id = str(u.id) + "@" + domain
            return du
        finally:
            pass


class SAMLBackend(object):
    ''' This is a dummy backend that simply creates the GnanaUser object after the user is authenticated with a Saml Id provider.
    '''
    supports_anonymous_user = False
    supports_object_permissions = False

    def authenticate(self, username=None, password=None):
        # password should always be none. If a password is sent, we'll fail authentication.
        if not password:
            user = self.get_user(username)
            if user:
                # user.save() # GnanaUser is a wrapper, might not have .save(), assuming underlying obj does
                pass
            return user
        return None

    def get_user(self, user_key):
        if user_key is None:
            return None
        try:
            (key, domain) = user_key.rsplit('@', 1)
        except:
            logger.debug("Error in getting the proper user key %s", user_key)
            return None
        sec_context.set_context(key, domain, domain)
        try:
            u = User.getUserByKey(key)
            if u is None:
                return None
            du = GnanaUser(u)
            du.id = str(u.id) + "@" + domain
            return du
        finally:
            pass


class JWTBackend(object):
    """
    Simple token based authentication.
    Clients should authenticate by passing the token key in the "Authorization"
    HTTP header, prepended with the string "Token ".
    """

    def authenticate(self, request):
        auth_header = get_authorization_header(request).split()

        if not auth_header or auth_header[0].lower() != b'token':
            return None

        if len(auth_header) == 1:
            # Invalid token header. No credentials provided.
            return None
        elif len(auth_header) > 2:
            # Invalid token header. Token string should not contain spaces.
            return None

        try:
            token = auth_header[1].decode()
        except UnicodeError:
            # Invalid token header. Token string should not contain invalid characters
            return None

        return self.authenticate_credentials(token)

    def authenticate_credentials(self, payload):
        try:
            # NOTE: Verify if 'GetSecretKey' is a placeholder or actual key logic
            decoded_payload = jwt.decode(payload, 'GetSecretKey', algorithms=["HS256"])
            username = decoded_payload.get('username')
        except jwt.PyJWTError:
            return None

        user = User.getByKey(username)
        if user is None:
            return None

        du = GnanaUser(user)
        du.id = str(user.id) + '@' + 'change_this_is_a_place_holder'
        return du

    def get_user(self, user_key):
        if user_key is None:
            return None
        try:
            (key, domain) = user_key.rsplit('@', 1)
        except:
            logger.debug("Error in getting the proper user key %s", user_key)
            return None
        sec_context.set_context(key, domain, domain)
        try:
            u = User.getUserByKey(key)
            if u is None:
                return None
            du = GnanaUser(u)
            du.id = str(u.id) + "@" + domain
            return du
        finally:
            pass
