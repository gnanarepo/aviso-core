import gc
import os
import bson
import pytz
import time
import uuid
import zlib
import socket
import base64
import hashlib
import avisosdk
import psycopg2
import threading
from Crypto.Cipher import AES
from urllib.parse import urlparse
from collections import namedtuple
from logging import Formatter, getLogger
from pymongo import MongoClient, ReadPreference
from pymongo.mongo_replica_set_client import MongoReplicaSetClient
from aviso.utils import is_true
from collections import OrderedDict
from aviso.framework.tenant_mongo_resolver import TenantMongoResolver 

in_test_mode = is_true(os.environ.get('gnana_test_mode', 'false'))



hex_char = ['0', '1', '2', '3', '4', '5', '6',
            '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F']

logger = getLogger('gnana.%s' % __name__)

# NOTE: This is imported into gnana.settings, hence limit the imports in this
# file to only python libraries.  If you need more than that, you probably
# want a new python module to make sure gnana.settings can be imported first.


# the file, with in the storage system.
FileInfo = namedtuple('fileinfo',
                      ['dataset',         # Dataset this file belongs to
                       'sandbox',           # Stage name of the file. _data for approved files
                       'filetype',        # Type of the file
                       'name',            # Name of the file
                       'fullpath'])        # Complete path that uniquely identifies


class GnanaDB(object):
    """ Base class for DB.  Doesn't implement any methods, this is meant to
    guide the alternate implementations for MongoDB storage in the future """

    def dropCollection(self, name):
        raise NotImplementedError()

    def ensureIndex(self, collection, index_field, options):
        """ Make sure the required index is present """
        raise NotImplementedError()

    def ensureExpiringIndex(self, collection, index_field, grace_period):
        """ Create an expiring index on the document, that will remove the
        record after grace_period.  If the DB doesn't support it, start
        some kind of background server and use this method to inform the
        service of expiring indices"""
        raise NotImplementedError()

    def saveDocument(self, collection, document, objid=None):
        ''' Save the document into the collection.  If an ID is provided,
        overwrite existing doc.  If no ID is provided, create a new one.'''
        raise NotImplementedError()

    def findDocuments(self, collection, criteria, fieldlist=None):
        """ Return a cursor that can be used to iterate over the documents"""
        raise NotImplementedError()

    def findDocument(self, collection, criteria, check_unique=False):
        ''' Find a document using the criteria provided.  We are expected
        to find only one. if forgive is True, return the firstdocument and
        forgive multiple matches.'''
        raise NotImplementedError()

    def find_count(self, collection, criteria={}):
        ''' Find the count of the matching documents. '''
        raise NotImplementedError()

    def removeDocument(self, collection, objid):
        """ Remove the document with the given ID"""
        raise NotImplementedError()

    def retrieve(self, collection, objid):
        ''' Find the specific document using a key '''
        raise NotImplementedError()

    def truncateCollection(self, collection, criteria):
        raise NotImplementedError()

    def getDistinctValues(self, collection, key):
        ''' Find distinctinve values for the key provided in the collection '''
        raise NotImplementedError()

    def dropCollectionsInNamespace(self, name):
        '''
        Drop all the collections in the given namespace. Meaning of namespace
        is driven by the implementation.  It could be native, or just a prefix
        '''
        raise NotImplementedError()

    def collection_names(self, prefix):
        """
        Yield collection names that start with the given prefix
        """
        raise NotImplementedError()


class Tracer(object):

    def __init__(self):
        self.thread_local = None

    def get_trace(self):
        if not self.thread_local:
            self.thread_local = threading.local()
        try:
            return self.thread_local.trace_id
        except AttributeError:
            self.thread_local.trace_id = str(uuid.uuid4())
            return self.thread_local.trace_id

    def set_trace(self, trace):
        if not self.thread_local:
            self.thread_local = threading.local()
        if trace:
            self.thread_local.trace_id = trace
        else:
            try:
                del self.thread_local.trace_id
            except AttributeError:
                pass

    trace = property(get_trace, set_trace)


tracer = Tracer()

def get_shell(url, shell=None, service_name='', tenant_name=None, authorization_token=None, sandbox=None):
    from aviso.settings import microservices_user, microservices_user_password, in_test_mode
    logger.info("Using %s to connect to %s" % (microservices_user, url))
    if in_test_mode:
        sdk_path = os.environ.get(service_name + "_sdk_path")
        service_url = os.environ.get(service_name + '_url', 'http://localhost:1234')
        shell = avisosdk.connect_sdk(service_url, sdk_path=sdk_path, tracer=tracer)
    else:
        shell = avisosdk.connect_sdk(url, tracer=tracer)
    shell.login_internal(username=microservices_user, password=microservices_user_password)
    shell.switch_to(tenant_name)
    return shell

def retry(retries=3):
    def retry_decorator(f):
        def wrapper(shell, *args, **kwargs):
            for i in range(retries):
                try:
                    ret = f(shell, *args, **kwargs)
                    break
                except avisosdk.AuthenticationError:
                    from aviso.settings import sec_context
                    if i == 3:
                        raise avisosdk.AuthenticationError("authentication error after trying three times")
                    logger.info("Waiting trail no: %d  %s" % (i, f.__name__))
                    time.sleep((i) * 30)
                    host = shell.server_info()
                    present_tenant = shell._tenant
                    new_shell = get_shell(
                        host, shell=args[0], tenant_name=present_tenant, authorization_token=sec_context.details.auth_token, sandbox=shell._sandbox)
                    # new_shell.switch_to(present_tenant, authorization_token=sec_context.details.auth_token)
                    shell._session = new_shell._session 
            return ret
        return wrapper
    return retry_decorator
avisosdk.Shell.api = retry(3)(avisosdk.Shell.api)

class UserDetails(object):

    def __init__(self, user_name, tenant_name, login_user_name, login_tenant_name, switch_type, use_deleted):
        if not user_name or not tenant_name or not login_tenant_name:
            raise Exception('Incorrect call to create user details')
        self.user_name = user_name
        self.tenant_name = tenant_name
        self.login_tenant_name = login_tenant_name
        self.login_user_name = login_user_name
        self.switch_type = switch_type
        self.use_deleted = use_deleted

    def get_details(self):
        try:
            return self.tenant_details

        except AttributeError:
            if self.use_deleted:
                from aviso.domainmodel.tenant import DeletedTenant as tenant_to_use
            else:
                from aviso.domainmodel.tenant import Tenant as tenant_to_use
            self.tenant_details = tenant_to_use.getByName(self.tenant_name)
            if not self.tenant_details:
                logger.info("Tenant \"%s\" is not found", self.tenant_name)
                raise Exception("Tenant name is incorrect")
            return self.tenant_details

    details = property(get_details)


def get_stuff(name):
    def getter_fn(self):
        # 1. Check directly in __dict__ to avoid triggering __getattr__ recursion
        if 'thread_local' not in self.__dict__:
            return 'N/A'

        # 2. Now it is safe to access self.thread_local
        try:
            ud = self.thread_local.details
            return getattr(ud, name, 'N/A')
        except AttributeError:
            return 'N/A'

    return getter_fn


dataset_cache = {}
decrypt_cache = {}
timezone_cache = {}


class SecurityContext(object):
    """ A single object is created from this class, which holds the current
    tenant name inside a thread local object. This holding pattern si required
    to make sure the thread_local object is created on demand, and will be same
    for all usages in the spawned process. This is achieved by creating a
    tenant_holder in the same module  """

    name = property(get_stuff('tenant_name'))
    details = property(get_stuff('details'))
    user_name = property(get_stuff('user_name'))
    login_tenant_name = property(get_stuff('login_tenant_name'))
    login_user_name = property(get_stuff('login_user_name'))
    switch_type = property(get_stuff('switch_type'))
    csv_version_info = {}


    # @property
    # def details(self):
    #     # 1. Check if thread_local exists safely
    #     if 'thread_local' not in self.__dict__:
    #         return None
    #
    #     # 2. Get the UserDetails Wrapper
    #     ud = getattr(self.thread_local, 'details', None)
    #
    #     # 3. UNWRAP IT: Return the actual Tenant object
    #     # This triggers UserDetails.get_details() -> loads from DB
    #     return ud.details if ud else None



    # @property
    # def details(self):
    #     if 'thread_local' not in self.__dict__:
    #         return None
    #     user_details = getattr(self.thread_local, 'details', None)
    #     return getattr(user_details, 'details', None)

    def get_effective_user(self):
        if self.switch_type == 'user':
            user_name = self.user_name
            tenant_name = self.name
        else:
            user_name = self.login_user_name
            tenant_name = self.login_tenant_name

        # For a tenant switch pick the user from the original domain
        with NewSecContext(user_name, tenant_name, self.login_tenant_name):
            from aviso.domainmodel.app import User
            full_username = '%s@%s' % (user_name, tenant_name)
            return User.getUserByLogin(full_username)

    def set_context(self, user_name, tenant_name, login_tenant_name, login_user_name=None, switch_type=None,
                    csv_version_info=None,
                    override_version_info=False,
                    use_deleted=False):

        # Save our self from the calls to each set_context
        if login_user_name is None:
            login_user_name = user_name

        if switch_type is None:
            switch_type = 'tenant'

        if csv_version_info and self.login_tenant_name == login_tenant_name or override_version_info:
            self.csv_version_info = csv_version_info

        ud = UserDetails(user_name, tenant_name, login_user_name,
                         login_tenant_name, switch_type, use_deleted)
        try:
            self.thread_local.details = ud
        except AttributeError:
            self.thread_local = threading.local()
            self.thread_local.details = ud
        # Make sure next call gets the correct aes_key
        try:
            del self.thread_local.aes_key
            del self.thread_local.tenant_db
        except AttributeError:
            pass
        try:
            del self.thread_local.tenant_time_zone
        except AttributeError:
            pass
        try:
            del self.thread_local.postgres_db
        except AttributeError:
            pass
        try:
            del self.thread_local.postgres_local_con
        except AttributeError:
            pass
        dataset_cache.clear()
        decrypt_cache.clear()

    def get_dataset_by_name_and_stage(self, ds, stage):
        k = '%s.%s' % (ds, stage) if stage else ds
        try:
            return dataset_cache[k]
        except KeyError:
            try:
                from etl.domainmodel.uip import Dataset
            except ModuleNotFoundError:
                # Probably a different app
                from aviso.domainmodel.datameta import DSClass as Dataset
                logger.info(
                    "ETL Module not found using dataset from service infrastructure")
            dataset_cache[k] = Dataset.getByNameAndStage(ds, stage)
            return dataset_cache[k]

    def get_tenant_time_zone(self):
        from aviso.settings import in_test_mode, DEBUG
        if self.name in timezone_cache and not (in_test_mode or DEBUG):
            return timezone_cache[self.name]
        try:
            return self.thread_local.tenant_time_zone
        except AttributeError:
            t = self.details
            if t:
                self.thread_local.tenant_time_zone = pytz.timezone(
                    t.get_config('forecast', 'timezone', "US/Pacific"))
            else:
                logger.error('Why is self.details None?  for %s', self.name)
                raise ValueError
            timezone_cache[self.name] = self.thread_local.tenant_time_zone
            return self.thread_local.tenant_time_zone

    tenant_time_zone = property(get_tenant_time_zone)

    def reset_context(self):
        try:
            del self.thread_local.details
            del self.thread_local.aes_key
            del self.thread_local.tenant_db
        except AttributeError:
            pass
        try:
            del self.thread_local.tenant_time_zone
        except AttributeError:
            pass
        try:
            del self.thread_local.postgres_db
        except AttributeError:
            pass
        try:
            del self.thread_local.postgres_local_con
        except AttributeError:
            pass

        self.csv_version_info = {}

    def peek_context(self):
        return (self.user_name, self.name, self.login_tenant_name, self.login_user_name, self.switch_type,
                self.csv_version_info)

    def compress(self, data, cls=None):
        """Encrypt data"""
        def encode(data):
            try:
                if not isinstance(data, bytes):
                    data = bytes(data, 'utf-8')
                compressed_data = zlib.compress(data)
                return base64.b64encode(compressed_data)
            except Exception as ex:
                logger.exception("Unable to compress")
                raise Exception("Unable to compress: %s" % str(ex))
        if isinstance(data, (str, bytes)):
            return encode(data)
        elif isinstance(data, (list, set, tuple)):
            return [encode(i) if isinstance(i, str) else i for i in data]
        else:
            return data

    def decompress(self, data, cls=None):
        """decompress data"""
        def decode(d):
            try:
                return zlib.decompress(base64.b64decode(d))
            except:
                pass
        if isinstance(data, (bytes, str)):
            return decode(data)
        else:
            return data

    def get_aes_key(self):
        try:
            return self.thread_local.aes_key
        except AttributeError:
            try:
                self.thread_local.aes_key = AES.new(
                    base64.b64decode(self.details.get_aes_key()),
                    mode=AES.MODE_ECB)
            except:
                return None
            return self.thread_local.aes_key
    aes_key = property(get_aes_key)

    def get_postgres_db(self):
        try:
            if self.thread_local.tenant_used_for_pg_db != self.name:
                del self.thread_local.postgres_db
            return self.thread_local.postgres_db
        except AttributeError:
            postgres_url = self.details.get_postgres_db_url()
            self.thread_local.postgres_db = None
            if postgres_url is not None:
                pg_url_parsed = urlparse(str(postgres_url))
                postgres_con = psycopg2.connect(database=pg_url_parsed.path.strip('/'),
                                                user=pg_url_parsed.username.strip(
                                                    '"'),
                                                password=pg_url_parsed.password,
                                                host=pg_url_parsed.hostname,
                                                port=pg_url_parsed.port,
                                                cursor_factory=psycopg2.extras.RealDictCursor
                                                )
                postgres_con.set_session(autocommit=True)
                self.thread_local.postgres_db = postgres_con
                self.thread_local.tenant_used_for_pg_db = self.name
        return self.thread_local.postgres_db

    postgres_db = property(get_postgres_db)

    # def get_tenant_db(self):
    #     from collections import OrderedDict
    #     MAX_CACHE_SIZE = 10
    #     try:
    #         if not hasattr(self.thread_local, 'tenant_db_map'):
    #             self.thread_local.tenant_db_map = OrderedDict()
    #         if self.name in self.thread_local.tenant_db_map:
    #             logger.info("cached_connection used for tenant %s", self.name)
    #             return self.thread_local.tenant_db_map[self.name]
    #     except AttributeError:
    #         self.thread_local = threading.local()
    #         self.thread_local.tenant_db_map = OrderedDict()
    #     from aviso.settings import CNAME
    #     try:
    #         logger.info("Created new connection for tenant %s", self.name)
    #         t_db = None
    #         try:
    #             #set to None for testing purpose
    #             rs_name = None
    #         except Exception:
    #             rs_name = None
    #         tenant_db_name = t_db.split('/')[-1].split('?')[0]
    #         from aviso.settings import modify_mongo_db_url
    #         if tenant_db_name == 'admin':
    #             t_db = modify_mongo_db_url(t_db)
    #             tenant_name_split = self.name.split(".")
    #             tenant_temp = tenant_name_split[0]
    #             tenant_db_name = "%s_cache_%s" % (self.name.replace('.', '_'), CNAME) if len(
    #                 tenant_name_split) > 2 and self.name != 'redhelix.co.uk' \
    #                 else tenant_temp + '_cache_' + CNAME

    #         if rs_name is not None:
    #             mongo_con = MongoReplicaSetClient(t_db, read_Preference=ReadPreference.SECONDARY_PREFERRED,
    #                                               replicaSet=rs_name)[tenant_db_name]
    #         else:
    #             mongo_con = MongoClient(t_db, read_Preference=ReadPreference.SECONDARY_PREFERRED)[tenant_db_name]

    #     except Exception as e:
    #         def get_test_tenant_db(tenant_name):
    #             return '_'.join([tenant_name.split('.')[0], 'cache_preprod'])

    #         tenant_name = self.name
    #         tenant_db_name = get_test_tenant_db(tenant_name)
    #         from aviso.settings import mongo_db_con_url
    #         mongo_con = MongoClient(mongo_db_con_url, w=1)[tenant_db_name]
    #         # Cache eviction: limit to 10 tenants per thread
    #     tenant_db_map = self.thread_local.tenant_db_map
    #     if len(tenant_db_map) >= MAX_CACHE_SIZE:
    #         _, old_con = tenant_db_map.popitem(last=False)
    #         try:
    #             old_con.client.close()
    #             del old_con
    #             gc.collect()
    #         except Exception as e:
    #             logger.warning("Failed to close and delete old MongoDB connection: %s", e)
    #     tenant_db_map[self.name] = mongo_con
    #     return tenant_db_map[self.name]
    
    def get_tenant_db(self):
        MAX_CACHE_SIZE = 10

        if not hasattr(self.thread_local, "tenant_db_map"):
            self.thread_local.tenant_db_map = OrderedDict()

        if self.name in self.thread_local.tenant_db_map:
            return self.thread_local.tenant_db_map[self.name]

        # stack=os.environ.get("STACK", "preprod")
        cname=os.environ.get("CNAME", "preprod")
        resolver = TenantMongoResolver()
        cfg = resolver.resolve(self.name, cname=cname, db_type="fm")

        client = MongoClient(cfg.mongo_url, unicode_decode_error_handler="ignore")
        db = client[cfg.db_name]

        if len(self.thread_local.tenant_db_map) >= MAX_CACHE_SIZE:
            _, old = self.thread_local.tenant_db_map.popitem(last=False)
            old.client.close()

        self.thread_local.tenant_db_map[self.name] = db
        
        return db

    tenant_db = property(get_tenant_db)

    def get_local_postgres_con(self):
        try:
            return self.thread_local.postgres_local_con
        except AttributeError:
            try:
                # import os
                # postgres_db_url = os.environ.get(
                #     'postgres_db_url', 'postgres://etluser:etluser@localhost:5432/etldb')
                # pg_db_con_url = os.environ.get(
                #     'postgres_common_db_url', postgres_db_url)
                from aviso.settings import POSTGRES_DB_URL # to avoid circular import
                pg_url_parsed = urlparse(POSTGRES_DB_URL)
                postgres_con = psycopg2.connect(database=pg_url_parsed.path.strip('/'),
                                                user=pg_url_parsed.username,
                                                password=pg_url_parsed.password,
                                                host=pg_url_parsed.hostname,
                                                port=pg_url_parsed.port,
                                                cursor_factory=psycopg2.extras.RealDictCursor
                                                )
                postgres_con.set_session(autocommit=True)
                self.thread_local.postgres_local_con = postgres_con
            except:
                return None
            return self.thread_local.postgres_local_con
    postgres_local_con = property(get_local_postgres_con)

    def get_microservice_config(self, service_name=None):
        if not getattr(self, 'thread_local', False) or service_name is None or self.name == 'N/A':
            return None
        tenant = self.details
        config = tenant.get_credentials("microservices_info")
        if config:
            service_config = config.get(service_name, None)
            if not service_config:
                return service_config
            service_config.update({'service_name': service_name})
            service_config.update({'auth_token': tenant.auth_token})
            return service_config
        else:
            return None

    def get_microservice(self, service_name):
        if not getattr(self, 'thread_local', False):
            return None
        config = self.get_microservice_config(service_name)
        if not config:
            raise Exception("microservice %s not enabled for tenant %s"% (service_name, self.name))
        source_tenant_name = config.get('source_tenant')
        source_host = config.get('host')
        shell = getattr(self, service_name + '_shell', None)
        if (shell and shell.server_info() != source_host) or shell is None:
            shell = get_shell(source_host, service_name=service_name, tenant_name=source_tenant_name, 
                              authorization_token=self.details.auth_token, sandbox=config.get('sandbox'))
        if shell._tenant != source_tenant_name:
            shell.switch_to(source_tenant_name, authorization_token=self.details.auth_token)
        shell._sandbox = config.get('sandbox')
        setattr(self, service_name+"_shell", shell)
        return shell

    def get_etl_service(self):
        """returns etl_data_service shell object to interact with etl_data_service"""
        return self.get_microservice("etl_data_service")

    etl = property(get_etl_service)

    def etl_service_enabled(self):
        return bool(self.get_microservice_config("etl_data_service"))

    is_etl_service_enabled = property(etl_service_enabled)

    def gbm_service_enabled(self):
        return bool(self.get_microservice_config("gbm_service")) 
    
    is_gbm_service_enabled = property(gbm_service_enabled)

    def get_gbm_service(self):
        """returns shell object to interact with gbm service"""
        return self.get_microservice("gbm_service")
    gbm = property(get_gbm_service)

    def get_forecast_app_service(self):
        return self.get_microservice("forecast_app_service")

    forecast_app = property(get_forecast_app_service)
    
    def forecast_service_enabled(self):
        return bool(self.get_microservice_config('forecast_app_service'))

    is_forecast_service_enabled = property(forecast_service_enabled)



class LoginUserContext():

    def __init__(self, username):
        self.username = username

    def __enter__(self):
        self.old_context = tenant_holder.peek_context()
        if self.username:
            user, tenant = self.username.split('@', 1)
            tenant_holder.set_context(user, tenant, tenant,
                                      switch_type=self.old_context[4])
        else:
            logger.error('Login Context without proper username is proven to be faulty.\
             This is for backward compatibility only')
            tenant_holder.set_context(self.old_context[3], self.old_context[2],
                                      self.old_context[2],
                                      switch_type=self.old_context[4])

    def __exit__(self, t, v, tb):
        tenant_holder.set_context(*self.old_context)
        return False


# Everyone should import and use the tenant_holder here
tenant_holder = SecurityContext()


class TooManyMatches(Exception):
    pass


class GnanaLogFormatter(Formatter):

    def __init__(self, **kwargs):
        super(GnanaLogFormatter, self).__init__(kwargs['format'])

    def format(self, record):
        record.tenant = tenant_holder.name
        record.trace = tracer.trace
        if tenant_holder.login_tenant_name != record.tenant:
            record.username = "%s@%s" % (
                tenant_holder.user_name, tenant_holder.login_tenant_name)
        else:
            record.username = tenant_holder.user_name
        return Formatter.format(self, record)


class AvisoFullLogFormatter(Formatter):


    def format(self, record):
        record.hostname = self.get_hostname()
        record.username = self.get_username()
        record.tenant = self.get_tenant()
        record.stack = self.get_stack_name()
        record.trace = self.get_trace()
        return Formatter.format(self, record)

    def get_hostname(self):
        hostname = "NA"
        try:
            hostname = socket.gethostname()
        except Exception as exception:
            print("Error in logging: %s" % exception)
        return hostname

    def get_username(self):
        username = "NA"
        try:
            if tenant_holder.login_tenant_name != self.get_tenant():
                username = "%s@%s" % (tenant_holder.user_name, tenant_holder.login_tenant_name)
            else:
                username = tenant_holder.user_name
        except Exception as exception:
            print("Error in logging %s" % exception)
        return username

    def get_tenant(self):
        tenant = "NA"
        try:
            tenant = tenant_holder.name
        except Exception as exception:
            print("Error in logging %s" % exception)
        return tenant

    def get_stack_name(self):
        stack = "NA"
        try:
            from aviso.settings import POOL_PREFIX
            stack = POOL_PREFIX
        except Exception as exception:
            print("Error in logging %s" % exception)
        return stack

    def get_trace(self):
        trace = "NA"
        try:
            trace = tracer.trace
        except Exception as exception:
            print("Error in logging %s" % exception)
        return trace


class GnanaStorage(object):
    # TODO: Based on how the S3 and File Storage evolve, define the base class
    # better so that additional storages can be defined based on that

    def filelist(self, tenant, inbox='_data', dataset=None, file_type=None):
        """
        Iterate over all the files and yeild with the file information for
        each matching file.
        inbox:
            Staging area is mandatory.  If no staging area is specified, _data
            is assumed.
        dataset:
            Limit the iteration to a given dataset only.
        file_type:
            Limit the iteration to a given type of files only.
        """
        raise NotImplementedError()

    def move_file(self, tenant, inbox, dataset, file_type, file_name,
                  old_full_path):
        """
        Move the file identified by full_path into the logical location for
        given tenant, dataset, inbox, file_type and name
        Return the new storage specific full_path
        """
        raise NotImplementedError()


class EventContext(object):

    def set_event_context(self, event_id):
        try:
            self.thread_local.event_id = event_id
        except AttributeError:
            self.thread_local = threading.local()
            self.thread_local.event_id = event_id

    def get_event_id(self):
        try:
            return self.thread_local.event_id
        except AttributeError:
            return None

    event_id = property(get_event_id)


event_holder = EventContext()


class NewSecContext(object):

    def __init__(self, username, tenantname, login_tenant_name):
        self.old_context = tenant_holder.peek_context()
        tenant_holder.set_context(username, tenantname, login_tenant_name,
                                  switch_type=self.old_context[4])

    def __enter__(self):
        pass

    def __exit__(self, exc_type, exc_val, exc_tb):
        tenant_holder.set_context(self.old_context[0], self.old_context[1], self.old_context[2],
                                  switch_type=self.old_context[4])
