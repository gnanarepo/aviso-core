import logging
import threading
import traceback

from aviso.domainmodel.diagnostics import ProbeRecord
from aviso.utils import dateUtils

logger = logging.getLogger('gnana.%s' % __name__)


class Probe(object):
    ''' Class to handle the probing needs for knowing what exactly happened to
    selected records'''
    def __init__(self):
        self.thread_local = None
        self.probing = False

    def start(self, probeid, location):
        """ Start the probing session.  Give an ID and location that started
        the probe """
        if(not self.thread_local):
            self.thread_local = threading.local()
        self.thread_local.probeid = probeid
        self.thread_local.location = location

        # Start the flag for probing
        self.probing = True

    def end(self):
        """ End the probing session.  Silently ignore errors if so probing
        session is found """
        if not self.probing:
            return
        self.probing = False
        try:
            del self.thread_local.probeid
            del self.thread_local.location
        except AttributeError:
            pass

    def set_location(self, new_location):
        self.thread_local.location = new_location

    def get_probe_context(self):
        if not self.probing:
            return {}
        else:
            return {'probeid': self.thread_local.probeid}

    def signal(self, message, params, location=None, message_key=None):
        ''' Log the probe message to console and DB if probing is enabled '''
        # If probing is not happening, just ignore
        if not self.probing:
            return

        # Save the probe record
        r = ProbeRecord()
        r.probeid = self.thread_local.probeid
        r.location = location or self.thread_local.location
        r.message = message
        r.params = params
        r.message_key = message_key
        # Get the caller for probe
        stack_frame = traceback.extract_stack(limit=2)[0]
        fp_segments = stack_frame[0].split('/')
        r.trace = "%s/%s:%s" % (fp_segments[-2],
                            fp_segments[-1],
                            stack_frame[1])
        r.timestamp = dateUtils.now()
        r.save()

        # Print the probe message
        msg = None
        if (isinstance(params, dict)):
            msg = message.format(**params)
        else:
            msg = message.format(params)

        print("%s - [Probe: %s] [In: %s] [At: %s] %s" % (r.timestamp,
                    r.probeid, r.location, r.trace, msg))

# Create a singleton for probe
probe_util = Probe()