"""
Author: balaji.s
"""

import re
import json
import hashlib
import logging
from datetime import date, time, datetime
from itertools import count
from urllib import parse as urlparse

import psycopg2
from psycopg2.extras import Json
from psycopg2 import ProgrammingError

from aviso.utils import GnanaError
from aviso.framework import GnanaDB, TooManyMatches

logger = logging.getLogger('gnana.%s' % __name__)



class LocalConnection:

    def __init__(self):
        psycopg2.extensions.register_adapter(dict, psycopg2.extras.Json)

    def __getattr__(self, attr):
        if attr is not '__getitem__':
            from aviso.settings import sec_context
            connection = None
            if sec_context:
                connection = sec_context.postgres_local_con
            if connection:
                return getattr(connection, attr)
            else:
                connection = GnanaPostgresDB.get_local_postgres_con()
                if connection:
                    return getattr(connection, attr)
                else:
                    raise Exception("postgres connection is not there")


class GnanaPostgresDB(GnanaDB):
    is_prod = False
    sec_context = None
    db = None
    cached_data = {}

    def __init__(self):

        class DbSwitcher:

            def __init__(self, parent):
                self.parent = parent
                psycopg2.extensions.register_adapter(dict, psycopg2.extras.Json)

            def __getattr__(self, attr):
                if attr is not '__getitem__':
                    # For local testing:
                    connection = self.parent.sec_context.postgres_db
                    return getattr(connection, attr) if connection else getattr(self.parent.local_postgres_db, attr)
                    # return getattr(self.parent.local_postgres_db, attr)

        self.tenantawaredb = DbSwitcher(self)
        self.local_postgres_db = LocalConnection()

    def __getattr__(self, attr):
        return(self.local_postgres_db, attr)
#         return getattr(self.local_postgres_db, attr)

    @staticmethod
    def __postgres_row_to_mongo_record__(row, sec_context, encrypt):
        record = {"object": {}}
        for key, value in row.items():
            if (str(key).startswith("_")) or key == 'last_modified_time':
                record[key] = value
            else:
                if isinstance(value, list):
                    val_list = []
                    for val in value:
                        val_list.append(val)
                    record['object'][str(key)] = val_list
                else:
                    record["object"][str(key)] = value
        return record

    def __check_tenant_aware__(self, collection):
        if collection.startswith(self.sec_context.name):
            return True
        return False

    def executeDQL(self, collection, statement):
        try:
            tenant_aware = self.__check_tenant_aware__(collection.strip('"'))
            if tenant_aware:
                self.db = self.tenantawaredb
            else:
                self.db = self.local_postgres_db
            with self.db.cursor() as cursor:
                cursor.execute(statement)
                if cursor.rowcount > 0:
                    for row in cursor.fetchall():
                        yield row
        except Exception as e:
            raise e

    def executeDML(self, collection, statement):
        try:
            tenant_aware = self.__check_tenant_aware__(collection.strip('"'))
            if tenant_aware:
                self.db = self.tenantawaredb
            else:
                self.db = self.local_postgres_db
            with self.db.cursor() as cursor:
                cursor.execute(statement)
                if 'RETURNING _id' in statement:
                    id = cursor.fetchone()['_id']
                    return id
                if cursor.rowcount:
                    return cursor.rowcount
                else:
                    logger.info("DML execution is unsuccessful")
        except Exception as e:
            raise e

    def cast_values(self, value, cast_type):
        if cast_type == 'jsonb_array':
            return 'CAST ( %s as jsonb [] )' % (value)
        elif cast_type is None:
            return value

    def mogrify_values(self, value, collection_name=None, cursor=None):
        if isinstance(value, list) and len(value) >= 1 and isinstance(value[0], dict):
            # It is assumed that we always use jsonb for dictionary types
            # As jsonb is faster than json
            cast_type = 'jsonb_array'
        else:
            cast_type = None

        # If cursor is not passed in, we create our own.
        if cursor is None:
            if collection_name and not self.__check_tenant_aware__(collection_name.strip('"')):
                self.db = self.local_postgres_db
            else:
                self.db = self.tenantawaredb
            with self.db.cursor() as cursor:
                val = str(cursor.mogrify(' %s ', [value]), 'utf-8')
        else:
            val = str(cursor.mogrify(' %s ', [value]), 'utf-8')

        if cast_type is not None:
            val = self.cast_values(val, cast_type)
        return val


    def __mongo_to_postgres_name_converter__(self, mongo_col_name):
        postgres_table_name = str(mongo_col_name).replace(".", "$")
        return '"' + postgres_table_name + '"'

    def __postgres_to_mongo_name_converter__(self, mongo_col_name):
        postgres_table_name = str(mongo_col_name).replace("$", ".")
        return postgres_table_name

    def __criteria_processing__(self, criteria=dict(), field_list=list(), typed_fields=dict()):
        selector = "*"
        condition = criteria
        for field in field_list:
            str(field).replace("object.", "")
        if field_list:
            if isinstance(field_list, dict):
                logger.info("Got field list as a dict :: %s" % field_list)
                field_list = list(field_list.keys())
            for i, default_field in enumerate(['_id', '_kind', '_version']):
                if default_field not in field_list:
                    field_list.insert(i, default_field)
            selector = " , ".join('"%s"' % x for x in field_list)

        if criteria:
            while True:
                condition = self.parse_mongo_to_psql(condition, typed_fields)
                if isinstance(condition, str):
                    break
            condition = 'where ' + condition
        else:
            condition = ''

        return selector, condition

    def py_dt_to_pg_dt(self, val):
        type_conv = {
            bool: "bool",
            time: "time",
            date: "date",
            float: "real",
            int: "bigint",
            str: "varchar",
            # unicode: "text", #TODO
            datetime: "timestamp",
            dict: "jsonb",
        }
        if type(val) is not list:  # because list has two types one array and other inner element
            return type_conv[type(val)]
        else:
            if len(val) > 0:
                return self.py_dt_to_pg_dt(val[0]) + " [] "

    def alter_table_add_missing_columns(self, table_name, table_data, columns):
        uid = None
        if '_id' in table_data:
            uid = table_data['_id']
            del table_data['_id']
        table_columns = self.get_columns_from_pg_table(table_name.strip('"'))
        if "_id" in table_columns:
            table_columns.remove("_id")
        missing_columns = [x for x in columns if x not in table_columns]
        st2 = "alter table %s add column " % table_name
        for col in missing_columns:
            # try to get value from the table_data to find out the data type of the column
            col_val = table_data.get(col.strip('"'))
            if not col_val:
                # try to check whether column is part of object
                col_val = table_data['object'].get(col.strip('"'))
            if not col_val:
                # Skipping altering the table as there is no way to find the type of the new column
                continue
            mis_col = " %s %s " % (col, self.py_dt_to_pg_dt(col_val))
            alterstmt = st2
            alterstmt += mis_col
            try:
                self.executeDML(self.__postgres_to_mongo_name_converter__(table_name), alterstmt)
                logger.info("Altered the table %s with statement %s" % (table_name, alterstmt))
            except Exception as E:
                logger.exception("Got exception while altering the table %s" % str(E))
                error = re.match(r"^column.+of relation.+ already exist", str(E))
                if not error:
                    raise E
        try:
            c, st = self.create_psql_statement_using_record(table_data, table_name, uid, missing_columns)
            ret = self.executeDML(self.__postgres_to_mongo_name_converter__(table_name), st)
            return ret
        except Exception as e:
            logger.exception("Got exception in inserting data After altering table %s" % (e))
            raise e

    def create_psql_statement_using_record(self, table_data, table_name, uid, missing_columns=[]):
        columns = []
        values = []
        if not uid:
            if '_id' in table_data:
                uid = table_data['_id']
                del table_data['_id']
        for key, value in table_data.items():
            if key != 'object':
                if '"' + str(key) + '"' in missing_columns and not value:
                    continue
                columns.append('"' + str(key) + '"')
                s = self.mogrify_values(value, self.__postgres_to_mongo_name_converter__(table_name).strip('"'))
                values.append(s)
            else:
                for key, value in table_data['object'].items():
                    if '"' + str(key) + '"' in missing_columns and not value:
                        continue
                    columns.append('"' + str(key) + '"')
                    s = self.mogrify_values(value, self.__postgres_to_mongo_name_converter__(table_name).strip('"'))
                    values.append(s)

        if uid:
            st = "update " + table_name + " set " + "(" + ",".join(columns) + ")" + " = " + "(" + ",".join(values) + "\
                    ) where _id = " + str(uid) + " RETURNING _id;"
        else:
            st = "INSERT INTO " + table_name + "(" + ",".join(columns) + ")" + " values \
                    " + "(" + ",".join(values) + ") RETURNING _id;"
        return columns, st

    def __insert_mongo_data_postgres__(self, table_data, table_name, uid):

        def table_creator(row, table_name):
            st = "CREATE TABLE " + table_name + "(_id bigserial primary key, "
            if '_id' in table_data:
                del table_data['_id']

            coloumns = []
            for key, value in row.items():
                if key != "object":
                    coloumns.append(str(key) + " " + self.py_dt_to_pg_dt(value))
                else:
                    for key, value in row['object'].items():
                        coloumns.append(str(key) + " " + self.py_dt_to_pg_dt(value))
            st += ",".join(coloumns) + ");"
            self.db.execute(st)
        if '_id' in table_data:
            uid = table_data['_id']
            del table_data['_id']

        columns, st = self.create_psql_statement_using_record(table_data, table_name, uid)
        try:
            ret = self.executeDML(self.__postgres_to_mongo_name_converter__(table_name), st)
            return ret
        except ProgrammingError as E:
            # logger.exception("Got exception while saving record __insert_mongo_data_postgres__ %s " % (str(E)))
            new_column_error = re.match(r"^column.+of relation.+ does not exist", str(E))
            new_row_error = re.match(r"^relation .+ does not exist", str(E))
            if new_column_error:
                if uid:
                    table_data['_id'] = uid
                return self.alter_table_add_missing_columns(table_name, table_data, columns)
            elif new_row_error:
                raise E
#                 table_creator(table_data, table_name)
#                 self.db.execute(st)
            else:
                raise E

    def encode_values_to_postgres_type(self, value):
        """Changes the special type characters to compatible with postgres"""
        if isinstance(value, str):
            if "'" in value:
                s = value.split("'")
                value = "''".join(s)
        return value

    def saveDocument(self, collection, document, objid=None, is_partial=False):
        try:
            collection = self.__mongo_to_postgres_name_converter__(collection)
            if(objid):
                doc = document.copy()
                doc['_id'] = objid
            else:
                doc = document
            identity = doc.get('_id', None)
            if is_partial and identity:
                doc.pop('_id')
                self.__insert_mongo_data_postgres__(doc, collection, identity)
                return identity
            else:
                return self.__insert_mongo_data_postgres__(doc, collection, None)
        except Exception as e:
            raise e

    def findDocument(self, collection, criteria, check_unique=False):
        collection = self.__mongo_to_postgres_name_converter__(collection)
        selector, condition = self.__criteria_processing__(criteria)
        st = "select %s from %s %s limit 1" % (selector, collection, condition)
        ret = self.executeDQL(self.__postgres_to_mongo_name_converter__(collection), st)
        res_list = []
        if ret:
            for r in ret:
                res_list.append(r)
        if check_unique:
            if len(res_list) > 1:
                raise TooManyMatches
        if res_list:
            encrypt = False
            if '_encdata' in res_list[0].keys():
                encrypt = True
            ret = self.__postgres_row_to_mongo_record__(res_list[0], self.sec_context, encrypt)
            return ret

    def findAll(self, collection):
        return self.findDocuments(collection, {})

    def find_count(self, collection, criteria={}):
        collection = self.__mongo_to_postgres_name_converter__(collection)
        selector, condition = self.__criteria_processing__(criteria)
        ret = self.executeDQL(self.__postgres_to_mongo_name_converter__(
            collection), "select count ( %s ) from %s %s" % (selector, collection, condition))
        return list(ret.__next__().values())[0]

    def dropCollection(self, name):
        drop_stmt = "drop table if exists {0};".format(self.__mongo_to_postgres_name_converter__(name))
        self.executeDML(self.__postgres_to_mongo_name_converter__(name), drop_stmt)

    def renameCollection(self, name, new_name, overwrite=False):
        if overwrite:
            self.dropCollection(new_name)
        self.executeDML(self.__postgres_to_mongo_name_converter__(name), "alter table %s rename to %s ;" %
                        (self.__mongo_to_postgres_name_converter__(name),
                         self.__mongo_to_postgres_name_converter__(new_name)))

    def updateAll(self, collection, criteria, set_to_criteria):
        pass

    def collection_names(self, prefix):
        # information schema will be there in both the session and tenant specific databases
        # making this method to use tenant specific database
        self.db = self.tenantawaredb
        query_to_execute = "SELECT table_name FROM information_schema.tables WHERE table_schema = 'public'"
        with self.db.cursor() as cursor:
            cursor.execute(query_to_execute)
            if cursor.rowcount > 0:
                for row in cursor:
                    table_name = row.get('table_name', None)
                    if table_name and \
                       str(row['table_name']).startswith(self.__mongo_to_postgres_name_converter__(prefix).strip('"')):
                        yield self.__postgres_to_mongo_name_converter__(row['table_name'])

    def renameCollectionsInNamespace(self, name, new_name, overwrite=False):
        namespace = name + "."
        # information schema will be there in both the session and tenant specific databases
        # making this method to use tenant specific database
        self.db = self.tenantawaredb
        with self.db.cursor() as cursor:
            cursor.execute("SELECT table_name FROM information_schema.tables WHERE table_schema = 'public'")
            if cursor.rowcount > 0:
                for row in cursor:
                    if self.__postgres_to_mongo_name_converter__(row['table_name']).startswith(namespace):
                        new_col_name = new_name + row['table_name'][len(namespace) - 1:]
                        self.renameCollection(name, new_col_name, overwrite=True)

    def removeDocument(self, collection, objid):
        table_name = self.__mongo_to_postgres_name_converter__(collection)
        self.executeDML(self.__postgres_to_mongo_name_converter__(
            collection), "delete from  %s where _id = %s ;" % (table_name, objid))

    def retrieve(self, collection, objid):
        collection = self.__mongo_to_postgres_name_converter__(collection)
        ret = self.executeDQL(self.__postgres_to_mongo_name_converter__(
            collection), " select * from %s where _id = %s ;" % (collection, objid))
        if ret:
#             row = ret.next()
            row = ret.__next__()
            encrypt = False
            if row and '_encdata' in row.keys():
                encrypt = True
            record = self.__postgres_row_to_mongo_record__(row, self.sec_context, encrypt)
            return record

    def get_unique_name(self, collection, include_fields=[]):
        # Initial naming strategy for index name
        # index name will have tenant_name
        # A 8-char random string will be generated to make the name unique
        # using last two elements of the list which is generated by splitting the collection with '.'
        # expects mongo collection name
        final_name_list = []
        seperator = '$'
        collection_name_list = collection.split('.')
        final_name_list.append(collection_name_list[0])  # Tenant name
        if len(collection_name_list) >= 3:
            # last two fields from collection name
            final_name_list.append(collection_name_list[-2] + seperator + collection_name_list[-1])
        hash_str = hashlib.md5(''.join(final_name_list + include_fields).encode(encoding='utf_8')).hexdigest()
        final_name_list.append(str(hash_str[:8]))
        if include_fields:
            final_name_list += include_fields
        final_name = seperator.join(final_name_list)
        # Postgres support the name which are less than 64 chars
        if len(final_name) > 64:
            logger.info("Name length (64) exceeded while naming index removing some fields")
            final_name_list.pop(1)
            return seperator.join(final_name_list)
        else:
            return final_name

    def check_already_indexed(self, collection_name, field):
        # check whether the data is cached already
        # Expecting Field is a single tuple which has field name and order like 1 or 0
        if isinstance(field[0], tuple):
            field = field[0][0]
        is_cached = self.cached_data.get(collection_name)
        if is_cached:
            if field in self.cached_data[collection_name]:
                return True
            del self.cached_data[collection_name]
            return False
        index_info = self.indexInformation(collection_name)
        indexed_fields = set()
        for values in index_info.values():
            val = values['key']
            indexed_fields.add(val[0][0])
        self.cached_data[collection_name] = list(indexed_fields)
        if field in list(indexed_fields):
            return True
        return False

    def ensureIndex(self, collection, index_fields, options, method=None):
        new_col_name = self.__mongo_to_postgres_name_converter__(collection)
        field_name = []
        index_name = []
        add_direction = True
        if method and method == 'gin':
            add_direction = False
        already_indexed = self.check_already_indexed(new_col_name, index_fields)
        if already_indexed:
            return
        if isinstance(index_fields, list):
            for i in range(len(index_fields)):
                if isinstance(index_fields[i][1], float):
                    index_fields[i][1] = int(index_fields[i][1])

            for field, order in index_fields:
                if str(field).startswith("object."):
                    field = str(field)[len("object."):]
                index_name.append(field)
                direction = " asc" if order == 1 else " desc"
                if add_direction:
                    f_name = '"' + field + '"' + direction
                else:
                    f_name = '"' + field + '"'
                field_name.append(f_name)
        elif isinstance(index_fields, str):
            if str(index_fields).startswith("object."):
                index_fields = str(index_fields)[len("object."):]
            field_name.append('"' + index_fields + '"')
            index_name.append(index_fields)
        else:
            raise GnanaError("index fields should be a list of tuples or a string ")
        if "unique" in options.keys() and (options["unique"] == True or options["unique"] == 1):
            unique = "unique"
        else:
            unique = ""
        index_name = self.get_unique_name(collection, index_name)
        index_name = '"' + index_name + '"'
        if method and method == 'gin':
            using_method = """ USING GIN( %s COLLATE PG_CATALOG."default") """ % " , ".join(field_name)
        else:
            using_method = " ( " + " , ".join(field_name) + " )"
        st = "create " + unique + " index " + index_name + " on " + new_col_name + using_method
        try:
            self.executeDML(collection, st)
        except ProgrammingError as E:
            tbl_not_exist = re.match(r"^relation .+ does not exist", str(E))
            index_already_exist = re.match(r"^relation .+ already exist", str(E))
            column_not_exist = re.match(r"^column.+of relation.+ does not exist", str(E))
            if tbl_not_exist or index_already_exist or column_not_exist:
                pass  # ignoring error, if exception due to table doesnot exist or column not exist
            else:
                raise E

    def dropIndexes(self, collection_name):
        table_name = self.__mongo_to_postgres_name_converter__(collection_name)
        indexes_query = "SELECT ci.relname from pg_index i,pg_class \
                         ci,pg_class ct where i.indexrelid=ci.oid and i.indrelid=ct.oid and\
                         ct.relname='%s'" % (table_name.strip('"'))
        try:
            ret = self.executeDQL(collection_name, indexes_query)
            for i in ret:
                st = 'drop index "%s"' % (i['relname'])
                try:
                    self.executeDML(collection_name, st)
                except Exception as e:
                    logger.exception(e)
        except Exception as e:
            logger.exception(e)

    def truncateCollection(self, name, criteria=None, typed_fields={}):
        name = self.__mongo_to_postgres_name_converter__(name)
        if criteria:
            selection, condition = self.__criteria_processing__(criteria, [], typed_fields=typed_fields)
            return self.executeDML(self.__postgres_to_mongo_name_converter__(name), "delete from  %s %s ;" % (name, condition))
        else:
            return self.executeDML(self.__postgres_to_mongo_name_converter__(name), "delete from %s ;" % (name))

    def insert(self, name, rec_list):
        self.postgres_bulk_execute(rec_list, name)
#         for rec in rec_list:
#             self.saveDocument(name, rec)

    def findDocuments(self, name, criteria, typed_fields=None, fieldlist=None, sort=None, batch_size=None, hint=None,
                      auto_decrypt=True, read_from_tertiary=False, query=None):

        def build_query(name):
            name = self.__mongo_to_postgres_name_converter__(name)
            selector, conditions = self.__criteria_processing__(
                criteria, field_list=fieldlist, typed_fields=typed_fields)
            st = "select %s from %s  %s " % (selector, name, conditions)
            if sort:
                st += " order by "
                sortsets = []
                for sort_keys in sort:
                    if not isinstance(sort_keys, tuple):
                        raise GnanaError("Expected tuple for the sort e.g (field,1)")
                    key = sort_keys[0]
                    key = key.replace('object.', '')
                    value = sort_keys[1] if len(sort_keys) == 2 else 0
                    if value == 1:
                        sortsets.append(str(key) + " ASC ")
                    else:
                        sortsets.append(str(key) + " DESC ")
                st += ",".join(sortsets) + ";"
            return st

        if typed_fields is None:
            typed_fields = {}
        if fieldlist is None:
            fieldlist = []
        if hint:
            logger.info("Postgres doesn't support hint")
        if not query:
            query = build_query(name)
        try:
            if self.__postgres_to_mongo_name_converter__(name).strip('"').startswith(self.sec_context.name):
                self.db = self.tenantawaredb
            else:
                self.db = self.local_postgres_db
            cursor = self.db.cursor()
            cursor.execute(query)
        except ProgrammingError as E:
            row_error = re.match(r"^relation .+ does not exist", str(E))
            if row_error:
                return PostgresDBCursorIterator(None, auto_decrypt, batch_size)
            else:
                raise(E)
        return PostgresDBCursorIterator(cursor, auto_decrypt, batch_size)
    findAllDocuments = findDocuments

    def postgres_query_executor(self, name, statement):
        try:
            if self.__postgres_to_mongo_name_converter__(name).strip('"').startswith(self.sec_context.name):
                self.db = self.tenantawaredb
            else:
                self.db = self.local_postgres_db
            cursor = self.db.cursor()
            cursor.execute(statement)
        except ProgrammingError as E:
            row_error = re.match(r"^relation .+ does not exist", str(E))
            if row_error:
                return {}
            else:
                raise(E)
        return PostgresDBCursorIterator(cursor, auto_decrypt=True)

    def getDistinctValues(self, name, key, criteria={}, encrypted=True):
        name = self.__mongo_to_postgres_name_converter__(name)
        if 'object.' in key:
            key = key.replace('object.', '')
        _, condition = self.__criteria_processing__(criteria)
        ret = self.executeDQL(self.__postgres_to_mongo_name_converter__(
            name), 'select distinct "%s" from %s %s ;' % (key, name, condition))
        if ret:
            ret_vals = []
            for val in ret:
                if isinstance(val[key], list):
                    list_item = []
                    for i in val[key]:
                        list_item.append(i)
                    ret_vals.append(list_item)
                else:
                    ret_vals.append(val[key])
            return ret_vals

    def getMultipleDistinctValues(self, name, keys, criteria={}, encrypted=True):
        name = self.__mongo_to_postgres_name_converter__(name)
        keys_modified = []
        for key in keys:
            key = key.replace('object.', '')
            keys_modified.append(key)
        _, condition = self.__criteria_processing__(criteria)
        distinct_projection = ','.join("\"%s\"" % key for key in keys_modified)
        ret = self.executeDQL(self.__postgres_to_mongo_name_converter__(
            name), 'select distinct %s from %s %s ;' % (distinct_projection, name, condition))
        return ret

    def getAggregateValues(self, collection, pipeline):
        pass

    def dropCollectionsInNamespace(self, name):
        # information schema will be there in both the session and tenant specific databases
        # making this method to use tenant specific database
        self.db = self.tenantawaredb
        with self.db.cursor() as cursor:
            cursor.execute("SELECT table_name FROM information_schema.tables WHERE table_schema = 'public'")
            if cursor.rowcount > 0:
                for row in cursor:
                    if str(row['table_name']).startswith(self.__mongo_to_postgres_name_converter__(name).strip('"')):
                        tablename = '"' + row['table_name'] + '"'
                        self.executeDML(name, "drop table %s ;" % tablename)

    def postgres_table_creator(self, query, collection_name=None):
        # This method is mainly used for creating a postgres table
        # making this method to use tenant specific database
        try:
            if collection_name:
                taware = self.__check_tenant_aware__(collection_name)
                if taware:
                    self.db = self.tenantawaredb
                else:
                    self.db = self.local_postgres_db
            else:
                self.db = self.tenantawaredb
            with self.db.cursor() as cursor:
                cursor.execute(query)
            return {'success': True}
        except Exception as e:
            raise e

    def indexInformation(self, collection):
        def getFromIndexdef(indexdef):
            unique = re.search("(UNIQ\w+)", indexdef)
            unique = True if unique else False
            key_info = re.search('\((.*?)\)', indexdef)
            if key_info:
                key_set = key_info.group(1)
                key_set = key_set.replace(" ", "")
                key_sets = key_set.split(',')
                key_set_tuples = []
                for k in key_sets:
                    k = k.strip(" ")
                    key_set_t = k
                    val = re.search(r'\"(.+?)\"', k)
                    key_set_t = val.group() if val else k
                    if k not in ['_id', 'last_modified_time']:
                        key_set_t = 'object.' + key_set_t.strip('"')
                    key_set_tuples.append((key_set_t, 1))
                index_name = '_id_' if '_id' in key_sets else '~'.join(val.strip('"') for val in key_sets)
            else:
                raise GnanaError("Index value not found from the indexdef")
            return unique, key_set_tuples, index_name
        index_info_stmt = "select * from pg_indexes where tablename = '%s'" % \
            (self.__mongo_to_postgres_name_converter__(collection.lower()).strip('"'))
        try:
            taware = self.__check_tenant_aware__(collection.strip('"'))
            if taware:
                self.db = self.tenantawaredb
            else:
                self.db = self.local_postgres_db
            with self.db.cursor() as cursor:
                cursor.execute(index_info_stmt)
                ret_value = {}
                if cursor.rowcount > 0:
                    row = []
                    for ind in cursor:
                        row.append(ind)
                    for index in row:
                        unique, key, index_name = getFromIndexdef(index['indexdef'])
                        index_name = index_name if index_name else index['indexname']
                        ret_value[index_name] = {}
                        if unique:
                            ret_value[index_name]['unique'] = unique
                        ret_value[index_name]['key'] = key
            return ret_value
        except Exception as e:
            raise GnanaError("Error in getting info : %s" % (e))

    def mongo_op_to_psql_op(self, operator):
        """Takes a mongodb operator and returns equivalent postgresql operator"""
        operator = str(operator).strip()
        if operator == "$eq":
            return "="
        elif operator == "$gt":
            return ">"
        elif operator == "$gte":
            return ">="
        elif operator == "$lt":
            return "<"
        elif operator == "$lte":
            return "<="
        elif operator == "$ne":
            return "!="
        elif operator == "$in":
            return "in"
        elif operator == "$nin":
            return "not in"
        elif operator == "$or":
            return "or"
        elif operator == "$and":
            return "and"
        elif operator == "arrayop":
            # Array contains operator in postgres
            return "@>"
        elif operator == "$regex":
            return "~*"
        else:
            raise GnanaError("invalid operator" + operator)

    def parse_mongo_to_psql(self, query, typed_fields={}):
        try:
            """Parses a mongodb query to postgresql query recursively"""
            for key, value in query.items():
                if key in ['$and', '$or']:
                    if len(value) == 1:
                        return value[0]
                    else:
                        all_conditions = []
                        psql_conditions = []
                        for condition in value:
                            all_conditions.append(condition)
                        for condition in all_conditions:
                            pre_con = condition
                            while True:
                                pre_con = self.parse_mongo_to_psql(pre_con, typed_fields)
                                if isinstance(pre_con, str):
                                    break
                            psql_conditions.append(pre_con)
                        ret_condition = '('
                        for c in psql_conditions[:-1]:
                            ret_condition += c + " " + self.mongo_op_to_psql_op(key) + " "
                        ret_condition += psql_conditions[-1] + ")"
                        return ret_condition
                elif key in ['$in', '$nin', '$eq', '$gt', '$gte', '$lt', '$lte', '$ne']:
                    if key in ['$in', '$nin']:
                        val_list = []
                        for val in value:
                            val = self.encode_values_to_postgres_type(val)
                            val_list.append(val)
                        val_list = str(val_list).replace('[', '(')
                        val_list = str(val_list).replace(']', ')')
                        val_list = val_list.replace("\"", "'")
                        condition = ' ' + self.mongo_op_to_psql_op(key) + " " + val_list
                        return condition
                    else:
                        if isinstance(value, list):
                            value = value[0]
                            value = self.encode_values_to_postgres_type(value)
                        if isinstance(value, datetime):
                            value = self.mogrify_values(value)
                        else:
                            if isinstance(value, int):
                                value = str(value)
                            value = " '" + value + "'"
                        condition = ' ' + self.mongo_op_to_psql_op(key) + value
                        return condition
                else:
                    if(len(query) > 1):
                        return self.parse_mongo_to_psql({"$and": [{k: v} for k, v in query.items()]}, typed_fields)
                    variable = key
                    if 'object' in variable:
                        variable = variable.replace('object.', '')
#                     if isinstance(value, long):
#                         value = str(value)
                    # TODO
                    if isinstance(value, bool):
                        condition = '"' + variable + '"' + " = '" + str(value) + "'"
                        return condition
                    if isinstance(value, int):
                        condition = '"' + variable + '"' + " = '" + str(value) + "'"
                        return condition
                    if len(value) == 1 or isinstance(value, str):
                        if isinstance(value, list):
                            value = value[0]
                        if isinstance(value, str) or isinstance(value, str):
                            value = self.encode_values_to_postgres_type(value)
                            if variable in typed_fields.keys():
                                typed_field_type = typed_fields[variable]['type']
                                is_array = re.search(
                                    "(ARRA\w+)", typed_field_type) or re.search("[\[]", typed_field_type)
                                if is_array:
                                    condition = "".join([
                                        '"', variable, '" ', self.mongo_op_to_psql_op('arrayop'), " '{\"", value, "\"}'"
                                    ])
                                    return condition
                            condition = '"' + variable + '"' + " = '" + value + "'"
                            return condition
                        if isinstance(value, datetime):
                            value = self.mogrify_values(value)
                            condition = '"' + variable + '" = ' + value
                            return condition
                        if isinstance(value, dict):
                            if len(list(value.keys())) == 1 and list(value.keys())[0] == '$regex':
                                r_condition = '"' + variable + '" ' + \
                                    self.mongo_op_to_psql_op('$regex') + " '" + value['$regex'] + "'"
                                return r_condition
                            condition = value
                            while True:
                                condition = self.parse_mongo_to_psql(condition, typed_fields)
                                if isinstance(condition, str):
                                    break
                            ret_condition = '"' + variable + '"' + condition
                            return ret_condition
        except:
            logger.error("Unable to convert query %s", json.dumps(query))
            raise

    def get_columns_from_rec(self, table_data):
        """Takes a record and extract all the columns from it and returns columns list"""
        columns = []
        for key in table_data:
            if key != 'object':
                columns.append('"' + str(key) + '"')
            else:
                for key in table_data['object']:
                    columns.append('"' + str(key) + '"')
        return columns

    def get_value_string(self, rec_list, col_list):
        """Takes list of records and returns a value string which can be used to insert/update"""

        ret_values = [None] * len(rec_list)
        id_val = rec_list[0].get('_id', None)
        if not id_val:
            try:
                col_list.remove('"_id"')
            except:
                pass
        col_idxs = {x[1:-1]: i for i, x in enumerate(col_list)}
        with self.tenantawaredb.cursor() as cursor:
            for i, rec in enumerate(rec_list):
                values = ['null'] * len(col_list)
                for key, value in rec.items():
                    if key != 'object':
                        values[col_idxs[key]] = self.mogrify_values(value, cursor=cursor)
                    else:
                        for key, value in rec['object'].items():
                            values[col_idxs[key]] = self.mogrify_values(value, cursor=cursor)

                ret_values[i] = "(" + ",".join(values) + ")"
        return ",".join(ret_values)

    def postgres_bulk_execute(self, bulk_list, table_name):
        """Takes a list of records to insert into postgresql db and execute in a single shot"""
        if not bulk_list:
            raise GnanaError("No bulk list to execute")
        table_name = self.__mongo_to_postgres_name_converter__(table_name)
        #columns = self.get_columns_from_rec(bulk_list[0])
        columns = self.get_columns_from_pg_table(table_name.strip('"'))
        all_values = self.get_value_string(bulk_list, columns)
        st = "INSERT INTO " + table_name + "(" + ",".join(columns) + ")" + " values " + all_values + ";"
        try:
            return self.executeDML(self.__postgres_to_mongo_name_converter__(table_name), st)
        except Exception as e:
            raise e

    def postgres_bulk_update_string(self, table_name, doc):
        """Takes a record to update and returns an update query"""
        if isinstance(doc, dict):
            doc = [doc]
        columns = self.get_columns_from_pg_table(table_name.strip('"'))
        all_values = self.get_value_string(doc, columns)
        table_name = self.__mongo_to_postgres_name_converter__(table_name)
        st = "update " + table_name + " set " + "(" + ",".join(columns) + ")" + " = " + all_values + " where _id = \
             " + str(doc[0]['_id'])
        return st

    def postgres_bulk_update(self, update_list):
        """Takes a list of update queries and executes them at a time"""
        # This method is used for tenant specific
        if not update_list:
            raise GnanaError("NO list is provided to update")
        try:
            self.db = self.tenantawaredb
            with self.db.cursor() as cursor:
                cursor.execute(";".join(update_list))
                if cursor.rowcount > 0:
                    return cursor.rowcount
        except Exception as e:
            raise e

    def postgres_copy_task(self, table_name, to_name, criteria={}, typed_fields={}, field_list=[], condition=None):
        """Creates a table basing on the existing table and copies all the data from the source table
           if there is no criteria"""
        table_name = self.__mongo_to_postgres_name_converter__(table_name)
        to_name = self.__mongo_to_postgres_name_converter__(to_name)
        # expected that a table is already created.
        fields_query = "SELECT c.column_name FROM information_schema.columns As c WHERE table_name = '%s' AND \
                  c.column_name NOT IN('_id');" % (table_name.strip('"'))
        f_list = []
        try:
            self.db = self.tenantawaredb
            with self.db.cursor() as cursor:
                cursor.execute(fields_query)
                if cursor.rowcount > 0:
                    all_fields = [x for x in cursor]
                    for f in all_fields:
                        f_list.append('"' + f['column_name'] + '"')
                else:
                    raise GnanaError("No fields found in the source table to copy")
        except Exception as e:
            raise e
        ins_stmt = 'insert into %s (%s) select %s from ' % (to_name, (',').join(f_list), (',').join(f_list))
        if condition:
            ins_stmt += condition
        else:
            ins_stmt += table_name

        if criteria:
            selector, condition = self.__criteria_processing__(
                criteria, field_list=field_list, typed_fields=typed_fields)
            ins_stmt += condition
        try:
            ret = self.executeDML(self.__postgres_to_mongo_name_converter__(table_name), ins_stmt)
            return ret
        except ProgrammingError as e:
            raise GnanaError(e)

    def get_columns_from_pg_table(self, column_name):
        column_name = self.__mongo_to_postgres_name_converter__(column_name)
        statement = "SELECT attrelid::regclass, attnum, attname\
                    FROM   pg_attribute\
                    WHERE  attrelid = '%s'::regclass\
                    AND    attnum > 0\
                    AND    NOT attisdropped\
                    ORDER  BY attnum;" % (column_name)
        try:
            ret = self.executeDQL(column_name, statement)
            ret_list = []
            if ret:
                # creating the list with order
                for r in ret:
                    ret_list.insert(r['attnum'], '"' + r['attname'] + '"')
            return ret_list
        except Exception as e:
            raise e

    def postgres_nocommit_connection(self):
        from aviso.settings import POSTGRES_DB_URL # to avoid circular import
        pg_url_parsed = urlparse.urlparse(POSTGRES_DB_URL)
        kwargs = dict(database=pg_url_parsed.path.strip('/'),
                                        user=pg_url_parsed.username,
                                        password=pg_url_parsed.password,
                                        host=pg_url_parsed.hostname,
                                        port=pg_url_parsed.port,
                                        cursor_factory=psycopg2.extras.RealDictCursor)
        postgres_con = psycopg2.connect(**kwargs)
        return postgres_con

    @classmethod
    def get_local_postgres_con(self):
        from aviso.settings import POSTGRES_DB_URL # to avoid circular import
        pg_url_parsed = urlparse.urlparse(POSTGRES_DB_URL)
        postgres_con = psycopg2.connect(database=pg_url_parsed.path.strip('/'),
                                        user=pg_url_parsed.username,
                                        password=pg_url_parsed.password,
                                        host=pg_url_parsed.hostname,
                                        port=pg_url_parsed.port,
                                        cursor_factory=psycopg2.extras.RealDictCursor
                                       )
        postgres_con.set_session(autocommit=True)
        return postgres_con

    def collection_exists(self, collection):
        try:
            postgres_table_name = self.__mongo_to_postgres_name_converter__(collection)
            tenant_aware = self.__check_tenant_aware__(collection.strip('"'))
            if tenant_aware:
                self.db = self.tenantawaredb
            else:
                self.db = self.local_postgres_db
            with self.db.cursor() as cursor:
                st = "SELECT EXISTS (SELECT FROM pg_catalog.pg_class c WHERE  c.relname ='" + \
                    postgres_table_name.strip('"') + "');"
                cursor.execute(st)
                if cursor.rowcount > 0:
                    for row in cursor.fetchall():
                        if row['exists']:
                            return row['exists']
                return False
        except Exception as e:
            raise e

    def critical_section(self, f):
        fn = f

        def new_func(*args, **kwargs):
            debug = kwargs.get('debug', False)
            acquired_lock = False
            try:
                wait_for_lock = kwargs.get('wait_for_lock', False)
                collection = kwargs.get('collection', None)
                lockname = kwargs.get('lockname', None)
                criteria = kwargs.get('criteria', None)
                check_unique = kwargs.get('check_unique', False)
                postgres_con = self.postgres_nocommit_connection()
                try:
                    if not debug:
                        self.acquire_lock(postgres_con, collection, lockname, criteria, check_unique, wait_for_lock)
                        acquired_lock = True
                except Exception as e:
                    raise e
                return fn(*args, **kwargs)
            except Exception as e:
                raise e
            finally:
                if not debug:
                    if acquired_lock:
                        self.release_lock(postgres_con, collection, lockname, criteria)
                else:
                    postgres_con.commit()
        return new_func

    def acquire_lock(self, con, collection, lockname, criteria={}, check_unique=False, wait_for_lock=False):
        try:
            with con.cursor() as cursor:
                try:
                    # cursor.execute('begin;')
                    collection = self.__mongo_to_postgres_name_converter__(collection)
                    if wait_for_lock:
                        st = "SELECT acquire FROM %s WHERE LOCKNAME = '%s' FOR UPDATE" % (collection, lockname)
                    else:
                        st = "SELECT acquire FROM %s WHERE LOCKNAME = '%s' FOR UPDATE NOWAIT" % (collection, lockname)
                    try:
                        ret = cursor.execute(st)
                    except Exception as e:
                        raise e
                    if cursor.rowcount > 0:
                        for row in cursor.fetchall():
                            pass
                    st = "UPDATE %s SET acquire = True WHERE LOCKNAME = '%s' " % (collection, lockname)
                    cursor.execute(st)
                except Exception as e:
                    collection_not_found = re.match(r"^relation .+ does not exist", str(e))
                    if collection_not_found:
                        logger.exception("Collection not found  %s" % str(e))
                    con.rollback()
                    raise e
        except Exception as e:
            raise e

    def release_lock(self, con, collection, lockname, criteria={}):
        try:
            with con.cursor() as cursor:
                try:
                    collection = self.__mongo_to_postgres_name_converter__(collection)
                    st = "UPDATE %s SET acquire = False WHERE LOCKNAME = '%s' " % (collection, lockname)
                    cursor.execute(st)
                except Exception as e:
                    collection_not_found = re.match(r"^relation .+ does not exist", str(e))
                    if collection_not_found:
                        logger.info("Collection not found  %s" % str(e))
                    else:
                        con.rollback()
                        raise e
                finally:
                    con.commit()
        except Exception as e:
            raise e

    def terminate_stuck_locks(self):
        from aviso.domainmodel.tenant import Tenant
        # need to use superuser connection for pg_stat_activity.
        con = Tenant().getPostgresSuperUserConnection()
        try:
            with con.cursor() as cursor:
                st1 = "SELECT pid, now() - pg_stat_activity.query_start AS duration,\
                query, state FROM pg_stat_activity WHERE query LIKE '%lock%' AND \
                (now() - pg_stat_activity.query_start) > interval '15 minutes';"
                try:
                    ret = cursor.execute(st1)
                except Exception as e:
                    raise e
                pids_dropped = []
                if cursor.rowcount > 0:
                    for i in cursor.fetchall():
                        st2 = "SELECT pg_terminate_backend(%s);" % str(i['pid'])
                        cursor.execute(st2)
                        pids_dropped.append(i['pid'])
            return {'success': True, 'pids_dropped': pids_dropped}
        except Exception as e:
            raise e
        finally:
            con.close()


class PostgresDBCursorIterator(object):

    def __init__(self, cursor, auto_decrypt, batch_size=2000):
        from aviso.settings import sec_context
        self.cursor = cursor
        self.auto_decrypt = auto_decrypt
        self.sec_context = sec_context
        self.limitrecs = None

    def hint(self, hint):
        raise GnanaError("hint not applicable for postgres ")

    def limit(self, limit):
        self.limitrecs = limit
        return self

    def skip(self, limit):
        if self.cursor:
            try:
                self.cursor.scroll(limit)
            except Exception as e:
                scroll_error = re.match(r"^scroll destination out of bounds", str(e))
                if scroll_error:
                    self.cursor = None
        return self

    def count(self):
        if self.cursor:
            return self.cursor.rowcount
        else:
            return 0

    def batch_size(self, size):
        if self.cursor:
            self.cursor.itersize = size
        return self

    def next(self):
        try:
            if self.cursor:
                if self.count() > 0:
                    row = self.cursor.fetchone()
                    encrypt = False
                    if '_encdata' in row.keys():
                        encrypt = True
                    record = GnanaPostgresDB.__postgres_row_to_mongo_record__(self, row, self.sec_context, encrypt)
                    return record
        except Exception as e:
            logger.exception(e)
            self.close()
            raise e

    def __iter__(self):
        try:
            if self.cursor:
                if self.count() > 0:
                    for i, row in zip(count(), self.cursor):
                        if self.limitrecs and i == self.limitrecs:
                            break
                        encrypt = False
                        if '_encdata' in row.keys():
                            encrypt = True
                        record = GnanaPostgresDB.__postgres_row_to_mongo_record__(row, self.sec_context, encrypt)
                        yield record
        except Exception as e:
            logger.exception(e)
            raise(e)
        finally:
            self.close()

    def close(self):
        try:
            if self.cursor:
                self.cursor.close()
        except Exception as e:
            logger.exception("Cursor is not closed due to %s" % (e))