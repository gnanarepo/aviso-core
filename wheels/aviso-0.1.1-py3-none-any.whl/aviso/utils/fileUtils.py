import os
import json
import time
import pprint
import shutil
import tarfile
import hashlib
import logging
import tempfile
import functools
from subprocess import Popen, PIPE, STDOUT

import boto
from boto.s3.key import Key

from aviso.utils import mkdir_p
from aviso.utils import GnanaError
from aviso.settings import gnana_storage, ISPROD
from aviso.settings import TMP_DIR, sec_context, BACKUP_CONFIG

logger = logging.getLogger('gnana.%s' % __name__)


def retry(retries=3):
    def retry_decorator(f):
        def wrapper(*args, **kwargs):
            for i in range(retries):
                try:
                    ret = f(*args, **kwargs)
                    break
                except Exception as e:
                    logger.exception("__func__  %s failed! :-( " % (f.__name__))
                    wait_time = (i + 1) * 30
                    logger.info("Waiting for %d seconds before retrying %s" % (wait_time, f.__name__))
                    time.sleep(wait_time)
                    if i == 2:
                        raise e
                    pass
            return ret
        return wrapper
    return retry_decorator


def filemd5(filename, block_size=2**20):
    f = open(filename)
    md5 = hashlib.md5()
    while True:
        data = f.read(block_size)
        if not data:
            break
        md5.update(data)
    f.close()
    return md5.hexdigest()


def progress_callback(up_down, bytes_transmitted, total_bytes):
    logger.info("Completed %2f.0%% of the %s" % (float(bytes_transmitted * 1000/total_bytes)/10, up_down))


def bucket_acc(directory_name, filename, key_name, autodelete=False, download=False, upload=False,
               retries = 3):
    s3Connect = boto.connect_s3()

    bucket = s3Connect.get_bucket('aviso-tenant-copy', validate=False)

    # EV Nov 17, 2014: This logic is not correct.  You want exactly one of
    # download, upload or autodelete to be true.  It will require more
    # combinations
    if not (download or upload or autodelete):
        raise Exception('Either upload or download must be True')
    if (download and upload and autodelete):
        raise Exception('Both upload or download can not be True')

    if upload:
        k = Key(bucket)
        k.key = key_name + "/"+filename
        if k.key:
            expanded_path = os.path.expanduser(directory_name+"/" + filename)
            k.set_contents_from_filename(
                expanded_path,
                cb=functools.partial(progress_callback, 'upload'),
                num_cb=21)

    if download:
        for i in range(retries):
            total_size = 0
            k = bucket.get_key(key_name + "/" + filename)
            if os.path.exists(directory_name + "/" + filename):
                remote_checksum = k.etag[1:-1]
                local_file_md5 = filemd5(os.path.join(directory_name, filename))
                if local_file_md5 == remote_checksum:
                    return True
                else:
                    os.remove(os.path.join(directory_name, filename))
            expanded_directoryname = os.path.expanduser(directory_name + "/" + filename)
            try:
                logger.info("Attempt : %d " % (i + 1))
                total_size = k.size
                k.get_contents_to_filename(
                    expanded_directoryname,
                    cb=functools.partial(progress_callback, 'download'),
                    num_cb=21)
                break
            except Exception as e:
                logger.info("Restore failed due to %s" % (e))
                logger.info("Bucket Size: %d " % (total_size))
                wait_time = (i + 1) * 30
                logger.info("Waiting for %d seconds before retrying" % (wait_time))
                time.sleep(wait_time)
                if i == 2:
                    raise e
                pass

    if autodelete:
            bucket.delete_key(key_name+"/"+filename)
    return True

upload_to_s3 = functools.partial(bucket_acc, upload=True)
download_from_s3 = functools.partial(bucket_acc, download=True)
delete_from_s3 = functools.partial(bucket_acc, autodelete=True)


def tar_cmd(directory_name, tar_file, file_to_add, tar=False, untar=False):
    if not (tar or untar):
        raise Exception('Either tar or untar must be True')
    if tar and untar:
        raise Exception('Both tar and untar can not be True')

    if tar:
        tarf = tarfile.open(directory_name+'/'+tar_file, 'w:gz')
        tarf.add(directory_name+"/"+file_to_add, file_to_add)
        tarf.close()
    elif untar:
        tarf = tarfile.open(directory_name+'/'+tar_file)
        tarf.extractall(path=directory_name)
        tarf.close()
    else:
        raise Exception('Neither tar, not untar')
    return True


tar = functools.partial(tar_cmd, tar=True)
extract = functools.partial(tar_cmd, untar=True)


def gpg_cmd(directory_name, pass_phrase, tar_base_filename, enc_base_filename, enc=False, dec=False):
    def execute(cmd):
        retrieve_process = Popen(cmd, stdout=PIPE, stderr=STDOUT)
        exit_code = retrieve_process.wait()
        output = retrieve_process.communicate()[0]
        return (exit_code, output)

    if not (enc or dec):
        raise Exception('Either enc or dec must be True')
    if enc and dec:
        raise Exception('Both enc and dec can not be True')

    tfname = directory_name+"/pass_phrase"
    with open(tfname, 'w') as f:
        f.write(pass_phrase)
    cmd = ''
    if enc:
        cmd = ["gpg", "--no-tty", "--yes", "--passphrase-fd", '1', "--passphrase-file",  os.path.expanduser(tfname),
               "-c", "--symmetric", "--cipher-algo", "aes256", "-o", directory_name+"/" + enc_base_filename,
               directory_name+"/" + tar_base_filename]
    if dec:
        cmd = ["gpg", "--no-tty", "--yes", "--passphrase-fd", '1', "--passphrase-file",  os.path.expanduser(tfname),
               "-o", directory_name+"/" + tar_base_filename, "--decrypt", directory_name + "/" + enc_base_filename]

    (exit_code, output) = execute(cmd)

    if (exit_code):
        # Retry one more time
        logger.info("GPG Retry one more time...")
        (exit_code, output) = execute(cmd)

    if exit_code:
        raise Exception('GPG Command failed. Command = [{cmd}], Exit = [{exit_code}], Output=[{output}]'.format(**locals()))
    return True

encrypt_file = functools.partial(gpg_cmd, enc=True)
decrypt_file = functools.partial(gpg_cmd, dec=True)


def backup_dataset(username, ds, inbox_name):
    attrs = {}
    ds.encode(attrs)
    for ft in attrs['filetypes']:
        try:
            del ft['last_approved_time']
            del ft['last_dd_time']
        except KeyError:
            pass
    backup = json.dumps(ds.get_as_map())
    fp = tempfile.NamedTemporaryFile(prefix='dataset', delete=False)
    fp.write(backup.encode())
    fp.close()
    gnana_storage.add_adhoc_file(username,
                                 "_".join([inbox_name, str(time.time())]),
                                 fp.name, dataset=ds.name)
    os.unlink(fp.name)


@retry(3)
def process_shell_command(path, process_command_list, command):
        try:
            process_cmd = Popen(process_command_list, cwd=path, stdout=PIPE)
            exit_code = os.waitpid(process_cmd.pid, 0)
            output = process_cmd.communicate()[0]
            if exit_code[1] != 0:
                logger.info("command:%s :error:%s", command, str(output))
                raise GnanaError("command:%s :error:%s" % (command, str(output)))
            return
        except:
            raise


def pull_config_repo():
    try:
        repopath = os.environ.get('CONFIG_REPO', '/opt/gnana/config')
        logger.info("Pulling the repo")
        process_shell_command(repopath, ["git", "pull"], "pull")
        logger.info("repo pulled")
    except:
        logger.warning("Problem in pulling config repository ")
        raise


def get_git_content(filename):
    content = {}
    if ISPROD or BACKUP_CONFIG:
        try:
            repopath = os.environ.get('CONFIG_REPO', '/opt/gnana/config')
            pull_config_repo()
            tenantpath = "/" . join([repopath, sec_context.name])
            logger.info("tenantpath: " + tenantpath)
            filepath = "/" . join([sec_context.name, filename])
            logger.info("filepath: " + filepath)
            if os.path.exists(tenantpath + "/" + filename):
                with open(repopath + "/" + filepath, "r") as f:
                    content = eval("".join(f.readlines()))
        except:
            logger.exception("Exception in reading content from config repository")
    return content


def gitbackup_dataset(file_name, content, comment):
    status = True
    git_errors = None

    if ISPROD or BACKUP_CONFIG:
        try:
            repopath = os.environ.get('CONFIG_REPO', '/opt/gnana/config')
            pull_config_repo()
            tenantpath = "/" . join([repopath, sec_context.name])
            logger.info("tenantpath: " + tenantpath)
            filepath = "/" . join([sec_context.name, file_name])
            logger.info("filepath: " + filepath)
            if not os.path.exists(tenantpath):
                os.mkdir(tenantpath)
                logger.info("Created folder with tenant name")
            with open(repopath + "/" + filepath, "w") as f:
                try:
                    f.write(pprint.pformat(content, indent=2))
                except Exception as ex:
                    logger.warning("Exception %s .Use json.loads() to get python representation of string value in config repository" % ex)
                    f.write(json.dumps(content))
            logger.info("Writing to file completed")
            logger.info("adding the file")
            process_shell_command(repopath, ["git", "add", filepath], "add")
            logger.info("Added file to the repo")
            process_shell_command(repopath, ["git", "commit", "-m", comment], "commit")
            logger.info("repo committed")
            logger.info("pushing the repo")
            process_shell_command(repopath, ["git", "push"], "push")
            logger.info("config repo updated")
        except Exception as e:
            logger.warning("Problem in updating config repository ")
            git_errors = "Problem in updating config repository %s" % e
            logger.info(git_errors)
            status = False

    return (status, git_errors)


class TempDirectory():
    def __init__(self, debug, cachedir):
        self.preset_directory = None
        self.directory_name = None
        if debug and cachedir is not None:
            self.preset_directory = cachedir

    def __enter__(self):
        if self.preset_directory:
            # if not os.path.exists(self.preset_directory):
            mkdir_p(self.preset_directory)
            return self.preset_directory
        else:
            self.directory_name = tempfile.mkdtemp(dir=TMP_DIR)
            return self.directory_name

    def __exit__(self, errortype, error, traceback):
        if self.directory_name:
            shutil.rmtree(self.directory_name)