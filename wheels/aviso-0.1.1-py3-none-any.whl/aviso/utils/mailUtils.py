import os
import logging
import smtplib
import jinja2
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication

from aviso import settings
from aviso.utils import is_prod

logger = logging.getLogger('gnana.%s' % __name__)


def format_datetime(value, formt='date'):
    if not value:
        return "No Date time"

    if formt == 'date':
        return value.strftime('%Y-%m-%d')
    elif formt == 'datetime':
        return value.strftime('%Y-%m-%d at %H:%M')


def aviso_support(value, include_user=False):
    value = value.split('@')
    if 'administrative.domain' in value:
        if include_user:
            return "Aviso Support (%s)" % value[0]
        else:
            return "Aviso Support"
    else:
        return value[0]


def send_mail(subject, body, sender, tolist, reply_to=None, cclist=None, bcclist=None, is_html=False,
              attachments=None, mimetype=None):
    """
    Refactored to use smtplib and email.mime instead of Django.
    """
    if attachments and not is_html:
        raise Exception('Attachments allowed only with HTML mail')

    # Ensure lists are lists
    if not (isinstance(tolist, list) or isinstance(tolist, tuple)):
        raise Exception('To must be a list or tuple')

    if settings.DEBUG:
        logger.info(body)
        print("This mail content is being printed on console, \
                since DEBUG is enabled. DEBUG should be false in production")
        print("Mail: " + subject)
        print("Sender: " + sender)
        print("To: " + ", ".join(tolist))
        if cclist:
            print("cc: " + ", ".join(cclist))
        if bcclist:
            print("bcc: " + ", ".join(bcclist))
        print("Body: \n")
        print(body)

        if attachments:
            for name, text in attachments.items():
                print("\n\n%s" % name)
                print("-" * len(name))
                print(text)
        return

    try:
        msg = MIMEMultipart('mixed')
        msg['Subject'] = subject
        msg['From'] = sender
        msg['To'] = ", ".join(tolist)
        if cclist:
            msg['Cc'] = ", ".join(cclist)
        if reply_to:
            msg['Reply-To'] = reply_to

        if is_html:
            alt_part = MIMEMultipart('alternative')

            text_part = MIMEText("This mail is in HTML Format. \
                                Please enable HTML for your client to see the message", 'plain')
            html_part = MIMEText(body, 'html')

            alt_part.attach(text_part)
            alt_part.attach(html_part)

            msg.attach(alt_part)
        else:
            msg.attach(MIMEText(body, 'plain'))

        if attachments:
            msg_mimetype = mimetype if mimetype else 'text/plain'
            main_type, sub_type = msg_mimetype.split('/', 1)

            for name, content in attachments.items():
                if main_type == 'text':
                    part = MIMEText(content, _subtype=sub_type)
                else:
                    part = MIMEApplication(content)

                part.add_header('Content-Disposition', 'attachment', filename=name)
                msg.attach(part)

        recipients = list(tolist)
        if cclist:
            recipients.extend(cclist)
        if bcclist:
            recipients.extend(bcclist)

        email_host = getattr(settings, 'EMAIL_HOST', 'localhost')
        email_port = getattr(settings, 'EMAIL_PORT', 25)
        email_user = getattr(settings, 'EMAIL_HOST_USER', None)
        email_pass = getattr(settings, 'EMAIL_HOST_PASSWORD', None)
        use_tls = getattr(settings, 'EMAIL_USE_TLS', False)

        server = smtplib.SMTP(email_host, email_port)

        if use_tls:
            server.starttls()

        if email_user and email_pass:
            server.login(email_user, email_pass)

        # Send
        server.sendmail(sender, recipients, msg.as_string())
        server.quit()

        logger.info("Mail sent successfully: %s", subject)
        return 1  # Return 1 to match Django's success signature

    except Exception:
        logger.exception("You might not have right mail configuration, \
                        or may be your sendmail deamon is not running")
        return 0


def send_mail2(fname, sender, tolist, is_html=False, **kwargs):
    reply_to = kwargs.pop('reply_to', None)
    cclist = kwargs.pop('cclist', None)
    template_engine = kwargs.pop('template_engine', 'python')
    # attachment accespted as dict {'name':'streaming text(fp.read())'}
    attachments = kwargs.pop('attachments', {})

    bcclist = ['aviso.admin@aviso.com']
    addbcc = False
    for mails in tolist:
        if mails.split('@')[1] != 'aviso.com':
            addbcc = True

    cname = settings.CNAME_DISPLAY_NAME if settings.CNAME_DISPLAY_NAME else settings.CNAME
    if settings.CNAME == 'localhost':
        kwargs['server_name'] = 'localhost'
    else:
        tenant_name = settings.sec_context.name
        host_addition = tenant_name.split('.', 1)[0]
        host_addition = host_addition.replace('_', '-')
        kwargs['server_name'] = host_addition + "." + cname + ".aviso.com"

    subject_line = None
    with open(os.path.join(settings.SITE_ROOT, 'mails', fname), 'r') as fp:
        try:
            subject_line = fp.readline()

            if template_engine == 'python':
                subject = subject_line.format(**kwargs).strip()
                body = fp.read().format(**kwargs)
            elif template_engine == 'jinja':
                jinja_env = jinja2.Environment(loader=jinja2.DictLoader({
                    'subject': subject_line,
                    'body': fp.read()
                }))
                jinja_env.filters['datetime'] = format_datetime
                jinja_env.filters['aviso_support'] = aviso_support
                subject = jinja_env.get_template("subject").render(**kwargs).strip()
                body = jinja_env.get_template("body").render(**kwargs)
            else:
                raise Exception("Unknown template '%s' engine for mails" % template_engine)

            if addbcc and is_prod():
                send_mail(subject, body, sender, tolist, reply_to=reply_to, cclist=cclist, bcclist=bcclist,
                          is_html=is_html, attachments=attachments)
            else:
                send_mail(subject, body, sender, tolist, reply_to=reply_to, cclist=cclist, is_html=is_html,
                          attachments=attachments)
        except Exception as e:
            logger.exception('kwargs %s - %s - subject %s' % (kwargs, e, subject_line))
            raise e