import collections
import json
import traceback
import json
import os
import logging
import itertools
import time
import functools
import datetime
from subprocess import Popen, PIPE
import zlib
import base64
from _collections import defaultdict

logger = logging.getLogger(__name__)

retries = 3


def is_prod():
    from aviso.settings import CNAME
    if CNAME in ['etl-ms', 'gbm1-ms', 'gbm2-ms', 'app']:
        return True
    return False


def decode_index_name(name):
    try:
        return zlib.decompress(base64.b64decode(name))
    except:
        logger.warn("decode index field failed with traceback" +
                    traceback.format_exc(10))
        return None


def mkdir_p(path):
    if os.path.exists(path):
        if os.path.isdir(path):
            return
        else:
            raise OSError("A file already exist at the specified path")
    else:
        # Make sure parent exists or created
        parent = os.path.dirname(path)
        mkdir_p(parent)

        # Create the directory
        os.mkdir(path)

def update_dict(dict1, dict2):
    ''' Update dict1 with dict2, and remove any item that is None safely '''
    for k1, v1 in dict2.items():
        if v1 is not None:
            dict1[k1] = v1
        else:
            dict1.pop(k1, None)

class GnanaError(Exception):

    def __init__(self, info, http_status=230):
        self.details = {}
        try:
            self.http_status = int(http_status)
        except ValueError:
            raise Exception("Unable to create GnanaError due to bad http_status")

        if(isinstance(info, str)):
            self.details['_error'] = info
        elif(isinstance(info, dict)):
            self.details.update(info)
        else:
            self.details['_additional_info'] = info

        # Supply a default error
        if(not '_error' in self.details):
            self.details['_error'] = self.__class__.__name__
        # Added message to support default usage of exception in logs
        self.message = str(self.details)

    def get_error(self):
        return self.details['_error']

    def http_response(self):
        return {
            "status": self.http_status,
            "headers": {
                "Content-Type": "application/json"
            },
            "body": json.dumps(self.details)
        }

TRUE_VALUES = {'true', '1', 'yes', 'yeah', 'si',
               'youbet', 'good', 'positive'}

def is_true(bool_like):
    if(isinstance(bool_like, str)):
        return bool_like.lower() in TRUE_VALUES
    if bool_like:
        return True
    return False

def memory_usage_resource():
    try:
        import resource
        import sys
        rusage_denom = 1024.
        if sys.platform == 'darwin':
            # ... it seems that in OSX the output is different units ...
            rusage_denom *= rusage_denom
        mem = resource.getrusage(
            resource.RUSAGE_SELF).ru_maxrss / rusage_denom
        return mem
    except Exception as e:
        logger.warn('Memrory usage failed with exception %s' % e)
        return -1

def diff_rec(left,
             right,
             ignore_keys={},
             comp_mode='dp',
             precision=6):
    '''
    Given two generic structures left and right, this will return
    a map showing their diff. It uses recursive drill down, so do
    not use on structures which have big depth!

    ignore_keys:
        set of keys to be ignored during comparison

    Global variables used by diff_rec:

    comp_mode:
        Numerical comparison modes. Must be one of
            - sf : significant figures
            - dp : decimal places
            - pc : percentage change
    precision:
        precision depending on the mode:
        if comp_mode='sf' then significant figures to round to before comparison
        if comp_mode='dp' then decimal places to round to before comparison
        if comp_mode='pc' then percentage change required to trigger diff
    '''
    ignore_keys = set(ignore_keys)

    def diff_rec_(left,
                  right):
        diffs = {}
        left_is_dict = isinstance(left, dict)
        right_is_dict = isinstance(right, dict)
        if left_is_dict and right_is_dict:
            left_keys = set(left.keys())
            right_keys = set(right.keys())
            shared_keys = left_keys & right_keys - ignore_keys
            only_in_left_keys = left_keys - right_keys - ignore_keys
            only_in_right_keys = right_keys - left_keys - ignore_keys
            map_diffs = {}
            for key in shared_keys:
                res = diff_rec_(left[key], right[key])
                if res:
                    if 'ValDiff' not in map_diffs:
                        map_diffs['ValDiff'] = {}
                    map_diffs['ValDiff'][key] = res
            if only_in_left_keys:
                tmp_map = {}
                for k in only_in_left_keys:
                    tmp_map[k] = left[k]
                map_diffs['OnlyInLeft'] = tmp_map
            if only_in_right_keys:
                tmp_map = {}
                for k in only_in_right_keys:
                    tmp_map[k] = right[k]
                map_diffs['OnlyInRight'] = tmp_map
            if map_diffs:
                diffs = map_diffs
            # do dict compare
        elif not left_is_dict and not right_is_dict:
            left_is_iterable = hasattr(left, '__iter__')
            right_is_iterable = hasattr(right, '__iter__')
            if isinstance(left, str):
                left_is_iterable = False
            if isinstance(right, str):
                right_is_iterable = False
            if left_is_iterable and right_is_iterable:
                iterable_diffs = {}
                idx = -1
                for item1, item2 in itertools.zip_longest(left, right):
                    idx += 1
                    res = diff_rec_(item1, item2)
                    if res:
                        iterable_diffs[idx] = res
                if iterable_diffs:
                    diffs = iterable_diffs
            elif not left_is_iterable and not right_is_iterable:
                if left != right:
                    if comp_mode == 'sf':
                        try:
                            left_num = ('%%.%dg' % (int(precision))) % (left)
                            right_num = ('%%.%dg' % (int(precision))) % (right)
                            if left_num != right_num:
                                diffs = (left, right, right - left)
                        except:
                            diffs = (left, right)
                    elif comp_mode == 'dp':
                        try:
                            left_num = ('{0:.%sf}' % (int(precision))).format(float(left))
                            right_num = ('{0:.%sf}' % (int(precision))).format(float(right))
                            if left_num != right_num:
                                diffs = (left, right, right - left)
                        except:
                            diffs = (left, right)
                    elif comp_mode == 'pc':
                        try:
                            if abs(right - left) / float(abs(left)) >= precision:
                                diffs = (left, right, right - left)
                        except:
                            diffs = (left, right)
                    else:
                        raise Exception("comp_mode='%s' not supported" % (comp_mode))
            else:
                diffs = (left, right)
        else:
            diffs = (left, right)
        return diffs

    return diff_rec_(left, right)

worker_pool = os.environ.get('WORKER_POOL', None)
if worker_pool:
    queue_name = lambda basename: "%s_%s" % (worker_pool, basename)
else:
    queue_name = lambda basename: basename

# def worker_availability(name):
#     for i in range(retries):
#         try:
#             q = inspect().active_queues()
#             if not q:
#                 return False
#             for key in q:
#                 for ins in q[key]:
#                     if name == str(ins['name']):
#                         return True
#             return False
#         except Exception as e:
#             wait_time = (i + 1) * 5
#             if i == (retries - 1):
#                 raise e
#             logger.info("Retry - %s worker_availability failed with %s Waiting for %d seconds" % ((i + 1), e, wait_time))
#             time.sleep(wait_time)

def get_mixpanel_id():
    return os.environ.get('MIXPANELID', None)


def mixpanel_request(url, data):
    try:
        data = base64.b64encode(json.dumps(data))
        return requests.post('{url}?data={data}'.format(url=url, data=data))
    except Exception:
        logger.exception("Could not log a mixpanel event")


def mixpanel_engage(user):
    mixpanelid = get_mixpanel_id()
    if (user.username in ('none', '', None) or
            user.username.endswith('administrative.domain') or
            not mixpanelid):
        return
    data = {'$distinct_id': user.username,
            '$token': mixpanelid,
            '$ignore_time': False,
            '$set': {'Role': 'Customer' if user.is_customer else 'Internal',
                     'User Role': user.user_role_label,
                     '$email': user.username,
                     '$name': user.username,
                     '$last_login': datetime.datetime.utcnow().isoformat()}}
    return mixpanel_request('https://api.mixpanel.com/engage/', data)


def log_to_mixpanel(user, event):
    mixpanelid = get_mixpanel_id()
    if (user.username in ('none', '', None) or
            user.username.endswith('administrative.domain') or
            not mixpanelid):
        return
    data = {'event': event,
            'properties': {'distinct_id': user.username,
                           'token': mixpanelid,
                           'user': user.username,
                           'email': user.username}}
    return mixpanel_request('https://api.mixpanel.com/track/', data)


def mkdir(p):
    try:
        os.mkdir(p)
    except OSError as e:
        if(e.errno == errno.EEXIST):
            pass
        else:
            raise


def reversemap(map_dict):
    reverse_map = {}
    for k, v in map_dict.items():
        str_v = str(v)
        if(not str_v in reverse_map):
            reverse_map[str_v] = []
        reverse_map[str_v].append(k)

    return reverse_map


def forwardmap(map_dict):
    forward_map = {}
    for k, v in map_dict.items():
        for values in v:
            forward_map[values] = k
    return forward_map


def update_nested_dict(dict1, dict2):
    '''Update dict1 with values from dict2.

    If a certain value is a dict in dict2, it is expected to be either not
    present or dict in dict1.
    '''
    for k, v in dict2.items():
        if isinstance(v, dict) and k in dict1:
            update_dict(dict1[k], v)
        else:
            if v is not None:
                dict1[k] = v
            else:
                dict1.pop(k, None)



TRUE_VALUES = {'true', '1', 'yes', 'yeah', 'si',
               'youbet', 'good', 'positive'}
retries = 3



def nested_default_dict(depth, t):
    """ Returns a dict with given depth where the leaf type is t.
    For example ``nested_default_dict(1, int)`` returns a dictionary where
    the first level defaults to dict and second level to int. For example
    counts['category']['counter'] += 10 will work as expected.
    """
    partial_func = functools.partial(collections.defaultdict, t)
    for t in range(depth):
        partial_func = functools.partial(collections.defaultdict, partial_func)
    return partial_func()


def nested_dict_iterator(dict_type_object, depth, tuple_prefix=tuple(), match_depth=True):
    for k, v in dict_type_object.items():
        if depth <= 1:
            yield tuple_prefix + (k, v)
        else:
            if isinstance(v, dict):
                for x in nested_dict_iterator(v, depth - 1, tuple_prefix + (k,)):
                    yield x
            else:
                if not match_depth:
                    yield tuple_prefix + (k, v)


def get_sf_session(oauthmeta):
    sf_url = '{url}?response_type=token&client_id={client_id}&redirect_uri={redirect_uri}\
             '.format(url=oauthmeta['authorize_url'],
                      client_id=oauthmeta['customer_key'],
                      redirect_uri=oauthmeta['callbackurl'])
    return (sf_url)



def sf_prompt_error(error_obj):
        if isinstance(error_obj, (SalesforceError)):
            err_msg = 'Error while updating salesforce'
            for content in error_obj.content:
                err_msg += '\n %s' % content.get('message', '')
                if 'fields' in content and content['fields']:
                    err_msg += 'for fields: %s' % content['fields']
        else:
            err_msg = 'INTERNAL SERVER ERROR'
        return err_msg


class CSVStreamer:

    ''' Provides file-like access. This batches the response into
    specified size, so we are not streaming individual row.
    '''

    def __init__(self, dataProvider, batchSize=500):
        self.dataProvider = dataProvider
        self.batchSize = batchSize
        self.data = []      # Each 'line' is an element in array.

    def __getitem__(self, key):
        if self.data:
            return ''.join(self.data)
        raise IndexError

    def __iter__(self):
        return self

    def next(self):
        del self.data[:]
        self.data = []
        idx = 0
        for rec in self.dataProvider:
            self.data.append(rec)
            idx += 1
            if idx == self.batchSize:
                break
        if self.data:
            return ''.join(self.data)
        raise StopIteration

class ProcessVeto(GnanaError):
    pass

def get_file_git_version(site_root, path=None):
    cmd = "git log -1 --pretty=format:%h --no-merges"
    if path:
        cmd += " {}".format(path)
    try:
        process = Popen(cmd, stdout=PIPE, cwd=site_root, shell=True, env=os.environ)
        output = process.communicate()[0]
        return output.strip()
    except Exception as e:
        logger.exception(str(e))
        return 'unknown'

def get_current_results(res_cls, cache_key):
    current_results = res_cls.getAllByFieldValue('run_time_horizon', 'custom_%s' % cache_key)
    result_cache = defaultdict(list)
    for d in current_results:
        result_cache[d.extid].append(d)
    logger.info("count %s of results in current %s", len(result_cache), cache_key)
    return result_cache

mongo_operator_map = {'in': '$in', 'nin': '$nin',
                        'lte': '$lte', 'lt': '$lt',
                        'gte': '$gte', 'gt': '$gt'}

def get_mongo_criteria(criteria):
    # this is to add $ symbol in criteria
    ret_criteria = {}
    for fld in criteria:
        ret_criteria[fld] = {}
        for op in criteria[fld]:
            ret_criteria[fld][mongo_operator_map.get(op, op)] = criteria[fld][op]
    return ret_criteria

is_none = lambda x: x == 'None' or x == 'none' or x == None or x == []