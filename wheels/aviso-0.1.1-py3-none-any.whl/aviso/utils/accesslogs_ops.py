import netaddr
from aviso.settings import ACCESSLOG, CNAME
from accesslogs.models import LogsConfiguration


def access_logs(username,ip,message,level,event, target='N/A'):
    if ACCESSLOG:
        logs_obj = LogsConfiguration()
        logs_obj.username = username
        logs_obj.ip = ip
        logs_obj.message = message
        logs_obj.level = level
        logs_obj.event = event
        logs_obj.logdate = None
        logs_obj.target = target
        logs_obj.cname = CNAME
        logs_obj.save(using='logs_access')


def get_remote_ip(request):
    remote_ip = request.META.get('HTTP_X_FORWARDED_FOR')
    if(remote_ip):
        remote_ip = remote_ip.split(',')[-1]
    else:
        remote_ip = request.META["REMOTE_ADDR"]
    return remote_ip


def ip_match(ip, valid_ip_list):
    ip = netaddr.IPAddress(ip)
    for n in valid_ip_list:
        if '/' in n:
            nw = netaddr.IPNetwork(n)
        else:
            nw = netaddr.IPNetwork(n+'/32')
        if ip in nw:
            return n
    return None