###############################################################################
#       Copyright Gnana, Inc 2012
#       All rights reserved
#       This code may not be used without written permission from Gnana, Inc.
#       Hessam Tehrani July 2012
###############################################################################

import collections
import logging
import re
from datetime import datetime, timedelta, date
from itertools import chain

import numpy as np
import pytz
from dateutil.relativedelta import relativedelta

from aviso.settings import sec_context
from aviso.utils.cache_utils import memcached

logger = logging.getLogger('gnana.%s' % __name__)

excelBase = datetime(1899, 12, 30, 0, 0, 0)
excelBaseDate = date(1899, 12, 30)
base_epoch = datetime(1970, 1, 1, tzinfo=pytz.utc)
onems = timedelta(milliseconds=1)

CAL_MONTHS = ['', 'January', 'February', 'March', 'April', 'May', 'June',
              'July', 'August', 'September', 'October', 'November', 'December']
WEEK_DAYS = ['Monday', 'Tuesday', 'Wednesday',
                            'Thursday', 'Friday', 'Saturday', 'Sunday']

# lambdas for convenience
datetime2xl = lambda dt: EpochClass.from_datetime(dt).as_xldate()
datetime2epoch = lambda dt: EpochClass.from_datetime(dt).as_epoch()
datetime2pytime = lambda dt: EpochClass.from_datetime(dt).as_pytime()
datetime2str = lambda dt, dt_format='%Y-%m-%d': dt.strftime(dt_format)

xl2datetime = lambda xl_dt: EpochClass.from_xldate(xl_dt).as_datetime()
xl2epoch = lambda xl_dt: EpochClass.from_xldate(xl_dt).as_epoch()
xl2pytime = lambda xl_dt: EpochClass.from_xldate(xl_dt).as_pytime()

# if you excel date is in tenant time zone, you should use below conversions
xl2datetime_ttz = lambda xl_dt: EpochClass.from_xldate(xl_dt, False).as_datetime()
xl2epoch_ttz = lambda xl_dt: EpochClass.from_xldate(xl_dt, False).as_epoch()
xl2pytime_ttz = lambda xl_dt: EpochClass.from_xldate(xl_dt, False).as_pytime()

epoch2datetime = lambda ep: EpochClass.from_epoch(ep).as_datetime()
epoch2pytime = lambda ep: EpochClass.from_epoch(ep).as_pytime()
epoch2xl = lambda ep: EpochClass.from_epoch(ep).as_xldate()

pytime2datetime = lambda ep: EpochClass.from_pytime(ep).as_datetime()
pytime2epoch = lambda ep: EpochClass.from_pytime(ep).as_epoch()
pytime2xl = lambda ep: EpochClass.from_pytime(ep).as_xldate()

datestr2xldate = lambda closedDate: EpochClass.from_string(cleanmmddyy(closedDate),
                                                           '%m/%d/%Y',
                                                           timezone='tenant').as_xldate()

fuzzydateinput2xldate = lambda date: fuzzydateinput(date).as_xldate()

ALL_PERIODS_CACHE = {}
ALL_PERIOD_RANGES_CACHE = {}

period = collections.namedtuple("period", ["mnemonic", "begin", "end"])

class EpochClass(object):
    """ epoch function returns an object of this type which can be used as long for all
    computations. However printing the values will result in displaying the value
    as a date time in the timezone preference based on the shell.
    """

    def __init__(self, ts=None):
        self.timezone = get_tenant_timezone()
        if ts is None:
            import time
            ts = time.time()
        self.ts = ts

    def __str__(self):
        return "%s" % datetime.fromtimestamp(self.ts, self.timezone)

    __repr__ = __str__

    def as_datetime(self):
        return datetime.fromtimestamp(self.ts, self.timezone)

    def as_xldate(self):
        d = self.as_datetime()
        d = d.astimezone(pytz.utc)
        e = datetime(d.year, d.month, d.day, d.hour, d.minute, d.second, d.microsecond)
        delta = e - excelBase
        return delta.days + (float(delta.seconds) / (3600 * 24))

    def as_tenant_xl_int(self):
        '''
        Useful for passing to the holidays which are defined as tenant excel date integers
        '''
        d = self.as_datetime()
        e = datetime(d.year, d.month, d.day, d.hour, d.minute, d.second, d.microsecond)
        delta = e - excelBase
        return delta.days

    def as_pytime(self):
        return self.ts

    def as_epoch(self):
        return int(self.ts * 1000)

    def __eq__(self, other):
        if isinstance(other, EpochClass):
            return self.ts == other.ts
        elif isinstance(other, (int)):
            return self.as_epoch() == other
        elif isinstance(other, datetime):
            if not other.tzinfo:
                raise Exception("Comparison to datetime without tzinfo not allowed")
            else:
                return self.as_datetime() == other
        else:
            return False

    def __ne__(self, other):
        return not (self.__eq__(other))

    def __lt__(self, other):
        if isinstance(other, EpochClass):
            return self.ts < other.ts
        elif isinstance(other, (int)):
            return self.as_epoch() < other
        elif isinstance(other, datetime):
            if not other.tzinfo:
                raise Exception("Comparison to datetime without tzinfo not allowed")
            else:
                return self.as_datetime() < other
        else:
            return False

    def __le__(self, other):
        if isinstance(other, EpochClass):
            return self.ts <= other.ts
        elif isinstance(other, (int)):
            return self.as_epoch() <= other
        elif isinstance(other, datetime):
            if not other.tzinfo:
                raise Exception("Comparison to datetime without tzinfo not allowed")
            else:
                return self.as_datetime() <= other
        else:
            return False

    def __gt__(self, other):
        if isinstance(other, EpochClass):
            return self.ts > other.ts
        elif isinstance(other, (int)):
            return self.as_epoch() > other
        elif isinstance(other, datetime):
            if not other.tzinfo:
                raise Exception("Comparison to datetime without tzinfo not allowed")
            else:
                return self.as_datetime() > other
        else:
            return False

    def __ge__(self, other):
        if isinstance(other, EpochClass):
            return self.ts >= other.ts
        elif isinstance(other, (int)):
            return self.as_epoch() >= other
        elif isinstance(other, datetime):
            if not other.tzinfo:
                raise Exception("Comparison to datetime without tzinfo not allowed")
            else:
                return self.as_datetime() >= other
        else:
            return False

    def __add__(self, other):
        if isinstance(other, (int)):
            return EpochClass(self.ts + other / 1000.0)
        elif isinstance(other, timedelta):
            return EpochClass(self.ts + other.total_seconds())
        elif isinstance(other, relativedelta):
            as_dt = self.as_datetime()
            new_datetime = as_dt + other
            tdelta = new_datetime - as_dt
            whole_days = tdelta.days * 86400
            seconds = tdelta.seconds
            microseconds = tdelta.microseconds
            result_1 = EpochClass(self.ts + (whole_days))
            # check to see if we have to add or subtract hours due to daylight saving
            hour_diff = (result_1.as_datetime().hour - as_dt.hour) % 24
            if hour_diff > 12:
                hour_diff = hour_diff - 24
            return EpochClass(self.ts + (whole_days + seconds + microseconds / 1000000.0 - hour_diff * 3600))
        else:
            raise Exception(
                "Unspported type %s.  EpochClass supports integers, timedelta and relativedelta" % type(other).__name__)

    def __sub__(self, other):
        if isinstance(other, (int)):
            return EpochClass(self.ts - other / 1000.0)
        elif isinstance(other, timedelta):
            return EpochClass(self.ts - other.total_seconds())
        elif isinstance(other, EpochClass):
            return timedelta(seconds=self.ts - other.ts)
        elif isinstance(other, relativedelta):
            as_dt = self.as_datetime()
            new_datetime = as_dt - other
            tdelta = new_datetime - as_dt
            whole_days = tdelta.days * 86400
            seconds = tdelta.seconds
            microseconds = tdelta.microseconds
            result_1 = EpochClass(self.ts + (whole_days))
            # check to see if we have to add or subtract hours due to daylight saving
            hour_diff = (result_1.as_datetime().hour - as_dt.hour) % 24
            if hour_diff > 12:
                hour_diff = hour_diff - 24
            return EpochClass(self.ts + (whole_days + seconds + microseconds / 1000000.0 - hour_diff * 3600))
        else:
            raise Exception("Unspported type %s.  EpochClass supports integers, EpochClass and timedelta" %
                            type(other).__name__)

    def __hash__(self):
        return hash(self.ts)

    @classmethod
    def from_pytime(cls, f):
        return cls(f)

    @classmethod
    def from_datetime(cls, dt):
        if not dt.tzinfo:
            raise Exception("Using naive datetime is very confusing with epoch")
        else:
            utc_time = dt.astimezone(pytz.utc)
            delta = utc_time - base_epoch
            return cls(delta.total_seconds())

    @classmethod
    def from_xldate(cls, xlfloat, utc=True):
        # days = int(xlfloat)
        # secondsF = (xlfloat - days) * 3600 * 24
        # seconds = int(secondsF)
        # microseconds = int(secondsF * 1000 - seconds * 1000)
        # naive_dt = excelBase + timedelta(days, seconds, microseconds)
        naive_dt = excelBase + timedelta(days=int(xlfloat), seconds=np.float64((xlfloat - int(xlfloat)) * 3600 * 24))
        if utc:
            dt = pytz.utc.localize(naive_dt)
        else:
            tz_info = get_tenant_timezone()
            dt = tz_info.localize(naive_dt, tz_info.dst(naive_dt))
        return cls.from_datetime(dt)

    @classmethod
    def from_epoch(cls, ep):
        return cls(float(ep) / 1000)

    @classmethod
    def from_string(cls, s, fmt, timezone='utc'):
        if timezone == 'utc':
            tzinfo = pytz.utc
        elif timezone == 'tenant':
            tzinfo = get_tenant_timezone()
        else:
            tzinfo = pytz.timezone(timezone)
        fuzzy_dt = datetime.strptime(s, fmt)
        return cls.from_datetime(tzinfo.localize(fuzzy_dt, is_dst=tzinfo.dst(fuzzy_dt)))


def epoch(desc="NOW", month=None, day=None, hour=0, mins=0, second=0, utc=True):

    if desc is None:
        raise Exception("Ambiguous value to epoch")
    elif isinstance(desc, str):
        if desc == "NOW":
            return EpochClass()
        elif re.match('\d{14}', desc):
            return EpochClass.from_datetime(
                get_tenant_timezone().localize(datetime.strptime(str(desc), '%Y%m%d%H%M%S')))
        else:
            raise Exception('ERROR: epoch() accepts only NOW or tenant date in format YYYYMMDDhhmmss ')
    elif isinstance(desc, datetime):
        return EpochClass.from_datetime(desc)
    elif isinstance(desc, (int, np.integer)) and month is None:
        if isinstance(desc, np.integer):
            desc = int(desc)
        if desc < 100000:
            return EpochClass.from_xldate(desc, utc=utc)
        else:
            return EpochClass.from_epoch(desc)
    elif isinstance(desc, float):
        if desc < 100000:
            return EpochClass.from_xldate(desc, utc=utc)
        else:
            return EpochClass.from_pytime(desc)
    else:
        return EpochClass.from_datetime(
            get_tenant_timezone().localize(datetime(desc, month, day, hour, mins, second)))


filename_formats = [
    '(\d\d\d\d)(\d\d)(\d\d).(\d\d)(\d\d)_\d+.csv',
    '(\d\d\d\d)(\d\d)(\d\d).(\d\d)(\d\d).csv',
    '(\d\d)(\d\d)(\d\d).(\d\d)(\d\d).csv',
    '(\d\d\d\d)(\d\d)(\d\d).csv',
    '(\d\d)(\d\d)(\d\d).csv',
]


def getDatetime(filename):
    for f in filename_formats:
        match = re.search(f, filename)
        if(match):
            break
    if(match):
        match_count = len(match.groups())
        year = int(match.group(1))
        if(year < 100):
            year += year < 67 and 2000 or 1900
        return datetime(year, int(match.group(2)), int(match.group(3)),
                        match_count > 3 and int(match.group(4)) or 0,
                        match_count > 4 and int(match.group(5)) or 0,
                        tzinfo=pytz.utc)
    else:
        return None


def get_date_time_for_extended_month(year, month, tzinfo):
    if month < 0:
        year = year - 1
        month += 13
    elif month > 12:
        year += 1
        month -= 12
    dt_tuple = (year, month, 1)
    try:
        dt = datetime(*dt_tuple)
        dt = tzinfo.localize(dt, is_dst=tzinfo.dst(dt))
    except pytz.exceptions.NonExistentTimeError:
        dt = datetime(*(dt_tuple + (1,)))
        dt = tzinfo.localize(dt, is_dst=tzinfo.dst(dt))
    return dt




def periods_for_year(y, quarters, period_type, tzinfo,
                     quarter_adjustments={},
                     month_adjustments={},
                     starting_quarter ={}):
    if period_type[0] in ('Y', 'y'):
        if not quarters:
            return []
        period_start = get_date_time_for_extended_month(y, quarters[0], tzinfo)
        period_end = get_date_time_for_extended_month(y, quarters[-1], tzinfo) - onems
        return [period(str(y), period_start, period_end,)]
    elif period_type[0] in ('Q', 'q'):
        periods = []
        quarter_mnemonic_shift = 0
        if str(y) in starting_quarter:
            quarter_mnemonic_shift = starting_quarter[str(y)] - 1
        elif int(y) in starting_quarter:
            quarter_mnemonic_shift = starting_quarter[int(y)] - 1
        for i, start_month in enumerate(quarters[:-1]):
            end_month = quarters[i + 1]
            mnemonic = "%04dQ%d" % (int(y), int(i + 1 + quarter_mnemonic_shift))
            adjust_begin, adjust_end = quarter_adjustments.get(
                mnemonic, (0, 0))
            periods.append(period(mnemonic,
                                  get_date_time_for_extended_month(
                                      y, start_month, tzinfo) + timedelta(adjust_begin),
                                  get_date_time_for_extended_month(y, end_month, tzinfo) + timedelta(adjust_end) - onems)
                           )
        return periods
    elif period_type[0] in ('M', 'm'):
        if not quarters:
            return []
        periods = []
        start_month = quarters[0]
        end_month = quarters[-1]
        # there is no month 0:
        month_range = filter(lambda x: x != 0, range(start_month, end_month))
        for i, month in enumerate(month_range):
            # be careful as there is no month 0
            mnemonic = "%04dM%02d" % (y, i + 1)
            adjust_begin, adjust_end = month_adjustments.get(mnemonic, (0, 0))
#             print '***************************************'
#             print '****month adjust***'
#             print adjust_begin, adjust_end
            periods.append(period(mnemonic,
                                  get_date_time_for_extended_month(y, month, tzinfo) + timedelta(adjust_begin),
                                  get_date_time_for_extended_month(y, month + 1 if month + 1 else 1, tzinfo) + timedelta(adjust_end) - onems)
                           )
        return periods
    elif period_type == 'CM':
        # Calendar Month for App / UI.
        # Assumes 3 month quarters with where month length equals length of calendar months.
        # Probably doesn't play nice with other offset features.
        qtrs = periods_for_year(y, quarters, 'Q', tzinfo, quarter_adjustments, month_adjustments)
        return list(chain(*[monthly_periods(q_prd) for q_prd in qtrs]))
    else:
        raise Exception('Unkwon period type: ' + period_type)
        return []


def get_all_periods(period_type, filt_out_qs=None):
    #wrapper around the caching function
    #returns a tuple of mnem, begdt, enddt
    tenant_name = sec_context.name
    filtered_qs = ';'.join(sorted(filt_out_qs)) if filt_out_qs is not None else None
    return all_periods_cache(tenant_name, period_type, filtered_qs)

def get_all_periods_array(period_type, filt_out_qs=None):
    #returns lists of mnems, begs, and ends separately
    tenant_name = sec_context.name
    filtered_qs = ';'.join( sorted(filt_out_qs)) if filt_out_qs is not None else None
    return all_periods_cache_array(tenant_name, period_type, filtered_qs)

def all_periods_cache(tenant_name, period_type, filtered_qs):
    #returns/caches a list of periods
    try:
        return ALL_PERIODS_CACHE[tenant_name, period_type, filtered_qs, 'list']
    except KeyError:
        ret_list = _get_all_periods(period_type, filtered_qs)
        ALL_PERIODS_CACHE[tenant_name, period_type, filtered_qs, 'list'] = ret_list
        return ret_list

def all_periods_cache_array(tenant_name, period_type, filtered_qs):
    #returns/caches a list and array of periods
    try:
        ret_list = ALL_PERIODS_CACHE[tenant_name, period_type, filtered_qs, 'list']
    except KeyError:
        ret_list = _get_all_periods(period_type, filtered_qs)
        ALL_PERIODS_CACHE[tenant_name, period_type, filtered_qs, 'list'] = ret_list
    try:
        ret_arr = ALL_PERIODS_CACHE[tenant_name, period_type, filtered_qs, 'array']
    except KeyError:
        _, begs, ends = zip(*ret_list)
        ret_arr = np.array((begs, ends))
        ALL_PERIODS_CACHE[tenant_name, period_type, filtered_qs, 'array'] = ret_arr
    return ret_list, ret_arr

@memcached
def get_all_periods__m(period_type, filt_out_qs=None):
    return get_all_periods(period_type, filt_out_qs)

def _get_all_periods(period_type, filt_out_qs=None):
    # Read the configuration
    t = sec_context.details
    period_config = t.get_config('forecast', 'quarter_begins')
    if not period_config:
        raise Exception('No configuration found for the quarter definition. (quarter_begins)')
    quarter_adjustments = t.get_config('forecast', 'quarter_adjustments')
    if not quarter_adjustments:
        quarter_adjustments = {}
    month_adjustments = t.get_config('forecast', 'month_adjustments')
    if not month_adjustments:
        month_adjustments = {}
    starting_quarter = t.get_config('forecast', 'starting_quarter')
    if not starting_quarter:
        starting_quarter = {}
    tzinfo = get_tenant_timezone()

    if isinstance(period_config, list):
        period_config = {'1990-': period_config}

    # Create a list of all periods
    all_periods = []
    for x in period_config:
        # Find the proper range to use
        if x.endswith('-'):
            start, end = x[0:-1], 2050
        elif x.find('-') == -1:
            start, end = x, x
        else:
            start, end = x.split('-')

        # Convert the range to integers
        start, end = int(start), int(end)
        for y in range(start, end + 1):
            all_periods.extend(
                periods_for_year(y, period_config[x], period_type, tzinfo, quarter_adjustments, month_adjustments,
                                 starting_quarter))
    all_periods = sorted(all_periods)
    # Validate that there are no duplicates
    if len(all_periods) > len(set(map(lambda x1: x1[0], all_periods))):
        raise Exception('Duplicate financial years found')

    if filt_out_qs:
        all_periods = [[qmn, beg, end] for qmn, beg, end in all_periods
                if qmn not in filt_out_qs]
    return all_periods


def get_all_periodsF(period_type, filt_out_qs=None):
    return [[datetime2xl(beg), datetime2xl(end)]
            for qmn, beg, end in get_all_periods(period_type, filt_out_qs)]

def period_details(a_datetime=None, period_type='Q', delta=0, count=1):
    if a_datetime is None:
        a_datetime = datetime.now(tz=pytz.utc)
    prds, beg_end_arr = get_all_periods_array(period_type)
    idx = np.searchsorted(beg_end_arr[1], a_datetime)
    if idx >= beg_end_arr.shape[1]:
        raise Exception("Given time doesn't fall into any known time span")
    if count == 1 or count == 0:
            return prds[idx + delta]
    else:
        if delta > 0:
            myslice = slice(idx + delta, idx + delta + count, 1)
        else:
            myslice = slice(idx + delta, idx + delta - count, -1)
        return prds[myslice]

def period_rng_from_mnem(mnemonic):
    # using tuples instead of namedtuples in here because this is performance critical
    tenant_name = sec_context.name
    try:
        return ALL_PERIOD_RANGES_CACHE[tenant_name, mnemonic]
    except KeyError:
        all_periods = get_all_periods('Q')
        for period in all_periods:
            if period.mnemonic == mnemonic:
                mnem_range = (datetime2epoch(period.begin), datetime2epoch(period.end))
                ALL_PERIOD_RANGES_CACHE[tenant_name, mnemonic] = mnem_range
                return mnem_range
            elif 'Q' not in mnemonic and (-1 <= int(mnemonic[:4]) - int(period.mnemonic[:4]) <= 1):
                boq_epoch = epoch(period.begin)
                for m in range(0, 3):
                    bom_ep = boq_epoch + relativedelta(months=m)
                    bom_dt = bom_ep.as_datetime()
                    month_mnem = str(bom_dt.year) + format(bom_dt.month, '02')
                    if mnemonic == month_mnem:
                        mnem_range = (bom_ep.as_epoch(), get_eom(bom_ep).as_epoch())
                        ALL_PERIOD_RANGES_CACHE[tenant_name, mnemonic] = mnem_range
                        return mnem_range
        else:
            raise Exception("No match for mnemonic: %s", mnemonic)


def period_details_by_mnemonic(mnemonic, period_type='Q', delta=0, count=1):
    all_periods = get_all_periods(period_type)
    for idx, time_span in enumerate(all_periods):
        if time_span[0] == mnemonic:
            if count == 1 or count == 0:
                return all_periods[idx + delta]
            elif delta > 0:
                return list(all_periods[idx + it + delta] for it in range(count))
            else:
                return list(all_periods[idx - it + delta] for it in range(count))
    else:
        raise Exception("Not match for mnemonic=%s (period_type=%s)" % (mnemonic, period_type))


def period_details2(a_datetime=None, period_type='Q', delta=0, count=1):
    delta = int(delta)
    count = int(count)
    assert count, "count cannot be zero for period_details2"
    if a_datetime is None:
        a_datetime = datetime.now(tz=pytz.utc)
    all_periods = get_all_periods(period_type)
    for idx, time_span in enumerate(all_periods):
        if time_span[1] <= a_datetime <= time_span[2]:
            if count > 0:
                return all_periods[(idx + delta):(idx + delta + count)]
            else:
                return all_periods[idx + delta + count + 1:idx + delta + 1]
    else:
        raise Exception("Given time doesn't fall into any known time span")


def period_details_from_date_range(start, end, period_type='Q'):
    '''
    Accepts a date string range and returns the period details belonging to this range.
    '''
    start_dt = epoch(int(start[0:4]), int(start[5:7]), int(start[8:10])).as_datetime()
    end_dt = epoch(int(end[0:4]), int(end[5:7]), int(end[8:10])).as_datetime()
    ret = list()
    if period_type == 'Q':
        start_p = period_details(start_dt).mnemonic
        end_p = period_details(end_dt).mnemonic
        range_upto = 5
    else:
        start_p = start_dt.strftime('%Y%m')
        end_p = end_dt.strftime('%Y%m')
        range_upto = 13
    start_p_year, start_p_month, end_p_year = int(start_p[0:4]), int(start_p[5:6]), int(end_p[0:4])
    try:
        while start_p_year <= end_p_year:
            for i in range(start_p_month, range_upto):
                if period_type == 'Q':
                    period = str(start_p_year)+'Q'+str(i)
                else:
                    period = str(start_p_year)+str(i).zfill(2)
                ret.append(period_details_by_mnemonic(period, period_type=period_type))
                if period == end_p:
                    raise
            start_p_month = 1
            start_p_year += 1
    except:
        pass
    return ret


def get_quarter_from_cache_key(cache_key):
    val = cache_key.split('_')[-2]
    if val.startswith('1'):
        as_of = epoch(int(val)).as_datetime()
    else:
        as_of = EpochClass.from_string(val, "%Y%m%d%S%f", 'tenant').as_datetime()
    return current_period(as_of)[0]


def current_period(a_datetime=None, period_type='Q'):
    return period_details(a_datetime, period_type, 0)


def current_periodF(a_xldate=None, period_type='Q'):
    cp = period_details(xl2datetime(a_xldate), period_type, 0)
    return [datetime2xl(cp[1]), datetime2xl(cp[2])]


def next_period(a_datetime=None, period_type='Q', skip=1, count=1):
    return period_details(a_datetime, period_type, delta=skip, count=count)


def prev_period(a_datetime=None, period_type='Q', skip=1, count=1):
    return period_details(a_datetime, period_type, delta=-skip, count=count)


def get_a_date_time_as_float_some_how(date_like_thing):
    if not date_like_thing:
        return None
    # Convert modified date from string to an excel float
    try:
        a_date = float(date_like_thing)
        if (a_date > 100000):
            a_date = EpochClass.from_epoch(a_date).as_xldate()
    except TypeError:
        # TODO: Move the type error to the exception list below so that
        # we will try the fall back mechanism after we see why it is failing first
        logger.error("Unable to determine the date from %s" + str(date_like_thing))
        logger.error('Type of the argument is %s', str(type(date_like_thing)))
        return None
    except (ValueError):
        try:
            a_date = datetime2xl(EpochClass.from_string(cleanmmddyy(date_like_thing), '%m/%d/%Y').as_datetime())
        except:
            logger.error("Unable to determine the date from " + date_like_thing)
            return None

    return a_date


def date2str(date):
    return str(date.month) + '/' + str(date.day) + '/' + str(date.year)


def cleanmmddyy(anstr):
    a = anstr.split('/')
    if len(a) != 3:
        return anstr
    year = int(a[2])
    if year < 70:
        year += 2000
    return str(int(a[0])) + '/' + str(int(a[1])) + '/' + str(year)


now = lambda: EpochClass().as_datetime()


def getperiods(begin_date, end_date):
    ret = []
    while(end_date > begin_date):
        ret.append(end_date)
        end_date = end_date + timedelta(-7)
    return reversed(ret)

formats = ["%Y/%m/%d", "%y/%m/%d",
           "%Y-%m/%d", "%y-%m-%d",
           "%Y-%b-%d", "%y-%b-%d",
           "%Y/%b/%d", "%y/%b/%d",
           "%m/%d/%Y"]


def fuzzydateinput(olddate, timezone=None):
    """ Converts datetime in one of the accepted string format to datetime
        object. If a timezone name is provided, the datetime is converted to UTC
        and returned.
    """
    if not timezone:
        timezone = 'tenant'

    for x in formats:
        try:
            return EpochClass.from_string(olddate, x, timezone=timezone)
        except ValueError:
            pass
    raise Exception("No formats matched - %s" % olddate)


def convert_date(d):
    if (isinstance(d, datetime)):
        return datetime2xl(d)
    elif (isinstance(d, float)):
        return d
    elif (isinstance(d, int)):
        return datetime2xl(epoch2datetime(d))
    else:
        raise ValueError()


class TimeHorizon(object):
    """ Manages time horizon (being, as_of, and end) for running
        forecasts.
        The begins, as_of, and horizon (end) take default values as
        the current epoch(), but that's less useful and is meant
        to simplify instantiating this class.
    """

    def __init__(self, begins=None, as_of=None, horizon=None):

        if as_of is None:
            as_of = now()
        self.as_of = as_of

        if begins is None or horizon is None:

            period_details = current_period(self.as_of)

            if begins is None:
                begins = period_details[1]

            if horizon is None:
                horizon = period_details[2]

        self.begins = begins
        self.as_of = as_of
        self.horizon = horizon

    def set_begins(self, d):
        self._begins = convert_date(d)

    def set_as_of(self, d):
        self._as_of = convert_date(d)

    def set_horizon(self, d):
        self._horizon = convert_date(d)

    def get_begins(self):
        return xl2datetime(self._begins)

    def get_beginsF(self):
        return self._begins

    def get_as_of(self):
        return xl2datetime(self._as_of)

    def get_as_ofF(self):
        return self._as_of

    def get_horizon(self):
        return xl2datetime(self._horizon)

    def get_horizonF(self):
        return self._horizon

    begins = property(get_begins, set_begins)
    as_of = property(get_as_of, set_as_of)
    horizon = property(get_horizon, set_horizon)

    as_ofF = property(get_as_ofF)
    beginsF = property(get_beginsF)
    horizonF = property(get_horizonF)

    @classmethod
    def from_dict(cls, time_horizon_dict):
        return cls(time_horizon_dict['_begins'],
                   time_horizon_dict['_as_of'],
                   time_horizon_dict['_horizon'])

    def encode_time_horizon(self):
        """ Returns begins, as_of and horizon epochs separated by a _
        (underscore). This method is used to timestamp the forecast
        results, so multiple runs can be cached.
        """
        return str(datetime2epoch(self.get_begins())) + '_' + \
            str(datetime2epoch(self.get_as_of())) + '_' + \
            str(datetime2epoch(self.get_horizon()))


def get_tenant_timezone():

    if sec_context.name and sec_context.name != 'N/A':
        return sec_context.tenant_time_zone
    else:
        return pytz.timezone("US/Pacific")


def get_tenant_timezone_offset():
    '''
    Returns timezone offset in minutes based on tenant's timezone. For example,
    if the tanant timezone is PST, it returns -480 (8*60) or -420 based on DST. The number can be
    positive or negative based on the timezone.
    '''
    now = datetime.now()
    localoffset = get_tenant_timezone().localize(now) - pytz.utc.localize(now)
    return -(localoffset.days * 86400 + localoffset.seconds) / 60


def from_db(date_object):
    if date_object.tzinfo:
        return date_object
    else:
        return pytz.utc.localize(date_object)


def monthly_periods(q_prd, period_type='Q'):
    """ Returns all monthly periods for a given quarterly period.
    Takes either a period namedtuple OR a string corresponding to a qtr mnem.
    NOTE: This is the UI / App layer format.
    """
    if isinstance(q_prd, str):
        q_prd = period_details_by_mnemonic(q_prd, period_type)
    boq_epoch = epoch(q_prd.begin)

    if period_type in ['Y', 'y']:
        months = ([current_period(boq_epoch.as_datetime(), period_type='M')] +
                  next_period(boq_epoch.as_datetime(), period_type='M', count=11))
    else:
        months = ([current_period(boq_epoch.as_datetime(), period_type='M')] +
                  next_period(boq_epoch.as_datetime(), period_type='M', count=2))

    for p, month in enumerate(months):
        bom, eom = epoch(month.begin), epoch(month.end)
        bom_dt, eom_dt = bom.as_datetime(), eom.as_datetime()
        mom_dt = bom_dt - (bom_dt - eom_dt) / 2
        mnth_mnm = str(mom_dt.year) + format(mom_dt.month, '02')

        if period_type in ['Y', 'y']:
            if bom >= q_prd.begin and eom <= q_prd.end:
                yield period(mnth_mnm, bom_dt, eom_dt)
        else:
            yield period(mnth_mnm, bom_dt, eom_dt)


def set_time_attrs(begins, as_of, horizon):
    if as_of.tzinfo:
        return current_period(as_of)[0]
    else:
        return current_period(pytz.utc.localize(as_of))[0]


class POIDetail(object):
    __slots__ = [
        "__as_of", "__begin", "__horizon",
        "__as_of_epoch", "__begin_epoch", "__horizon_epoch",
        "__as_of_datetime", "__begin_datetime", "__horizon_datetime",
    ]
    __format_str = "%Y%m%d_%H%M%S"

    def __init__(self, as_of, begin=None, horizon=None):
        self.as_of = as_of
        if begin is None or horizon is None:
            cp = current_period(self.as_of)
            if begin is None:
                self.begin = cp["begin"]
            if horizon is None:
                self.horizon = cp["end"]

    @property
    def as_of(self):
        return self.__as_of

    @as_of.setter
    def as_of(self, val):
        if isinstance(val, EpochClass):
            self.__as_of = val
        else:
            self.__as_of = epoch(val)
        self.__as_of_datetime = self.as_of.as_datetime()
        self.__as_of_epoch = self.as_of.as_epoch()

    @property
    def as_of_epoch(self):
        return self.__as_of_epoch

    @property
    def as_of_datetime(self):
        return self.__as_of_datetime

    @property
    def begin(self):
        return self.__begin

    @begin.setter
    def begin(self, val):
        if isinstance(val, EpochClass):
            self.__begin = val
        else:
            self.__begin = epoch(val)
        self.__begin_datetime = self.as_of.as_datetime()
        self.__begin_epoch = self.as_of.as_epoch()

    @property
    def begin_epoch(self):
        return self.__begin_epoch

    @property
    def begin_datetime(self):
        return self.__begin_datetime

    @property
    def horizon(self):
        return self.__horizon

    @horizon.setter
    def horizon(self, val):
        if isinstance(val, EpochClass):
            self.__horizon = val
        else:
            self.__horizon = epoch(val)
        self.__horizon_datetime = self.as_of.as_datetime()
        self.__horizon_epoch = self.as_of.as_epoch()

    @property
    def horizon_epoch(self):
        return self.__horizon_epoch

    @property
    def horizon_datetime(self):
        return self.__horizon_datetime

    def __str__(self):
        return "as_of=%s|begin=%s|horizon:%s" % (
            self.as_of_datetime.strftime(POIDetail.__format_str),
            self.begin_datetime.strftime(POIDetail.__format_str),
            self.horizon_datetime.strftime(POIDetail.__format_str),
        )

    __repr__ = __str__


def is_valid_mnemonic(mnemonic, period_type='Q'):
    '''
    Accepts a mnemonic string and returns whether its a valid mnemonic or not.
    period_type = Q/M/CM/Y
    '''
    if period_type == 'Q':
        regex = "^\d{4}Q[1-4]$"
    elif period_type == 'M':
        regex = "^\d{4}M[0,1]\d$"
    elif period_type == 'CM':
        regex = "^\d{4}[0,1]\d$"
    else:
        regex = "^\d{4}$"
    return True if re.match(regex, mnemonic) else False


STD_PRD_LABELS = {'thisq': 'This Quarter',
                  'nextq': 'Next Quarter',
                  'thism': 'This Month',
                  'nextm': 'Next Month',
                  'thisw': 'This Week',
                  'nextw': 'Next Week',
                  'next180': 'Next 180 Days'}

PRD_STR_CACHE = {}


def rng_from_prd_str(std_prd_str, fmt='epoch', period_type='Q'):
    """Given a standard period string, like thisQ, thisM, nextW, etc
    return the boundaries of that period as a tuple of (begin, end)"""
    from api.app import get_now
    today = get_now()
    try:
        return PRD_STR_CACHE[sec_context.name, std_prd_str, fmt]
    except KeyError:
        if is_valid_mnemonic(std_prd_str, period_type):
            prd_details = period_details_by_mnemonic(std_prd_str, period_type)
            from_epoch, til_epoch = epoch(prd_details.begin), epoch(prd_details.end)
        elif std_prd_str == 'thisq' or std_prd_str == 'THIS_Q':
            cp = current_period()
            from_epoch, til_epoch = epoch(cp.begin), epoch(cp.end)
        elif std_prd_str == 'ALL':
            PRD_STR_CACHE[sec_context.name, std_prd_str, fmt] = (None, None)
            return (None, None)
        elif std_prd_str == 'NEXT_Q':
            nxt = next_period()
            from_epoch, til_epoch = epoch(nxt.begin), epoch(nxt.end)
        elif std_prd_str == 'THIS_M':
            from_epoch, til_epoch = get_bom(today), get_eom(today)
        elif std_prd_str == 'NEXT_M':
            diff = relativedelta(months=1)
            from_epoch, til_epoch = get_bom(today) + diff, get_eom(today) + diff
        elif std_prd_str == 'THIS_W':
            from_epoch, til_epoch = get_bow(today), get_eow(today)
        elif std_prd_str == 'NEXT_W':
            diff = relativedelta(weeks=1)
            from_epoch, til_epoch = get_bow(today) + diff, get_eow(today) + diff
        elif std_prd_str == 'next180':
            from_epoch, til_epoch = epoch(), epoch() + relativedelta(days=180)
        elif std_prd_str == 'PAST':
            past_tuple = (None, get_yest(today).as_datetime().strftime("%Y-%m-%d"))
            PRD_STR_CACHE[sec_context.name, std_prd_str, fmt] = past_tuple
            return past_tuple
        else:
            PRD_STR_CACHE[sec_context.name, std_prd_str, fmt] = (None, None)
            return (None, None)

        if fmt == 'epoch':
            ret_val = (from_epoch.as_epoch(), til_epoch.as_epoch())
        elif fmt == 'xldate':
            ret_val = (from_epoch.as_xldate(), til_epoch.as_xldate())
        elif fmt == 'string':
            ret_val = (from_epoch.as_datetime().strftime("%Y-%m-%d"), til_epoch.as_datetime().strftime("%Y-%m-%d"))
        PRD_STR_CACHE[sec_context.name, std_prd_str, fmt] = ret_val
        return ret_val


def get_yest(ep):
    """
    get previous day from epoch, returns an epoch
    """
    yest = ep.as_datetime() - timedelta(days=1)
    return epoch(yest.replace(hour=0, minute=0, second=0))


def get_bow(ep):
    """
    get beginning of week from epoch, returns an epoch
    """
    day = ep.as_datetime()
    bow = day - timedelta(days=day.weekday())
    return epoch(bow.replace(hour=0, minute=0, second=0))


def get_eow(ep):
    """
    get end of week
    """
    epdt = ep.as_datetime()
    future = epdt + timedelta(days=6-epdt.weekday())
    eom = future.replace(hour=23, minute=59, second=59)
    return epoch(eom)


def get_week_ago(ep):
    """
    get date a week ago from epoch, returns an epoch
    """
    day = ep.as_datetime()
    return epoch(day.replace(minute=0, second=0) - timedelta(days=7))


def get_bom(ep):
    """
    get beginning of month from epoch, returns an epoch
    """
    return epoch(ep.as_datetime().replace(day=1, hour=0, minute=0, second=0))

def get_eom(ep):
    """
    get end of month
    """
    epdt = ep.as_datetime()
    future = epdt + relativedelta(months=1)
    eom = future.replace(day=1, hour=23, minute=59, second=59) + relativedelta(days=-1)
    return epoch(eom)

def get_boq(ep):
    """
    get beginning of period from epoch, returns an epoch
    """
    period_info = period_details(ep.as_datetime())
    return epoch(period_info.begin)

def lazy_get_boq(ep):
    """
    get inexact beginning of quarter by going back 90 days, returns an epoch
    """
    day = ep.as_datetime()
    return epoch(day.replace(minute=0, second=0) - timedelta(days=90))


def get_eoq(ep):
    """
    get end of period from epoch, returns an epoch
    """
    period_info = period_details(ep.as_datetime())
    return epoch(period_info.end)


def get_future_bom(ep, delta=None, months=0):
    """
    get beginning of a future month that months away from epoch, returns an epoch
    """
    epdt = ep.as_datetime()
    future = epdt + delta + relativedelta(months=months)
    return epoch(future.replace(day=1, hour=0, minute=0, second=0))


def get_nextq_mnem(mnem):
    """
    get next quarter mnemonic from mnemonic
    """
    try:
        year, q = mnem.split('Q')
        q = str(int(q) % 4 + 1)
        year = year if q != '1' else str(int(year) + 1)
        return 'Q'.join([year, q])
    except ValueError:
        year, m = mnem[:4], mnem[4:]
        m = str(int(m) % 12 + 1)
        year = year if m != '1' else str(int(year) + 1)
        return ''.join([year, m.zfill(2)])


def get_prevq_mnem(mnem):
    """
    get previous quarter mnemonic from mnemonic
    """
    try:
        year, q = mnem.split('Q')
        q = str(int(q) -1 % 4) if q != '1' else '4'
        year = year if q != '4' else str(int(year) - 1)
        return 'Q'.join([year, q])
    except ValueError:
        year, m = mnem[:4], mnem[4:]
        m = str(int(m) - 1 % 12) if m != '01' else '12'
        year = year if m != '12' else str(int(year) - 1)
        return ''.join([year, m.zfill(2)])


def format_date_ymd(date):
    return datetime.fromtimestamp(date/ 1000.).strftime('%Y%m%d')


def compare_mnems(*mnems, **kwargs):
    """
    compare a number of mnemonics of any type, and return sorted list
    orders mnems from earliest to latest based on start times

    Parameters:
    end_last: bool, optional
        if True, breaks ties by taking mnems with later end times first
        default False (take mnems with earlier end times first in case of tie)

    >>> compare_mnems('2019Q1', '201711', '2018Q4')
    ['201711', '2018Q4', '2019Q1']
    >>> compare_mnems('2019Q1', '201711', '2018Q4', end_last=True)
    ['2018Q4', '201711', '2019Q1']
    """
    if kwargs.get('end_last'):
        sort_key = lambda x: (x[1][0], -x[1][1])
    else:
        sort_key = lambda x: (x[1][0], x[1][1])
    quartermnems = ['Q' in mnem for mnem in mnems]
    if all(quartermnems) or not any(quartermnems):
        return sorted(mnems)
    mnem_ranges = [(mnem, period_rng_from_mnem(mnem)) for mnem in mnems]
    return [x[0] for x in sorted(mnem_ranges, key=sort_key)]


def is_same_day(first, second):
    '''
    Accepts two dates in epoch and tells whether they fall on the same day.
    '''
    if first is None or second is None:
        return False
    first_dt = first.as_datetime()
    second_dt = second.as_datetime()
    if (first_dt.year, first_dt.month, first_dt.day) == (second_dt.year, second_dt.month, second_dt.day):
        return True
    else:
        return False


@memcached
def period_info_from_mnem(mnem, monthly=False, has_nextq=False):
    """
    return info about a period from the mnemonic
    """
    prd_infos = collections.defaultdict(lambda: collections.defaultdict(list))

    def add_period(mnem, qtr, beg=None, end=None, is_comp=False):
        if not beg and not end:
            beg, end = period_rng_from_mnem(mnem)
        beg = epoch(beg)
        end = epoch(end)
        prd_infos[mnem].update({'qtr': qtr,
                                'begin': beg.as_xldate(),
                                'end': end.as_xldate(),
                                'is_comp': is_comp,
                                })
        if is_comp:
            prd_infos[qtr]['comp_list'].append(mnem)

    add_period(mnem, mnem, is_comp=not monthly)

    if monthly:
        for month_mnem, month_beg, month_end in monthly_periods(mnem):
            add_period(month_mnem, mnem, month_beg, month_end, is_comp=True)

    if has_nextq:
        nextq_mnem = get_nextq_mnem(mnem)
        add_period(nextq_mnem, nextq_mnem, is_comp=not monthly)
        if monthly:
            for month_mnem, month_beg, month_end in monthly_periods(nextq_mnem):
                add_period(month_mnem, nextq_mnem, month_beg, month_end, is_comp=True)

    return prd_infos


class MonthsMaker(object):
    """
    converts quarters to months, for memcached
    """
    @staticmethod
    def make(Q, *args):
        try:
            return [x[0] for x in monthly_periods(Q)] + [Q]
        except:
            return []