from aviso.domainmodel.app import User
from aviso.domainmodel.oauth import Oauth
from aviso.domainmodel.saml_idp import IdP
from aviso.framework import NewSecContext
from aviso.onelogin.saml.Utils import calculate_x509_fingerprint


def findIdP(tenant_or_username):
    ''' Find the identity provider for the tenant. Each tenant,
    if configured for Saml SSO, can have its own IdP. Returns the
    IdP metadata or None. tenant_name is full domain name in lowercase.
    Ex: ringcentral.com.'''

    if tenant_or_username == 'ui_tester@administrative.domain':
        return None

    if '@' in tenant_or_username:
        user_name = tenant_or_username.split("@")[0]
        tenant_name = tenant_or_username.split("@")[1]
        with NewSecContext(user_name, tenant_name, tenant_name):
            try:
                user = User.getByFieldValue("username", tenant_or_username)
                if user and user.linked_to:
                    tenant_name = user.linked_to.split("@")[1]
            except:
                pass
    else:
        tenant_name = tenant_or_username

    idp = IdP.getByTenantName(tenant_name)
    idpmeta = {}
    if idp:
        idp.encode(idpmeta)
        idpmeta['idp_cert_fingerprint'] = \
            calculate_x509_fingerprint(idpmeta['idp_cert'])
    else:
        idpmeta = None
    return idpmeta


def findOauth(tenant_name):
    ''' Find the identity provider for the tenant. Each tenant,
    if configured for Saml SSO, can have its own IdP. Returns the
    IdP metadata or None. tenant_name is full domain name in lowercase.
    Ex: ringcentral.com.'''
    oauth = Oauth.getByTenantName(tenant_name)
    oauthmeta = {}
    if oauth:
        oauth.encode(oauthmeta)
    else:
        oauthmeta = None
    return oauthmeta