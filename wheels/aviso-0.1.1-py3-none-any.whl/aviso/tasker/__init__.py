import copy
import uuid
import inspect
import logging
import hashlib
import importlib

from aviso.settings import CNAME, sec_context

logger = logging.getLogger(__name__)

"""
Tasker is a task execution framework. Provides an ability to execute
"tasks" in multithreaded, multiserver, multiprocess environments.

__init__ - common code, base task
models - models
workers - worker implementations
managers - task manager implementations
"""


class VersionManager(object):
    _versions = {}

    def get_class_version(self, inst):
        cls = inst.__class__
        try:
            return self._versions[cls]
        except KeyError:
            version = hashlib.sha1(VersionManager.get_source(inst)).hexdigest()
            self._versions[cls] = version
            return version

    @staticmethod
    def get_source(inst):
        return '\n'.join(
            [''.join(inspect.getsourcelines(f[1])[0])
                for f in inspect.getmembers(inst, predicate=inspect.ismethod)]
        )

VERSION_MANAGER = VersionManager()


def _make_hash(obj, debug=False):
    # memory optimized http://stackoverflow.com/a/8714242
    """
    make_hash({'x': 1, 'b': [3,1,2,'b'], 'c': {1:2}})
    make_hash({'x': 1, 'b': [3,1,2,'b'], 'c': {1:2}})
    make_hash({'x': 1, 'b': [3,1,2,'b']})
    make_hash({'x': 1, 'b': [3,1,2,'b']})
    make_hash({'x': 1, 'b': [3,1,2,'b']})
    """
    try:
        if isinstance(obj, (set, tuple, list)):
            if isinstance(obj, (set,)):
                obj = list(obj)
                obj.sort()
            return tuple(map(make_hash, obj))
        elif not isinstance(obj, dict):
            return hash(obj)
        try:
            new_o = copy.deepcopy(obj)
        except:
            if debug:
                logger.info('Deepcopy failing for: %s' % str(obj))
                import pickle
                pickle.dump(obj, open("deepcopy_failure.p", "wb"))
            raise
        nitems = list(new_o.items())
        nitems.sort(key=lambda x: x[0])
        for k, v in nitems:
            if v is not None:
                new_o[k] = make_hash(v)
            else:
                new_o[k] = make_hash("None")
        new_oo = list(new_o.items())
        new_oo.sort(key=lambda x: x[0])
        return hash(tuple(frozenset(new_oo)))
    except Exception as e:
        if not debug:
            _make_hash(obj, debug=True)
        raise Exception(e)


def make_hash(params):
    """
    Calculate sha1 of a dictionary

    :param params: dict - a dictionary
    :return: str - calculated hash id of params
    """
    return hashlib.sha1(bytes(str(_make_hash(params)), 'utf-8')).hexdigest()


class V2Task(object):
    """
    Base Task class

    :param params: dict - task parameters. You are not allowed to mess with params
        after creation.
    :param context: dict - task context

    trace_id - id shared between all members of a run tree
    task_id - globally unique id for a task
    dependencies - task dependencies (must be implemented as cached_property)
    res_id - globally unique id for a task result (multiple tasks may have same res_id)
    parent_task - parent task object
    parent_id - parent task id
    """
    STATUS_CREATED = 0
    STATUS_STARTED = 1
    STATUS_FINISHED = 2
    STATUS_ERROR = 3
    STATUS_SUBMITTED = 4

    LIFETIME_LONG = 'long'  # 4 months
    LIFETIME_MEDIUM = 'medium'  # 1 month
    LIFETIME_SHORT = 'short'  # 1 w

    version = 1.0
    retry_strategy = None
    retry_expires = None

    lazy_load = False
    skip_task_cache = False
    mutually_exclusive_with = []

    def __init__(self, params=None, variables=None, context=None, **kw):
        self.tmanager = None
        self.lifetime = sec_context.name
        self.task_id = str(uuid.uuid1())
        self._name = self.__class__.__name__
        self._path = '{}.{}'.format(self.__module__, self.name)
        self._params = params if isinstance(params, dict) else {}
        self._variables = variables if isinstance(variables, dict) else {}
        self._context = {}
        self._context = self.update_context(context)
        self.version = self._get_version()
        self._res_id = None
        self._kw = kw
        self.cache_key = None
        self.as_of_mnemonic = None
        self.dependencies = None
        self.consumers = []
        self.level = 0
        self.unique = self.is_unique()
        self.re_register = self.reregister_on_time_out()
        self.do_cleanup_on_re_register = False

    def cleanup_on_re_register(self, dep_results, *args, **kwargs):
        logger.info("cleanup_on_reregister called")

    @staticmethod
    def create_task(path, params=None, context=None):
        """
        dynamically loads a class object by path: 'tasks.reports.generators.TaskName'
        """
        class_data = path.rsplit(".", 1)
        module_path = class_data[0]
        class_str = class_data[1]
        try:
            module = importlib.import_module(module_path)
        except ImportError as e:
            raise Exception('Path does not exist: "{}" -- "{}"'.format(path, e))
        task = getattr(module, class_str, None)
        if not task:
            raise Exception('Task "{}" not found in "{}" module'.format(class_str, module_path))
        t = task(params=params, context=context)
        try:
            from aviso.tasks import gnana_task_support
            setattr(gnana_task_support.thread_local_tags, "tags", t.get_tags())
        except AttributeError as ex:
            logger.info("Retrieving tags failed due to %s" % ex)
        return t

    def __repr__(self):
        return "%s@%s (Task: %s S3: %s)" % (self._path, id(self), self.task_id, self.res_id)

    def generate_res_id(self):
        def mkhash(name, value):
            return make_hash({'name': name, 'value': value})
        k = [mkhash(self.name, self.params), self.version, CNAME]
        if self.unique:
            k += [str(uuid.uuid1())]
        h = make_hash(k)
        return h

    def is_cached(self):
        return True

    def is_pinned(self):
        return True

    def new_dependencies(self):
        if self.dependencies is not None:
            raise Exception("Calling new dependencies incorrectly")
        self.dependencies = self.create_dependencies()
        if self.dependencies is None:
            raise Exception("Return Empty Dictionary if you have no dependencies")

    def create_dependencies(self):
        logger.warning("create_dependencies is not implemented by %s" % self.__class__.__name__)
        return {}

    def get_v2stats_creation_params(self):
        return {}

    def get_res_id(self):
        if not self._res_id:
            self._res_id = self.generate_res_id()
        return self._res_id

    res_id = property(get_res_id, None)

    @property
    def params(self):
        return self._params

    @property
    def variables(self):
        return self._variables

    @property
    def name(self):
        return self._name

    @property
    def path(self):
        return self._path

    @property
    def metadata(self):
        return {'name': self.name,
                'res_id': self.res_id,
                'version': self.version,
                'params': self.params}

    @property
    def context(self):
        return self._context

    def update_context(self, ctx):
        if ctx:
            self._context.update(ctx)
            if "trace" in ctx:
                self.trace_id = ctx["trace"]
            elif "trace_id" in ctx:
                self.trace_id = ctx["trace_id"]
            if "lifetime" in ctx:
                self.lifetime = ctx["lifetime"]
        return self._context

    def _get_version(self):
        if self.context.get('versioning', True):
            return 'native'
        try:
            return VERSION_MANAGER.get_class_version(self)
        except TypeError as e:
            logger.warning("Could not get file version for task: %s and class: %s, because of %s",
                           self.name, self.__class__.__name__, str(e))
            return 'native'

    def get_desired_queue(self):
        return "memory"

    def cleanup_on_fail(self):
        logger.warning('cleanup_on_fail: Not implemented for %s' % self.path)

    def cleanup_on_revoke(self):
        logger.warning('cleanup_on_revoke: Not implemented for %s' % self.path)

    def execute(self, dep_results, *args, **kwargs):
        raise NotImplementedError('Must be implemented in a child class')

    def is_unique(self):
        return False

    def reregister_on_time_out(self):
        return True

class BaseV2Task(V2Task):
    def create_dependencies(self):
        deps = {}
        return deps

    def is_cached(self):
        return False

    def is_pinned(self):
        return False