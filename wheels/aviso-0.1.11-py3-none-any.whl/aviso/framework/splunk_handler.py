import json
import logging
import queue
import socket
import threading
import time

import requests
import urllib3

urllib3.disable_warnings()

_HOST = socket.gethostname()

try:
    from aviso.framework import tracer as _tracer, tenant_holder as _tenant_holder
except ImportError:
    _tracer = None
    _tenant_holder = None


class AsyncLogWorker(threading.Thread):
    """
    Daemon thread that drains an in-memory queue and batch-POSTs to Splunk HEC.
    All network I/O is confined to this thread — callers only touch enqueue(),
    which does a non-blocking put_nowait().
    """

    def __init__(self, url, token, batch_size=100, flush_interval=5, max_queue_size=10000):
        super().__init__(daemon=True, name="SplunkHECWorker")
        self.url = url
        self.token = token
        self.batch_size = batch_size
        self.flush_interval = flush_interval
        self._queue = queue.Queue(maxsize=max_queue_size)
        self._stop_event = threading.Event()
        self._session = requests.Session()
        self._session.headers.update({
            "Authorization": f"Splunk {token}",
            "Content-Type": "application/json",
        })

    def enqueue(self, event):
        """Non-blocking enqueue. Returns False if the queue is full (log dropped)."""
        try:
            self._queue.put_nowait(event)
            return True
        except queue.Full:
            return False

    def run(self):
        buffer = []
        last_flush = time.time()

        while not self._stop_event.is_set():
            try:
                item = self._queue.get(timeout=min(self.flush_interval, 2))
                buffer.append(item)
            except queue.Empty:
                pass

            while len(buffer) < self.batch_size:
                try:
                    buffer.append(self._queue.get_nowait())
                except queue.Empty:
                    break

            elapsed = time.time() - last_flush
            if buffer and (len(buffer) >= self.batch_size or elapsed >= self.flush_interval):
                self._flush(buffer)
                buffer = []
                last_flush = time.time()

        # Final drain on shutdown
        while True:
            try:
                buffer.append(self._queue.get_nowait())
            except queue.Empty:
                break
        if buffer:
            self._flush(buffer)

    def _flush(self, buffer):
        if not buffer:
            return
        try:
            payload = "\n".join(json.dumps(evt) for evt in buffer)
            resp = self._session.post(self.url, data=payload, timeout=(5, 15), verify=False)
            if resp.status_code not in (200, 201):
                print(f"[SplunkHandler] HTTP {resp.status_code}: {resp.text[:200]}")
        except Exception as exc:
            print(f"[SplunkHandler] flush error: {exc}")

    def stop(self):
        """Signal the worker to stop and wait for the final flush (up to 20 s)."""
        self._stop_event.set()
        self.join(timeout=20)


class SplunkHECHandler(logging.Handler):
    """
    Async Python logging.Handler for Splunk HEC.

    Attach to any logger — emit() enqueues records without blocking.
    A single background thread batches and ships events every 5 s (or 100 events).
    The worker auto-respawns if killed by a framework restart (e.g. Django autoreloader).

    Usage:
        handler = SplunkHECHandler(url=..., token=..., service="my-service")
        logging.getLogger("gnana").addHandler(handler)
    """

    def __init__(
        self,
        url,
        token,
        service="aviso",
        environment="production",
        batch_size=100,
        flush_interval=5,
        max_queue_size=10000,
        level=logging.NOTSET,
    ):
        super().__init__(level)
        self._url = url
        self._token = token
        self._service = service
        self._environment = environment
        self._batch_size = batch_size
        self._flush_interval = flush_interval
        self._max_queue_size = max_queue_size
        self._worker_lock = threading.Lock()
        self._worker = self._make_worker()

    def _make_worker(self):
        w = AsyncLogWorker(
            url=self._url,
            token=self._token,
            batch_size=self._batch_size,
            flush_interval=self._flush_interval,
            max_queue_size=self._max_queue_size,
        )
        w.start()
        return w

    def _ensure_worker(self):
        """Respawn the worker thread if it has died (e.g. killed by atexit/reload)."""
        if not self._worker.is_alive():
            with self._worker_lock:
                if not self._worker.is_alive():
                    self._worker = self._make_worker()

    def emit(self, record):
        try:
            self._ensure_worker()
            now = time.time()
            event = {
                "time": round(now, 3),
                "sourcetype": "_json",
                "event": {
                    "timestamp": int(now * 1000),
                    "message": self.format(record),
                    "level": record.levelname,
                    "logger": record.name,
                    "filename": record.filename,
                    "lineno": record.lineno,
                    "funcName": record.funcName,
                    "trace_id": (_tracer.trace if _tracer else None),
                    "tenant": (getattr(_tenant_holder, 'name', None) if _tenant_holder else None),
                    "service": self._service,
                    "environment": self._environment,
                    "host": _HOST,
                    "process": record.process,
                },
            }
            self._worker.enqueue(event)
        except Exception:
            self.handleError(record)

    def close(self):
        self._worker.stop()
        super().close()
