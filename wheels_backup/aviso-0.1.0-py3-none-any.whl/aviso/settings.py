import os
import sys
import socket
import logging
import memcache
import datetime
from logging.config import dictConfig
from urllib.parse import urlparse, urlencode, parse_qsl, urlunparse  # Added required imports

from pymongo import MongoClient

from aviso.framework import event_holder, tenant_holder
from aviso.framework.metriclogger import Metriclogger
from aviso.framework.mongodb import GnanaMongoDB
from aviso.framework.postgresdb import GnanaPostgresDB
from aviso.utils import is_true, get_file_git_version

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SITE_ROOT = os.path.normpath(os.path.join(os.path.dirname(os.path.realpath(__file__)), '..'))

deploy_mode = os.environ.get('mode', 'development')
DEBUG = deploy_mode == 'development'
ISPROD = deploy_mode == 'production'
in_test_mode = is_true(os.environ.get('gnana_test_mode', 'false'))

event_context = event_holder
sec_context = tenant_holder

CNAME = os.environ.get('GNANA_CNAME', socket.gethostname())
CNAME_DISPLAY_NAME = os.environ.get('CNAME_DISPLAY_NAME', None)
POOL_PREFIX = CNAME_DISPLAY_NAME if CNAME_DISPLAY_NAME else CNAME
# CODE_VERSION = get_file_git_version(SITE_ROOT)

microservices_user = os.environ.get('MICROSERVICES_USER', '')
microservices_user_password = os.environ.get('MICROSERVICES_USER_PASSWORD', '')

AVISO_APPS = os.environ.get('AVISO_APPS', None)

gnana_cprofile_bucket = 'aviso-dev-profiles'
use_s3 = is_true(os.environ.get('USE_S3', 'False'))
TMP_DIR = '/tmp'

# -----------------------------------------------------------------------------
# POSTGRES SETUP
# -----------------------------------------------------------------------------
pg_db_con_url = os.environ.get('PG_DB_CONNECTION_URL', 'postgres://etluser:etluser@localhost:5432/etldb')
pg_url_parsed = urlparse(pg_db_con_url)

POSTGRES_DB_URL = pg_db_con_url
SQLALCHEMY_DATABASE_URI = pg_db_con_url
SQLALCHEMY_ENGINE_OPTIONS = {
    'pool_size': int(os.environ.get('SQLALCHEMY_POOL_SIZE', 10)),
    'max_overflow': int(os.environ.get('SQLALCHEMY_MAX_OVERFLOW', 20)),
    'pool_timeout': int(os.environ.get('SQLALCHEMY_POOL_TIMEOUT', 30)),
    'pool_recycle': int(os.environ.get('SQLALCHEMY_POOL_RECYCLE', 1800))
}

postgres_common_db_enabled = is_true(os.environ.get('postgres_common_db_enabled', ''))

gnana_db2 = GnanaPostgresDB()
gnana_db2.sec_context = sec_context

DEFAULT_OPSDB_URL = 'mysql://gnana:gnana@devopscenter.chm9s1xog441.us-east-1.rds.amazonaws.com:3306/gnana'
OPCENTER_PWD = os.environ.get('OPCENTER_DB_PASSWORD', None)

DB_CONFIG = {
    'opcenter': {
        'url': DEFAULT_OPSDB_URL,
        'password': OPCENTER_PWD
    }
}


# -----------------------------------------------------------------------------
# MONGODB SETUP (Restored from Old Settings)
# -----------------------------------------------------------------------------

# Helper function restored from old settings
def modify_mongo_db_url(url):
    max_pool_size = os.environ.get('max_pool_size', "1")
    max_idle_time_ms = os.environ.get('max_idle_time_ms', "30000")
    socket_timeout_ms = os.environ.get('socket_timeout_ms', "300000")
    retry_writes = os.environ.get('retry_writes', "false")
    ssl = is_true(os.environ.get('mongo_db_atlas_enabled', None))

    params = {
        "maxPoolSize": max_pool_size,
        "maxIdleTimeMS": max_idle_time_ms,
        "socketTimeoutMS": socket_timeout_ms,
        "retryWrites": retry_writes
    }
    if ssl:
        params['ssl'] = "true"

    url_parts = list(urlparse(url))
    query = dict(parse_qsl(url_parts[4]))
    query.update(params)
    url_parts[4] = urlencode(query)
    return urlunparse(url_parts)


# Default fallback URL
# mongo_db_url = os.environ.get('MONGODB_URI')
# mongo_db_con_url = os.environ.get('MONGO_DB_CONNECTION_URL')
# # Apply modifiers
# mongo_db_url = modify_mongo_db_url(mongo_db_url)
# mongo_db_url_parsed = urlparse(mongo_db_url)

# # Extract DB Name if not set
# if 'mongo-db-name' not in os.environ:
#     dbname = mongo_db_url_parsed.path.strip('/')
#     os.environ['mongo-db-name'] = dbname

# gnana_db = None
# try:
#     mongo_con = MongoClient(mongo_db_url, unicode_decode_error_handler='ignore')[os.environ['mongo-db-name']]
#     gnana_db = GnanaMongoDB(mongo_con)
#     gnana_db.is_prod = ISPROD
#     gnana_db.sec_context = sec_context
# except Exception as e:
#     print(f"Warning: Unable to connect to MongoDB: {e}")
#     gnana_db = None

gnana_db = GnanaMongoDB()
gnana_db.is_prod = ISPROD
gnana_db.sec_context = sec_context

# Local Cache DB Setup (Restored)
local_mongo_db = None
local_db = None

# try:
#     local_mongodb_url = "mongodb://{}:27017".format(os.environ.get('local_mongodb_url', 'localhost'))
#     local_mongo_db = MongoClient(local_mongodb_url, w=0)[os.environ.get('mongo-cache-db', 'local_cache')]
#     local_db = GnanaMongoDB(local_mongo_db)
# except Exception as e:
#     print("Unable to connect with the local mongodb for local cache service: " + str(e))
#     local_mongo_db = None
#     local_db = None

# -----------------------------------------------------------------------------
# CACHE & MEMCACHE
# -----------------------------------------------------------------------------
memcache_server = os.environ.get('MEM_CACHE_INSTANCE', 'localhost')


class CacheManager(object):
    def __init__(self):
        self.pid = os.getpid()
        self._cache = self._connect(DEBUG, memcache_server)

    def _connect(self, debug_mode, server):
        try:
            if debug_mode:
                return memcache.Client([server], server_max_value_length=30 * 1024 * 1024)
            else:
                import pylibmc
                return pylibmc.Client([server], binary=True, behaviors={"tcp_nodelay": True, "ketama": True})
        except Exception as e:
            print(f"Cache connection error: {e}")
            return None

    def get_client(self):
        # Handle fork safety (PID check)
        if self.pid != os.getpid():
            self.pid = os.getpid()
            self._cache = self._connect(DEBUG, memcache_server)
        return self._cache


cache_manager = CacheManager()
cache_con = cache_manager

cache_ttls = {
    'default': 60 * 60,
    'uip': 120 * 60,
}

GLOBAL_CACHE_URL = os.environ.get('GLOBAL_CACHE_URL', None)
if DEBUG:
    global_cache = memcache.Client([memcache_server], server_max_value_length=30 * 1024 * 1024)
else:
    import redis

    global_cache = redis.from_url(GLOBAL_CACHE_URL, socket_keepalive=True,
                                  socket_timeout=300) if GLOBAL_CACHE_URL else None

# -----------------------------------------------------------------------------
# LOGGING
# -----------------------------------------------------------------------------
syslog_address = '/dev/log' if sys.platform.startswith('linux') else '/var/run/syslog'

LOG_CONFIG = {
    'version': 1,
    'disable_existing_loggers': True,
    'formatters': {
        'simple': {
            'format': '%(levelname)s %(asctime)s %(process)d %(message)s'
        },
    },
    'handlers': {
        'console': {
            'level': 'DEBUG',
            'class': 'logging.StreamHandler',
            'formatter': 'simple'
        },
    },
    'loggers': {
        '': {  # Root logger
            'handlers': ['console'],
            'level': 'INFO',
        },
        'gnana': {
            'handlers': ['console'],
            'level': 'DEBUG' if DEBUG else 'INFO',
            'propagate': False
        }
    }
}

dictConfig(LOG_CONFIG)
logging.setLoggerClass(Metriclogger)
logger = logging.getLogger('gnana.core')

# -----------------------------------------------------------------------------
# EMAIL
# -----------------------------------------------------------------------------
EMAIL_HOST = os.environ.get('EMAIL_HOST', 'localhost')
EMAIL_PORT = int(os.environ.get('EMAIL_PORT', 25))
EMAIL_HOST_USER = os.environ.get('EMAIL_HOST_USER', '')
EMAIL_HOST_PASSWORD = os.environ.get('EMAIL_HOST_PASSWORD', '')
EMAIL_USE_TLS = is_true(os.environ.get('EMAIL_USE_TLS', 'False'))
EMAIL_SENDER = 'admin@aviso.com'

# -----------------------------------------------------------------------------
# APP CONFIG
# -----------------------------------------------------------------------------
ACCESSLOG = True
WORKER_POOL = os.environ.get('WORKER_POOL', 'primary-pool')

raw_script_users = os.environ.get('script_users', "")
script_users = [user + "@administrative.domain" for user in raw_script_users.split(':') if user]
script_users.extend([
    "etl_user@administrative.domain",
    "build_user@administrative.domain"
])
gnana_tenant_bucket = 'aviso-test-data'

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = '7^lq0*j2c14)&15r*ffb3p^l85cdjlc8-&s65e#=dzt8imh&9*'
postgres_common_db_enabled = is_true(os.environ.get('postgres_common_db_enabled', ''))
CNAME_DISPLAY_NAME = os.environ.get('CNAME_DISPLAY_NAME', None)

POOL_PREFIX = CNAME_DISPLAY_NAME if CNAME_DISPLAY_NAME else CNAME

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [
            os.path.join(SITE_ROOT, "aviso", "templates"),
        ],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

MIDDLEWARE = [
    # need to think weather need it or not #SECURITYMIDDLEWARE
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    # 'django.middleware.common.CommonMiddleware',
    # 'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    # 'django.middleware.clickjacking.XFrameOptionsMiddleware',
    'aviso.framework.middleware.TenantSupportMiddleware',
    'aviso.framework.middleware.SessionIdleTimeout',
]

AUTHENTICATION_BACKENDS = ('aviso.framework.authentication.MongoBackend',
                           'aviso.framework.authentication.SAMLBackend'
                           )

gnana_cprofile_bucket = 'aviso-dev-profiles'

INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'aviso',
]

BACKUP_CONFIG = is_true(os.environ.get('BACKUP_CONFIG', 'False'))

log_config = None

ROOT_URLCONF = 'aviso.urls'

ADMIN_DOMAIN = "administrative.domain"
DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

mongo_db_name = os.environ.get('mongo-cache-db', 'local_cache')

SDK_VERSION_FILE_NAME = str(AVISO_APPS) + '_SDK_VERSION'
try:
    with open(SDK_VERSION_FILE_NAME) as f:
        SDK_VERSION = f.read()
except:
    SDK_VERSION = 'NOT_DEFINED'


class S3ConnectionFactory(object):
    @staticmethod
    def get_storage(use_s3_flag):
        # Delayed import to avoid circular dependencies or unnecessary loading
        from aviso.framework.storage import GnanaS3Storage, GnanaFileStorage
        return GnanaS3Storage() if use_s3_flag else GnanaFileStorage()


gnana_storage = S3ConnectionFactory.get_storage(use_s3)