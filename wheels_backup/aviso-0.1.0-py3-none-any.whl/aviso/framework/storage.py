import os
import ssl
import sys
import time
import errno
import shutil
import codecs
import logging
import tempfile
from shutil import copyfile

import boto
import boto3
import boto.s3.key

from aviso.utils import mkdir_p
from aviso.framework import FileInfo, GnanaStorage
from aviso.settings import CNAME, gnana_tenant_bucket, ISPROD

logger = logging.getLogger('gnana.%s' % __name__)
home_dir = os.environ.get('HOME') or os.environ.get('USERPROFILE')
if not home_dir:
    raise RuntimeError("Neither HOME nor USERPROFILE environment variable is set.")
pathprefix = home_dir + '/tenants'


class S3Bucket(object):

    def __init__(self, bucket_name=None):
        self.s3 = boto.connect_s3()
        self.b = self.s3.get_bucket(bucket_name or gnana_tenant_bucket, validate=False)

    def __enter__(self):
        return self.b

    def __exit__(self, *args, **kwargs):
        self.s3.close()


class GnanaS3Storage(GnanaStorage):

    def get_file_path(self, path):
        return path

    def add_file_object(self, fobject, fullpath, filename, replace=False, bucket=gnana_tenant_bucket):
        with S3Bucket(bucket_name=bucket) as b:
            k = boto.s3.key.Key(b)
            k.key = '/'.join([fullpath, filename])
            status = k.set_contents_from_file(fobject, encrypt_key=True, replace=replace)
            if not status:
                logger.error("Unable to overwrite in S3 as your replace option is False - file %s" % fullpath)
                raise Exception('Unable to overwrite in S3 as your replace option is False')
            return True

    def addFile(self, tenant, inbox, dataset, file_type, file_name,
                local_file_path, replace=False, stackspecific=False, first_file=True, cname=CNAME):

        with S3Bucket() as b:
            k = boto.s3.key.Key(b)
            if stackspecific and cname:
                s3list = [tenant, cname, dataset, "_files", inbox, file_type, file_name]
                s3list_d = [tenant, cname, dataset, "_files", '_data', file_type, file_name]
            else:
                s3list = [tenant, dataset, "_files", inbox, file_type, file_name]
                s3list_d = [tenant, dataset, "_files", '_data', file_type, file_name]

            k.key = "/".join(s3list)
            if first_file and self.file_exists(tenant, '_data', dataset, file_type, file_name,
                                               stackspecific=stackspecific):
                if not replace:
                    logger.error("Same file %s uploaded and approved , if you want overwrite use replace True" % file_name)
                    raise Exception('Same file uploaded and approved , if you want overwrite use replace True')
                else:
                    existing_key = "/".join(s3list_d)
                    back_up = "/".join(['backup', tenant, dataset, "_files",
                                        '_data', file_type, file_name])
                    # b.objects[existing_key].copy_to(back_up)
                    b.copy_key(back_up, gnana_tenant_bucket, existing_key)

            status = k.set_contents_from_filename(local_file_path, encrypt_key=True, replace=replace)
            if not status:
                logger.error("Unable to overwrite in S3 as your replace option is False - file %s" % file_name)
                raise Exception('Unable to overwrite in S3 as your replace option is False')
        return k.key

    def add_adhoc_file(self, tenant, file_name, local_file_path, dataset=None, stackspecific=False, get_md5=False):
        with S3Bucket() as b:
            key_path = self.get_full_path_for_adhoc_file(tenant, file_name, dataset,
                                                         stackspecific=stackspecific)
            k = boto.s3.key.Key(b)
            k.key = key_path
            k.set_contents_from_filename(local_file_path, encrypt_key=True)
        if get_md5:
            return (k.key, k.md5)
        return k.key

    def put_file(self, tenant, file_name, local_file_path, dataset=None, stackspecific=False, md5=None):
        key_path = self.get_full_path_for_adhoc_file(tenant, file_name, dataset,
                                                     stackspecific=stackspecific)
        try:
            boto3.client('s3').put_object(
                Bucket=gnana_tenant_bucket,
                Key=key_path,
                Body=local_file_path,
                ContentMD5=md5)
            return {'success':True,'path':key_path}
        except Exception as e:
            logger.error(e)
            return {'success':False,'error':e}

    def get_full_path_for_adhoc_file(self, tenant, file_name, dataset=None, stackspecific=False, cname=CNAME):
        if dataset:
            s3list = [tenant, dataset, file_name]
            if stackspecific and cname:
                s3list = [tenant, cname, dataset, file_name]
            full_path = "/".join(s3list)
        else:
            full_path = "/".join([tenant, file_name])
        return full_path

    def move_file(self, tenant, inbox, dataset, file_type, file_name,
                  old_full_path, stackspecific=False):
        with S3Bucket() as b:
            k = b.lookup(old_full_path)
            s3list = [tenant, dataset, "_files", inbox, file_type, file_name]
            if stackspecific and CNAME:
                s3list = [tenant, CNAME, dataset, "_files", inbox, file_type, file_name]
            dest_key = "/".join(s3list)
            k.copy(gnana_tenant_bucket, dest_key, preserve_acl=True, encrypt_key=True)
            k.delete()
        return dest_key

    def copy_file(self, old_full_path, new_full_path, old_bucket_name, new_bucket_name):
        with S3Bucket(bucket_name=old_bucket_name) as b:
            k = b.lookup(old_full_path)
            k.copy(new_bucket_name, new_full_path, preserve_acl=True, encrypt_key=True)
            return k.size

    def get_known_stages(self, tenant, dataset, stackspecific=False):
        with S3Bucket() as b:
            prefix = "/".join([tenant, dataset, "_files"])
            if stackspecific and CNAME:
                prefix = "/".join([tenant, CNAME, dataset, "_files"])
            keys = b.list(prefix=prefix)
            known_stages = set()
            for kw in keys:
                try:
                    if stackspecific and CNAME:
                        (_tenant, _cname, _dataset, _dummy, _stage,
                         _filetype, _filename) = kw.name.split('/')
                    else:
                        (_tenant, _dataset, _dummy, _stage,
                         _filetype, _filename) = kw.name.split('/')
                except:
                    logger.info("Ignoring the path %s" % kw.name)
                    continue
                known_stages.add(_stage)
        return known_stages

    def adhocfilelist(self, tenant, path=None, delimiter='', bucket_name=None):
        """
        This methods returns the file info for any path for a given
        tenant. It is not tied to a datset or stage. If no path is
        specified, the top level info is returned.
        """
        with S3Bucket(bucket_name) as b:
            if path:
                prefix = "/".join([tenant, path])
            else:
                prefix = "/".join([tenant])

            # get_all_keys paginates the results, which we don't want.
            keys = b.list(prefix=prefix, delimiter=delimiter)
            for kw in keys:
                _names = kw.name.split('/')
                _fname = _names[-1] or _names[-2]
                yield {"fullpath": kw.name, "name": _fname}

    def filelist(self, tenant, inbox='_data', dataset=None, file_type=None, files=None, stackspecific=False, cname=CNAME):
        inbox = inbox or '_data'
        with S3Bucket() as b:
            if dataset:
                s3list = [tenant, dataset, "_files", inbox]
                if stackspecific and cname:
                    s3list = [tenant, cname, dataset, "_files", inbox]
                prefix = "/".join(s3list)
            else:
                prefix = "/".join([tenant])

            keys = b.list(prefix=prefix)
            for kw in keys:
                try:
                    if stackspecific and cname:
                        (_tenant, _cname, _dataset, _dummy, _stage,
                         _filetype, _filename) = kw.name.split('/')
                    else:
                        (_tenant, _dataset, _dummy, _stage,
                         _filetype, _filename) = kw.name.split('/')
                except Exception:
                    logger.debug("Ignoring the path %s", kw.name)
                    continue

                # No need to check and see if the dataset matches.  If a dataset
                # is specified, prefix is already limiting what keys we consider

                if file_type and (_filetype != file_type):
                    continue
                if not _filename:
                    continue

                info_args = (_dataset, _stage, _filetype, _filename, kw.name)
                if files:
                    if _filename in files:
                        yield FileInfo(*info_args)
                else:
                    yield FileInfo(*info_args)

    def open(self, fullpath, bucket=gnana_tenant_bucket):
        for dummy in range(10):
            try:
#                 tfile = BytesIO()
                tfile = tempfile.NamedTemporaryFile(delete=True)
                s3_data = s3reader(fullpath, bucket=bucket)
                for x in s3_data:
                    tfile.write(x)
                s3_data.close()
                tfile.seek(0)
                return tfile
            except Exception:
                logger.exception("Exception in reading from S3 file %s", fullpath)
        else:
            raise Exception('Unable to read from S3 file after 10 attempts')

    def open_in_utf_8(self, fullpath, bucket=gnana_tenant_bucket):
        for line in codecs.iterdecode(self.open(fullpath, bucket=bucket), 'utf-8', errors="surrogateescape"):
            for singleline in line.split('\r'):
                yield singleline

    def open_tar(self, fullpath, bucket=gnana_tenant_bucket):
        for dummy in range(10):
            try:
                with S3Bucket() as b:
                    k = b.lookup(fullpath)
                    tfile = tempfile.NamedTemporaryFile(delete=True)
                    k.get_contents_to_file(tfile)
                    tfile.seek(0)
                    return tfile
            except Exception:
                logger.exception("Exception in reading from S3 tar file %s", fullpath)
        else:
            raise Exception('Unable to read from S3 tar file after 10 attempts')

    def deleteFile(self, tenant, inbox, dataset, file_type, file_name, stackspecific=False):
        with S3Bucket() as b:
            s3list = [tenant, dataset, "_files", inbox, file_type, file_name]
            if stackspecific and CNAME:
                s3list = [tenant, CNAME, dataset, "_files", inbox, file_type, file_name]
            k = boto.s3.key.Key(b)
            k.key = "/".join(s3list)
            b.delete_key(k)

    def delete_adhoc_file(self, fullpath, bucket=gnana_tenant_bucket):
        with S3Bucket(bucket_name=bucket) as b:
            k = boto.s3.key.Key(b)
            k.key = fullpath
            b.delete_key(k)

    def delete_multiple_files(self, fullpath, bucket=gnana_tenant_bucket,
                              action='delete_specific_keys', keys_to_delete=[]):
        with S3Bucket(bucket_name=bucket) as b:
            if action == 'delete_all':
                keys_to_delete = b.list(prefix=fullpath)
            b.delete_keys(keys_to_delete)

    def file_exists(self, tenant, inbox, dataset, file_type, file_name, stackspecific=False):
        with S3Bucket() as b:
            k = boto.s3.key.Key(b)
            s3list = [tenant, dataset, "_files", inbox, file_type, file_name]
            if stackspecific and CNAME:
                s3list = [tenant, CNAME, dataset, "_files", inbox, file_type, file_name]
            k.key = "/".join(s3list)
            return k.exists()

    def if_exists(self, path, bucket=gnana_tenant_bucket):
        with S3Bucket(bucket_name=bucket) as b:
            k = boto.s3.key.Key(b)
            k.key = path
            return k.exists()

    def remove_tenant(self, name):
        # Do we really want to implement this????
        pass

    def save_daily_results_to_s3(self, file_name, data_dict):
        try:
            import json
            boto3.client('s3').put_object(
                Bucket='daily-results',
                Key=file_name,
                Body=json.dumps(data_dict))
            return {'success': True, 'path': file_name}
        except Exception as e:
            logger.error(e)
            return {'success': False, 'error': e}

    def read_daily_results_from_s3(self, file_name):
        try:
            import json
            return json.loads(boto3.client('s3').get_object(
                Bucket='daily-results',
                Key=file_name).get('Body').read())

        except Exception as e:
            logger.error(e)
            return {'success': False, 'error': e}

    def delete_daily_results_from_s3(self, file_name):
        try:
            import json
            return boto3.client('s3').delete_object(
                Bucket='daily-results',
                Key=file_name)

        except Exception as e:
            logger.error(e)
            return {'success': False, 'error': e}


class GnanaFileStorage(GnanaStorage):
    """
    An implementation of storage that simply utilizes the home directory.

    This can be in production if we ever use NTFS mounted directories.  S3
    is not necessarily safe due to eventual consistency.
    """

    def get_file_path(self, path):
        return '/'.join([pathprefix, path])

    def add_file_object(self, fobject, fullpath, filename, replace=False, bucket=None):
        fullpath = self.get_file_path(fullpath)
        mkdir_p(fullpath)
        file_path = "/".join([fullpath, filename])
        if not replace:
            if os.path.exists(file_path):
                return
        permission = 'w'
        fobj = fobject.read()
        if isinstance(fobj, bytes):
            permission = 'wb'
        with open(file_path, permission) as f:
            f.write(fobj)
        return file_path

    def addFile(self, tenant, inbox, dataset,
                file_type, file_name, local_file_path, replace, stackspecific=False, first_file=True):
        s3list = [pathprefix, tenant, dataset, "_files", inbox,
                  file_type]
        if stackspecific and CNAME:
            s3list = [pathprefix, tenant, CNAME, dataset, "_files", inbox, file_type]
        dirname = "/".join(s3list)
        mkdir_p(dirname)
        full_path = "/".join([dirname, file_name])
        copyfile(local_file_path, full_path)
        return full_path

    def add_adhoc_file(self, tenant, file_name, local_file_path, dataset=None, stackspecific=False):
        dirname = os.path.join(pathprefix, tenant)
        if stackspecific and CNAME:
            dirname = os.path.join(dirname, CNAME)
        if dataset:
            dirname = os.path.join(dirname, dataset)
        mkdir_p(dirname)
        full_path = os.path.join(dirname, file_name)
        copyfile(local_file_path, full_path)
        return full_path

    def get_full_path_for_adhoc_file(self, tenant, file_name, dataset=None, stackspecific=False):
        dirname = os.path.join(pathprefix, tenant)
        if stackspecific and CNAME:
            dirname = os.path.join(dirname, CNAME)
        if dataset:
            dirname = os.path.join(dirname, dataset)
        full_path = os.path.join(dirname, file_name)
        return full_path

    def move_file(self, tenant, inbox, dataset, file_type, file_name,
                  old_full_path, stackspecific=False):

        # Make sure required destination directory is present
        s3list = [pathprefix, tenant, dataset, "_files", inbox, file_type]
        if stackspecific and CNAME:
            s3list = [pathprefix, tenant, CNAME, dataset, "_files", inbox,
                      file_type]
        dirname = "/".join(s3list)
        mkdir_p(dirname)
        new_full_path = "/".join([dirname, file_name])
        os.rename(old_full_path, new_full_path)
        return new_full_path

    def copy_file(self, old_full_path, new_full_path, old_bucket_name, new_bucket_name):
        shutil.copy(old_full_path, new_full_path)

    def get_known_stages(self, tenant, dataset, stackspecific=False):
        dirname = os.path.join(pathprefix, tenant, dataset, "_files")
        if stackspecific and CNAME:
            dirname = os.path.join(pathprefix, tenant, CNAME, dataset, "_files")
        return set(os.listdir(dirname))

    def adhocfilelist(self, tenant, path=None, delimiter='', bucket_name=None):
        """
        This methods returns the file info for any path for a given
        tenant. It is not tied to a datset or stage. If no path is
        specified, the top level info is returned. This will not recurse by default.
        """
        def yield_this(tenant, path):
            dirname = os.path.join(pathprefix, tenant, path) if path else os.path.join(pathprefix, tenant)
            try:
                for ft in os.listdir(dirname):
                    fullpath = os.path.join(dirname, ft)
                    if not ft.startswith('.'):
                        yield {"fullpath": fullpath, "name": ft, "isdir": os.path.isdir(fullpath)}
            except OSError as err:
                if err.errno == errno.ENOENT:
                    pass
                else:
                    raise

        for x in yield_this(tenant, path):
            yield x

    def filelist(self, tenant, inbox=None, dataset=None, file_type=None, stackspecific=False):
        inbox = inbox or '_data'
        if dataset:
            for x in self.yield_files(tenant, inbox, dataset, file_type, stackspecific=stackspecific):
                yield x
        else:
            dirname = os.path.join(pathprefix, tenant)
            try:
                for dataset in os.listdir(dirname):
                    full_dataset_path = os.path.join(dirname, dataset)
                    if os.path.isdir(full_dataset_path):
                        for x in self.yield_files(tenant, inbox, dataset, file_type):
                            yield x
            except OSError as err:
                if err.errno == errno.ENOENT:
                    pass
                else:
                    raise

    def yield_files(self, tenant, inbox, dataset, file_type, files=None, stackspecific=False):
        dirname = os.path.join(pathprefix, tenant, dataset, "_files", inbox)
        if stackspecific and CNAME:
            dirname = os.path.join(pathprefix, tenant, CNAME, dataset, "_files", inbox)
        try:
            for ft in os.listdir(dirname):
                full_type_dir = os.path.join(dirname, ft)
                if (os.path.isdir(full_type_dir) and (not file_type or file_type == ft)):
                    for f in (files or os.listdir(full_type_dir)):
                        if not f.startswith('.'):
                            yield FileInfo(dataset, inbox, ft,
                                           f, os.path.join(full_type_dir, f))
        except OSError as err:
            if err.errno == errno.ENOENT:
                pass
            else:
                logger.error("OS Error (%s) while yielding files", err.errno,
                             exc_info=sys.exc_info())
                raise
        except:
            logger.error("Error while yielding files", exc_info=sys.exc_info())

    def open(self, fullpath, bucket=None):
        return open(fullpath, 'r', errors='surrogateescape')

    def open_in_utf_8(self, fullpath, bucket=gnana_tenant_bucket):
        return self.open(fullpath, bucket=gnana_tenant_bucket)

    def open_tar(self, fullpath, bucket=None):
        return open(fullpath, 'r')

    def deleteFile(self, tenant, inbox, dataset, file_type, file_name, stackspecific=False):
        fullpath = os.path.join(pathprefix, tenant, dataset,
                                "_files", inbox, file_type, file_name)
        if stackspecific and CNAME:
            fullpath = os.path.join(pathprefix, tenant, CNAME, dataset,
                                    "_files", inbox, file_type, file_name)
        os.remove(fullpath)

    def delete_adhoc_file(self, fullpath, bucket=None):
        try:
            os.remove(fullpath)
        except:
            pass

    def file_exists(self, tenant, inbox, dataset, file_type, file_name, stackspecific=False):
        fullPath = os.path.join(pathprefix, tenant, dataset, "_files",
                                inbox, file_type, file_name)
        if stackspecific and CNAME:
            fullPath = os.path.join(pathprefix, tenant, CNAME, dataset, "_files",
                                    inbox, file_type, file_name)
        return os.path.isfile(fullPath)

    def if_exists(self, path, *args, **kwargs):
        return os.path.isfile(self.get_file_path(path))

    def remove_tenant(self, tenant):
        tenant_path = os.path.join(pathprefix, tenant)
        try:
            shutil.rmtree(tenant_path)
        except OSError as ose:
            if ose.errno != errno.ENOENT:
                raise


class s3reader(object):
    """
    Duck typed class to allow passing S3 file as a stream into CSV reader.

    Not 100% compatible with any stream.
    """

    def __init__(self, key, bucket=gnana_tenant_bucket):

        self.s3 = boto.connect_s3()
        b = self.s3.get_bucket(bucket, validate=False)
        k = boto.s3.key.Key(b)
        k.name = key

        self.key = k
        self.key.open_read()
        self.existing = b''
        self.blocksize = 1400
        if ISPROD:
            self.blocksize = 8900
        self.end_of_everything = False

    def readline(self):
        fragments = []
        cb = None
        if self.existing:
            cb = self.existing
            self.existing = b''
        else:
            cb = self.read_more()

        while cb:
            parts = cb.split(b'\n', 1)
            fragments.append(parts[0])
            if len(parts) == 2:
                self.existing = parts[1]
                fragments.append(b'\n')
                return b''.join(fragments)
            else:
                cb = self.read_more()

        line_to_return = b''.join(fragments)
        return line_to_return

    def read_more(self, wait_time=1):
        if self.end_of_everything:
            return None
        try:
            cbuffer = self.key.read(self.blocksize)
        except ssl.SSLError as err:
            if 'timed out' in str(err):
                # Retry in case of timeout
                if wait_time >= 300:
                    logger.warning("Reached the maximum wait time. Raising timeout error")
                    raise err
                else:
                    logger.warning("Timeout reading the next block. Waiting for %s seconds . . . ", wait_time)
                    time.sleep(wait_time)
                    return self.read_more(wait_time=min(300, wait_time * 2))
            else:
                raise err
        if not cbuffer:
            self.end_of_everything = True
        return cbuffer

    def __iter__(self):
        line = self.readline()
        while line:
            yield line
            line = self.readline()

    def close(self):
        self.key.close()
        self.s3.close()
