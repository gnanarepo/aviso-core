"""
This module provides the cache abstraction including a name space concept
implemented using https://code.google.com/p/memcached/wiki/NewProgrammingTricks
"""
import hashlib
import logging
from inspect import stack
from uuid import uuid4
from functools import wraps

from aviso.settings import cache_ttls, cache_con
from aviso.settings import sec_context
from aviso.utils.misc_utils import get_nested, set_nested, pop_nested, try_index

TEN_MINUTES = 60 * 10
default_ttl = cache_ttls.get('default', 60*60)


logger = logging.getLogger('gnana.%s' % __name__)

_PYCACHE = {}

def get_group_prefix(key, group):

    # Get current group prefix
    group_prefix = cache_con.cache.get('group.%s' % group)
    if not group_prefix:
        group_prefix = uuid4()
        cache_con.cache.set('group.%s' % group, group_prefix, time=cache_ttls.get(group, default_ttl))
    return "%s.%s" % (group_prefix, key)


def put_into_cache(key, value, group, totalsize=-1, chunker=None, exp_time=None):

    # If no cache is initialized, it is a no-op
    if not cache_con.cache:
        return

    # Put the value now
    try:
        grp = get_group_prefix(key, group)
        cache_success = cache_con.cache.set(grp, value, time=exp_time if exp_time else cache_ttls.get(group, default_ttl))
        if cache_success is False and chunker:
            chunk_keys = []
            for i, chunk in enumerate(chunker.chunk(value)):
                chunk_key = hashlib.md5(grp + '_chunk_{}'.format(i)).hexdigest()
                cache_con.cache.set(chunk_key, chunk, time=exp_time if exp_time else cache_ttls.get(group, default_ttl))
                chunk_keys.append(chunk_key)
            cache_con.cache.set(grp, {'__chunks__': chunk_keys}, time=exp_time if exp_time else cache_ttls.get(group, default_ttl))
        logger.debug("saving %s key into memcache" % key)
    except Exception as ex:
        logger.warning('Unable to cache %s of size %s due to %s ', key, totalsize, str(ex))
        if not chunker:
            return
        logger.warn('retrying cache set with chunker')
        try:
            chunk_keys = []
            for i, chunk in enumerate(chunker.chunk(value)):
                chunk_key = hashlib.md5(grp + '_chunk_{}'.format(i)).hexdigest()
                cache_con.cache.set(chunk_key, chunk, time=exp_time if exp_time else cache_ttls.get(group, default_ttl))
                chunk_keys.append(chunk_key)
            cache_con.cache.set(grp, {'__chunks__': chunk_keys}, time=exp_time if exp_time else cache_ttls.get(group, default_ttl))
        except Exception as e:
            logger.warn('failed cache set with chunker: %s', str(e))


def get_from_cache(key, group, chunker=None):

    logger.debug("getting %s from memcache" % key)
    try:
        result = cache_con.cache.get(get_group_prefix(key, group))
        if result and isinstance(result, dict) and  ('__chunks__' in result and chunker):
            logger.info('dechunking cache get')
            try:
                chunks = [cache_con.cache.get(chunk_key) for chunk_key in result['__chunks__']]
                return chunker.dechunk(chunks)
            except Exception as e:
                logger.warn('failed to dechunk: %s, callstack: %s', str(e), stack())
        return result
    except Exception as ex:
        logger.warning("unable to read %s due to %s", key, str(ex))


def remove_group(group):
    cache_con.cache.delete('group.%s' % group)


def remove_key(key, group):
    cache_con.cache.delete(get_group_prefix(key, group))


def get_set_from_cache(key, group, fn):
    val = get_from_cache(key, group)
    if not val:
        val = fn()
        put_into_cache(key, val, group)
    return val


def remove_from_cache(func_name, *args, **kwargs):
    if not cache_con.cache:
        return
    key = make_cache_key(func_name, args, kwargs)
    try:
        remove_key(key, sec_context.details.name)
    except Exception as ex:
        logger.warning("unable to remove %s due to %s", func_name, str(ex))


def memcached(func):
    def cached_func(*args, **kwargs):
        try:
            key = make_cache_key(func.__name__, args, kwargs)
            ret_val = get_from_cache(key, sec_context.details.name)
            assert ret_val is not None
        except Exception as e:
            ret_val = func(*args, **kwargs)
            try:
                put_into_cache(key, ret_val, sec_context.details.name)
            except Exception as ee:
                pass
        return ret_val
    return cached_func


def make_cache_key(func_name, args, kwargs):
    return hashlib.md5("%s%s%s" % (func_name,
                                   [str(arg, 'utf-8') for arg in args],
                                   [(str(k, 'utf-8'), str(v, 'utf-8')) for k, v in sorted(kwargs.items())])
                              ).hexdigest()


def memcacheable(cache_name, *cacheargs, **cache_kwargs):
    """
    decorator to add to a function or class to cache results
    caches result of call or instantiation in MEMCACHED

    MEMCACHED considerations:
    -   as of 2/23/2018, all our environments have at most 1 memcached server (some alphas have None)
        so we dont have to worry about keeping caches in sync, since theres only 1
        if at any point that changes, this will need to be rearchitected (and probably a bunch of other stuff)

    -   memcached has a size limit for the values it can store of 1MB
        in the event you want to store something larger than that, there are two ways to try and get around it
        encoding:
            try to encode the value into something that takes less space
            pass an encoder class which has static 'encode' and 'decode' methods (ex HierEncoder)
        chunking:
            split value up into smaller chunks that will fit into cache
            pass a chunker class which has static 'chunk' and 'dechunk' methods (ex HierChunker)

    -   memcached is a {key: value} store, there is no nesting like {key: {inner_key: value}}
        the key for storing the value is constructed using the cache_name, and the function/class value of each cache_arg
        example:
            >>> @memcacheable('cachey', ('val1', 0), ('val2', 1))
            >>> def add_vals(val1, val2):
            >>>     return val1 + val2
            >>> add_vals(10, 5)
            the memcached key will be a hashed version of ['cachey', 10, 5] and the value will be 15

    Arguments
    ---------
    cache_name: str, required
        name of cache

    cacheargs: tuple, optional, (arg name, arg position)
        name that maps to argument in decorated function, used to make key for storing in cache
        and the position of that argument in function call

    encoder: class, optional
        class providing an encode and decode method

    chunker: class, optional
        class providing a chunk and dechunk method
    """
    def decorator(func):
        @wraps(func)
        def wrapped(*args, **kwargs):
            if kwargs.pop('skip_cache', None):
                return func(*args, **kwargs)

            chunker = cache_kwargs.get('chunker')
            encoder = cache_kwargs.get('encoder')

            key = make_cache_key(cache_name, get_cache_args(cacheargs, *args, **kwargs), {})
            val = get_from_cache(key, sec_context.details.name, chunker=chunker)
            if not val:
                val = func(*args, **kwargs)
                cache_val = encoder.encode(val) if encoder else val
                put_into_cache(key, cache_val, sec_context.details.name, chunker=chunker, exp_time=TEN_MINUTES)
            if encoder:
                try:
                    val = encoder.decode(val)
                except Exception as e:
                    #  TEMP: trying to figure out whats going on in memcached
                    logger.warn('failed to decode error: %s, with kwargs: %s', str(e), cache_kwargs)
                    val = func(*args, **kwargs)
            return val
        return wrapped
    return decorator


def clears_memcache(cache_name, *cacheargs, **cache_kwargs):
    """
    decorator to add to a function or class to clear cache
    clears results in MEMCACHED

    MEMCACHED considerations:
    -   memcached is a {key: value} store, there is no nesting like {key: {inner_key: value}}
        if you want to clear multiple keys at once you can use an arg_maker
        arg_maker:
            make more args out of the cache_args passed to clears_memcache
            pass an arg_maker class which has a static 'make' method (ex MonthMaker)

    Arguments
    ---------
    cache_name: str, required
        name of cache

    cacheargs: tuple, optional, (arg name, arg position)
        name that maps to argument in decorated function, used to make key for storing in cache
        and the position of that argument in function call

    arg_maker: class, optional
        class providing a make method
    """
    def decorator(func):
        @wraps(func)
        def wrapped(*args, **kwargs):
            val = func(*args, **kwargs)
            key_args = get_cache_args(cacheargs, *args, **kwargs)
            arg_maker = cache_kwargs.get('arg_maker')
            clear_keys = [key_args] if not arg_maker else [key_args + [arg] for arg in arg_maker.make(*key_args)]
            for clear_key in clear_keys:
                key = make_cache_key(cache_name, clear_key, {})
                try:
                    remove_key(key, sec_context.details.name)
                except Exception as e:
                    logger.warn(e)
            return val
        return wrapped
    return decorator


def pycacheable(cache_name, *cacheargs, **cache_kwargs):
    """
    decorator to add to a function or class to cache results
    caches result of call or instantiation in PYCACHE

    PYCACHE considerations:
    -   PYCACHE is just a globally scoped python dictionary
        since its a dictionary, you can nest keys {key: {inner_key: value}}
        the keys for storing the value is constructed using the cache_name, and the function/class value of each cache_arg
        example:
            >>> @pycacheable('cachey', ('val1', 0), ('val2', 1))
            >>> def add_vals(val1, val2):
            >>>     return val1 + val2
            >>> add_vals(10, 5)
            pycache will now look like {'cachey': {10: {5: 15}}}

    -   PYCACHE lives on the backend server
        since some of our environments have multiple boxes/thread, we have to do some work to keep them in sync
        ex if the cache is invalidated on server A, it better get invalidated on server B too
        pycache transparently handles this with cache versioning using memcached as a store of the version

    -   the hit rate for pycache will be lower than memcached
        because of the multiple boxes/threads the hit rate between sessions will be around 25%
        within sessions, if a session val is passed or memcached is on, the hit rate should be 100%

    -   there is some overhead in checking the version number from memcached
        so it is not optimal to use this for a quick calculation that you make 100s of times

    Arguments
    ---------
    cache_name: str, required
        name of cache

    cacheargs: tuple, optional, (arg name, arg position)
        name that maps to argument in decorated function, used to make key for storing in cache
        and the position of that argument in function call
    """
    def decorator(func):
        @wraps(func)
        def wrapped(*args, **kwargs):
            ucache_name = str(cache_name)
            session = cache_kwargs.get('session', False)
            cache_keys = [sec_context.name, ucache_name] + get_cache_args(cacheargs, *args, **kwargs)
            # get latest version # of cache from memcached
            latest_version = get_pycache_version(cache_keys)
            cached_val, cached_version, cached_session = get_nested(_PYCACHE, cache_keys, (None, None, None))
            # regenerate val if:
            # no value in cache
            # no connection with memcached to check version AND session doesnt match cashed session
            # version in memcached doesnt match version in cache
            if cached_val is None or (latest_version is False and session != cached_session) or cached_version != latest_version:
                if not latest_version:
                    latest_version = 0
                val = func(*args, **kwargs)
                set_nested(_PYCACHE, cache_keys, (val, latest_version, session))
            return get_nested(_PYCACHE, cache_keys)[0]
        return wrapped
    return decorator


def clears_pycache(cache_name, *cacheargs):
    """
    decorator to remove items from cache

    PYCACHE considerations:
    -   PYCACHE is a dictionary, so instead of clearing value at a time, you can clear many levels at once
        example:
            >>> @pycacheable('cachey', ('Q', 0), ('P', 1))
            >>> def period_is_future(Q, P):
            >>>     return True
            >>> period_is_future('2019Q1', '201802')
            >>> period_is_future('2019Q1', '201803')
            pycache will now look like {'cachey': {'2019Q1': {'201802': True, '201803': True}}
            once it becomes 201803, 201802 is no longer true and so you could invalidate like
            >>> @clears_pycache('cachey', ('Q', 0), ('P', 1))
            >>> def period_is_past(Q, P):
            >>>     return
            >>> period_is_past('2019Q1', '201802')
            pycache will now be {'cachey': {'2019Q1': {'201803': True}}
            but if its now 2019Q2, you could also invalidate all of Q1 in one go
            >>> @clears_pycache('cachey', ('Q', 0))
            >>> def quarter_is_past(Q):
            >>>     return
            >>> quarter_is_past('2019Q1')
            pycache will now be {'cachey': {'2019Q1': {}}

    -   pycache versioning is saved in memcached
        when a value is first saved, its version is set to 0
        when the cache gets cleared, the version number gets incremented in memcached
        when fetching from cache, we check that the cache version is not less than the latest memcache version

    Arguments
    ---------
    cache_name: str, required
        name of cache

        cacheargs: tuple, optional, (arg name, arg position)
            name that maps to argument in decorated function, used to make key for storing in cache
            and the position of that argument in function call
    """
    def decorator(func):
        @wraps(func)
        def wrapped(*args, **kwargs):
            ucache_name = str(cache_name)
            ret_val = func(*args, **kwargs)
            cache_keys = [sec_context.name, ucache_name] + get_cache_args(cacheargs, *args, **kwargs)
            pop_nested(_PYCACHE, cache_keys)
            incr_pycache_version(cache_keys)
            return ret_val
        return wrapped
    return decorator


ARGS_CACHE = {}
def get_cache_args(cacheargs, *args, **kwargs):
    args_hash = (str(cacheargs), str(args), str(kwargs))
    try:
        return ARGS_CACHE[args_hash]
    except KeyError:
        val = [kwargs.get(k, try_index(args, i)) for k, i in cacheargs]
        ARGS_CACHE[args_hash] = val
        return val


def get_pycache_version(cache_keys):
    """
    gets the latest version of pycache from memcached
    pycache is nested dict, so we try to find the latest version for the deepest nesting
    returns False if no cache connection found
    returns 0 if no version info found in cache
    """
    # some protection against cache server being down
    try:
        # dev environment use python-memcached, which returns 0 if cache is down
        cache_alive = cache_con.cache.set('dummy', 'check') != 0
    except Exception as e:
        # prod uses pylibmc which raises an exception if cache is down
        logger.warn(e)
        cache_alive = False
    if not cache_alive:
        return False
    version_keys = [x for x in cache_keys]
    while len(version_keys) > 1:
        latest_version = cache_con.cache.get(hashlib.md5(str(version_keys)).hexdigest())
        if latest_version:
            return latest_version
        version_keys.pop()
    return 0


def incr_pycache_version(cache_keys):
    """
    increments latest version of pycache
    """
    # grab latest version so we can increment it
    latest_version = get_pycache_version(cache_keys)
    if not latest_version:
        latest_version = 0
    version_key = hashlib.md5(str(cache_keys)).hexdigest()
    try:
        # increment cache version (add only stores in memcached if key doesnt already exist)
        cache_con.cache.add(version_key, latest_version)
        cache_con.cache.incr(version_key)
    except Exception as e:
        # protection against cache failures on prod
        logger.warn(e)


def set_pycache_version(cache_keys, version):
    """
    sets the latest version of pycache from memcached
    """
    version_key = hashlib.md5(str(cache_keys)).hexdigest()
    try:
        cache_con.cache.set(version_key, version)
    except Exception as e:
        # protection against cache failures on prod
        logger.warn(e)