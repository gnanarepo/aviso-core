import re
import pytz
import logging
from functools import wraps
from collections import defaultdict
from datetime import datetime, date
from itertools import chain, combinations, islice, cycle
from operator import lt, gt, le, ge, itemgetter, add, mul, sub

from aviso.settings import sec_context

logger = logging.getLogger('gnana.%s' % __name__)


CURR_TABLE = {u'USD': u'$',
              u'EUR': u'\u20ac',
              u'GBP': u'\xA3'}

MONTH_NAMES = ['January', 'Feburary', 'March', 'April', 'May', 'June',
               'July', 'August', 'September', 'October', 'November', 'December']

range_lambdas = {}

SNIPPET_DATE = r'(?P<year>\d{1,})-(?P<month>\d{1,2})-(?P<day>\d{1,2})'
SNIPPET_TIME = r'(?P<hour>\d{1,2}):(?P<minute>\d{1,2}):(?P<second>\d{1,2})' + \
               r'(?:\.(?P<subsecond>\d+))?'
SNIPPET_ZONE = r'(?:(?P<tz_sign>[-+])(?P<tz_hour>\d{1,2})' + \
               r'(?::?(?P<tz_minute>\d{1,2})(?::?(?P<tz_second>\d{1,2}))?)?)' + \
               r'|(?P<tz_utc>[Zz])'

SNIPPET_ZONE_REST = r'(?:(?P<tz_sign>[-+])(?P<tz_hour>\d{1,2})(?P<tz_minute>\d{1,2}))'

PATTERN_DATE = r'^%s(?:%s)?$' % (SNIPPET_DATE, SNIPPET_ZONE)
PATTERN_DATETIME = r'^%s[T ]%s(?:%s)?$' % (SNIPPET_DATE, SNIPPET_TIME,
                                           SNIPPET_ZONE)

PATTERN_DATETIME_REST = r'^%s[T]%s%s$' % (SNIPPET_DATE, SNIPPET_TIME, SNIPPET_ZONE_REST)

RE_DATE = re.compile(PATTERN_DATE)
RE_DATETIME = re.compile(PATTERN_DATETIME)
RE_DATETIME_REST = re.compile(PATTERN_DATETIME_REST)
MIN_DATE = date(1900, 1, 1)



class defaultvaldict(defaultdict):
    def __init__(self, dicttype=float, default=0.0):
        defaultdict.__init__(self, dicttype)
        self.default = default

    def __getitem__(self, key):
        val = defaultdict.get(self, key, self.default)
        try:
            return float(val[0])
        except (TypeError, ValueError):
            return val

    def get(self, key, default=None):
        default = default if default is not None else self.default
        return defaultdict.get(self, key, default)


def try_float(maybe_float, default=0.0):
    try:
        return float(maybe_float)
    except:
        return default


def pct_str_to_float(x, default=0.0):
    """ Convert a string to a float."""
    if isinstance(x, str) and '%' in x:
        try:
            return float(x.strip('%'))/100
        except:
            return default
    else:
        return try_float(x, default)


def pct_float_to_str(val):
    return "{:.1%}".format(val)


def sub_fields(dct, flds, key, def_val=None):
    """ Substitutes all values of a field."""
    for fld in flds:
        try:
            dct[fld] = dct[fld][key]
        except:
            dct[fld] = def_val
    return dct


def powerset(iterable):
    """ Given an iterable, return a new iterable of all subsets."""
    xs = list(iterable)
    return chain.from_iterable(combinations(xs, n)
                               for n in range(len(xs) + 1))


def inrange(val, range_tuple):
    """Check if a value is in a range. A range tuple looks like
    (50,60,True,False) means 50<x<=60.
    Nones in the first 2 places mean -inf and +inf respectively.
    """
    range_tuple = tuple(range_tuple)
    try:
        return range_lambdas[range_tuple](val)
    except KeyError:
        pass
    try:
        left_op = gt if range_tuple[2] else ge
    except IndexError:
        left_op = gt
    try:
        right_op = lt if range_tuple[3] else le
    except IndexError:
        right_op = lt
    try:
        if range_tuple[1] is None:
            range_lambdas[range_tuple] = lambda x: left_op(x, range_tuple[0])
        else:
            range_lambdas[range_tuple] = lambda x: left_op(x, range_tuple[0]) and right_op(x, range_tuple[1])
        return range_lambdas[range_tuple](val)
    except IndexError:
        return False


def format_val(val, fmt, c=None, ep_cache=None):
    """Format a value for display according to our standard conventions."""
    from aviso.utils.dateUtils import epoch
    if fmt == 'amount':
        val = try_float(val)
        abs_val = abs(val)
        curr = CURR_TABLE.get(c, '$')
        neg_prefix = '-' if val != abs_val else ''
        for (exp, letter) in [(9, 'B'), (6, 'M'), (3, 'K')]:
            if abs_val >= 10 ** exp:
                return neg_prefix + '{}{:0,.1f}{}'.format(curr, abs_val / 10 ** exp, letter)
        else:
            return neg_prefix + '{}{:0,.1f}'.format(curr, abs_val)
    elif fmt == 'longAmount':
        val = try_int(val)
        abs_val = abs(val)
        curr = CURR_TABLE.get(c, '$')
        neg_prefix = '-' if val != abs_val else ''
        return neg_prefix + '{}{:,}'.format(curr, val)
    elif fmt == 'excelDate':
        try:
            try:
                return ep_cache[val]
            except:
                ret_val = datetime.strftime(epoch(try_float(val, 'N/A')).as_datetime(), '%b %d')
                if ep_cache is not None:
                    ep_cache[val] = ret_val
                return ret_val
        except:
            return 'N/A'
    elif fmt == 'stringDate':
        try:
            return datetime.strftime(epoch(val).as_datetime(), '%Y-%m-%d')
        except:
            return 'N/A'
    elif fmt == 'none':
        return val
    elif fmt == 'calMonth':
        yyyy, mm = val[:4], int(val[4:])
        return '{month} {year}'.format(month=MONTH_NAMES[mm-1], year=yyyy)
    elif fmt == 'yyyymmdd':
        try:
            yyyy, mm, dd = int(val[:4]), int(val[4:6]), int(val[6:8])
            return '{month}/{day}/{year}'.format(month=mm,
                                                 day=dd,
                                                 year=yyyy)
        except:
            return 'N/A'
    else:
        return "'%s'" % val


def get_nested(input_dict, nesting, default=None):
    """
    get value (or dict) from nested dict by specifying the levels to go through
    """
    if not nesting:
        return input_dict
    for level in nesting[:-1]:
        input_dict = input_dict.get(level, {})
    return input_dict.get(nesting[-1], default)


def get_asof(dtls, fld, asof):
    """
    takes a timeseries list (dtls) and returns the field value as of a specific timestamp
    """
    try:
        return [x[1] for x in dtls[fld] if x[0] <= asof][-1]
    except:
        return dtls.get(fld, [[None, None]])[0][1]



def set_nested(input_dict, nesting, value):
    """
    set value (or dict) in nested dict by specifying the path to traverse
    """
    if not nesting:
        input_dict.clear()
        return
    curr_dict = input_dict
    for level in nesting[:-1]:
        try:
            curr_dict = curr_dict[level]
        except KeyError:
            curr_dict[level] = {}
            curr_dict = curr_dict[level]
    curr_dict[nesting[-1]] = value


def pop_nested(input_dict, nesting, default=None):
    """
    pop value (or dict) from nested dict by specifying the levels to go through
    """
    if not nesting:
        return input_dict
    for level in nesting[:-1]:
        input_dict = input_dict.get(level, {})
    return input_dict.pop(nesting[-1], default)


def get_nesting(dicty):
    """
    yield list of nestings in dictionary
    >>> dicty =  {'a': {'1': '1'}, 'b': {'2': {'*': '*'}, '3': {'&': '&'}}}
    >>> list(get_nesting(dicty))
    [['b', '2', '*'], ['b', '3', '&'], ['a', '1']]
    """
    stack = [(k, v, [k]) for k, v in dicty.items()]
    while stack:
        key, value, nesting = stack.pop()
        try:
            stack.extend((kid, kid_value, nesting + [kid]) for kid, kid_value in value.items())
        except AttributeError:
            yield nesting


# helper function
def iter_chunks(my_list, batch_size=5):
    start = 0
    more = True
    while more:
        end = start + batch_size
        if end < len(my_list):
            yield my_list[start:end]
            start = end
        else:
            more = False
            yield my_list[start:]


def dict_chunks(data, batch_size=5):
    it = iter(data)
    for _ in range(0, len(data), batch_size):
        yield {k: data[k] for k in islice(it, batch_size)}


def set_chunks(data, batch_size=5):
    it = iter(data)
    for _ in range(0, len(data), batch_size):
        yield {k for k in islice(it, batch_size)}


def percent_change(new, old, round_val=True):
    new, old = try_float(new), try_float(old)
    try:
        if round_val:
            return round((((1. * new - old) / abs(old)) * 100), 1), 'percentage'
        return (((1. * new - old) / abs(old)) * 100), 'percentage'
    except ZeroDivisionError:
        return new, 'amount'


def describe_trend(val):
    if val in [0, None]:
        return 'no_arrow', 'no difference to', 'ok'
    if val < 0:
        return 'down_arrow', 'below', 'bad'
    elif val > 0:
        return 'up_arrow', 'above', 'good'
    logger.info('Mystery value {}'.format(val))
    return 'no_arrow', 'no difference to', 'ok'


def index_of(val, array):
    """
    returns index in presorted array where val would be inserted (to left)
    """
    low, high = 0, len(array) - 1
    while low <= high:
        mid = (high + low) // 2
        if array[mid] == val:
            return mid
        elif val < array[mid]:
            high = mid - 1
        else:
            low = mid + 1
    return low - 1 if low else low


def flatten_to_list(*args, **kwargs):
    """
    takes arguments that may be strings or lists or lists of lists and returns flattened list
    ex:
    combine_to_list(1, 2, 3, [4, 5], 6, [[[7],8], 9])
    [1, 2, 3, 4, 5, 6, 7, 8, 9]
    """
    flat_list = kwargs.get('flat_list', [])
    for arg in args:
        if isinstance(arg, list):
            flatten_to_list(*arg, flat_list=flat_list)
        else:
            flat_list.append(arg)
    return flat_list


def flatten_to_dict(dictionary):
    """
    takes a nested dictionary and flattens to one level
    {'A': 1, 'B': {'c': 2, 'd': 3}} --> {'A': 1, 'B_c': 2, 'B_d': 3}
    """
    new_dict = {}
    for key, value in dictionary.items():
        if isinstance(value, dict):
            for suffix, val in value.items():
                new_dict[key + '_' + suffix] = val
        else:
            new_dict[key] = value
    return new_dict


def flatten_to_dict_and_flip(dictionary):
    """
    takes a nested dictionary and flattens to one level, then flips keys and values
    {'A': [1, 2] , 'B': {'c': 3, 'd': 4}, 'E': 5, 'F': 5} --> {1: ['A'], 2: ['A'], 3: ['B_c'], 4: ['B_d'], 5: ['E', 'F']}
    """
    new_dict = defaultdict(list)
    for field, val in dictionary.items():
        if isinstance(val, dict):
            for suffix, value in val.items():
                if isinstance(value, list):
                    for v in value:
                        new_dict[v].append(field + '_' + suffix)
                else:
                    new_dict[value].append(field + '_' + suffix)
        else:
            if isinstance(val, list):
                for v in val:
                    new_dict[v].append(field)
            else:
                new_dict[val].append(field)
    return new_dict


def trimsort(iterable, distinct, key=None):
    """
    sort an iterable by key, and keep only the first unique item by distinct
    iterable = [{'a': 1, 'b': 2}, {'a': 1, 'b': 3}, {'a': 2, 'b': 4}, {'b': 5}]
    trimsort(iterable, 'a') --> [{'a': 1, 'b': 2}, {'a': 2, 'b': 4}]
    """
    sorted_iter = sorted(iterable, key=key)
    seen = set()
    for item in sorted_iter:
        try:
            distinct_val = itemgetter(distinct)(item)
        except (KeyError, IndexError):
            continue
        if distinct_val not in seen:
            yield item
        seen.add(distinct_val)


def merge_iterator(lol):
    flat_list = [tuple(list(x) + [i]) for (i, lst) in enumerate(lol) for x in lst]
    flat_list.sort()
    currs = [None for lst in lol]
    for (t, v, i) in flat_list:
        currs[i] = v
        yield (t, currs)


def try_int(x, default=None):
    try:
        return int(x)
    except:
        return default


def arg_min(itr, fn):
    return min((fn(x), x) for x in itr)[1]


def least_upper_bound(lst, x):
    """ lst is a sorted (descending order) iterable
        x is the value we're interested in """
    for i, v in enumerate(lst):
        if not i:
            if v < x:
                return None
        else:
            if lst[i] < x:
                break
        lub = v
    return lub


def prune_list(lst, sensitivity):
    return [val for index, val in enumerate(lst)
            if index in [0, len(lst) - 1] or val - lst[index - 1] >= sensitivity]


def prune_pfx(fld):
    """ Helper function to prune the time-slicing prefix from field name"""
    if fld.startswith('latest_'):
        return fld[7:]
    elif fld.startswith('as_of_fv_'):
        return fld[9:]
    elif fld.startswith('as_of_'):
        return fld[6:]
    elif fld.startswith('frozen_'):
        return fld[7:]
    else:
        return fld


def prune_sfx(fld):
    """Helper function to prune suffixed field names"""
    suffixes = ['_ui', '_asof', '_adj', '_bucket']
    for suffix in suffixes:
        fld = fld.replace(suffix, '')
    return fld


def prune_all(fld):
    return prune_pfx(prune_sfx(fld))


def get_standard_nm(fld):
    std_fld_nms = ['ForecastCategory', 'TypeTrans', 'CloseDate', 'StageTrans', 'OwnerID']
    for std_nm in std_fld_nms:
        if std_nm.lower() in fld.lower():
            return std_nm
    return fld


def get_readable(fld_name):
    if 'ForecastCategory' in fld_name:
        return 'Forecast Category'
    elif 'Stage' in fld_name:
        return 'Stage'
    elif 'CloseDate' in fld_name:
        return 'Close Date'
    else:
        return fld_name


def merge_dicts(*dictionaries):
    """
    combine dictionaries together
    """
    result = {}
    for dictionary in dictionaries:
        result.update(dictionary)
    return result


def merge_set_dicts(*dictionaries):
    """
    combine dictionaries of sets
    """
    result = defaultdict(set)
    for dictionary in dictionaries:
        for k,v in dictionary.items():
            result[k] |= v
    return result


def get_dep_fields(field, fm_config):
    """
    get dependent fields for fm category from fm config
    """
    try:
        for field in get_nested(fm_config, ['categories', field, 'fields'], [field]):
            yield (field, get_nested(fm_config, ['categories', field], {}))
    except TypeError:
        yield (field, get_nested(fm_config, ['categories', field], {}))


def get_sfx_fields(node, mgr, values, *fields):
    """
    get suffixed fields if in values, otherwise return nonsuffixed
    """
    if node == mgr:
        for field in fields:
            yield field
    sfx = '_mgr'
    for field in fields:
        if field + sfx in values:
            yield field + sfx
        else:
            yield field


def remove_key(lst, key):
    new_lst = []
    for item in lst:
        new_lst.append({k:v for k,v in item.items() if k != key})
    return new_lst


def merge_nested_dicts(dict1, dict2):
    """
    merge two nested dictionaries together
    """
    for key in dict2:
        if key in dict1 and isinstance(dict1[key], dict) and isinstance(dict2[key], dict):
            merge_nested_dicts(dict1[key], dict2[key])
        else:
            dict1[key] = dict2[key]
    return dict1


def split_field(fld):
    try:
        fld_pfx, fld_sfx = fld.split('_')
        fld_sfx = '_' + fld_sfx
    except:
        fld_pfx, fld_sfx = fld, ''
    return fld_pfx, fld_sfx


def pad_list(values, interval, keep_end=False):
    """
    fills in a list of values so that the distance between values is interval
    pad_list([1, 3, 7], 1) -> [1, 2, 3, 4, 5, 6, 7]
    if keep_end, preserves distance of at least interval between second to last and last value
    pad_list([1, 3.5, 7], 1, True) - > [1, 2, 3, 3.5, 4.5, 5.5, 7]
    """
    padded_list = []
    prev_val = None
    last_val = values[-1]
    for curr_val in values:
        while prev_val is not None and curr_val - prev_val > interval:
            prev_val = prev_val + interval
            if not keep_end or last_val - prev_val >= interval:
                padded_list.append(prev_val)
        padded_list.append(curr_val)
        prev_val = curr_val
    return padded_list


def try_index(listy, index, default=None):
    try:
        return listy[index]
    except:
        return default


def retryable(tries):
    """
    decorator to retry functions that may have intermittent errrors
    decorated functions must return a success
    """
    def decorator(func):
        @wraps(func)
        def wrapped(*args, **kwargs):
            attempts = 1
            while attempts <= tries:
                success = func(*args, **kwargs)
                if success:
                    return success
                attempts += 1
            if not success:
                logger.warn('function: %s failed after %s attempts', func, attempts)
            return success
        return wrapped
    return decorator


def make_list(maybe_list):
    if isinstance(maybe_list, str):
        maybe_list = [maybe_list]
    return maybe_list


def eval_args(args_list):
    """
    eval_args([1, '+', 2 ,'*', 3, '-', 4]) => 3
    """
    operator_map = {'+': add, '-': sub, '*': mul, '/': safe_div}
    operator_precedence = {'/': 2, '*': 2, '+': 1, '-': 1}
    while len(args_list) > 1:
        op_index, op_key = max(enumerate(args_list), key=lambda x: operator_precedence.get(x[1]))
        operator = operator_map.get(op_key)
        val = operator(args_list[op_index - 1], args_list[op_index + 1])
        args_list = args_list[:op_index - 1] + [val] + args_list[op_index + 2:]
    return args_list[0]


def safe_div(num, denom):
    try:
        return num / denom
    except ZeroDivisionError:
        return 0


def roundrobin(*iterables):
    "roundrobin('ABC', 'D', 'EF') --> A D E B F C"
    # Recipe credited to George Sakkis
    pending = len(iterables)
    nexts = cycle(iter(it).next for it in iterables)
    while pending:
        try:
            for next in nexts:
                yield next()
        except StopIteration:
            pending -= 1
            nexts = cycle(islice(nexts, pending))



def transform_field(field_value):
    #ETL shell times out here. Add catch here.
    from aviso.utils.dateUtils import datetime2xl, epoch
    try:
        tdetails = sec_context.details
        if isinstance(field_value, bool) or isinstance(field_value, float) or isinstance(field_value, int):
            return str(field_value)

        if not isinstance(field_value, str):
            return field_value
        dt_type = tdetails.get_config('dateformat', 'deprecated_float_dates')
        if RE_DATETIME.match(field_value):
                field_value = datetime.strptime(field_value[:-5], '%Y-%m-%dT%H:%M:%S.%f')
        elif RE_DATE.match(field_value):
            field_value = datetime.strptime(field_value, '%Y-%m-%d').date()
        else:
            return field_value

        if isinstance(field_value, datetime):
            if not field_value.tzinfo:
                field_value = pytz.utc.localize(field_value)
            if dt_type.get('enable', False):
                field_value = datetime2xl(field_value)
            else:
                field_value = epoch(field_value).as_epoch()
        elif isinstance(field_value, date):
            if dt_type.get('enable', False):
                field_value = datetime(field_value.year, field_value.month, field_value.day)
                if not field_value.tzinfo:
                    field_value = pytz.utc.localize(field_value)
                field_value = datetime2xl(field_value)
            else:
                if field_value < MIN_DATE:
                    field_value = MIN_DATE
                field_value = field_value.strftime('%Y%m%d')
        return str(field_value)
    except Exception as e:
        logger.exception('Exception while transforming field %s :%s'%(e))
        print(type(e))
        raise

def transform_field_cdc(field_value):
    #ETL shell times out here. Add catch here.
    from aviso.utils.dateUtils import datetime2xl, epoch
    try:
        tdetails = sec_context.details
        if isinstance(field_value, bool) or isinstance(field_value, float) or isinstance(field_value, int):
            return str(field_value)

        if not isinstance(field_value, str):
            return field_value
        dt_type = tdetails.get_config('dateformat', 'deprecated_float_dates')
        if RE_DATETIME.match(field_value):
                field_value = datetime.strptime(field_value[:-5], '%Y-%m-%dT%H:%M:%S.%f')
        elif RE_DATE.match(field_value):
            field_value = datetime.strptime(field_value, '%Y-%m-%d').date()
        else:
            return field_value

        if isinstance(field_value, datetime):
            if not field_value.tzinfo:
                field_value = pytz.utc.localize(field_value)
            if dt_type.get('enable', False):
                field_value = datetime2xl(field_value)
            else:
                field_value = epoch(field_value).as_epoch()
        elif isinstance(field_value, date):
            if dt_type.get('enable', False):
                field_value = datetime(field_value.year, field_value.month, field_value.day)
                if not field_value.tzinfo:
                    field_value = pytz.timezone(tdetails.get_all_config()['forecast']['timezone']).localize(field_value)
                field_value = datetime2xl(field_value)
            else:
                if field_value < MIN_DATE:
                    field_value = MIN_DATE
                field_value = field_value.strftime('%Y%m%d')
        return str(field_value)
    except Exception as e:
        logger.exception('Exception while transforming field %s :%s'%(e))
        print(type(e))
        raise