import re
import sys
import hashlib
from math import sqrt, pi, exp, log10

from numpy import array, size, asarray, reshape, sum, power

invsqrt2pi = 1.0 / sqrt(2 * pi)
tiny = 1.0e-15

logistic_cutoff = 16.0
max_int = sys.maxsize


def md5_hash(value):
    try:
        return int(hashlib.md5(value.encode()).hexdigest(), 16) % max_int
    except Exception as e:
        raise e


def mean_fc(nparr, cnt):
    '''
    take a numpy array and count of elements and calculate the mean
    (useful when zeros are missing from data, but you know the total count)
    '''
    return sum(nparr) / float(cnt)


def var_fc(nparr, cnt):
    '''
    take numpy array and count of elements, and calculate the population variance
    (useful when zeros are missing from data, but you know the total count)
    '''
    fc_mean = sum(nparr) / float(cnt)
    return (sum(power(nparr - fc_mean, 2)) + (cnt - len(nparr)) * power(fc_mean, 2)) / float(cnt)


def svar_fc(nparr, cnt):
    '''
    take numpy array and count of elements, and calculate the sample variance
    (useful when zeros are missing from data, but you know the total count)
    '''
    fc_mean = sum(nparr) / float(cnt)
    (sum(power(nparr - fc_mean, 2)) + (cnt - len(nparr)) * power(fc_mean, 2)) / float(cnt - 1)


def sd_fc(nparr, cnt):
    '''
    take numpy array and count of elements, and calculate the population standard deviation
    (useful when zeros are missing from data, but you know the total count)
    '''
    fc_mean = sum(nparr) / float(cnt)
    return sqrt((sum(power(nparr - fc_mean, 2)) + (cnt - len(nparr)) * power(fc_mean, 2)) / float(cnt))


def ssd_fc(nparr, cnt):
    '''
    take numpy array and count of elements, and calculate the sample standard deviation
    (useful when zeros are missing from data, but you know the total count)
    '''
    fc_mean = sum(nparr) / float(cnt)
    return sqrt((sum(power(nparr - fc_mean, 2)) + (cnt - len(nparr)) * power(fc_mean, 2)) / float(cnt - 1))


def logistic(x):
    if x > logistic_cutoff: return 1.0
    if x < -logistic_cutoff: return 0.0
    return 1.0 / (1 + exp(-x))


def normalizeRows(A):
    arrayA = array(A)
    sums = arrayA.sum(axis=1)
    sumt = sums.reshape(size(arrayA, 0), 1)
    for i in range(0, sumt.size):
        if abs(sumt[i]) < 0.00000001: sumt[i] = 1.0
    result = arrayA / sumt
    return result.tolist(), result


def excelToFloat(x):
    try:
        return float(x)
    except:
        if type(x) is str:
            xstr = x
        else:
            xstr = x.__str__()

        if (xstr.strip().__len__() == 0): return 0;
        xm = xstr.replace('$', '')
        x0 = xm.replace('(', '-')
        x1 = x0.strip(')')
        x2 = x1.replace(',', '')
        return float(x2)


def samenum(a, b):
    astr = a.__str__()
    bstr = b.__str__()
    if (re.match('^[0-9$()-,]*$', astr) is None): return False
    if (re.match('^[0-9$()-,]*$', bstr) is None): return False
    return excelToFloat(a) == excelToFloat(b)


def samenum2(a, b):
    astr = a.__str__()
    bstr = b.__str__()
    try:
        af = excelToFloat(astr)
        bf = excelToFloat(bstr)
        return af == bf
    except:
        return False


# this function is used to turn a nested for loop to a single loop
def meshgrid2(arrs):
    lens = map(len, arrs)

    helperarrs = []
    for alen in lens:
        x = range(0, alen)
        helperarrs.append(x)

    dim = len(arrs)
    sz = 1
    for s in lens:
        sz *= s

    ans = []
    for i, arr in enumerate(helperarrs):
        slc = [1] * dim
        slc[i] = lens[i]
        arr2 = asarray(arr).reshape(slc)
        for j, sz0 in enumerate(lens):
            if j != i:
                arr2 = arr2.repeat(sz0, axis=j)
        ans.append(arr2)

    lenans = len(ans)
    for i in range(0, lenans):
        ans[i] = reshape(ans[i], sz)
    result = []
    for j in range(0, sz):
        item = []
        for i in range(0, lenans):
            item.append(arrs[i][ans[i][j]])
        result.append(item)
    return result


def list2dict(alist):
    if type(alist) != list:
        return alist
    if type(alist[0]) != list:
        return {alist[0]: list2dict(alist[1])}
    result = {}
    for item in alist:
        result[item[0]] = list2dict(item[1])
    return result


def dropextrasatend(a):
    if len(a) == 1:
        return a
    mysum = 0.0
    for i in range(0, len(a) - 1):
        mysum += a[len(a) - i - 1]
        if mysum > tiny: break
    return a[:len(a) - i]


def count_digits(x):
    '''
    Takes an integer as an input an outputs the number of digits present in it.
    '''
    if x <= 999999999999997:
        return int(log10(x)) + 1
    else:
        return len(str(x))