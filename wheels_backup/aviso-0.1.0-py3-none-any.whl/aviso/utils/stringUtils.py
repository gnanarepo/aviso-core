import string
import random

# Replaced Django imports with pure Python logic inside the function

vow = list('AEIOU')
con = list(set(list(string.ascii_uppercase)) - set(vow))


def random_string(size=8, chars=None):
    if chars is None:
        chars = string.ascii_letters + string.digits
    return ''.join(random.choice(chars) for x in range(size))


def random_token():
    ran = random.choice(con)
    ran1 = random.choice(vow)
    ran2 = random.choice(con)
    ran3 = random.choice(vow)
    ran4 = random.choice(con)
    return ran + ran1 + ran2 + ran3 + ran4


def to_money(x, cents=False):
    try:
        if cents:
            return '${0:,.2f}'.format(x)
        else:
            return '${0:,.0f}'.format(x)
    except:
        return x


def first15(s):
    if s and len(s) > 15:
        return s[0:15]
    else:
        return s


def html_escape(text):
    """
    Refactored to remove Django's mark_safe and force_text.
    It simply returns the escaped string using standard Python replacement.
    """
    # Converting input to string handles the job of force_text/force_str
    s = str(text)

    # mark_safe is a Django marker used to tell templates "don't escape this again".
    # In pure Python, we just return the modified string.
    return (s
            .replace('&', '&amp;')
            .replace('<', '&lt;')
            .replace('>', '&gt;')
            .replace('"', '&quot;')
            .replace("'", '&#39;')
            .replace("(", '&#28;')
            .replace(")", '&#29;')
            )