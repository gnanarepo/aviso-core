'''
Created March 2017

@author: Sujith
'''

import re
import sys
import json
import pprint
import logging
import traceback
import collections
from copy import deepcopy

from psycopg2 import ProgrammingError

from aviso.tasker import make_hash
from aviso.domainmodel import Model
from aviso.utils import GnanaError, diff_rec
from aviso.utils.mailUtils import send_mail2
from aviso.domainmodel.datameta import DSClass
from aviso.utils.fileUtils import gitbackup_dataset
from aviso.domainmodel.auth_tokens import AuthorizationToken
from aviso.settings import gnana_db2, sec_context, CNAME, CNAME_DISPLAY_NAME, AVISO_APPS, global_cache

logger = logging.getLogger('gnana.%s' % __name__)

CONFIG_PATHS_FULL_PREPARE = ['params.general.indexed_fields',
                             'params.general.dimensions',
                             'maps']

def set_full_prepare_flag(dataset):
    flag = dataset + '~' + '_data'
    tenant = sec_context.details
    flagValue = tenant.get_flag('prepare_status', flag, {})
    flagValue['full_prepare'] = True
    return tenant.set_flag('prepare_status', flag, flagValue)


def capture_paths(diff, path):

    path_set = set()

    def capture_paths_internal(diff, path, path_set):

        try:
            for i in diff:
                if i == 'ValDiff':
                    capture_paths_internal(diff[i], path, path_set)
                elif i == 'OnlyInRight' or i == 'OnlyInLeft' or isinstance(diff, tuple):
                    path_without_trailing_dot = path[:-1]
                    path_set.add(path_without_trailing_dot)
                    y = path_without_trailing_dot.split('.')
                    path = '.'.join(y[:-1])
                    path = path + '.' if len(y) > 1 else path
                    if isinstance(diff, tuple):
                        break
                elif isinstance(i, int) or isinstance(i, int):
                    path_without_trailing_dot = path[:-1]
                    path_set.add(path_without_trailing_dot)
                else:
                    path += (i+'.')
                    path = capture_paths_internal(diff[i], path, path_set)
            return path
        except Exception as _:
            exc_type, exc_value, exc_traceback = sys.exc_info()
            err_msg = "\n".join(traceback.format_exception(
                exc_type, exc_value, exc_traceback))
            logger.error(
                'Error while calculating the paths internally .\n%s', err_msg)

    capture_paths_internal(diff, path, path_set)

    return path_set


def validate_and_set_full_prepare(diff_obtained, dataset):
    paths_changed = list(capture_paths(diff_obtained, ''))
    logger.info('Paths changed: %s dataset: %s' % (paths_changed, dataset))
    mark_full_prepare = False
    for path in paths_changed:
        for prepare_path in CONFIG_PATHS_FULL_PREPARE:
            if path.startswith(prepare_path):
                logger.info(
                    'As path %s changed. Marking for full_prepare ..' % path)
                mark_full_prepare = True
                break
        if mark_full_prepare:
            break
    if mark_full_prepare:
        set_full_prepare_flag(dataset)

def get_dataset_diff(old_config, config, sandbox_name):
    dataset_list = set(old_config.get('datasets', {})) | set(config.get('datasets', {}))
    dataset_diff = {}
    old_dataset_config = {}
    new_dataset_config = {}
    for dataset in dataset_list:
        ds, new_ds = DSClass.getByName(dataset), DSClass.getByName(dataset, sandbox=sandbox_name) 
        if ds:
            old_dataset_config = ds.get_as_map()
        if new_ds:
            new_dataset_config = new_ds.get_as_map()
        diff_obtained = diff_rec(old_dataset_config, new_dataset_config)
        if diff_obtained:
            dataset_diff[dataset] = diff_obtained
            validate_and_set_full_prepare(diff_obtained, dataset)
    return dataset_diff
            
class Sandbox(Model):
    """Model for maintaining Sandbox for tenant config module"""
    postgres = True
    collection_name = 'sandboxes'
    kind = 'domainmodel.sandbox.Sandbox'
    version = 1
    encrypted = False
    index_list = {'name': {'unique': True}}
    SANDBOX_CREATED_STATUS = 0
    SANDBOX_COMMITED_STATUS = 1

    def __init__(self, attrs=None):
        """Inintailizes sandbox object with necessary attributes

        Args:

                name: name of the sandbox
                changes: All the changes saved with the sandbox name
                    Example: {'<path1>':{'hash':'<hash1>',
                                         'change':'<change1>',
                                         'action':'modify/remove_config/remove_path'},
                              '<path2>':{'hash':'<hash2>',
                                         'change': '<change2>',
                                         'action':'modify/remove_config/remove_path'}}
                comment: comment to the sandbox
        """
        self.name = None
        self.changes = {}
        self.comment = None
        self.creator = None
        self.status = self.SANDBOX_CREATED_STATUS
        super(Sandbox, self).__init__(attrs)

    def encode(self, attrs):
        """Loads the class attributes into a given dictionary

        Args:

                attrs: dictionary in which object attributes will be loaded
        """
        attrs['name'] = self.name
        attrs['changes'] = json.dumps(self.changes)
        attrs['comment'] = self.comment
        attrs['creator'] = self.creator
        attrs['status'] = self.status
        return super(Sandbox, self).encode(attrs)

    def decode(self, attrs):
        """Loads the class object usng attributes passed in attrs

        Args:

                attrs: dictionary which contains class attributes to load class object
        """
        self.name = attrs.get('name')
        self.changes = json.loads(attrs.get('changes'))
        self.comment = attrs.get('comment')
        self.creator = attrs.get('creator')
        self.status = attrs.get('status', self.SANDBOX_CREATED_STATUS)
        return super(Sandbox, self).decode(attrs)
    
    def mark_commit(self):
        self.status = self.SANDBOX_COMMITED_STATUS
        self.changes = {}
        self.save()

    @classmethod
    def create_postgres_table(cls):
        """Create the postgres table for the sandbox class

        Args:


        Return:

                dict: represents the executed operation with success:True
                      else exception message will be returned
        """
        statement = 'create table "{tablename}"(\
                _id                    bigserial primary key,\
                _kind                  varchar,\
                _version               int,\
                last_modified_time     bigint,\
                name                   varchar,\
                changes                varchar,\
                comment                varchar,\
                creator                varchar,\
                status                 int\
                  )'
        return gnana_db2.postgres_table_creator(statement.format(tablename=cls.getCollectionName().replace('.', '$')),
                                                cls.getCollectionName())

    @classmethod
    def get_sandbox_obj(cls, name):
        """Get the sandbox object

        Args:

                name: name of the Sandbox
        Return:

                Object: Sandbox instance
        """
        try:
            criteria = {'name': name}
            sandbox_obj = Sandbox.getBySpecifiedCriteria(criteria=criteria, check_unique=True)
            return sandbox_obj if sandbox_obj else Sandbox()
        except ProgrammingError as perror:
            collection_not_found = re.match(r"^relation .+ does not exist", str(perror))
            if collection_not_found:
                Sandbox.create_postgres_table()
                return Sandbox()
            else:
                raise
        except:
            raise

    @classmethod
    def partial_update(cls, c_config, u_config):
        """Updates a nested dictionary with the passed in dictionary

        Args:

                c_config: current (existing config)
                u_config: Partial config to update the existing config
        Returns:

                dict: Updated currrent config with the partial update
        """
        for key, value in u_config.items():
            if isinstance(value, collections.Mapping):
                res = cls.partial_update(c_config.get(key, {}), value)
                c_config[key] = res
            else:
                c_config[key] = u_config[key]
        return c_config

    @classmethod
    def getAll(cls, criteria=None, fieldList=[], return_dict=False):
        kwargs = dict(criteria=criteria, fieldList=fieldList, return_dict=return_dict)
        try:
            return super(Sandbox, cls).getAll(**kwargs)
        except Exception as e:
            collectionName = Sandbox.getCollectionName()
            real_collection_name = collectionName.replace(".", "$")
            statement = """ALTER TABLE %s ADD COLUMN STATUS INT DEFAULT 0""" % real_collection_name
            cls.get_db().executeDML(collectionName, statement)
            return super(Sandbox, cls).getAll(**kwargs)


    @classmethod
    def get_sandboxd_config(cls, sandbox_name):
        """Returns the tenant config by a sandbox
        Args:
                sandbox_name: name of the sandbox
        Return:
                object: Sandbox instances which are matched against the sandbox name
        """
        criteria = {'name': sandbox_name, "status": cls.SANDBOX_CREATED_STATUS}
        sandbox_objs = Sandbox.getAll(criteria=criteria)
        for sandbox_obj in sandbox_objs:
            yield sandbox_obj

    @staticmethod
    def sandboxChanges():
        """changes tuple for every change in sandbox"""
        return collections.namedtuple('SandboxChanges', ['path', 'hash', 'changes', 'action'])

    def changes_in_sandbox(self):
        """get the sandboxd changes
        Args:
        Return:
                NamedTuple: changes for every change is added to named tuple and returns
        """
        all_changes = self.changes
        for change in all_changes:
            yield Sandbox.sandboxChanges()(path=change,
                                           hash=self.changes[change]['hash'],
                                           changes=self.changes[change]['changes'],
                                           action=self.changes[change].get('action', 'modify'))


    @classmethod
    def commit(cls, sandbox_name):
        """Commits the sandboxd tenant config to tenant
        Args:
                sandbox_name: name of the sandbox we are going to commit
        Returns:
                None
        Raises:
                GnanaError: if hash validations are failed
        """
        sandbox_obj = cls.get_sandbox_obj(sandbox_name)
        if not sandbox_obj:
            raise GnanaError("No sandbox found with name %s" % sandbox_name)        
        if sandbox_obj.status == Sandbox.SANDBOX_COMMITED_STATUS:
            raise GnanaError(f"{sandbox_name} Sandbox is already commited")
        ten = sec_context.details
        config = ten.get_all_config()
        old_config = deepcopy(config)
        
        result = ten.apply_sandbox_config(sandbox_name, config)
        dataset_diff = get_dataset_diff(old_config, config, sandbox_name)
        # removing to remove config
        for category in config:
            for config_name in config[category]:
                ten.set_config(category, config_name, value=config[category][config_name])
        for category, config_name in result['remove_config']:
            ten.remove_config(category, config_name)
        for category, conf_path in result['remove_path']:
            ten.remove_path_in_config(category, conf_path)
        comment = sandbox_obj.comment + ' --creator:%s ' %sandbox_obj.creator
        sandbox_obj.mark_commit()
        new_ten = sec_context.details
        new_config = new_ten.get_all_config()

        logger.info("Backing up old config")
        backup_and_mail_changes(old_config, new_config, dataset_diff, sec_context.name,
                                '@'.join([sec_context.user_name, sec_context.name]),
                                comment, "Sandbox Tenant config approve")
        logger.info("Backup of old config completed")
        recache_dataset_config(sandbox='None')
        return result


    @classmethod
    def resync(cls, sandbox_name):
        """Resync the sandboxd changes

        Args:

                cls: instance of the class
                sandbox_name: name of the sandbox which is going to be resynced
        Return:

                None
        Raises:

                GnanaError: If sandbox is not found
        """
        ten = sec_context.details
        criteria = {'name': sandbox_name}
        sandbox_obj = Sandbox.getBySpecifiedCriteria(criteria=criteria, check_unique=True)
        if not sandbox_obj:
            raise GnanaError("No sandbox found with name %s" % sandbox_name)
        for sandbox in sandbox_obj.changes_in_sandbox():
            path = sandbox.path
            full_path = path.split('.')
            category = full_path.pop(0)
            conf_path = '.'.join(full_path)
            existing_value = ten.get_flattened_config(category)
            hash_value = None
            current_value = None
            current_value = existing_value.get(conf_path, None)

            hash_value = make_hash({conf_path: current_value})
            sandbox_obj.changes.update({sandbox.path:{'hash':hash_value,
                                                 'changes':sandbox.changes}})
        sandbox_obj.save()
        return

    @classmethod
    def delete_keys_from_dict(cls, dict_del, lst_keys):
        for k in lst_keys:
            try:
                del dict_del[k]
            except KeyError:
                pass
        for v in dict_del.values():
            if isinstance(v, dict):
                cls.delete_keys_from_dict(v, lst_keys)

        return dict_del

def backup_and_mail_changes(old_tdetails, new_tdetails, dataset_diff,  tenant_name, username, comment, category):

    gitcomment = (comment + " -user:" + username)
    file_name = "tenantconfig_" + tenant_name + ".json"
    content = deepcopy(new_tdetails)
    old_tdetails.pop('datasets', None)
    new_tdetails.pop('datasets', None)
    mail_changes = diff_rec(old_tdetails, new_tdetails)
    mail_changes.update(dataset_diff)
    if mail_changes:
        gitbackup_dataset(file_name, content, gitcomment)
        format_changes = pprint.pformat(mail_changes, indent=2)
        cname = CNAME_DISPLAY_NAME if CNAME_DISPLAY_NAME else CNAME
        send_mail2('tenant_config.txt',
                   'Aviso <notifications@aviso.com>',
                   new_tdetails.get('receivers', {}).get('dataset_changes', ['gnackers@aviso.com']),
                   reply_to='Data Science Team <gnackers@aviso.com>',
                   tenantname=sec_context.name,
                   comment=comment, changes=format_changes, category=category,
                   modifier=username, user_name=sec_context.user_name,
                   cName=cname)
    return mail_changes


def get_global_cache_key(token, dataset, stage, full_config):
    app = "".join(AVISO_APPS)
    if stage is None:
        stage = 'None'
    l = [token.stack, token.tenant, dataset, stage, "_data", str(full_config), app]
    key = ":".join(l)
    logger.info("key is %s", key)
    return key

def recache_dataset_config(tenant=None, dataset="ALL_DATASETS", sandbox=None):
    from aviso.domainmodel.tenant import Tenant
    peek_context = sec_context.peek_context()
    if tenant is None:
        # usually (user_name, name,login_tenant_name) = peek_context[:3]
        tenant = peek_context[1]
    criteria = { "object.source_tenant": tenant }
    if not AuthorizationToken.get_count(criteria):
        return
    def for_sandbox(dataset, sandbox):
        auth_tokens = AuthorizationToken.getAll(criteria)
        for auth_token_obj in auth_tokens:
            result = {}
            ten = Tenant.getByName(tenant)
            datasets_config = ten.get_all_config(sandbox=sandbox).get('datasets',{})
            if dataset != "ALL_DATASETS":
                datasets_config = {dataset: datasets_config.get(dataset,{})}
            for dataset_name, config in datasets_config.items():
                for full_config_flag in [True, False]:
                    key = f"tenant={tenant}, dataset={dataset_name} sandbox={sandbox} "\
                    f"full_config_flag={full_config_flag} stack={auth_token_obj.stack}"
                    try:
                        global_cache.set(
                            get_global_cache_key(auth_token_obj, dataset_name, 
                                                sandbox, full_config_flag),
                            json.dumps(config))
                        result[key] = True
                    except:
                        result[key] = False
        return result
    if sandbox:
        return for_sandbox(dataset, sandbox)
    else:
        sec_context.set_context(peek_context[0], tenant, tenant)
        result = {}
        for sandbox in Sandbox.getAll():
            result.update(for_sandbox(dataset, sandbox.name))
        # setting for main sandbox
        result.update(for_sandbox(dataset, None))
        sec_context.set_context(*peek_context)
        return result
