import copy
import re
import time
import uuid
import json
import base64
import hashlib
import logging
import psycopg2
import datetime
import threading
import psycopg2.extras
from Crypto import Random
from random import choice
from Crypto.Cipher import AES
from urllib.parse import urlparse
from string import ascii_uppercase
from _collections import defaultdict
from pyschema.core import Record as Schema
from pymongo import MongoClient, DESCENDING

from aviso import settings
from aviso.domainmodel import Model
from aviso.keymanager.models import AesKey
from aviso.settings import DEBUG, sec_context
from aviso.utils.mailUtils import send_mail2
from aviso.domainmodel.sandbox import Sandbox
from aviso.utils.dateUtils import EpochClass
from aviso.settings import event_context, ISPROD
from aviso.domainmodel.schema.tenant_config import schema
from aviso.utils.dict_utils import flatten_dict, unflatten_dict
from aviso.utils import GnanaError, diff_rec, cache_utils, dateUtils, is_prod
from aviso.settings import CNAME, gnana_db2, gnana_db, POSTGRES_DB_URL, in_test_mode

logger = logging.getLogger('gnana.%s' % __name__)

def make_hash(params):
    """
    Calculate sha1 of a dictionary

    :param params: dict - a dictionary
    :return: str - calculated hash id of params
    """
    return hashlib.sha1(bytes(str(_make_hash(params)), 'utf-8')).hexdigest()


def _make_hash(obj, debug=False):
    # memory optimized http://stackoverflow.com/a/8714242
    """
    make_hash({'x': 1, 'b': [3,1,2,'b'], 'c': {1:2}})
    make_hash({'x': 1, 'b': [3,1,2,'b'], 'c': {1:2}})
    make_hash({'x': 1, 'b': [3,1,2,'b']})
    make_hash({'x': 1, 'b': [3,1,2,'b']})
    make_hash({'x': 1, 'b': [3,1,2,'b']})
    """
    try:
        if isinstance(obj, (set, tuple, list)):
            if isinstance(obj, (set,)):
                obj = list(obj)
                obj.sort()
            return tuple(map(make_hash, obj))
        elif not isinstance(obj, dict):
            return hash(obj)
        try:
            new_o = copy.deepcopy(obj)
        except:
            if debug:
                logger.info('Deepcopy failing for: %s' % str(obj))
                import pickle
                pickle.dump(obj, open("deepcopy_failure.p", "wb"))
            raise
        nitems = list(new_o.items())
        nitems.sort(key=lambda x: x[0])
        for k, v in nitems:
            if v is not None:
                new_o[k] = make_hash(v)
            else:
                new_o[k] = make_hash("None")
        new_oo = list(new_o.items())
        new_oo.sort(key=lambda x: x[0])
        return hash(tuple(frozenset(new_oo)))
    except Exception as e:
        if not debug:
            _make_hash(obj, debug=True)
        raise Exception(e)


class Tenant(Model):
    ''' Encapsulates the possible operations from tenant. Contains the
    tenant name, algorithm parameters, dimensions,
    yearly and quarterly targets etc

    Transformation to change it to a document during save and
    retrieve is done in the mongofwk.py module
    '''
    collection_name = "tenant_view"
    tenant_aware = False
    kind = "domainmodel.tenant.Tenant"
    version = 1
    postgres = True
    index_list = {'name': {'unique': True}}
    typed_fields = {'organization_id': {'type': 'varchar ARRAY'}}

    def __init__(self, attrs=None):
        self.name = None
        self.credentials = {}
        self.pod_id = None
        self.aes_key = None
        self.aes_key_partial = None
        self.aes_key_hash = None
        self.is_encrypted = False
        self.schema = schema
        self.tenant_db_url = None
        self.postgres_user_info = None
        self.tenant_postgres_url = None
        self.deleted = False
        self.organization_id = None
        self.auth_token = None
        super(Tenant, self).__init__(attrs)

    def encode(self, attrs):
        if not self.name:
            raise TenantError("No tenant name specified")
        attrs['name'] = self.name
        attrs['cred_map'] = self.credentials
        attrs['pod_id'] = self.pod_id
        attrs['tenant_db_url'] = self.tenant_db_url
        attrs['aes_key'] = self.aes_key
        attrs['is_encrypted'] = self.is_encrypted
        attrs['aes_key_partial'] = self.aes_key_partial
        attrs['aes_key_hash'] = self.aes_key_hash
        attrs['postgres_user_info'] = self.postgres_user_info
        attrs['tenant_postgres_url'] = self.tenant_postgres_url
        attrs['deleted'] = self.deleted
        attrs['organization_id'] = self.organization_id
        attrs['auth_token'] = self.auth_token
        return super(Tenant, self).encode(attrs)

    @classmethod
    def getByName(cls, name):
        """Overrided method from the base class model

        Args:
                cls: class (Method should be called with class as first argument).
                name: name of the tenant.
        Return:
                object: Tenant instance.
        """
        try:
            obj_name = name
            attrs = cls.get_db().findDocument(cls.getCollectionName(),
                                              {'object.name': obj_name}
                                              )

        except Exception as e:
            collection_not_found = re.match(r'relation .+ does not exist', e)
            if collection_not_found:
                # logger.info("Tenant view not found .... starting migration")
                # TODO: Following code can be removed as migration in done already
                # from welcome.management.commands.create_tenant_views import migrate
                # migrate()
                obj_name = name
                attrs = cls.get_db().findDocument(cls.getCollectionName(),
                                                  {'object.name': obj_name}
                                                  )
            else:
                raise
        return cls(attrs) if attrs else None

    def decode(self, attrs):
        self.name = attrs.get('name')
        if not self.name:
            raise TenantError("No tenant name specified")

        if 'cred_map' in attrs:
            self.credentials = attrs['cred_map']

        if 'aes_key' in attrs:
            self.aes_key = attrs['aes_key']
        if 'aes_key_partial' in attrs:
            self.aes_key_partial = attrs['aes_key_partial']
        if 'aes_key_hash' in attrs:
            self.aes_key_hash = attrs['aes_key_hash']
        if 'pod_id' in attrs:
            self.pod_id = attrs['pod_id']
        if 'tenant_db_url' in attrs:
            self.tenant_db_url = attrs['tenant_db_url']
        if 'postgres_user_info' in attrs:
            self.postgres_user_info = attrs.get('postgres_user_info')
        if 'tenant_postgres_url' in attrs:
            self.tenant_postgres_url = attrs.get('tenant_postgres_url')

        else:
            self.pod_id = None
        self.is_encrypted = attrs.get('is_encrypted', False)
        if 'drop' in attrs:
            self.deleted = attrs.get('deleted')
        self.organization_id = attrs.get('organization_id')
        self.auth_token = attrs.get('auth_token')
        super(Tenant, self).decode(attrs)
        return

    def has_config(self, category, config_name):
        """Checks whether the tenant has the config of spefied category, config name

        Args:
                category: tenant config category.
                config_name: tenant config config_name.
        Return:
                bool: True if config else False.
        """
        if '.' in config_name:
            config_name = config_name.split('.')[0]
        criteria = TenantConfig.get_criteria(self.id, category, config_name)
        confobj = TenantConfig.getBySpecifiedCriteria(criteria=criteria)
        if not confobj:
            return False
        return True

    def apply_sandbox_config(self, sandbox, all_config):
        result = {
            "remove_config": [],
            "remove_path": [],
            "run_prepare": False,
        }
        for sandbox_obj in Sandbox.get_sandboxd_config(sandbox):
            # multitple changes can be there for a sandbox
            # iterate through each change and apply config one by one
            for hunk in sandbox_obj.changes_in_sandbox():
                if "OppDS" in hunk.path:
                    result['run_prepare'] = True
                path = hunk.path  # datasets.OppDS.maps
                full_path = path.split('.')  # ["datasets", "OppDS"]
                sandbox_category = full_path[0]  # "datasets"
                sandbox_config_name = full_path[1]  # OppDS
                action = hunk.action
                if len(full_path[2:]) == 0:
                    # Replace all the change in the config
                    # all_config_names = [config_name for config_name in ]
                    # if (sandbox_category in all_config and
                    #     sandbox_config_name in all_config[sandbox_category]):
                    if action == 'modify':
                        unflatten_dict(hunk.changes)
                        if sandbox_category not in all_config:
                            all_config[sandbox_category] = {sandbox_config_name: hunk.changes}
                        else:
                            all_config[sandbox_category][sandbox_config_name] = hunk.changes
                    elif action == 'remove_config':
                        all_config.get(sandbox_category, {}).pop(sandbox_config_name, None)
                        result["remove_config"].append((sandbox_category, sandbox_config_name))
                elif action == 'modify':
                    flatten_dict(all_config)
                    all_config.update({path: hunk.changes})
                    unflatten_dict(all_config)
                elif action == 'remove_path':
                    flatten_dict(all_config)
                    all_config.pop(path, None)
                    unflatten_dict(all_config)
                    result['remove_path'].append((sandbox_category, ".".join(full_path[1:])))
        return result

    def get_all_config(self, sandbox=None):
        """Get all the available config of the tenant

        Args:
                self: instance of the class tenant.
        Return:
                dict: config with all categories.
        """
        all_configs = TenantConfig.getAll({'tenant_id': self.id})
        configs = defaultdict(dict)
        for config in all_configs:
            configs[config.category].update({config.config_name: config.value})
        all_config = dict(configs)
        if sandbox:
            self.apply_sandbox_config(sandbox, all_config)
        return all_config

    def get_config(self, category, config_name=None, default=None, sandbox=None):
        """Get the config specified

        Args:

                self: instance of the class tenant.
                category: category of tenant config.
                config_name: config_name of the tenant config.
        Return:

                dict: config of specified category.
        """
        if not config_name:
            return self.get_config_by_category(category, sandbox)
        if '.' in config_name:
            try:
                if sandbox:
                    # try to get data from the sandbox
                    sandbox_objs = Sandbox.get_sandboxd_config(sandbox)
                    if sandbox_objs:
                        for sandbox_obj in sandbox_objs:
                            if '.'.join([category, config_name]) in sandbox_obj.changes:
                                return sandbox_obj.changes['.'.join([category, config_name])]['changes']
                        else:
                            return default
                    else:
                        return default

                conf_name = config_name.split('.')[0]
                current_config = self.get_config(category, conf_name, default)
                return self.find_in_config({conf_name: current_config}, config_name)
            except KeyError:
                return default
        criteria = TenantConfig.get_criteria(self.id, category, config_name)
        confobj = TenantConfig.getBySpecifiedCriteria(criteria=criteria)
        # If sandbox name is passed, get sandboxd config and apply config and
        # return back the config

        if sandbox:
            try:
                current_config = confobj.value
            except:
                current_config = None
            all_config = {category: {config_name: current_config}}
            self.apply_sandbox_config(sandbox, all_config)
            if all_config:
                return all_config[category][config_name]
            else:
                return default
        if confobj:
            return confobj.value
        else:
            return default

    def set_auth_token(self):
        payload = {'tenant': self.name,
                   'stack': CNAME}
        if CNAME == 'localhost':
            payload['change'] = str(time.time())
        token = make_hash(payload)
        self.auth_token = token

    @classmethod
    def get_config_restrict_paths(cls):
        from aviso.settings import AVISO_APPS
        import importlib
        paths = []
        try:
            for app in AVISO_APPS.split(':'):
                try:
                    paths.extend(importlib.import_module(app).config_restrict_paths)
                except:
                    pass
        except Exception as e:
            logger.exception(e)
        return paths

    def get_config_by_category(self, category, sandbox=None):
        """Get config basing on category

        Args:
                category: category of the tenant config.
                sandbox: name of the sandbox (If provided config with that sandbox
                       shall be returned).
        Return:
                dict: Entire config of the specified category.
        """
        all_config = self.get_all_config(sandbox=sandbox)
        criteria = TenantConfig.get_criteria(self.id, category, None)
        confobj_itr = TenantConfig.getAll(criteria=criteria)
        all_values = {}
        all_values[category] = {}
        for conf_obj in confobj_itr:
            all_values[conf_obj.category][conf_obj.config_name] = conf_obj.value
        if sandbox:
            self.apply_sandbox_config(sandbox, all_values)
        return all_values[category]

    def check_config_diff(self, keys) -> bool:
        """This method if to get whether change is there in specific fields of csv

        Args:
                self: instance of the tenant class.
                keys: essentially a dict (result of diff_rec).
        Result:
                bool: True if change in specific key which needs schema change.
        """
        for key in keys:
            if key in ['static_fields', 'unique_fields', 'fields']:
                return True
        return False

    @classmethod
    def get_possible_paths(cls, category, config_name, value):
        for possible_path in cls.traverse({category: {config_name: value}}):
            yield possible_path

    @classmethod
    def traverse(cls, dic, path=None):
        if not path:
            path = None

        if isinstance(dic, dict):
            for x in dic.keys():
                local_path = '.'.join([path, x] if path else [x])
                yield local_path
                for b in cls.traverse(dic[x], local_path):
                    yield b

    def set_config_validations(self, category, config_name, value) -> list:
        """Validations to be done before changing tenant config

        Args:
                category: category of the tenant config.
                config_name: config_name of the specified category.
        Return:
                list: list of validation errors.
        """
        # any modifications to the csv config is stopped in case of postgres,
        # because it needs a manual migration task for now.
        if category == 'csv_data':
            prev_config = self.get_config(category, config_name)
            if prev_config and prev_config.get('postgres_enabled', False):
                # diff the changes for the any field changes
                diff = diff_rec(prev_config, value)
                if diff:
                    for k in diff:
                        raise_error = self.check_config_diff(diff[k].keys())
                        if raise_error:
                            prefix = "%s._csvdata.%s." % (self.name, config_name)
                            data_available = []
                            for col_name in gnana_db2.collection_names(prefix):
                                data_available.append(col_name[len(prefix):])
                            print("data available", data_available)
                            if data_available:
                                error_message = "Please follow the instructions in "
                                error_message += "https://avisoplan.atlassian.net/wiki/"
                                error_message += "pages/viewpage.action?pageId=14549036 "
                                error_message += ".... to change the config"
                                raise GnanaError(error_message)

        validate = self.validate_config(category, config_name, value)
        if validate:
            logger.error("Validation errors \
                         found during validation of the config_change %s", ", ".join(validate))

            # Fail only in non-prod environments for a month or so.
            if is_prod() or CNAME in ('pre-sales', 'impl', 'demo') or in_test_mode:
                raise GnanaError("schema validation failed when\
                                 setting the configuration.  %s" % "\n".join(validate))
        return validate

    @classmethod
    def delete_keys_from_dict(cls, dict_del, lst_keys, res=[]):
        for k in lst_keys:
            try:
                res.append((k, dict_del.pop(k)))
            except KeyError:
                pass
        for v in dict_del.values():
            if isinstance(v, dict):
                cls.delete_keys_from_dict(v, lst_keys)
        return dict_del, res

    def set_config(self, category, config_name, value, sandbox_name=None, sandbox_comment=None):
        """Setting config for a category and config name in tenant config

        Args:
                category: category of the tenant config.
                config_name: config name for the specified tenant config category.
                value: value to be set for the specified category and config_name.
                sandbox_name: name of the sandbox in which changes are saved.
                sandbox_comment: comment to the sandbox if changes are saving into sandbox.
        Return:
                list: list of validation errors during set config.
        """
        # This method is for backward compatibility
        # Eventually all config changes should use sandbox mechanism
        # Raising the error if path is given for a config_name
        # If tenant config should change with path use the sandbox mechanism
        # Assuming config name will not contain '.'
        if sandbox_name and sandbox_comment:
            return self.set_config_sandbox(category, config_name, value, sandbox_name, sandbox_comment)
        if '.' in config_name:
            raise GnanaError("Path has been sent in config name... \
                              This behavior is only supported with staging. Use sandbox and do sandbox \
                              commit instead!")
        validate = self.set_config_validations(category, config_name, value)
        # remove restricted keys if any
        restricted_paths = self.get_config_restrict_paths()
        for restricted_path in restricted_paths:
            # get the key
            cat = restricted_path.split('.')[0]
            if category == cat:
                try:
                    key_to_remove = restricted_path.split('.')[-1]
                    self.delete_keys_from_dict(value, [key_to_remove])
                except:
                    pass
        criteria = TenantConfig.get_criteria(self.id, category, config_name)
        confobj = TenantConfig.getBySpecifiedCriteria(criteria=criteria)
        if not confobj:
            confobj = TenantConfig()
        confobj.category = category
        confobj.config_name = config_name
        confobj.value = value
        confobj.tenant_id = self.id
        confobj.save()
        return validate

    def find_in_config(self, current_config, config_path):
        """Find the specifc value path in a nested dictionary

        Args:
                self: instance of the tenant config
                current_config: existing config
                config_path: path to check inside current_config
        Return:
                any-type: returns the value at the path, otherwise it throws KeyError
        """
        keys = config_path.split('.')
        f_val = current_config
        for key in keys:
            try:
                f_val = f_val[key]
            except KeyError:
                raise
        return f_val

    def build_partial_change(self, path, fval):
        """Used to build a partial dictionary which could be part of tenant config dictionary

        Args:
                path: '.' separated path of tenant config
                f_val: value which is going to change for the path
        Return:
                config_name: config name from the path
                partial_value: partially built dictionary for tenant config
        """

        def skip_first(itr):
            """Generator which skips the first value of a iterator

            Args:
                    itr: an iterable object
            Return:
                    generator: yields value inside the iterable object after skipping first value
            """
            iterable = iter(itr)
            next(iterable)
            for a_value in iterable:
                yield a_value

        keys = path.split('.')
        config_name = keys.pop(0)
        if len(keys) == 0:
            return config_name, fval
        if len(keys) == 1:
            return config_name, {keys[0]: fval}
        partial_value = {keys[-1]: fval}
        for key in skip_first(keys[::-1]):
            partial_value = {key: partial_value}
        return config_name, partial_value

    def get_flattened_config(self, category, config_name=None, default=None, sandbox=None):
        """
        Returns the tenant config in flattened structure

        Args:
                category: category in the tenant config
                config_name: config_name of the specified tenant config category
        Return:
                dict: returns the flattened config
        """
        normal_config = self.get_config(category, config_name=config_name, default=default, sandbox=sandbox)
        flatten_dict(normal_config)
        return normal_config

    def set_config_sandbox(self, category, config_name, value, sandbox_name, sandbox_comment):
        """sets the tenant config to the sandbox

        Args:
                self: instance of the tenant config
                category: category in the tenant config
                config_name: config_name of the specified tenant config category
                value: value of the specified tenant config category and config_name
                sandbox_name: name of the sandbox
                sandbox_comment: comment to be included in sandbox
        Return:
                list: list of validations with errors
        """
        # Make all validations and save the config to sandbox
        # Is is assumed that if path is sent as a config name...
        # First element will be the config name and remaining path shall be part of the value
        config_path = config_name
        confi_name, final_value = self.build_partial_change(config_name, value)
        validations = self.set_config_validations(category, confi_name, final_value)
        # restrict the paths which are not allowed
        restricted_paths = self.get_config_restrict_paths()
        for restricted_path in restricted_paths:
            # if we are setting a path restircted inside some value
            if len(config_path.split('.')) == 1:
                try:
                    key_to_remove = restricted_path.split('.')[-1]
                    self.delete_keys_from_dict(value, [key_to_remove])
                except:
                    pass
            if restricted_path.split('.')[-1] in config_path.split('.'):
                raise GnanaError("You are trying to set the config in a restricted path ! Please check.")
        # Get current config for the category, check whether the value is present or not
        # Check for the path , make hash save in the sandbox
        # existing_value = self.get_config(category)
        existing_value = self.get_flattened_config(category)
        hash_value = None
        current_value = None
        # get the current value from the exisiting config
        current_value = existing_value.get(config_path, None)
        hash_value = make_hash({config_path: current_value})

        # save the config into sandbox
        sandbox = Sandbox().get_sandbox_obj(sandbox_name)
        sandbox.changes.update({'.'.join([category, config_path]):
                                {'hash': hash_value,
                                 'changes': value,
                                 'action': 'modify'}})
        sandbox.name = sandbox_name
        sandbox.comment = sandbox_comment
        sandbox.status = Sandbox.SANDBOX_CREATED_STATUS
        sandbox.creator = '@'.join([sec_context.user_name, sec_context.login_tenant_name])
        sandbox.save()
        return validations

    def validate_config(self, category, key, data=None):
        """Validates the given config using pyschema

        Args:
                self: instance of the tenant class
                category: category of the tenant config
                key: config name of the specified category
                data: data to test the schema against
        Result:
                list: list of validation errors
        """
        if data is None:
            return []
        validate = None
        try:
            schema = Schema(self.schema)
            temp = {category: {key: data} if data else {}}
            validate = schema.validate(temp)
            if validate:
                logger.info('validation errors are %s' % ",".join(validate))

        except Exception as e:
            msg = 'schema error for %s.%s, and error message is %s' % (category, key, e)
            logger.warning(msg)
            validate = [msg]
        return validate

    def remove_config_sandbox(self, category, config_name, sandbox_name, sandbox_comment):
        """adds removing config path to sandbox, when sandbox is comitted config will be removed"""
        # to get old value
        criteria = TenantConfig.get_criteria(self.id, category, config_name)
        confobj = TenantConfig.getBySpecifiedCriteria(criteria=criteria)
        if not confobj:
            raise GnanaError('Key Not Found!!!')
        old_value = confobj.value
        config_path = config_name
        existing_value = self.get_flattened_config(category)
        hash_value = None
        current_value = None
        # get the current value from the exisiting config
        current_value = existing_value.get(config_path, None)
        hash_value = make_hash({config_path: current_value})

        # save the config into sandbox
        # changes wont be there as we are removing the exisiting config
        sandbox = Sandbox().get_sandbox_obj(sandbox_name)
        sandbox.changes.update({'.'.join([category, config_path]):
                                {'hash': hash_value,
                                 'changes': None,
                                 'action': 'remove_config'}})
        sandbox.name = sandbox_name
        sandbox.comment = sandbox_comment
        sandbox.status = Sandbox.SANDBOX_CREATED_STATUS
        sandbox.creator = '@'.join([sec_context.user_name, sec_context.name])
        sandbox.save()
        return old_value

    def remove_path_in_config(self, category, config_name, sandbox_name=None, sandbox_comment=None):
        """removes a specific path in the config"""
        if '.' not in config_name:
            raise GnanaError("Probably you are trying to remove config!! Please use action=remove instead")
        # get the old value
        if sandbox_name:
            existing_value = self.get_flattened_config(category)
            # get path value
            config_path = config_name
            current_value = existing_value.get(config_name, None)
            hash_value = make_hash({config_name: current_value})
            sandbox = Sandbox().get_sandbox_obj(sandbox_name)
            sandbox.changes.update({'.'.join([category, config_path]):
                                    {'hash': hash_value,
                                     'changes': None,
                                     'action': 'remove_path'}})
            sandbox.name = sandbox_name
            sandbox.status = Sandbox.SANDBOX_CREATED_STATUS
            sandbox.comment = sandbox_comment
            sandbox.creator = '@'.join([sec_context.user_name, sec_context.name])
            sandbox.save()
            return current_value
        else:
            config_name, conf_path = config_name.split('.')
            current_value = self.get_config(category, config_name)
            flatten_dict(current_value)
            current_value.pop(conf_path)
            unflatten_dict(current_value)
            self.set_config(category, config_name, current_value)

    def remove_config(self, category, config_name, sandbox_name=None, sandbox_comment=None):
        """Remove the config from tenant config

        Args:
                self: instance of thetenant class
                category: category of tenant config
                config_name: config_name of the specified category
        Result:
                anytype: old config value
        Raises:
                Key error if the config is not found.
        """
        if '.' in config_name:
            raise GnanaError(" '.' is not expected in remove config, is your intention is remove path ?")
        if sandbox_name and sandbox_comment:
            return self.remove_config_sandbox(category, config_name, sandbox_name, sandbox_comment)
        criteria = TenantConfig.get_criteria(self.id, category, config_name)
        confobj = TenantConfig.getBySpecifiedCriteria(criteria=criteria)
        if not confobj:
            raise GnanaError('Key Not Found!!!')
        old_value = confobj.value
        confobj.remove(confobj.id)
        return old_value

    def get_all_flags(self):
        """All flags of the tenant

        Args:
                self: instance of the class
        Return:
                dict: all flags of the tenant
        """
        all_flags = TenantFlag.getAll({'tenant_id': self.id})
        flags = defaultdict(dict)
        for flag in all_flags:
            flags[flag.category].update({flag.config_name: flag.value})
        return dict(flags)

    def get_flag(self, flagset, flag, default=None):
        criteria = TenantFlag.get_criteria(self.id, flagset, flag)
        flagobj = TenantFlag.getBySpecifiedCriteria(criteria=criteria)
        if flagobj:
            return flagobj.value
        else:
            if default is not None:
                return default
            else:
                raise GnanaError("Key Not Found!!!")

    def set_flag(self, flagset, flag, value):
        criteria = TenantFlag.get_criteria(self.id, flagset, flag)
        flagobj = TenantFlag.getBySpecifiedCriteria(criteria=criteria)
        if flagobj:
            old_value = flagobj.value
        else:
            flagobj = TenantFlag()
            old_value = None
        flagobj.category = flagset
        flagobj.config_name = flag
        flagobj.value = value
        flagobj.tenant_id = self.id
        flagobj.save()
        return old_value

    def remove_flag(self, flagset, flag):
        # Get the flag object, remove record and return the old flag value back
        criteria = TenantFlag.get_criteria(self.id, flagset, flag)
        flagobj = TenantFlag.getBySpecifiedCriteria(criteria=criteria)
        if not flagobj:
            raise GnanaError('Key Not Found!!!')
        old_value = flagobj.value
        flagobj.remove(flagobj.id)
        return old_value

    def getAllConfigOptions(self):
        conf_obj_itr = TenantConfig.getAll({'tenant_id': self.id})
        config_options = []
        for confobj in conf_obj_itr:
            config_options.append((confobj.category, confobj.config_name))
        return config_options

    def getStageMap(self):
        stageList = self.get_config('forecast', 'stageMap')
        stageMap = {}
        for item in (stageList or []):
            stageMap[item[0]] = item[1]
        return stageMap

    def credmap_exist(self, cred_map_name):
        return cred_map_name in self.credentials

    def get_credentials(self, cred_map_name):
        stored_creds = self.credentials.get(cred_map_name)
        if isinstance(stored_creds, dict):
            ret = {}
            for x in stored_creds:
                ret[x] = self.decrypt(stored_creds[x])
            if cred_map_name not in ['aviso', 'microservices_info'] and ret.get('updated_time'):
                expected_time_diff = 60 * 86400  # default for 2 months
                time_diff = int(int(time.time()) - ret.get('updated_time'))
                if ret.get('expire_warn_days'):
                    expected_time_diff = int(ret.get('expire_warn_days')) * 86400  # converting days into seconds
                    ret.pop('expire_warn_days')
                # Checking if the credentials updated is greater than 2 months
                if time_diff > expected_time_diff and ret.get('sent_mail') == False:
                    try:
                        if CNAME != 'etl-ms':
                            cclist = 'integration@aviso.com'
                        else:
                            cclist = self.get_config('endpoint_reset', 'email_ids', default='integration@aviso.com')
                        if isinstance(cclist, str):
                            cclist = [cclist]
                        logger.info('Sending endpoint reset warning for tenant: %s in %s' % (
                            sec_context.name, CNAME))
                        send_mail2('endpoint_reset_warning.txt',
                                   'Aviso <notifications@aviso.com>',
                                   ['prepare-jira-tickets@aviso.com'],
                                   reply_to='Integration Team <integration@aviso.com>',
                                   cclist=cclist,
                                   tenantname=sec_context.name, cname=CNAME,
                                   endpoint=cred_map_name)
                        self.credentials[cred_map_name]['sent_mail'] = True
                        self.save()
                    except Exception as e:
                        logger.exception("Exception while sending mail %s", e)
                ret.pop('updated_time')
                ret.pop('sent_mail')
            return ret
        if isinstance(stored_creds, list):
            ret = []
            for stored_cred in stored_creds:
                ret_dict = {}
                for key in stored_cred:
                    ret_dict[key] = self.decrypt(stored_cred[key])
                ret.append(ret_dict)
            return ret

    def save_credentials(self, cred_map_name, credentials):
        if isinstance(credentials, dict):
            encrypted_creds = {}
            for x in credentials:
                encrypted_creds[x] = self.encrypt(credentials[x])
            self.credentials[cred_map_name] = encrypted_creds
        if isinstance(credentials, list):
            encrypted_creds_list = []
            for credential in credentials:
                encrypted_creds = {}
                for key in credential:
                    encrypted_creds[key] = self.encrypt(credential[key])
                encrypted_creds_list.append(encrypted_creds)
            self.credentials[cred_map_name] = encrypted_creds_list

    def encrypt(self, val):
        return val

    def decrypt(self, val):
        # LATER: Add tenant specific encryption and decryption
        return val

    def create_tenant_db(self):
        """Create tenant specific database configuration."""
        tenant_name = self.name
        db_name = '%s_db_%s' % (tenant_name[:-4].replace('.', '-')
                                if tenant_name[-4:-3] == '.'
                                else tenant_name.replace('.', '-'),
                                CNAME
                                )
        tenant_db = self.get_pod_db()
        client = MongoClient(tenant_db, unicode_decode_error_handler = 'ignore')
        db = client[db_name]
        generated_strong_password = base64.b32encode(
            Random.get_random_bytes(40))
        db.add_user(db_name, generated_strong_password.decode())
        url = urlparse(tenant_db)
        db_url = 'mongodb://{username}:{password}@{hostname_port}/{path}'.format(
            username=db_name,
            password=generated_strong_password.decode(),
            hostname_port=url.netloc.split('@')[1],
            path=db_name
        )
        key = AES.new(
            base64.b64decode(self.get_aes_key()),
            mode=AES.MODE_ECB)
        self.tenant_db_url = base64.b64encode(
            key.encrypt(db_url + (' ' * (16 - len(db_url) % 16)))).decode()
        return

    def create_postgres_user(self):
        """ gets tenant url from tenant databases (which does not have user name and password)
            generates user name,  generate random password and persist it in tenant collection
            creates users in database using credentials generated above
        """

        # generating username
        tenant_name = self.name
        user_name = "%s_user_%s" % (tenant_name[:-4].replace('.', '_')
                                    if tenant_name[-4:-3] == '.'
                                    else tenant_name.replace('.', '_'),
                                    CNAME.replace('-', '_')
                                    )
        user_name = '"' + user_name + '"'
        # generating password
        generated_strong_password = base64.b32encode(Random.get_random_bytes(40))
        # encrypting and encoding the user name and password to persist in
        # tenant collection
        encoded_user_name = base64.b64encode(user_name.encode())
        encoded_password = base64.b64encode(generated_strong_password)
        user_info = encoded_user_name.decode() + ":" + encoded_password.decode()
        if settings.DEBUG is False:
            try:
                key = AES.new(base64.b64decode(self.get_aes_key()),
                              mode=AES.MODE_ECB)
                encrypted_user_details = key.encrypt(
                    user_info + (' ' * (16 - len(user_info) % 16))).decode()
                logger.info("Got AES key and encrypted the user info")
                logger.info("user info %s" % encrypted_user_details)
            except:
                logger.exception("Exception in getting aes key")
                encrypted_user_details = user_info
            encoded_encrypted_user_details = base64.b64encode(
                encrypted_user_details.encode())
            logger.info("encoded encrypted username %s" % encoded_encrypted_user_details)
            self.postgres_user_info = encoded_encrypted_user_details.decode()
        else:
            self.postgres_user_info = user_info
        postgres_con = self.getPostgresSuperUserConnection()
        try:
            with postgres_con.cursor() as cursor:
                cursor.execute("create user %s" % user_name)
                cursor.execute(
                    "ALTER USER %s with password \'%s\'" % (user_name, generated_strong_password.decode()))
                cursor.execute("CREATE TABLESPACE %s location \'/data/%s\';" % (user_name, user_name))
                cursor.execute("grant all on tablespace %s to %s;" % (user_name, user_name))
        except Exception as e:
            logger.exception("Creation of postgres user and tablespace is failed with msg: %s" % e)
            raise
        finally:
            postgres_con.close()
        return

    def get_tenant_db(self):
        if self.tenant_db_url is not None:
            key = AES.new(
                base64.b64decode(self.get_aes_key()),
                mode=AES.MODE_ECB)
            x = key.decrypt(base64.b64decode(self.tenant_db_url))
            return x.decode().rstrip(' ')
        else:
            return self.get_pod_db()

    def get_postgres_db_url(self):
        """ gets tenant url from tenantdatabases (which does not have username and password)
            gets tenant login information from tenant collection
            builds and returns  postgres db url using information above
        """
        try:
            criteria = {'object.pod_id': self.pod_id or 'default'}
            # getting tenant url from tenantdatabases
            tenant_db = TenantDatabases.getBySpecifiedCriteria(
                criteria, check_unique=True)
            postgres_url = getattr(tenant_db, "postgres_url", None)
            db_url = None
            if self.name == 'administrative.domain':
                return POSTGRES_DB_URL
            if self.postgres_user_info:
                # getting user name and password from tenant collection and
                # decrypting it
                encoded_encrypted_user_info = self.postgres_user_info
                encrypted_user_info = base64.b64decode(encoded_encrypted_user_info.encode())
                try:
                    key = AES.new(
                        base64.b64decode(self.get_aes_key()),
                        mode=AES.MODE_ECB)
                    user_info = key.decrypt(encrypted_user_info).decode()
                except Exception as e:
                    if self.encrypted:
                        logger.exception("Exception while getting AES key --- %s" % e)
                    user_info = encrypted_user_info.decode()
                encoded_user_name = user_info.split(':')[0]
                encoded_password = user_info.split(':')[1]
                user_name = base64.b64decode(encoded_user_name.encode()).decode()
                password = base64.b64decode(encoded_password.encode()).decode()
                parsed_url = urlparse(postgres_url)
                # URL is generated using user name and password from tenant collection
                # and other details such as database name address from tenant
                # databases
                db_url = 'postgres://{username}:{password}@{hostname}:{port}/{path}'.format(
                    username=user_name,
                    password=password,
                    hostname=parsed_url.hostname,
                    port=parsed_url.port,
                    path=parsed_url.path.split('/')[-1])
            return db_url
        except Exception as e:
            logger.info("Tenant DB is not configured properly")
            logger.exception("Failed to get the tenant db ::: %s", e)
            # remove the code after the postgres user creation is automated successfully
            if self.tenant_postgres_url is not None:
                return self.tenant_postgres_url
            raise GnanaError("Tenant DB not configured properly %s" % (e))

    def get_replica_set_name(self):
        try:
            criteria = {'object.pod_id': self.pod_id or 'default'}
            tenant_db = TenantDatabases.getBySpecifiedCriteria(
                criteria, check_unique=True)
        except:
            raise GnanaError("Tenant Database is not configured properly")
        return getattr(tenant_db, "replica_set_name", None)

    def get_pod_db(self):
        try:
            criteria = {'object.pod_id': self.pod_id or 'default'}
            tenant_db = TenantDatabases.getBySpecifiedCriteria(
                criteria, check_unique=True)
        except:
            raise GnanaError("Tenant Database is not configured properly")
        return tenant_db.db_url

    def get_aes_key(self):
        if ISPROD is False:
            raise GnanaError("Aes Keys is won't be available for ISPROD is False stacks")
        def get_aes_key_helper(retries=3):
            if settings.DEBUG:
                return self.aes_key
            keyindex = "~".join([settings.CNAME, self.name])
            if settings.OPCENTER_PWD:
                for i in range(retries):
                    try:
                        k = AesKey.objects.get(keyindex=keyindex)
                        break
                    except Exception as ex:
                        import django
                        django.db.close_old_connections()
                        logger.exception("Failed to get aes_key due to %s" % ex)
                        wait_time = 2 ** (i + 1)
                        logger.info("waiting for %d seconds before retrying" % wait_time)
                        time.sleep(wait_time)
                        if i == retries - 1:
                            raise GnanaError(["Unable to retrieve partial key", ex.args])
                        pass
                aes_key = k.keypart
            else:
                aes_key = self.aes_key_partial
            if not aes_key:
                raise GnanaError(
                    "Unable to retrieve partial key - key_p1 : %s - keyindex : %s - " % (aes_key, keyindex))
            if hashlib.md5(aes_key.encode()).hexdigest() == self.aes_key_hash:
                return aes_key
            else:
                raise GnanaError("Invalid Key")

        aes_key_hash = self.aes_key_hash if self.aes_key_hash else ''
        return cache_utils.get_set_from_cache("_".join([self.name, aes_key_hash, "aes_key"]), 'keys',
                                              get_aes_key_helper)

    def generate_aes_key(self):
        aes_key = base64.b64encode(Random.get_random_bytes(24)).decode()
        if not settings.DEBUG:
            keyindex = "~".join([settings.CNAME, self.name])
            if settings.OPCENTER_PWD:
                k = None
                try:
                    k = AesKey.objects.get(keyindex=keyindex)
                except:
                    k = AesKey()
                    k.keyindex = keyindex
                k.keypart = aes_key
                k.save()
            else:
                # No access to OpCenter
                self.aes_key_partial = aes_key
        else:
            # DEBUG is set to true so store the key in Tenant Collection
            self.aes_key = aes_key
        self.aes_key_hash = hashlib.md5(aes_key.encode()).hexdigest()

    def create_postgres_user_table(self):
        user_schema = 'create table "{user_col_name}"(\
            _id                       bigserial primary key,\
            username                  varchar UNIQUE,\
            name                      varchar,\
            email                     varchar,\
            password                  varchar,\
            last_login                timestamp,\
            valid_ip_list             varchar ARRAY,\
            valid_devices             jsonb,\
            validation_code           varchar,\
            validation_expiry         timestamp with time zone,\
            roles                     jsonb,\
            ip_validation_code        varchar,\
            ip_code_gen_time          int,\
            account_locked            bool,\
            login_attempts            integer,\
            failed_login_time         integer,\
            user_timeout              integer,\
            is_customer               bool,\
            user_role                 varchar,\
            is_disabled               bool,\
            preset_validation_code    varchar,\
            show_experimental         bool,\
            password_salt             varchar,\
            ssh_keys                  jsonb,\
            uuid                      varchar,\
            uuid_validation_expiry    timestamp,\
            activation_status         varchar,\
            mail_date                 timestamp,\
            is_second_login           bool,\
            _version                  int,\
            _kind                     varchar,\
            last_modified_time        bigint,\
            pre_validation_devices    jsonb\
        )'
        old_context = sec_context.peek_context()
        sec_context.set_context('N/A', self.name, self.name)
        try:
            gnana_db2.postgres_table_creator(user_schema.format(user_col_name=(self.name + '.user').replace('.', '$')))
        except Exception as e:
            logger.exception("Creating of postgres user table failed %s" % e)
            raise
        finally:
            sec_context.set_context(*old_context)

    @classmethod
    def from_tenant(cls, t):
        cloned_object = cls()
        attrs = {}
        t.encode(attrs)
        cloned_object.decode(attrs)
        cloned_object.id = t.id
        return cloned_object

    def getPostgresSuperUserConnection(self):
        # logging into database as super user and create users with credentials
        # generated above (not encrypted)
        try:
            criteria = {'object.pod_id': self.pod_id or 'default'}
            tenant_db = TenantDatabases.getBySpecifiedCriteria(
                criteria, check_unique=True)
        except:
            raise GnanaError(
                "unable to get postgres url while creating user and password for new tenant")
        postgres_url = tenant_db.postgres_url
        super_user = tenant_db.postgres_super_user
        postgres_url_parsed = urlparse(postgres_url)
        postgres_con = psycopg2.connect(
            database=postgres_url_parsed.path.strip('/'),
            user=base64.b64decode(super_user.split(':')[0].encode()).decode(),
            password=base64.b64decode(super_user.split(':')[1].encode()).decode(),
            host=postgres_url_parsed.hostname,
            port=postgres_url_parsed.port,
            cursor_factory=psycopg2.extras.RealDictCursor
        )
        postgres_con.set_session(autocommit=True)

        return postgres_con

    def update_info(self, data):
        """
        Update the attributes of tenant
        :param data: A dictionary with attributes to be updated
        :return: status of updated and update failed attributes
        """
        if not data:
            return {'success': False,
                    'message': 'Nothing is passed to update'}
        try:
            not_updated = []
            for tenant_attr in data:
                if getattr(self, tenant_attr, 'Not_a_Member') is not 'Not_a_Member':  # Avoiding creation of new
                    # attributes
                    logger.info("Updating %s information on Tenant" % tenant_attr)
                    if tenant_attr in self.typed_fields:
                        typed_field_type = self.typed_fields[tenant_attr]['type']
                        is_array = re.search("(ARRA\w+)", typed_field_type) or re.search("[\[]", typed_field_type)
                        if is_array and not isinstance(data[tenant_attr], list):
                            if data[tenant_attr]:
                                data[tenant_attr] = [data[tenant_attr]]
                    setattr(self, tenant_attr, data[tenant_attr])
                else:
                    not_updated.append(tenant_attr)
            self.save()
            ret_msg = {'success': True}
            if not_updated:
                not_updated.sort()
                ret_msg.update({'Fields which are not updated': not_updated})
            return ret_msg
        except Exception as e:
            logger.exception("Exception while updating tenant information:-- %s" % e)
            return {'success': False,
                    'message': str(e)}


class DeletedTenant(Tenant):
    collection_name = "deleted_tenant_view"

    def purgeCollections(self, name):
        # Drop all the collections with the given prefix
        gnana_db.dropCollectionsInNamespace(name)

        if DEBUG:
            gnana_db2.dropCollectionsInNamespace(name)
        else:
            # Drop the user and Table space as superuser
            user_name = "%s_user_%s" % (name[:-4].replace('.', '_')
                                        if name[-4:-3] == '.'
                                        else name.replace('.', '_'),
                                        CNAME.replace('-', '_')
                                        )
            user_name = '"' + user_name + '"'
            postgres_con = self.getPostgresSuperUserConnection()
            try:
                with postgres_con.cursor() as cursor:
                    all_rel = []
                    cursor.execute(
                        "select tablename from pg_tables where schemaname= 'public' and tablename like '%s%%';"
                        % (name.replace('.', '$')))
                    if cursor.rowcount > 0:
                        for row in cursor:
                            all_rel.append(row)
                    for row in all_rel:
                        if str(row['tablename']).startswith(name.replace('.', '$')):
                            tablename = '"' + row['tablename'] + '"'
                            cursor.execute("drop table %s ;" % tablename)
                    cursor.execute("DROP TABLESPACE  IF EXISTS %s ;" % (user_name))
                    cursor.execute("DROP USER IF EXISTS %s" % user_name)
            except Exception as e:
                logger.exception("Got exception in purging tablespace and user %s" % e)
                raise
            finally:
                postgres_con.close()
            logger.info("Purged Tablespace and user successfuly")


class TenantDatabases(Model):
    collection_name = "tenant_databases"
    tenant_aware = False
    postgres = True
    version = 1.0
    kind = "domainmodel.tenant.TenantDatabases"
    index_list = {}

    def __init__(self, attrs=None):
        self.pod_id = None
        self.cname = None
        self.db_url = None
        self.replica_set_name = None
        self.postgres_url = None
        self.postgres_super_user = None
        super(TenantDatabases, self).__init__(attrs)

    def encode(self, attrs):
        attrs['pod_id'] = self.pod_id
        attrs['cname'] = self.cname
        attrs['db_url'] = self.db_url
        attrs['replica_set_name'] = self.replica_set_name
        attrs['postgres_url'] = self.postgres_url
        attrs['postgres_super_user'] = self.postgres_super_user
        return super(TenantDatabases, self).encode(attrs)

    def decode(self, attrs):
        self.pod_id = attrs.get('pod_id')
        self.cname = attrs.get('cname')
        self.db_url = attrs.get('db_url')
        self.replica_set_name = attrs.get('replica_set_name')
        self.postgres_url = attrs.get('postgres_url')
        self.postgres_super_user = attrs.get('postgres_super_user')
        return super(TenantDatabases, self).decode(attrs)

    @classmethod
    def create_postgres_table(cls):
        tenant_databases_schema = 'create table "tenant_databases"(\
                _id                    bigserial primary key,\
                _kind                  varchar,\
                _version               int,\
                last_modified_time     bigint,\
                pod_id                 varchar,\
                cname                  varchar,\
                db_url                 varchar,\
                replica_set_name       varchar,\
                postgres_url           varchar,\
                postgres_super_user    varchar\
                  )'
        return gnana_db2.postgres_table_creator(tenant_databases_schema, cls.getCollectionName())


class TenantBaseConfiguration(Model):
    tenant_aware = False
    version = 1
    postgres = True
    encrypted = False
    index_list = {
        'tenant_id~category~config_name': {'unique': True}
    }

    def __init__(self, attrs=None):
        self.tenant_id = None
        self.category = None
        self.config_name = None
        self.value = None
        return super(TenantBaseConfiguration, self).__init__(attrs)

    def encode(self, attrs):
        attrs['tenant_id'] = self.tenant_id
        attrs['category'] = self.category
        attrs['config_name'] = self.config_name
        attrs['value'] = json.dumps(self.value)
        super(TenantBaseConfiguration, self).encode(attrs)

    def decode(self, attrs):
        self.tenant_id = attrs['tenant_id']
        self.category = attrs['category']
        self.config_name = attrs['config_name']
        self.value = json.loads(attrs['value'])
        super(TenantBaseConfiguration, self).decode(attrs)

    @classmethod
    def create_postgres_table(cls):
        table_name = str(cls.getCollectionName()).replace(".", "$")
        rstr = ''.join(choice(ascii_uppercase) for _ in range(8))
        fk_name = 'tenant_id_fk' + rstr
        schema = """create table "{table_name}" (
                    "_id"                bigserial primary key,
                    "tenant_id"          bigint,
                    "category"           varchar,
                    "config_name"        varchar,
                    "value"              varchar,
                    "_kind"              varchar,
                    "_version"           int,
                    "last_modified_time" bigint,
                    constraint {fk_name} foreign key (tenant_id) references tenant (_id) on delete cascade
                    )"""
        return gnana_db2.postgres_table_creator(schema.format(table_name=table_name, rstr=rstr, fk_name=fk_name),
                                                cls.getCollectionName())

    @classmethod
    def get_criteria(cls, tenant_id, category, config_name):
        if not config_name:
            return {'$and': [{'tenant_id': tenant_id}, {'category': category}]}
        else:
            return {'$and': [{'tenant_id': tenant_id}, {'category': category}, {'config_name': config_name}]}


class TenantFlag(TenantBaseConfiguration):
    collection_name = 'tenant_flags'
    kind = "domainmodel.tenant.TenantFlag"


class TenantConfig(TenantBaseConfiguration):
    collection_name = 'tenant_configs'
    kind = "domainmodel.tenant.TenantConfig"

    def getByNameAndStage(self):
        pass


class TenantEvents(Model):
    collection_name = "tenant_events"
    version = 1.0
    encrypted = False
    index_list = {
        "created_time": {"direction": DESCENDING},
        "expires": {'expireAfterSeconds': 10},
        "color": {},
        'username': {}
    }

    def __init__(self, attrs=None):
        self.username = None
        self.message = None
        self.created_time = None
        self.end_time = None
        self.color = None
        self.parent_id = None
        self.event_id = None
        self.exception_value = None
        self.params = None
        self.expires = dateUtils.now() + datetime.timedelta(90)
        super(TenantEvents, self).__init__(attrs)

    def encode(self, attrs):
        attrs['username'] = self.username
        attrs['message'] = self.message
        attrs['created_time'] = self.created_time
        attrs['color'] = self.color
        attrs['params'] = self.params
        attrs['end_time'] = self.end_time
        attrs['parent_id'] = self.parent_id
        attrs['event_id'] = self.event_id
        attrs['exception_value'] = self.exception_value
        attrs['expires'] = self.expires
        return attrs

    def decode(self, attrs):
        self.username = attrs['username']
        self.message = attrs['message']
        self.created_time = attrs['created_time']
        self.color = attrs['color']
        self.params = attrs.get('params', None)
        self.end_time = attrs.get('end_time', None)
        self.parent_id = attrs['parent_id']
        self.event_id = attrs['event_id']
        self.exception_value = attrs.get('exception_value', None)
        self.expires = attrs['expires']

    @classmethod
    def create_tenant_log(cls, message, color, params, start_time, end_time, parent_id, event_id):
        log_message = cls()
        log_message.message = message
        log_message.color = color
        log_message.params = params
        log_message.created_time = start_time
        log_message.end_time = end_time
        log_message.parent_id = parent_id
        log_message.event_id = event_id
        log_message.username = sec_context.user_name + "@" + sec_context.login_tenant_name
        log_message.save()
        return log_message

    @classmethod
    def update_tenant_log(cls, event_id, end_time, exception_value):
        cursor = cls.getByFieldValue('event_id', event_id)
        cursor.end_time = end_time
        cursor.exception_value = exception_value
        cursor.save(id_field='event_id')

    @classmethod
    def get_records(cls, color=None, username=None, str_msg=None, end_time=None, records=100, sub_events=False):
        criteria = {}
        if color:
            criteria.update({'object.color': {'$in': color}})
        if str_msg:
            regfind = r'(' + str_msg + '){1}'
            criteria.update({'object.message': {'$regex': regfind}})
        if username:
            criteria.update({'object.username': username})
        if end_time == 'in_process':
            criteria.update({'object.end_time': None})
        if type(end_time) is int:
            criteria.update({'object.end_time': {'$lt': end_time}})
        if not sub_events:
            criteria.update({'object.parent_id': None})
        records = int(records)
        db_to_use = cls.get_db()
        cursor = db_to_use.findDocuments(
            name=cls.getCollectionName(),
            criteria=criteria,
            sort=[('object.created_time', -1)],
        ).limit(records)
        for x in cursor:
            obj = cls(x)
            yield {'username': obj.username,
                   'color': obj.color,
                   'time': obj.created_time,
                   'message': obj.message,
                   'end_time': obj.end_time,
                   'parent_id': obj.parent_id,
                   'event_id': obj.event_id,
                   'params': obj.params
                   }

    @classmethod
    def get_hierarchy(cls, event_id=None):
        if not event_id:
            return
        return TenantEvents().get_event_tree(TenantEvents().get_root(event_id))

    def get_root(self, event_id):
        if not self.get_parent(event_id):
            return event_id
        else:
            return self.get_root(self.get_parent(event_id))

    def get_event_tree(self, current_id):
        if not current_id:
            return
        else:
            dic = {}
            cursor = self.getAllByFieldValue('event_id', current_id)
            for obj in cursor:
                dic = {'username': obj.username,
                       'color': obj.color,
                       'time': obj.created_time,
                       'message': obj.message,
                       'end_time': obj.end_time,
                       'parent_id': obj.parent_id,
                       'event_id': obj.event_id,
                       'params': obj.params,
                       'children': []
                       }
            child_cursor = self.getAllByFieldValue('parent_id', current_id)
            lst = list(child_cursor)
            child_id = None
            if lst:
                for i in lst:
                    child_id = i.event_id
                    dic['children'].append(self.get_event_tree(child_id))
            return dic

    def get_parent(self, child_id):
        rec = self.getByFieldValue('event_id', child_id)
        parent = rec.parent_id
        return parent


class TenantEventContext():
    event_stack = threading.local()

    def __init__(self, message, color, params):
        self.message = message
        self.color = color
        self.params = params
        self.start_time = None
        self.end_time = None
        self.event_id = str(uuid.uuid4())
        self.parent = None
        self.model_obj = None
        self.exception_value = None

    def __enter__(self):
        self.start_time = EpochClass().as_epoch()
        try:
            self.parent = self.event_stack.stack[-1]  # for sub-events just append in the list with their id
            self.event_stack.stack.append(self.event_id)
        except (IndexError, AttributeError):
            parent_eventid = event_context.event_id
            if parent_eventid:
                self.parent = parent_eventid
            else:
                self.parent = None
            self.event_stack.stack = [self.event_id]  # gives AttributeError and starts the list with parent id
        self.model_obj = TenantEvents.create_tenant_log(self.message, self.color, self.params, self.start_time,
                                                        self.end_time, self.parent, self.event_id)
        return self

    def __exit__(self, exc_type, exc_value, exc_traceback):
        self.event_stack.stack = self.event_stack.stack[0:-1]
        if exc_type:
            self.exception_value = "Type: " + str(exc_type) + ", Value: " + str(exc_value)
        if self.model_obj:
            self.model_obj.end_time = EpochClass().as_epoch()
            self.model_obj.exception_value = self.exception_value
            self.model_obj.save()


def tenant_events(message, color):
    try:
        def tenant_event_decorator(fn):
            def new_func(*args, **kwargs):
                with TenantEventContext(message, color, kwargs):
                    response = fn(*args, **kwargs)
                return response

            return new_func

        return tenant_event_decorator
    except Exception as e:
        logger.exception(str(e))


class TenantError(Exception):

    def __init__(self, error):
        self.error = error
