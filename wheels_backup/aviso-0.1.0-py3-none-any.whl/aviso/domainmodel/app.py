import re
import time
import pytz
import base64
import logging
import datetime
from Crypto.PublicKey import RSA
from aviso.domainmodel import Model
from Crypto.Hash import SHA, SHA512
from Crypto.Signature import PKCS1_PSS

from aviso.utils.dateUtils import now
from aviso.utils.stringUtils import random_string
from aviso.settings import sec_context, script_users


logger = logging.getLogger('gnana.%s' % __name__)


class User(Model):
    """ Stores and retrieves user information in a tenant
    specific collection"""
    collection_name = 'user'
    version = 3
    postgres = True
    kind = "domainmodel.app.User"
    tenant_aware = True
    index_list = {
        'username': {'unique': True}
    }
    # Prevents this object from being encrypted.
    encrypted = False
    USER_ROLES = (
        (None, 'Unknown'),
        ('ceo', 'CEO'),
        ('cfo', 'CFO'),
        ('cro', 'CRO'),
        ('customer_success', 'Customer Success'),
        ('sales_regional_vp', 'Sales Regional VP'),
        ('sales_vp_director', 'Sales VP / Director'),
        ('sales_manager', 'Sales Manager'),
        ('sales_ops_vp_director', 'Sales Ops VP / Director'),
        ('sales_ops_manager', 'Sales Ops Manager'),
        ('sales_ops', 'Sales Ops'),
        ('sales_rep', 'Sales Rep'),
        ('finance_vp', 'Finance VP'),
        ('finance_manager', 'Finance  Manager'),
        ('finance_analyst', 'Finance Analyst'),
        ('it', 'IT')
    )

    def __init__(self, attrs=None):

        # Original attributes
        self.name = None
        self.username = None
        self.email = None
        self.password_hash = None
        self.last_login = None

        self.valid_ips = {}
        self.valid_devices = {}

        # the above field would save the device
        # user tried to login from the validation code for the
        # device and the time at which he tried to login
        self.pwd_validation_code = None
        # datetime.datetime.now()
        self.pwd_validation_expiry = now()
        self.roles = {}
        self.account_locked = False
        self.login_attempts = 0
        self.failed_login_time = 0

        # Added to allow users to have long lived sessions
        tenant_details = sec_context.details
        self.user_timeout = tenant_details.get_config('security', 'session_timeout', 120)

        # Added to distinguish users created for customers
        # and for gnana to introspect results

        # True if the user is a customer false if the user is a gnana employee.
        self.is_customer = True
        self.user_role = None

        # Additional attrbibutes for new functionality
        self.is_disabled = False
        self.preset_validation_code = None
        self.show_experimental = False
        self.password_salt = None

        self.ssh_keys = {}
        # Added to validate new user through url
        self.uuid = None
        self.uuid_validation_expiry = None
        self.activation_status = None
        self.mail_date = None
        self.is_second_login = False
        # Used only for SSO users
        self.linked_accounts = []
        self.linked_to = ""
        self.refresh_token = ""

        super(User, self).__init__(attrs)

    def set_ssh_pub_key(self, key_value):
        content = key_value.split()
        # Create the key to validate it
        RSA.importKey(' '.join(content))
        self.ssh_keys[content[-1]] = key_value

    def get_code(self):
        if(self.pwd_validation_code and
           self.pwd_validation_expiry > now()):
            return self.pwd_validation_code
        return None

    def set_code(self, code):
        self.pwd_validation_code = code
        self.pwd_validation_expiry = (now() +
                                      datetime.timedelta(days=1))

    validation_code = property(get_code, set_code)

    def add_devices(self, device):
        time_now = time.time()
        first_record = {
            'first_used': time_now,
            'user_agent': 'Administrative Addition',
        }

        print('Current Device is', device)

        if device not in self.valid_devices:
            self.valid_devices[device] = {}
        self.valid_devices[device].update(first_record)

    def reset_all_devices(self):
        self.valid_devices = {}

    def remove_device(self, device):
        try:
            return self.valid_devices.pop(device)
        except:
            return False

    def add_ip(self, ip):

        # Check the format
        expression = re.compile('^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}(/[\d]+)?$')
        if not expression.match(ip):
            return False

        first_record = {
            'first_used': time.time(),
            'user_agent': 'Administrative Addition'
        }

        if ip not in self.valid_ips:
            self.valid_ips[ip] = {}
        self.valid_ips[ip].update(first_record)
        return True

    def reset_all_ips(self):
        self.valid_ips = {}

    def remove_ip(self, ip):
        try:
            return self.valid_ips.pop(ip)
        except:
            return False

    def new_validation(self, device, ip, user_agent):
        time_now = time.time()
        first_record = {
            'first_used': time_now,
            'first_used_from': ip
        }
        if device not in self.valid_devices:
            self.valid_devices[device] = {}
        self.valid_devices[device].update(first_record)

        if not 'user_agent' in self.valid_devices[device]:
            self.valid_devices[device]['user_agent'] = user_agent
        from aviso.utils.accesslogs_ops import ip_match
        ip_used = ip_match(ip, self.valid_ips)

        if ip_used is None:
            tdetails = sec_context.details
            ip_factors = tdetails.get_config('security', 'ip_factors', {})
            strict_ip_check = ip_factors.get('strict_ip_check', True)
            if strict_ip_check:
                ip_used = ip
            else:
                ip_segments = ip.split('.')
                ip_segments[-1] = '0'
                ip_used = '.'.join(ip_segments) + '/24'

        if ip_used not in self.valid_ips:
            self.valid_ips[ip_used] = {}

        self.valid_ips[ip_used].update(first_record)
        if not 'user_agent' in self.valid_ips[ip_used]:
            self.valid_ips[ip_used]['user_agent'] = user_agent

    def set_last_login(self, device, ip, user_agent):
        time_now = time.time()
        last_record = {'last_used': time_now, 'last_used_from': ip}
        if device in self.valid_devices:
            self.valid_devices[device].update(last_record)
        from aviso.utils.accesslogs_ops import ip_match
        ip_used = ip_match(ip, self.valid_ips)
        if ip_used in self.valid_ips:
            self.valid_ips[ip_used].update(last_record)

    def is_valid_ip(self, ip):
        from aviso.utils.accesslogs_ops import ip_match
        return ip_match(ip, self.valid_ips.keys())

    def is_valid_device(self, device):
        return device in self.valid_devices

    def get_refresh_token(self):
        return self.refresh_token

    def encode(self, attrs):
        attrs['name'] = self.name
        if self.username:
            attrs['username'] = self.username.lower()
        else:
            raise UserError("Missing username")
        if self.email:
            attrs['email'] = self.email
        else:
            raise UserError("Missing Email")

        if self.password_hash:
            attrs['password'] = self.password_hash
        else:
            # To support postgres update
            attrs['password'] = None
        if self.last_login:
            attrs['last_login'] = self.last_login
        else:
            attrs['last_login'] = None

        if self.validation_code:
            attrs['validation_code'] = self.pwd_validation_code
            attrs['validation_expiry'] = self.pwd_validation_expiry
        else:
            attrs['validation_code'] = None
            attrs['validation_expiry'] = None

        # We are flatting the priv and dim assignment to avoid MongoDB
        # restrictions
        new_roles = {}
        for r, role_val in self.roles.items():
            new_roles[r] = []
            for priv_val in role_val.values():
                new_roles[r].extend(priv_val.values())
        attrs['roles'] = new_roles
        attrs['user_timeout'] = self.user_timeout
        attrs['is_customer'] = self.is_customer
        attrs['user_role'] = self.user_role

        attrs['is_disabled'] = self.is_disabled
        attrs['preset_validation_code'] = self.preset_validation_code
        attrs['password_salt'] = self.password_salt
        attrs['show_experimental'] = self.show_experimental
        attrs['account_locked'] = self.account_locked
        attrs['login_attempts'] = self.login_attempts
        attrs['failed_login_time'] = self.failed_login_time
        attrs['ssh_keys'] = self.ssh_keys.items() if not self.postgres else self.ssh_keys
        if self.uuid:
            attrs['uuid'] = self.uuid
            attrs['uuid_validation_expiry'] = self.uuid_validation_expiry
            attrs['activation_status'] = self.activation_status
        else:
            attrs['uuid'] = None
            attrs['uuid_validation_expiry'] = None
            attrs['activation_status'] = None

        attrs['valid_devices'] = self.valid_devices
        attrs['valid_ips'] = {'items': [(k, v) for k, v in self.valid_ips.items()]}

        if self.mail_date:
            attrs['mail_date'] = self.mail_date
        else:
            attrs['mail_date'] = None
        attrs['is_second_login'] = self.is_second_login
        attrs["linked_accounts"] = self.linked_accounts
        attrs['refresh_token'] = self.refresh_token
        if self.linked_to:
            attrs["linked_to"] = self.linked_to
        return super(User, self).encode(attrs)

    def decode(self, attrs):
        self.name = attrs.get('name')
        self.user_timeout = attrs.get('user_timeout', 120)
        self.username = attrs.get('username')
        self.password_hash = attrs.get('password')
        self.email = attrs.get('email')
        self.last_login = attrs.get('last_login')
        if self.last_login:
            self.last_login = pytz.utc.localize(self.last_login)
        self.pwd_validation_code = attrs.get('validation_code')
        self.pwd_validation_expiry = attrs.get('validation_expiry')
        if self.pwd_validation_expiry:
            self.pwd_validation_expiry = pytz.utc.localize(self.pwd_validation_expiry)
        self.roles = {}

        # Read the roles back and put them in the right place
        new_roles = attrs.get('roles', {})
        for r, flat_list in new_roles.items():
            self.roles[r] = {}
            for priv_tuple in flat_list:
                priv, dim, write, delegate = priv_tuple
                if priv not in self.roles[r]:
                    self.roles[r][priv] = {}
                self.roles[r][priv][dim] = [priv, dim, write, delegate]

        self.is_customer = attrs.get('is_customer')
        self.user_role = attrs.get('user_role')
        self.is_disabled = attrs.get('is_disabled', False)
        self.preset_validation_code = attrs.get('preset_validation_code')
        self.password_salt = attrs.get('password_salt', None)
        self.show_experimental = attrs.get('show_experimental', False)
        self.account_locked = attrs.get('account_locked', False)
        self.login_attempts = attrs.get('login_attempts', 0)
        self.failed_login_time = attrs.get('failed_login_time', 0)
        self.ssh_keys = dict(attrs.get('ssh_keys', []))
        self.uuid = attrs.get('uuid')
        self.uuid_validation_expiry = attrs.get('uuid_validation_expiry')
        self.activation_status = attrs.get('activation_status')
        self.mail_date = attrs.get('mail_date', None)
        self.is_second_login = attrs.get('is_second_login', False)
        self.linked_accounts = attrs.get("linked_accounts") or []
        self.linked_to = attrs.get("linked_to", "")
        self.refresh_token = attrs.get('refresh_token', "")

        tdetails = sec_context.details
        now = time.time()

        def load_last_n(name, config_name):
            device_factors = tdetails.get_config('security', config_name, {})
            hard_limit = device_factors.get('hard_limit', 60) * 24 * 60 * 60
            soft_limit = device_factors.get('soft_limit', 15) * 24 * 60 * 60
            max_devices = device_factors.get('max_entries', 20)

            valid_device_list = []
            admin_list = []
            attr_value = attrs.get(name, None)
            if not attr_value:
                return {}

            # Postgres workaround to add items
            if 'items' in attr_value:
                attr_value = attr_value['items']

            if isinstance(attr_value, dict):
                attr_value = attr_value.items()

            for d, d_info in attr_value:
                if (d_info.get('user_agent', '') == 'Administrative Addition'):
                    admin_list.append([None, d, d_info])
                elif now < d_info.get('first_used', 0) + hard_limit and now < d_info.get('last_used', 0) + soft_limit:
                    valid_device_list.append([d_info.get('last_used', 0), d, d_info])

            # Trim the list to first max_devices
            valid_device_list = sorted(valid_device_list, reverse=True)
            if len(valid_device_list) > max_devices:
                valid_device_list = valid_device_list[0:max_devices]
            return dict((x[1], x[2]) for x in admin_list + valid_device_list)

        # Load the valid devices and ips with a limit of last max_devices
        self.valid_devices = load_last_n('valid_devices', 'device_factors')
        self.valid_ips = load_last_n('valid_ips', 'ip_factors')

        super(User, self).decode(attrs)

    def upgrade_attrs(self, attrs):
        if attrs['_version'] < 2:
            attrs['object']['roles'] = dict((k, {}) for k in attrs['object']['roles'])
        if attrs['_version'] < 3:
            new_roles = {}
            for r, role_val in attrs['object'].get('roles', {}).items():
                new_roles[r] = []
                for priv_val in role_val.values():
                    new_roles[r].append(priv_val)
            attrs['object']['roles'] = new_roles

    @classmethod
    def getUserByLogin(cls, username):
        return cls.getByFieldValue('username', username.lower())

    @classmethod
    def getUserByKey(cls, key):
        return cls.getByKey(key)

    def verify_password(self, password):
        password = password.strip()
        if password.startswith('SIGNATURE::'):
            dummy, dummy, t, dummy, signature = password.split(':')
            for k in self.ssh_keys.values():
                try:
                    key = RSA.importKey(k)
                    h = SHA.new(t.encode('utf-8'))
                    verifier = PKCS1_PSS.new(key)
                    if verifier.verify(h, base64.b64decode(signature)):
                        if abs(time.time() - float(t)) < 20:
                            return True
                        else:
                            if self.username in script_users + ['micro_user@administrative.domain']:
                                return True
                            logger.error('Trying to login using old signature for %s', self.username)
                            return False
                except:
                    logger.exception('Unknown error')
            return False
        else:
            cipher = SHA512.new((password + self.password_salt if self.password_salt else password).encode('utf-8'))
            hashed_pwd = cipher.hexdigest()
            return hashed_pwd == self.password_hash

    def set_password(self, password):
        password = password.strip()
        if password.startswith('SIGNATURE::'):
            raise UserError('Password may not start with that prefix')
        self.password_salt = random_string()
        cipher = SHA512.new((password + self.password_salt).encode('utf-8'))
        self.password_hash = cipher.hexdigest()

    def get_password(self):
        raise UserError("Password can't be retrieved")

    password = property(get_password, set_password)

    def has_password(self):
        return True if self.password_hash else False

    @property
    def user_role_label(self):
        return dict(self.USER_ROLES).get(self.user_role)


class UserError(Exception):

    def __init__(self, error):
        self.error = error
