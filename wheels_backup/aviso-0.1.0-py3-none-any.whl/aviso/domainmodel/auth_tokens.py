'''
Created June 2017

@author: Sujith
'''

from aviso.domainmodel import Model
from aviso.settings import gnana_db2

class AuthorizationToken(Model):
    """Model for maintaining the authorization tokens for the registered Tenants"""
    postgres = True
    collection_name = "authorization_tokens"
    kind = "domainmodel.auth_tokens.AuthorizationToken"
    version = 1
    encrypted = False
    tenant_aware = False
    index_list = {
        'tenant~primary_tenant~stack':{
            'unique': True
        }
    }

    def __init__(self, attrs=None):
        """Initializes the authorization_token class"""
        self.token = None
        self.stack = None
        self.primary_tenant = False
        self.tenant = None
        self.generated_by = None
        super(AuthorizationToken, self).__init__(attrs)

    def encode(self, attrs):
        """Loads the class attributes into a given dictionary

        Args:

                attrs: dictionary in which object attributes will be loaded
        """
        attrs['token'] = self.token
        attrs['stack'] = self.stack
        attrs['primary_tenant'] = self.primary_tenant
        attrs['tenant'] = self.tenant
        attrs['generated_by'] = self.generated_by
        attrs['source_tenant'] = self.source_tenant
        super(AuthorizationToken, self).encode(attrs)

    def decode(self, attrs):
        """Loads the class object usng attributes passed in attrs

        Args:

                attrs: dictionary which contains class attributes to load class object
                consider case 
                    current stack is gbm and 
                    forecast service is trying to connect to gbm
                    primary_tenant (type=bool) weather forecast service tenant is primary or not
                    tenant (type=string) tenant name in forecast service
                    stack (type=string) cname of forecast service
                    generated_by (type=string) name of user who is trying to set
                    soruce_tenant (type=string) tenant name in gbm service 
        """
        self.token = attrs.get('token')
        self.stack = attrs.get('stack')
        self.primary_tenant = attrs.get('primary_tenant', False)
        self.tenant = attrs.get('tenant')
        self.generated_by = attrs.get('generated_by')

        self.source_tenant = attrs.get('source_tenant')
        super(AuthorizationToken, self).decode(attrs)

    @classmethod
    def create_postgres_table(cls):
        """Create the postgres table for the sandbox class

        Args:


        Return:

                dict: represents the executed operation with success:True
                      else exception message will be returned
        """
        statement = 'create table "{tablename}"(\
                _id                    bigserial primary key,\
                _kind                  varchar,\
                _version               int,\
                last_modified_time     bigint,\
                token                  varchar,\
                stack                  varchar,\
                primary_tenant         boolean,\
                tenant                 varchar,\
                generated_by           varchar,\
                source_tenant          varchar\
                  )'
        print(statement.format(tablename=cls.getCollectionName().replace('.', '$')))
        return gnana_db2.postgres_table_creator(statement.format(tablename=cls.getCollectionName().replace('.', '$')),
                                                cls.getCollectionName())

