class BaseModel(object):
    """Base class for all domainmodel objects and provides the basic ORM
    capabilities and conventions.

    In addition, this class also provides a
    few class level methods that can be used to retrieve objects by keys
    and names.

    This base class adds the following into the collection:

    _id
        Database ID of the object

    _kind
        Type of the object stored in the collection.  Most of the time, a
        collection holds homogeneous kind of objects, however this is not
        guaranteed.

    _version
        Each object will store a schema version used to store the object.
        In the future it is expected that, an upgrade method is called to
        progressively upgrade the data in the collection.

        .. NOTE:: As of now we are storing the version, but no upgrade logic
            is implemented.

    object
        All the attributes of the object are encoded by calling the encode
        method and saved with object key

        During encoding each domainobject should ensure there are no periods
        in any dictionaries.  This is a limitation in document databases.

    Following Class level variables to be defined by each domain object:

    kind
        Kind of the object

    tenant_aware
        If the tenant aware is set to true, when saving the objects,
        collection name is prefixed with the tenant name from security context
        object

    version
        Current object schema version

    index_list
        A dictionary of indexes to be ensured when saving.  When specifying
        the index, additional options can be provided as a subdictionary.

        Examples::

            # Just an index
            'probeid': {}

            # Unique index on object.username field in DB
            'username': {'unique': True}

            # Creating index in descending order, default value is ASCENDING
            "created_time": {'direction': DESCENDING}

            # Index to expire documents after certain age. In this example
            # document expires after 900 sec + value in object.timestamp
            # field
            'timestamp': {
                'expireAfterSeconds': 900
            }

    query_list
        A dictionary in the same format as indexes, that must be searchable
        but not actually created in the DB as indexes.

    collection_name
        Name of the collection in which to store the values.

        .. WARNING: Never use ModelClass.collection_name directly, instead
            use ModelClass.getCollectionName() method.  Using the method ensures
            that tenant prefixing is done properly.
    """
    kind = None
    tenant_aware = True
    collection_name = None
    index_list = {}
    version = None
    index_checked = {}
    # as database encryption is in place
    # no need to encrypt explicitly
    # If a model needs data save in encrypted
    # specify encrypted True in specific model
    encrypted = False
    query_list = {}
    check_sum = None  # Used in UIP prepare to compare stage_uip & main_uip records
    typed_fields = {}
    compressed = False
    for_sdk = False

    def __init__(self, attrs, for_sdk=False):
        self.for_sdk = for_sdk
        if attrs is not None and (u'_id' in attrs or '_id' in attrs):
            self.id = attrs[u'_id']
            if u'_kind' not in attrs:
                raise ModelError("Kind of object is not defined by subclass")
            if attrs[u'_kind'] != self.kind and not for_sdk:
                raise ModelError(
                    "Loading incorrect type of object, DB: %s, Required: %s" %
                    (attrs[u'_kind'], self.kind))
            # Ideally this should not be here.
            # if self.encrypted and self.tenant_aware and u'_encdata' in attrs and attrs.get('_encdata'):
            #     decdata = BSON(
            #         sec_context.decrypt(attrs[u'_encdata'])).decode()
            #     if decdata:
            #         attrs[u'object'] = decdata
            if attrs['_version'] != self.version:
                self.upgrade_attrs(attrs)
            self.last_modified_time = attrs.get('last_modified_time', None)
            self.check_sum = attrs.get('check_sum', None)
            self.decode(attrs[u'object'])
        else:
            self.id = None
            self.last_modified_time = None
            self.check_sum = None
        
    def encode(self, attrs):
        """Called before saving to get a dictionary representation of the
        object suitable for saving into a document database.  Make sure to
        call the super class method in the implementations.  No need to return
        anything, just updating the attrs is enough.
        """
        attrs['last_modified_time'] = self.last_modified_time
        attrs['check_sum'] = self.check_sum
        return attrs

    # Nothing to decode
    def decode(self, attrs):
        """Called to reconstruct the object from the dictionary.  Initialize
        any required variables and make sure to call the super class
        """
        self.last_modified_time = self.last_modified_time or attrs.get(u'last_modified_time', None)
        if attrs.get(u'check_sum', None):
            self.check_sum = attrs.get(u'check_sum', None)
        pass

class ModelError(Exception):

    def __init__(self, error):
        self.error = error
