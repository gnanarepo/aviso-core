"""Period utilities for Aviso SDK time-based operations.

This module provides comprehensive period management functionality including
quarter/month/week calculations, period range operations, and temporal
filtering with timezone support.

The PeriodUtils class handles complex period logic such as:
- Dynamic period generation with configurable fiscal year definitions
- Period arithmetic and navigation (next/previous periods)
- Temporal filtering and range calculations
- Calendar period conversions and adjustments
- Performance-optimized caching for repeated operations
"""

import collections
import datetime
import re
from datetime import timedelta
from functools import cached_property
from itertools import chain
from typing import Any, Dict, List, Optional, Tuple, Union

import pytz
from dateutil.relativedelta import relativedelta
from .tenant_utils import TenantUtils
from .datetime_utils import TenantDateTime
# from ..config.period_config import PeriodConfig
# from ..database import MongoDBReadUtils
from .utils import flatten_to_list

# Named tuple for period representation
PeriodTuple = collections.namedtuple("PeriodTuple", ["mnemonic", "begin", "end"])

# One millisecond timedelta constant
onems = timedelta(milliseconds=1)


class PeriodUtils:
    """Generic period utilities for time-based business operations.

    This class provides comprehensive period management functionality including
    fiscal year calculations, period arithmetic, temporal filtering, and
    performance-optimized period range operations.

    The utility supports multiple period types (Years, Quarters, Months, Weeks)
    with configurable fiscal year definitions, timezone handling, and
    period-aware caching for optimal performance.

    Attributes:
        tenant_utils: Tenant configuration utilities for period settings
        period_config: Period configuration for system time preferences
        ALL_PERIODS_CACHE: Performance cache for generated period definitions
        ALL_PERIOD_RANGES_CACHE: Performance cache for period range lookups

    Examples:
        ```python
        from aviso.sdk.common import TenantUtils, PeriodUtils
        from aviso.sdk.config import PeriodConfig
        
        tenant_utils = TenantUtils('tenant-id', fm_client)
        period_config = PeriodConfig({'sys_time': True})
        period_utils = PeriodUtils(tenant_utils, period_config)
        
        # Get current quarter
        current_q = period_utils.current_period(period_type='Q')
        
        # Get next 2 quarters
        next_quarters = period_utils.next_period(count=2, period_type='Q')
        
        # Get period range from mnemonic
        begin, end = period_utils.period_rng_from_mnem('2024Q1')
        ```
    """

    def __init__(self, tenant_utils: TenantUtils, period_config: None, db_utils: None) -> None:
        """Initialize PeriodUtils with tenant and configuration dependencies.

        Args:
            tenant_utils: Tenant utilities for accessing period configurations
                and timezone settings from the FM API
            period_config: Period configuration for system time preferences
                and period-specific operational behaviors

        Note:
            Initializes performance caches that will be populated on first use
            of period operations. This lazy loading approach optimizes startup time.
        """
        self.tenant_utils = tenant_utils
        self.period_config = period_config
        self.db_utils = db_utils

        # Performance caches - populated lazily on first access
        self.ALL_PERIODS_CACHE: Dict[Tuple[str, Optional[str]], List[PeriodTuple]] = {}
        self.ALL_PERIOD_RANGES_CACHE: Dict[str, Tuple[int, int]] = {}
        self.PRD_STR_CACHE = {}
        self._config_cache: Dict[str, Any] = {}

    def next_period(
            self,
            a_datetime: Optional[datetime.datetime] = None,
            period_type: str = 'Q',
            skip: int = 1,
            count: int = 1
    ) -> Union[PeriodTuple, List[PeriodTuple]]:
        """Get the next period(s) from a given datetime.

        Calculates future periods relative to the specified datetime,
        with support for skipping periods and retrieving multiple periods.

        Args:
            a_datetime: Reference datetime (defaults to current UTC time)
            period_type: Type of period - 'Q' (Quarter), 'M' (Month), 'Y' (Year), 'W' (Week)
            skip: Number of periods to skip forward (default: 1)
            count: Number of periods to return (default: 1)

        Returns:
            Single PeriodTuple if count=1, otherwise List[PeriodTuple]

        Examples:
        ```python
            # Get next quarter
            next_q = period_utils.next_period(period_type='Q')
            
            # Get 3 quarters starting 2 quarters from now
            future_qs = period_utils.next_period(skip=2, count=3, period_type='Q')
            
            # Get next month from specific date
            ref_date = datetime.datetime(2024, 6, 15, tzinfo=pytz.utc)
            next_month = period_utils.next_period(ref_date, period_type='M')
        ```
        """
        return self.period_details(a_datetime, period_type, delta=skip, count=count)

    def current_period(
            self,
            a_datetime: Optional[datetime.datetime] = None,
            period_type: str = 'Q'
    ) -> PeriodTuple:
        """Get the current period containing the specified datetime.

        Determines which period contains the given datetime based on
        the tenant's fiscal year configuration.

        Args:
            a_datetime: Reference datetime (defaults to current UTC time)
            period_type: Type of period - 'Q' (Quarter), 'M' (Month), 'Y' (Year), 'W' (Week)

        Returns:
            PeriodTuple representing the current period

        Examples:
        ```python
            # Get current quarter
            current_q = period_utils.current_period(period_type='Q')
            print(f"Current quarter: {current_q.mnemonic}")
            
            # Get current month for specific date
            ref_date = datetime.datetime(2024, 3, 15, tzinfo=pytz.utc)
            current_month = period_utils.current_period(ref_date, period_type='M')
        ```
    """
        return self.period_details(a_datetime, period_type, delta=0)

    def get_current_period(self):
        """
        get mnemonic of current app period
        Returns:
            str -- period mnemonic
        """
        return self.current_period(self.get_now().as_datetime()).mnemonic

    def period_details(
            self,
            a_datetime: Optional[datetime.datetime] = None,
            period_type: str = 'Q',
            delta: int = 0,
            count: int = 1
    ) -> Union[PeriodTuple, List[PeriodTuple]]:
        """Get period details with optional offset and count.

        Core method for period calculations that finds periods relative to a
        reference datetime. Supports both single period retrieval and bulk
        operations for multiple periods.

        Args:
            a_datetime: Reference datetime (defaults to current UTC time)
            period_type: Type of period - 'Q' (Quarter), 'M' (Month), 'Y' (Year), 'W' (Week)
            delta: Offset from the containing period (positive=future, negative=past)
            count: Number of periods to return (1 returns single PeriodTuple)

        Returns:
            Single PeriodTuple if count=1, otherwise List[PeriodTuple]

        Raises:
            ValueError: If the datetime doesn't fall into any known period range

        Examples:
        ```python
            # Get current quarter
            current = period_utils.period_details(period_type='Q', delta=0)
            
            # Get next 3 quarters
            future = period_utils.period_details(delta=1, count=3, period_type='Q')
            
            # Get previous 2 months from specific date
            ref_date = datetime.datetime(2024, 6, 15, tzinfo=pytz.utc)
            past = period_utils.period_details(ref_date, 'M', delta=-2, count=2)
        ```
        Note:
            Uses cached period definitions for performance. The containing period
            is identified first, then delta and count are applied for navigation.
        """
        if a_datetime is None:
            a_datetime = datetime.datetime.now(tz=pytz.utc)

        all_periods = self.get_all_periods(period_type)

        # Find the period containing the reference datetime
        for idx, time_span in enumerate(all_periods):
            if time_span[1] <= a_datetime <= time_span[2]:
                target_index = idx + delta

                # Return single period or list based on count
                if count == 1 or count == 0:
                    return all_periods[target_index]
                elif delta >= 0:
                    # Forward direction: target_index + 0, 1, 2, ...
                    end_index = min(target_index + count, len(all_periods))
                    return list(all_periods[target_index + i] for i in range(end_index - target_index))
                else:
                    # Backward direction: target_index, target_index-1, target_index-2, ...
                    start_index = max(target_index - count + 1, 0)
                    return list(all_periods[target_index - i] for i in range(target_index - start_index + 1))

        # No containing period found
        raise ValueError(f"DateTime {a_datetime} doesn't fall into any known time span for period type {period_type}")

    def get_eom(self, tenant_dt: TenantDateTime) -> TenantDateTime:
        """Get end of month for the given TenantDateTime.

        Calculates the last moment of the month containing the input datetime,
        with proper daylight saving time handling and timezone preservation.

        Args:
            tenant_dt: TenantDateTime instance to find end of month for

        Returns:
            TenantDateTime representing the end of the month (23:59:59.999)
            in the same timezone as the input

        Examples:
        ```python
            import pytz
            tz = pytz.timezone('America/New_York')
            dt = TenantDateTime(tz, 1609459200)  # 2021-01-01 00:00:00 UTC
            eom = period_utils.get_eom(dt)
            str(eom)  # End of January 2021
        ```            '2021-01-31 23:59:59.999000-05:00'

        Note:
            Handles daylight saving time transitions correctly by re-localizing
            the final datetime. The microsecond is set to 999000 to represent
            the last moment before the next day begins.
        """
        current_dt = tenant_dt.as_datetime()

        # Move to first day of next month, then subtract to get end of current month
        next_month = current_dt + relativedelta(months=1)
        first_of_next = next_month.replace(
            day=1, hour=23, minute=59, second=59, microsecond=999000
        )
        eom = first_of_next + relativedelta(days=-1)

        # Handle daylight saving time transitions
        timezone_info = eom.tzinfo
        if timezone_info:
            # Remove timezone info temporarily, then re-localize
            naive_eom = eom.replace(tzinfo=None)
            # Re-localize with proper DST handling
            localized_eom = timezone_info.localize(naive_eom, is_dst=None)
        else:
            localized_eom = eom

        return TenantDateTime.from_datetime(tenant_dt.timezone, localized_eom)

    def get_date_time_for_extended_month(
        self,
        year: int,
        month: int,
        tzinfo: pytz.BaseTzInfo,
        day: int = 1
    ) -> datetime.datetime:
        """Get datetime for months outside the normal 1-12 range with timezone handling.

        Handles month values that extend beyond standard calendar year bounds,
        automatically adjusting the year when month is <1 or >12. Includes proper
        daylight saving time handling for timezone transitions.

        Args:
            year: Base year for the date calculation
            month: Month value (can be negative or >12, will adjust year accordingly)
            tzinfo: pytz timezone info for localization
            day: Day of month (default: 1)

        Returns:
            datetime.datetime: Timezone-aware datetime with DST handling

        Examples:
        ```python
            tz = pytz.timezone('America/New_York')
            # Month 0 becomes December of previous year
            dt1 = period_utils.get_date_time_for_extended_month(2024, 0, tz)
            # Month 13 becomes January of next year
            dt2 = period_utils.get_date_time_for_extended_month(2024, 13, tz)
        ```
        """
        if month < 0:
            year = year - 1
            month += 13
        elif month > 12:
            year += 1
            month -= 12
        dt_tuple = (year, month, day)
        try:
            dt = datetime.datetime(*dt_tuple)
            dt = tzinfo.localize(dt, is_dst=tzinfo.dst(dt))
        except pytz.exceptions.NonExistentTimeError:
            dt = datetime.datetime(*(dt_tuple + (1,)))
            dt = tzinfo.localize(dt, is_dst=tzinfo.dst(dt))
        return dt

    def period_details_by_mnemonic(
        self,
        mnemonic: str,
        period_type: str = 'Q',
        delta: int = 0,
        count: int = 1
    ) -> Union[PeriodTuple, List[PeriodTuple]]:
        """Get period details by mnemonic identifier with optional offset and count.

        Locates a period by its mnemonic identifier (e.g., '2024Q1', '202406') and
        returns periods relative to that position. Supports both single period
        retrieval and bulk operations for multiple periods.

        Args:
            mnemonic: Period mnemonic identifier (e.g., '2024Q1', '2024M06', '2024')
            period_type: Type of period - 'Q' (Quarter), 'M' (Month), 'Y' (Year), 'W' (Week)
            delta: Offset from the located period (positive=future, negative=past)
            count: Number of periods to return (1 returns single PeriodTuple)

        Returns:
            Single PeriodTuple if count=1, otherwise List[PeriodTuple]

        Raises:
            Exception: If no period found with the specified mnemonic and period_type

        Examples:
        ```python
            # Get Q1 2024 details
            q1 = period_utils.period_details_by_mnemonic('2024Q1', 'Q')
            
            # Get next 3 quarters after Q2 2024
            future_qs = period_utils.period_details_by_mnemonic(
            '2024Q2', 'Q', delta=1, count=3)
        """
        all_periods = self.get_all_periods(period_type)
        for idx, time_span in enumerate(all_periods):
            if time_span[0] == mnemonic:
                if count == 1 or count == 0:
                    return all_periods[idx + delta]
                elif delta > 0:
                    return list(all_periods[idx + it + delta] for it in range(count))
                else:
                    return list(all_periods[idx - it + delta] for it in range(count))
        else:
            raise Exception(
                "No match for mnemonic=%s (period_type=%s)" % (mnemonic, period_type))

    def monthly_periods(self, q_prd, period_type: str = 'Q'):
        """Returns all monthly periods for a given quarterly period.

        Takes either a period namedtuple OR a string corresponding to a qtr mnem.
        NOTE: This is the UI / App layer format.

        Args:
            q_prd: Either a period namedtuple or string mnemonic for a quarter/year
            period_type: Type of period - 'Q' (Quarter), 'Y' (Year)

        Yields:
            PeriodTuple: Monthly periods within the specified quarter/year

        Examples:
        ```python
            # Get monthly periods for Q1 2024
            q1_months = list(period_utils.monthly_periods('2024Q1', 'Q'))
            
            # Get monthly periods for a period tuple
            q_period = period_utils.period_details_by_mnemonic('2024Q2', 'Q')
            q2_months = list(period_utils.monthly_periods(q_period, 'Q'))
        ```
        """
        if isinstance(q_prd, str):
            q_prd = self.period_details_by_mnemonic(q_prd, period_type)
        boq_epoch = TenantDateTime.epoch(self.tenant_utils.timezone, q_prd.begin)

        if period_type in ['Y', 'y']:
            months = ([self.current_period(boq_epoch.as_datetime(), period_type='M')] +
                      self.next_period(boq_epoch.as_datetime(), period_type='M', count=11))
        else:
            months = ([self.current_period(boq_epoch.as_datetime(), period_type='M')] +
                      self.next_period(boq_epoch.as_datetime(), period_type='M', count=2))

        for p, month in enumerate(months):
            bom, eom = TenantDateTime.epoch(self.tenant_utils.timezone, month.begin), TenantDateTime.epoch(
                self.tenant_utils.timezone, month.end)
            bom_dt, eom_dt = bom.as_datetime(), eom.as_datetime()
            mom_dt = bom_dt - (bom_dt - eom_dt) / 2
            mnth_mnm = str(mom_dt.year) + format(mom_dt.month, '02')

            if period_type in ['Y', 'y']:
                if bom >= q_prd.begin and eom <= q_prd.end:
                    yield PeriodTuple(mnth_mnm, bom_dt, eom_dt)
            else:
                yield PeriodTuple(mnth_mnm, bom_dt, eom_dt)

    def datetime2epoch(self, dt: datetime.datetime) -> int:
        """Convert a timezone-aware datetime into epoch ms.

        Args:
            dt: Timezone-aware datetime to convert

        Returns:
            int: Epoch milliseconds (Unix timestamp * 1000)

        Examples:
        ```python
            import pytz
            dt = datetime.datetime(2024, 1, 1, tzinfo=pytz.utc)
            epoch_ms = period_utils.datetime2epoch(dt)
            epoch_ms
            1704067200000
        ```
        """
        return TenantDateTime.from_datetime(self.tenant_utils.timezone, dt).as_epoch()

    def periods_for_year(self, y: int, quarters: List[int], period_type: str, tzinfo: pytz.BaseTzInfo,
                         quarter_adjustments: Dict[str, Tuple[int, int]] = {},
                         month_adjustments: Dict[str, Tuple[int, int]] = {},
                         starting_quarter: Dict[Union[str, int], int] = {}, week_start: int = 7,
                         year_adjustments: Dict[str, Tuple[int, int]] = {}
                         ) -> List[PeriodTuple]:
        """Generate periods for a specific year based on period type and configuration.

        Creates period tuples (Year, Quarter, Month, or Week) for a given year using
        fiscal calendar configuration and adjustment parameters. Handles various
        period types with custom start dates and boundary adjustments.

        Args:
            y: Year for which to generate periods
            quarters: List of month numbers defining quarter/period boundaries
            period_type: Type of periods to generate - 'Y'/'y' (Year), 'Q'/'q' (Quarter),
                        'M'/'m' (Month), 'W'/'w' (Week), 'CM' (Calendar Month)
            tzinfo: pytz timezone for date calculations
            quarter_adjustments: Dict mapping quarter mnemonics to (begin_days, end_days) adjustments
            month_adjustments: Dict mapping month mnemonics to (begin_days, end_days) adjustments
            starting_quarter: Dict mapping year to starting quarter number (1-4)
            week_start: Day of week for week start (1=Monday, 7=Sunday)
            year_adjustments: Dict mapping year strings to (begin_days, end_days) adjustments

        Returns:
            List[PeriodTuple]: List of period tuples with mnemonic, start, and end dates

        Examples:
        ```python
            # Generate quarters for 2024
            quarters_2024 = period_utils.periods_for_year(
                2024, [1, 4, 7, 10, 13], 'Q', pytz.timezone('US/Pacific')
            )

            # Generate months with adjustments
            months_2024 = period_utils.periods_for_year(
                2024, [1, 13], 'M', pytz.timezone('US/Eastern'),
                month_adjustments={'2024M01': (5, -2)}
            )
        ```
        """
        if period_type[0] in ('Y', 'y'):
            if not quarters:
                return []
            adjust_begin, adjust_end = year_adjustments.get(str(y), (0, 0))
            period_start = self.get_date_time_for_extended_month(y, quarters[0], tzinfo) + timedelta(adjust_begin)
            period_end = self.get_date_time_for_extended_month(
                y, quarters[-1], tzinfo) - onems + timedelta(adjust_end)
            return [PeriodTuple(str(y), period_start, period_end, )]
        elif period_type[0] in ('Q', 'q'):
            periods = []
            quarter_mnemonic_shift = 0
            if str(y) in starting_quarter:
                quarter_mnemonic_shift = starting_quarter[str(y)] - 1
            elif int(y) in starting_quarter:
                quarter_mnemonic_shift = starting_quarter[int(y)] - 1
            for i, start_month in enumerate(quarters[:-1]):
                end_month = quarters[i + 1]
                mnemonic = "%04dQ%d" % (int(y), int(i + 1 + quarter_mnemonic_shift))
                adjust_begin, adjust_end = quarter_adjustments.get(
                    mnemonic, (0, 0))
                periods.append(PeriodTuple(mnemonic,
                                           self.get_date_time_for_extended_month(
                                               y, start_month, tzinfo) + timedelta(adjust_begin),
                                           self.get_date_time_for_extended_month(y, end_month, tzinfo) + timedelta(
                                               adjust_end) - onems)
                               )
            return periods
        elif period_type[0] in ('M', 'm'):
            if not quarters:
                return []
            periods = []
            start_month = quarters[0]
            end_month = quarters[-1]
            # there is no month 0:
            month_range = filter(lambda x: x != 0, range(start_month, end_month))
            for i, month in enumerate(month_range):
                # be careful as there is no month 0
                mnemonic = "%04dM%02d" % (y, i + 1)
                adjust_begin, adjust_end = month_adjustments.get(mnemonic, (0, 0))
                #             print '***************************************'
                #             print '****month adjust***'
                #             print adjust_begin, adjust_end
                periods.append(PeriodTuple(mnemonic,
                                           self.get_date_time_for_extended_month(
                                               y, month, tzinfo) + timedelta(adjust_begin),
                                           self.get_date_time_for_extended_month(y, month + 1 if month + 1 else 1,
                                                                                 tzinfo) + timedelta(
                                               adjust_end) - onems)
                               )
            return periods
        elif period_type[0] in ('W', 'w'):
            periods = []
            quarter_mnemonic_shift = 0
            if str(y) in starting_quarter:
                quarter_mnemonic_shift = starting_quarter[str(y)] - 1
            elif int(y) in starting_quarter:
                quarter_mnemonic_shift = starting_quarter[int(y)] - 1
            for i, start_month in enumerate(quarters[:-1]):
                end_month = quarters[i + 1]
                mnemonic = "%04dQ%d" % (int(y), int(i + 1 + quarter_mnemonic_shift))
                adjust_begin, adjust_end = quarter_adjustments.get(
                    mnemonic, (0, 0))
                boq = self.get_date_time_for_extended_month(y, start_month, tzinfo) + timedelta(adjust_begin)
                eoq = self.get_date_time_for_extended_month(y, end_month, tzinfo) + timedelta(adjust_end) - onems

                bow = boq
                counter = 1
                while (bow < eoq):
                    month_range = filter(lambda x: x != 0, range(start_month, end_month))
                    for j, m_month in enumerate(month_range):
                        mnemonic = "%04dM%02d" % (y, i * 3 + j + 1)
                        adjust_begin, adjust_end = month_adjustments.get(mnemonic, (0, 0))
                        bom = self.get_date_time_for_extended_month(y, m_month, tzinfo) + timedelta(adjust_begin)
                        eom = self.get_date_time_for_extended_month(y, m_month + 1 if m_month + 1 else 1,
                                                                    tzinfo) + timedelta(adjust_end) - onems
                        eom = min(eom, eoq)

                        week = 1
                        while (bow < eom):
                            eow = bow + timedelta(days=(week_start - bow.weekday() + 7) % 7 or 7)
                            eow = self.get_date_time_for_extended_month(eow.year, eow.month, tzinfo, day=eow.day)
                            eow = min(eow - onems, eoq)

                            lower_month_bound = self.get_date_time_for_extended_month(y, m_month, tzinfo)
                            lower_quarter_bound = self.get_date_time_for_extended_month(y, start_month, tzinfo)
                            lower_bound = max(lower_quarter_bound, lower_month_bound)
                            upper_month_bound = self.get_date_time_for_extended_month(y,
                                                                                      m_month + 1 if m_month + 1 else 1,
                                                                                      tzinfo) - onems
                            upper_quarter_bound = self.get_date_time_for_extended_month(y, end_month, tzinfo)
                            upper_bound = min(upper_month_bound, upper_quarter_bound)

                            month = min(max(bow, lower_bound), upper_bound).month
                            year = min(max(bow, lower_bound), upper_bound).year

                            mnemonic = "%04d%02dW%02d" % (year, month, week)
                            periods.append(PeriodTuple(mnemonic, bow, eow))

                            week += 1
                            bow = eow + onems

                            counter += 1
                            if counter % 100 == 0:
                                break

                    counter += 1
                    if counter % 100 == 0:
                        break
            return periods
        elif period_type == 'CM':
            # Calendar Month for App / UI.
            # Assumes 3 month quarters with where month length equals length of calendar months.
            # Probably doesn't play nice with other offset features.
            qtrs = self.periods_for_year(y, quarters, 'Q', tzinfo, quarter_adjustments, month_adjustments)
            return list(chain(*[self.monthly_periods(q_prd) for q_prd in qtrs]))
        else:
            raise Exception('Unkwon period type: ' + period_type)
            return []

    def _get_config(self, section: str, key: str, default: Any = None) -> Any:
        """Fetch tenant config with caching."""
        cache_key = f"{section}.{key}"
        if cache_key not in self._config_cache:
            self._config_cache[cache_key] = self.tenant_utils.get_tenant_config(section, key, default)
        return self._config_cache[cache_key]



    def _get_all_periods(
        self,
        period_type: str,
        filt_out_qs: Optional[List[str]] = None
    ) -> List[Union[PeriodTuple, List[Any]]]:
        # Configs pulled with caching
        period_config = self._get_config('forecast', 'quarter_begins')
        year_adjustments = self._get_config('forecast', 'year_adjustments', {}) or {}
        quarter_adjustments = self._get_config('forecast', 'quarter_adjustments', {}) or {}
        month_adjustments = self._get_config('forecast', 'month_adjustments', {}) or {}
        starting_quarter = self._get_config('forecast', 'starting_quarter', {}) or {}
        week_start = self._get_config('forecast', 'week_start', 7)
        tzinfo = self.tenant_utils.timezone

        if not period_config:
            raise Exception('No configuration found for the quarter definition. (quarter_begins)')

        if isinstance(period_config, list):
            period_config = {'1990-': period_config}

        # Create a list of all periods
        all_periods = []
        for x in period_config:
            # Find the proper range to use
            if x.endswith('-'):
                start, end = x[0:-1], 2050
            elif x.find('-') == -1:
                start, end = x, x
            else:
                start, end = x.split('-')

            # Convert the range to integers
            start, end = int(start), int(end)
            for y in range(start, end + 1):
                all_periods.extend(
                    self.periods_for_year(y, period_config[x], period_type, tzinfo, quarter_adjustments,
                                          month_adjustments,
                                          starting_quarter, week_start, year_adjustments))
        all_periods = sorted(all_periods)
        # Validate that there are no duplicates
        if len(all_periods) > len(set(map(lambda x1: x1[0], all_periods))):
            raise Exception('Duplicate financial years found')

        if filt_out_qs:
            return [[qmn, beg, end] for qmn, beg, end in all_periods
                    if qmn not in filt_out_qs]
        else:
            return all_periods

    def get_all_periods(self, period_type: str, filt_out_qs: Optional[List[str]] = None) -> List[
        Union[PeriodTuple, List[Any]]]:
        """Get all periods with caching for improved performance.

        Retrieves all periods for the specified type, using cached results when
        available. Cache key includes both period type and filtered quarters
        to ensure correct cache behavior.

        Args:
            period_type: Type of periods to generate - 'Y'/'y' (Year), 'Q'/'q' (Quarter),
                        'M'/'m' (Month), 'W'/'w' (Week), 'CM' (Calendar Month)
            filt_out_qs: Optional list of period mnemonics to exclude from results

        Returns:
            List of PeriodTuple objects or nested lists [mnemonic, begin, end] if filtering

        Examples:
        ```python
            # Get all quarters with caching
            all_quarters = period_utils.get_all_periods('Q')

            # Get filtered months (returns nested lists)
            filtered_months = period_utils.get_all_periods('M', ['2024M01', '2024M02'])
        ```
        """

        filtered_qs = ';'.join(
            sorted(filt_out_qs)) if filt_out_qs is not None else None
        try:
            return self.ALL_PERIODS_CACHE[period_type, filtered_qs]
        except KeyError:
            ret_val = self._get_all_periods(period_type, filt_out_qs)
            self.ALL_PERIODS_CACHE[period_type, filtered_qs] = ret_val
            return ret_val

    def get_nextq_mnem_safe(self, mnem: str, skip: int = 1) -> str:  # Tested
        """Get the next quarter mnemonic from the current quarter mnemonic.

        Safely finds the next quarter by looking up the current quarter in
        all periods and returning the quarter at the specified skip distance.

        Args:
            mnem: Current quarter mnemonic, e.g., '2020Q2' or year '2020'
            skip: How many quarters to skip ahead (default: 1)

        Returns:
            Next quarter mnemonic, or empty string if not found

        Examples:
        ```python
            # Get next quarter
            next_q = period_utils.get_nextq_mnem_safe('2024Q1')
            next_q
            '2024Q2'

            # Skip 2 quarters ahead
            future_q = period_utils.get_nextq_mnem_safe('2024Q1', skip=2)
            future_q
            '2024Q3'
        ```
        """
        if len(mnem) == 4:
            return str(int(mnem) + 1)

        all_prds = self.get_all_periods('Q')
        for (curr_q, _curr_beg, _curr_end), (next_q, _next_beg, _next_end) in zip(all_prds, all_prds[skip:]):
            if curr_q == mnem:
                return next_q
        return ''

    def period_rng_from_mnem(self, mnemonic: str) -> Tuple[int, int]:
        """Get period range (begin, end) epochs from mnemonic with caching.

        Retrieves the begin and end epoch timestamps for a given period mnemonic.
        Uses caching for performance and handles different period types including
        quarters, years, months, and weeks with fiscal calendar adjustments.

        Args:
            mnemonic: Period mnemonic (e.g., '2024Q1', '2024', '202401', '202401W01')

        Returns:
            Tuple of (begin_epoch_ms, end_epoch_ms) for the period

        Raises:
            Exception: If no match found for the given mnemonic

        Examples:
        ```python
            # Get quarter range
            begin_ms, end_ms = period_utils.period_rng_from_mnem('2024Q1')

            # Get year range
            year_begin, year_end = period_utils.period_rng_from_mnem('2024')

            # Get month range
            month_begin, month_end = period_utils.period_rng_from_mnem('202403')
        ```
        """
        # using tuples instead of namedtuples in here because this is performance critical

        month_adjustments = self._get_config('forecast', 'month_adjustments', {}) or {}
        try:
            return self.ALL_PERIOD_RANGES_CACHE[mnemonic]
        except KeyError:
            all_periods = self.get_all_periods('Y') if len(mnemonic) == 4 else (
                self.get_all_periods('W') if 'W' in mnemonic else self.get_all_periods('Q'))
            for period in all_periods:
                if period.mnemonic == mnemonic:
                    mnem_range = (self.datetime2epoch(period.begin), self.datetime2epoch(period.end))
                    self.ALL_PERIOD_RANGES_CACHE[mnemonic] = mnem_range
                    return mnem_range
                elif 'Q' not in mnemonic and 'W' not in mnemonic and (
                        -1 <= int(mnemonic[:4]) - int(period.mnemonic[:4]) <= 1):
                    boq_epoch = TenantDateTime.epoch(self.tenant_utils.timezone, period.begin)
                    if not month_adjustments:
                        for m in range(0, 3):
                            bom_ep = boq_epoch + relativedelta(months=m)
                            bom_dt = bom_ep.as_datetime()
                            month_mnem = str(bom_dt.year) + format(bom_dt.month, '02')
                            if mnemonic == month_mnem:
                                mnem_range = (bom_ep.as_epoch(), self.get_eom(bom_ep).as_epoch())
                                self.ALL_PERIOD_RANGES_CACHE[mnemonic] = mnem_range
                                return mnem_range
                    else:
                        months = [self.current_period(boq_epoch.as_datetime(), 'M')]
                        for m in range(0, 2):
                            months.append(self.current_period(months[m].end + relativedelta(days=1), 'M'))

                        for m in range(0, 3):
                            adjust_begin, adjust_end = month_adjustments.get(months[m].mnemonic, (0, 0))
                            bom_dt = TenantDateTime.epoch(self.tenant_utils.timezone, months[m].begin).as_datetime()
                            bom_dt_adj = TenantDateTime.epoch(self.tenant_utils.timezone,
                                                              months[m].begin).as_datetime() - timedelta(
                                days=adjust_begin)
                            bom_dt = max(bom_dt, bom_dt_adj)
                            month_mnem = str(bom_dt.year) + format(bom_dt.month, '02')
                            if mnemonic == month_mnem:
                                mnem_range = (self.datetime2epoch(months[m].begin), self.datetime2epoch(months[m].end))
                                self.ALL_PERIOD_RANGES_CACHE[mnemonic] = mnem_range
                                return mnem_range
            else:
                raise Exception("No match for mnemonic: %s", mnemonic)

    def get_now(self) -> 'TenantDateTime':
        """Get current time for the application.

        Returns the current time based on configuration - either system time
        or a configured override time from tenant flags.

        Returns:
            TenantDateTime representing the current application time

        Examples:
        ```python
            # Get current app time
            now = period_utils.get_now()
            print(f"Current time: {now}")

            # Use in period calculations
            current_quarter = period_utils.current_period(now.as_datetime(), 'Q')
        ```
        """
        if self.period_config.use_sys_time:
            return TenantDateTime.epoch(self.tenant_utils.timezone)
        else:
            try:
                return TenantDateTime.epoch(self.tenant_utils.timezone,
                                            self.tenant_utils.get_tenant_flag('prd_svc', 'now_date'))
            except:
                return TenantDateTime.epoch(self.tenant_utils.timezone)

    def relative_period(self, now: 'TenantDateTime', begin: 'TenantDateTime', end: 'TenantDateTime') -> str:
        """Determine if a period is current, future, or historical relative to now.

        Args:
            now: Current reference time
            begin: Period begin time
            end: Period end time

        Returns:
            'c' if current (now is within period),
            'f' if future (now is before period),
            'h' if historical (now is after period)

        Examples:
        ```python
            now = period_utils.get_now()
            q_period = period_utils.period_details_by_mnemonic('2024Q2', 'Q')
            begin_dt = TenantDateTime.epoch(tenant_utils.timezone, q_period.begin)
            end_dt = TenantDateTime.epoch(tenant_utils.timezone, q_period.end)

            status = period_utils.relative_period(now, begin_dt, end_dt)
            status
            'c'  # if currently in Q2 2024
        ```
        """
        if begin <= now <= end:
            return 'c'
        else:
            return 'f' if now < begin else 'h'

    def get_period_as_of(
            self,
            period: str,
            as_of: Optional[int] = None,
            prd_begin_for_h: bool = False) -> int:
        """Get the as_of timestamp for a period with validation and fallbacks.

        Determines the appropriate timestamp to use for period-based calculations.
        If as_of is provided, validates it's within the period. Otherwise returns
        appropriate timestamps based on period status (current/future/historical).

        Args:
            period: Period mnemonic (e.g., '2024Q2')
            as_of: Optional epoch timestamp to validate and use
            prd_begin_for_h: If True, use period begin for historical periods
                           instead of period end

        Returns:
            Epoch timestamp in milliseconds for use in period calculations

        Examples:
        ```python
            # Get as_of for current quarter (uses current time or period override)
            as_of_ms = period_utils.get_period_as_of('2024Q2')

            # Validate provided as_of timestamp
            validated = period_utils.get_period_as_of('2024Q2', 1609459200000)

            # Use period begin for historical periods
            hist_begin = period_utils.get_period_as_of('2023Q4', prd_begin_for_h=True)
        ```
        """
        if as_of:
            prd_begin, prd_end = self.period_rng_from_mnem(period)
            if TenantDateTime.epoch(self.tenant_utils.timezone, prd_begin).as_epoch() <= as_of <= TenantDateTime.epoch(
                    self.tenant_utils.timezone, prd_end).as_epoch():
                return as_of

        # for historic periods, return end of period
        prd_begin, prd_end = [TenantDateTime.epoch(self.tenant_utils.timezone, x) for x in
                              self.period_rng_from_mnem(period)]
        now = self.get_now()
        if self.relative_period(now, prd_begin, prd_end) == 'h':
            return prd_end.as_epoch() if not prd_begin_for_h else prd_begin.as_epoch()

        try:
            return TenantDateTime.epoch(self.tenant_utils.timezone, self.tenant_utils.get_tenant_flag('prd_svc',
                                                                                                      '{}_now_date'.format(
                                                                                                          period))).as_epoch()
        except:
            return now.as_epoch()

    def component_periods(self, period: str, period_type: str = 'Q') -> List[str]:
        """Get periods that roll up to a given period.

        Retrieves the list of component periods that aggregate into the specified
        period. For quarterly periods with monthly FM enabled, returns the constituent
        monthly periods. Otherwise, returns the period itself.

        Args:
            period: Period mnemonic to get components for (e.g., '2020Q2')
            period_type: Type of period processing, defaults to 'Q' for quarterly

        Returns:
            List of component period mnemonics that roll up to the given period.
            For quarterly periods with monthly FM: ['2020M04', '2020M05', '2020M06']
            For other cases: ['2020Q2']

        Examples:
        ```python
            # Quarterly period with monthly FM enabled
            period_utils.component_periods('2020Q2')
            ['2020M04', '2020M05', '2020M06']

            # Quarterly period without monthly FM
            period_utils.component_periods('2020Q2')  # monthly_fm = False
            ['2020Q2']

            # Non-quarterly period
            period_utils.component_periods('2020M01')
            ['2020M01']
        ```

        Note:
            This method depends on the period_config.monthly_fm setting to determine
            whether to decompose quarterly periods into monthly components.
        """
        if period[-2] != 'Q' or not self.period_config.monthly_fm:
            return [period]

        return [
            mnemonic for (mnemonic, _beg_dt, _end_dt) in self.monthly_periods(period, period_type)
        ]

    def prev_period(self, a_datetime=None, period_type='Q', skip=1, count=1):
        """Get previous period(s) relative to a reference datetime.

        Args:
            a_datetime: Reference datetime (defaults to current UTC time)
            period_type: Type of period - 'Q' (Quarter), 'M' (Month), 'Y' (Year), 'W' (Week)
            skip: Number of periods to skip backwards (default 1)
            count: Number of periods to return (1 returns single PeriodTuple)

        Returns:
            Single PeriodTuple if count=1, otherwise List[PeriodTuple]

        Examples:
            # Get previous quarter
            prev_q = period_utils.prev_period()

            # Get previous 3 quarters
            prev_quarters = period_utils.prev_period(count=3)

            # Get previous month from specific date
            ref_date = datetime.datetime(2024, 6, 15, tzinfo=pytz.utc)
            prev_m = period_utils.prev_period(ref_date, 'M')
        """
        return self.period_details(a_datetime, period_type, delta=-skip, count=count)

    def get_available_periods(self):
        """Get available periods in app.

        Returns a set of period mnemonics including current period, previous period,
        next periods based on configuration, and any periods from database.

        Returns:
            set: Set of period mnemonics

        Examples:
            # Get all available periods
            periods = period_utils.get_available_periods()
            {'2024Q4', '2025Q1', '2025Q2', '2025Q3'}
        """
        now_dt = self.get_now().as_datetime()
        required_periods = {self.prev_period(now_dt)[0],
                            self.current_period(now_dt)[0]}
        required_periods |= {self.next_period(now_dt, skip=i + 1)[0] for i in
                             range(self.period_config.future_periods_count)}
        result_periods = set(self.db_utils.fetch_distinct_periods())
        return required_periods | result_periods

    def get_available_quarters_and_months(self):
        """Get mapping of quarters to their component months.

        Args:
            config: Period configuration object
            db: Optional database connection

        Returns:
            Dictionary mapping quarter strings to lists of month strings
        """
        available_periods = self.get_available_periods()
        quarters_and_months = {}
        for period in available_periods:
            quarters_and_months[period] = self.component_periods(period)
        return quarters_and_months

    @cached_property
    def quarters_and_months(self):
        """Get mapping of quarters to their component months.

        Returns a dictionary mapping quarter mnemonics to lists of their
        component monthly period mnemonics using the configured period settings.

        Returns:
            Dictionary mapping quarter strings to lists of month strings
        """
        return self.get_available_quarters_and_months()

    def get_quarter_of_month(self, month: str, period: str = None) -> str:
        """Get the quarter that contains the given month period.

        Converts a monthly period to its containing quarterly period.
        If the input is already a quarter, returns it unchanged.
        If the month is not found in any quarter, falls back to current period.

        Args:
            month: Period string, either monthly (e.g., '2025M03') or quarterly (e.g., '2025Q1')
            period: Fallback period to return if month is not found in any quarter

        Returns:
            Quarterly period string that contains the given month

        Examples:
            utils.get_quarter_of_month('2025M03')
            '2025Q1'

            utils.get_quarter_of_month('2025Q2')  # Already a quarter
            '2025Q2'

            utils.get_quarter_of_month('2023M07')  # Not in cache
            '2025Q1'  # Falls back to current period
        """
        if "Q" in month:
            return month
        else:
            for quarter, months in self.quarters_and_months.items():
                if month in months:
                    return quarter
        return period

    def rng_from_prd_str(self, std_prd_str: str, fmt: str = 'epoch', period_type: str = 'Q') -> Tuple[
        Optional[Union[int, float, str]], Optional[Union[int, float, str]]]:
        """Get period range boundaries from a standard period string.

        Translates standard period strings like 'THIS_Q', 'NEXT_W', 'last30', etc. into
        concrete period boundaries. Returns the beginning and end of the specified period
        in the requested format with caching for performance optimization.

        Args:
            std_prd_str: Period string identifier (e.g., 'THIS_Q', 'NEXT_M', 'last30')
                        or a direct period mnemonic like '2024Q1'
            fmt: Output format for timestamps:
                - 'epoch': milliseconds since epoch (default)
                - 'xldate': Excel-compatible date format
                - 'string': formatted date string 'YYYY-MM-DD'
            period_type: Period type for mnemonic validation ('Q', 'M', 'CM', 'Y')
            user_level: Whether this is a user-level request (unused)

        Returns:
            Tuple of (begin, end) timestamps in the requested format.
            Either value may be None for open-ended ranges.

        Examples:
            ```python
            # Get current quarter range as epoch timestamps
            begin_ms, end_ms = period_utils.rng_from_prd_str('THIS_Q')

            # Get next 30 days as formatted date strings
            start_date, end_date = period_utils.rng_from_prd_str('next30', fmt='string')

            # Get specific quarter range
            q1_begin, q1_end = period_utils.rng_from_prd_str('2024Q1')
            ```
        """

        today = self.get_now()
        try:
            return self.PRD_STR_CACHE[self.tenant_utils.tenant, std_prd_str, fmt]
        except KeyError:
            if self.is_valid_mnemonic(std_prd_str, period_type):
                prd_details = self.period_details_by_mnemonic(std_prd_str, period_type)
                from_epoch, til_epoch = (TenantDateTime.epoch(self.tenant_utils.timezone, prd_details.begin),
                                         TenantDateTime.epoch(self.tenant_utils.timezone, prd_details.end))
            elif std_prd_str == 'thisq' or std_prd_str == 'THIS_Q':
                cp = self.current_period()
                from_epoch, til_epoch = (TenantDateTime.epoch(self.tenant_utils.timezone, cp.begin),
                                         TenantDateTime.epoch(self.tenant_utils.timezone, cp.end))
            elif std_prd_str == 'SELECTED_Q':
                slctd_prd_begin = self.tenant_utils.get_tenant_flag('selected_period', 'slctd_prd_begin', {})
                slctd_prd_end = self.tenant_utils.get_tenant_flag('selected_period', 'slctd_prd_end', {})
                from_epoch, til_epoch = (TenantDateTime.epoch(self.tenant_utils.timezone, slctd_prd_begin),
                                         TenantDateTime.epoch(self.tenant_utils.timezone, slctd_prd_end))
            elif std_prd_str == 'SELECTED_NEXT':
                slctd_prd_next_q_start = self.tenant_utils.get_tenant_flag('selected_period', 'slctd_prd_next_q_start', 0)
                from_epoch, til_epoch = TenantDateTime.epoch(self.tenant_utils.timezone, slctd_prd_next_q_start), None
            elif std_prd_str == 'ALL':
                self.PRD_STR_CACHE[self.tenant_utils.tenant, std_prd_str, fmt] = (None, None)
                return (None, None)
            elif std_prd_str == 'NEXT_Q':
                nxt = self.next_period()
                from_epoch, til_epoch = (TenantDateTime.epoch(self.tenant_utils.timezone, nxt.begin),
                                         TenantDateTime.epoch(self.tenant_utils.timezone, nxt.end))
            elif std_prd_str == 'THIS_M':
                from_epoch, til_epoch = self.get_bom(today), self.get_eom(today)
            elif std_prd_str == 'NEXT_M':
                diff = relativedelta(months=1)
                from_epoch, til_epoch = self.get_bom(today) + diff, self.get_eom(self.get_eom(today) + diff)

            elif std_prd_str == 'THIS_W':
                current_p = self.current_period().mnemonic
                weekly_periods_info = self.get_weekly_periods_info_in_quarter(current_p, today)

                for week_info in weekly_periods_info.values():
                    if week_info['relative_period'] == 'c':
                        from_epoch, til_epoch = (
                            TenantDateTime.epoch(self.tenant_utils.timezone, week_info['begin']),
                            TenantDateTime.epoch(self.tenant_utils.timezone, week_info['end'])
                        )
                        break

            elif std_prd_str == 'NEXT_W':
                diff = relativedelta(weeks=1)
                current_p = self.current_period().mnemonic
                weekly_periods_info = self.get_weekly_periods_info_in_quarter(current_p, today)

                for week_info in weekly_periods_info.values():
                    if week_info['relative_period'] == 'c':
                        from_epoch, til_epoch = (TenantDateTime.epoch(self.tenant_utils.timezone, week_info['begin']) + diff,
                                                 TenantDateTime.epoch(self.tenant_utils.timezone, week_info['end']) + diff)
                        break

            elif std_prd_str == 'next180':
                from_epoch, til_epoch = (TenantDateTime.epoch(self.tenant_utils.timezone),
                                         TenantDateTime.epoch(self.tenant_utils.timezone) + relativedelta(days=180))
            elif std_prd_str == 'last90':
                from_epoch, til_epoch = (TenantDateTime.epoch(self.tenant_utils.timezone) - relativedelta(days=90),
                                         TenantDateTime.epoch(self.tenant_utils.timezone))
            elif std_prd_str == 'next90':
                from_epoch, til_epoch = (TenantDateTime.epoch(self.tenant_utils.timezone),
                                         TenantDateTime.epoch(self.tenant_utils.timezone) + relativedelta(days=90))
            elif std_prd_str == 'last30':
                from_epoch, til_epoch = (TenantDateTime.epoch(self.tenant_utils.timezone) - relativedelta(days=30),
                                         TenantDateTime.epoch(self.tenant_utils.timezone))
            elif std_prd_str == 'next30':
                from_epoch, til_epoch = (TenantDateTime.epoch(self.tenant_utils.timezone),
                                         TenantDateTime.epoch(self.tenant_utils.timezone) + relativedelta(days=30))
            elif std_prd_str == 'last7':
                from_epoch, til_epoch = (TenantDateTime.epoch(self.tenant_utils.timezone) - relativedelta(days=7),
                                         TenantDateTime.epoch(self.tenant_utils.timezone))
            elif std_prd_str == 'next7':
                from_epoch, til_epoch = (TenantDateTime.epoch(self.tenant_utils.timezone),
                                         TenantDateTime.epoch(self.tenant_utils.timezone) + relativedelta(days=7))
            elif std_prd_str == 'more_than_30':
                from_epoch, til_epoch = (TenantDateTime.epoch(self.tenant_utils.timezone) + relativedelta(days=30),
                                         None)
            elif std_prd_str == 'more_than_last_90':
                from_epoch, til_epoch = (None,
                                         TenantDateTime.epoch(self.tenant_utils.timezone) - relativedelta(days=90))
            elif std_prd_str == 'from_today':
                from_epoch, til_epoch = (TenantDateTime.epoch(self.tenant_utils.timezone),
                                         None)
            elif std_prd_str == 'PAST':
                yest_now = TenantDateTime.epoch(self.tenant_utils.timezone, today.as_datetime() - timedelta(days=1))
                yesterdays_value = self.get_eod(yest_now)
                if fmt == "xldate":
                    yesterdays_value = yesterdays_value.as_xldate()
                elif fmt == 'epoch':
                    yesterdays_value = yesterdays_value.as_epoch()
                elif fmt == 'string':
                    yesterdays_value = yesterdays_value.as_datetime().strftime("%Y-%m-%d")
                past_tuple = (None, yesterdays_value)
                self.PRD_STR_CACHE[self.tenant_utils.tenant, std_prd_str, fmt] = past_tuple
                return past_tuple

            elif std_prd_str == 'DYNAMIC_WEEK':
                cur_week_days = ['Sunday', 'Monday', 'Tuesday']
                dt = today.as_datetime()
                day_of_week = dt.strftime("%A")
                target_week_status = ['f']
                if day_of_week in cur_week_days:
                    target_week_status.append('c')

                current_p = self.current_period().mnemonic
                quarter_week_range = self.weekly_periods(current_p)
                now_dt = today.as_datetime()
                begin_timestamps = []

                for week_range in quarter_week_range:
                    week_info = self.render_period(week_range, now_dt)
                    if week_info['relative_period'] in target_week_status:
                        begin_timestamps.append(week_info['begin'])

                from_epoch = TenantDateTime.epoch(self.tenant_utils.timezone, min(begin_timestamps))
                til_epoch = None

            else:
                self.PRD_STR_CACHE[self.tenant_utils.tenant, std_prd_str, fmt] = (None, None)
                return (None, None)

            if fmt == 'epoch':
                ret_val = (from_epoch.as_epoch() if from_epoch else None,
                           til_epoch.as_epoch() if til_epoch else None)
            elif fmt == 'xldate':
                ret_val = (from_epoch.as_xldate() if from_epoch else None,
                           til_epoch.as_xldate() if til_epoch else None)
            elif fmt == 'string':
                ret_val = (from_epoch.as_datetime().strftime("%Y-%m-%d") if from_epoch else None,
                           til_epoch.as_datetime().strftime("%Y-%m-%d") if til_epoch else None)
            if std_prd_str in ['SELECTED_Q', 'SELECTED_NEXT']:
                return ret_val
            self.PRD_STR_CACHE[self.tenant_utils.tenant, std_prd_str, fmt] = ret_val
            return ret_val

    def get_eod(self, ep: TenantDateTime) -> TenantDateTime:
        """Get end of day from a TenantDateTime instance.

        Calculates the last moment of the day containing the input timestamp,
        with proper daylight saving time handling and timezone preservation.

        Args:
            ep: TenantDateTime instance to find end of day for

        Returns:
            TenantDateTime representing the last moment of the day (23:59:59.000)
            in the same timezone as the input

        Examples:
            ```python
            now = period_utils.get_now()
            eod = period_utils.get_eod(now)
            str(eod)  # '2024-05-15 23:59:59.000000-04:00'
            ```

        Note:
            Handles daylight saving time transitions correctly by removing and
            re-applying timezone information with DST detection.
        """
        epdt = ep.as_datetime()
        eod = epdt.replace(hour=23, minute=59, second=59, microsecond=0)
        tzinfo = eod.tzinfo
        eod = eod.replace(tzinfo=None)
        eod = tzinfo.localize(eod, is_dst=tzinfo.dst(eod))
        return TenantDateTime.epoch(self.tenant_utils.timezone, eod)

    def is_valid_mnemonic(self, mnemonic: str, period_type: str = 'Q') -> bool:
        """Validate if a string is a properly formatted period mnemonic.

        Checks whether a string follows the correct format pattern for different
        period types based on regular expression matching.

        Args:
            mnemonic: The string to validate as a period mnemonic
            period_type: Type of period to validate against:
                - 'Q': Quarterly (format: '2024Q1')
                - 'M': Monthly with M prefix (format: '2024M01')
                - 'CM': Calendar Month (format: '202401')
                - 'Y': Year (format: '2024')

        Returns:
            True if the string matches the expected format, False otherwise

        Examples:
            ```python
            # Validate quarterly mnemonic
            period_utils.is_valid_mnemonic('2024Q1', 'Q')  # True
            period_utils.is_valid_mnemonic('2024Q5', 'Q')  # False

            # Validate monthly mnemonic
            period_utils.is_valid_mnemonic('2024M03', 'M')  # True
            ```
        """
        if period_type == 'Q':
            regex = "^\d{4}Q[1-4]$"
        elif period_type == 'M':
            regex = "^\d{4}M[0,1]\d$"
        elif period_type == 'CM':
            regex = "^\d{4}[0,1]\d$"
        else:
            regex = "^\d{4}$"
        return True if re.match(regex, mnemonic) else False

    def get_bom(self, ep: TenantDateTime) -> TenantDateTime:
        """Get beginning of month from a TenantDateTime instance.

        Calculates the first moment of the month containing the input timestamp,
        with proper daylight saving time handling and timezone preservation.

        Args:
            ep: TenantDateTime instance to find beginning of month for

        Returns:
            TenantDateTime representing the first moment of the month (00:00:00.000)
            in the same timezone as the input

        Examples:
            ```python
            import pytz
            tz = pytz.timezone('America/New_York')
            dt = TenantDateTime(tz, 1615478400000)  # 2021-03-11 00:00:00 UTC
            bom = period_utils.get_bom(dt)
            str(bom)  # Beginning of March 2021
            # '2021-03-01 00:00:00.000000-05:00'
            ```

        Note:
            Handles daylight saving time transitions correctly by removing and
            re-applying timezone information with DST detection.
        """
        bom = ep.as_datetime().replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        # Applying Daylight savings
        tzinfo = bom.tzinfo
        bom = bom.replace(tzinfo=None)
        bom = tzinfo.localize(bom, is_dst=tzinfo.dst(bom))
        return TenantDateTime.epoch(self.tenant_utils.timezone, bom.replace(hour=0, minute=0, second=0, microsecond=0))

    def get_weekly_periods_info_in_quarter(self, q_mnemonic: str, today_epoch: TenantDateTime) -> Dict[
        str, Dict[str, Any]]:  # Tested
        """Get weekly period information for all weeks in a quarter.

        Computes detailed information about each weekly period within a specified quarter,
        including begin/end timestamps, forecast availability, and relative positioning.

        Args:
            q_mnemonic: Quarter mnemonic (e.g., '2024Q2')
            today_epoch: Reference TenantDateTime representing current time

        Returns:
            Dictionary mapping weekly period mnemonics to their details:
            - 'begin': Epoch milliseconds for period start
            - 'end': Epoch milliseconds for period end
            - 'has_forecast': Boolean indicating if forecast data is available
            - 'relative_period': 'c' (current), 'f' (future), or 'h' (historical)

        Examples:
            ```python
            # Get weekly periods info for current quarter
            now = period_utils.get_now()
            current_q = period_utils.current_period(now.as_datetime()).mnemonic
            weekly_info = period_utils.get_weekly_periods_info_in_quarter(current_q, now)

            # Access details for a specific week
            week_data = weekly_info['202403W01']
            ```
        """
        quarter_week_range = self.weekly_periods(q_mnemonic)
        now_dt = today_epoch.as_datetime()

        weekly_period_info = {
            week_range.mnemonic: self.render_period(week_range, now_dt)
            for week_range in quarter_week_range
        }

        return weekly_period_info

    def weekly_periods(self, q_prd, period_type='Q'):  # Tested
        """Get all weekly periods within a specified quarterly period.

        Retrieves a list of weekly periods that fall completely within a quarter or year.
        Takes either a period tuple or a string mnemonic as input and returns the
        constituent weekly periods.

        Args:
            q_prd: Either a PeriodTuple or a string mnemonic (e.g., '2024Q1')
            period_type: Type of the containing period ('Q' for quarter, 'Y' for year)

        Returns:
            List[PeriodTuple]: Weekly periods within the specified period

        Notes:
            - Weekly period mnemonics have format YYYYMM(W)WW
            - Week numbering follows these rules:
              1. First Monday of quarter is week 2 if first day isn't Monday
              2. Days after last Sunday of quarter belong to the last week
              3. Week numbering resets every quarter

        Examples:
            ```python
            # Get weeks in Q1 2024 using string mnemonic
            q1_weeks = period_utils.weekly_periods('2024Q1')

            # Get weeks in Q2 2024 using period tuple
            q2_tuple = period_utils.period_details_by_mnemonic('2024Q2')
            q2_weeks = period_utils.weekly_periods(q2_tuple)
            ```
        """
        if isinstance(q_prd, str):
            q_prd = self.period_details_by_mnemonic(q_prd, period_type)
        return self.period_range(q_prd.begin, q_prd.end, period_type='W')

    def period_range(self,
                     a_datetime_begin: Optional[datetime.datetime] = None,
                     a_datetime_end: Optional[datetime.datetime] = None,
                     period_type: str = 'W') -> List[PeriodTuple]:  # Tested
        """Get all periods that fall completely within a datetime range.

        A convenience wrapper around period_details_range.

        Args:
            a_datetime_begin: Start of the datetime range
            a_datetime_end: End of the datetime range
            period_type: Type of periods to retrieve ('Y', 'Q', 'M', 'W')

        Returns:
            List of PeriodTuple objects that fall within the specified range

        Raises:
            Exception: If either datetime bound is None or no matching periods found
        """
        return self.period_details_range(a_datetime_begin, a_datetime_end, period_type)

    def period_details_range(self,
                             a_datetime_begin: Optional[datetime.datetime] = None,
                             a_datetime_end: Optional[datetime.datetime] = None,
                             period_type: str = 'W') -> List[PeriodTuple]:  # Tested
        """Get all periods that fall completely within a datetime range.

        Retrieves periods of the specified type where the entire period falls
        within the given datetime range.

        Args:
            a_datetime_begin: Start of the datetime range
            a_datetime_end: End of the datetime range
            period_type: Type of periods to retrieve ('Y', 'Q', 'M', 'W')

        Returns:
            List of PeriodTuple objects that fall within the specified range

        Raises:
            Exception: If either datetime bound is None
            Exception: If no matching periods found
        """
        if a_datetime_begin is None or a_datetime_end is None:
            raise Exception("Given range is open ended")

        all_periods = self.get_all_periods(period_type)
        periods = []
        for idx, time_span in enumerate(all_periods):
            if a_datetime_begin <= time_span[1] and time_span[2] <= a_datetime_end:
                periods.append(all_periods[idx])
        if not periods:
            raise Exception("Given time doesn't fall into any known time span")
        return periods

    def render_period(self, period_tuple, now_dt):  # Tested
        """Render period with metadata for API responses.

        Creates a dictionary representation of a period with timing information,
        relative position, and forecast availability status.

        Args:
            period_tuple: PeriodTuple containing mnemonic, begin and end dates
            now_dt: Reference datetime for relative period calculation

        Returns:
            dict: Period details containing:
                - begin: Epoch milliseconds for period start
                - end: Epoch milliseconds for period end
                - relative_period: 'c' (current), 'f' (future), or 'h' (historical)
                - has_forecast: Boolean indicating if forecast data is available
        """
        rel_prd = self.relative_period(now_dt, period_tuple.begin, period_tuple.end)

        return {'begin': TenantDateTime.epoch(self.tenant_utils.timezone, period_tuple.begin).as_epoch(),
                'end': TenantDateTime.epoch(self.tenant_utils.timezone, period_tuple.end).as_epoch(),
                'relative_period': rel_prd,
                'has_forecast': self.period_has_forecast(period_tuple.mnemonic, rel_prd == 'f')}


    def period_has_forecast(self, period: str, future_period: Optional[bool] = None) -> bool:
        """Determine if a period has forecast data available.

        Checks whether forecast data should be available for a given period based on
        period type, forecast settings, and whether it's a future period.

        Args:
            period: The period mnemonic to check (e.g., '2024Q2', '202405', '20240501W1')
            future_period: Optional boolean indicating if this is a future period.
                If None, it will be determined based on the current time.

        Returns:
            Boolean indicating whether forecast data should be available for the period.

        Note:
            - Weekly periods ('W') only have forecasts for non-future periods
            - Quarterly periods ('Q') always have forecasts
            - Monthly periods have forecasts when monthly_predictions is enabled and
              they're not future periods
        """
        # Weekly periods only have forecasts for non-future periods
        if 'W' in period:
            return not future_period

        # If future_period wasn't provided, determine it based on current time
        if future_period is None:
            prd_begin, prd_end = [TenantDateTime.epoch(self.tenant_utils.timezone, x)
                                  for x in self.period_rng_from_mnem(period)]
            now = self.get_now()
            future_period = self.relative_period(now, prd_begin, prd_end) == 'f'

        # Return True for quarterly periods or for monthly periods with monthly_predictions enabled
        # that aren't future periods and aren't yearly periods (len(period) != 4)
        return 'Q' in period or (self.period_config.monthly_predictions and
                                 not future_period and
                                 len(period) != 4)

    def prev_periods_allowed_in_deals(self):  # Tested
        prev_periods = []
        for i in range(0, 1):
            # Add the yearly period mnemonic
            year_mnemonic = self.prev_period(period_type='Y', skip=i).mnemonic
            prev_periods.append(year_mnemonic)

            # Add 4 quarterly period mnemonics
            for j in range(0, 4):
                qtr_mnemonic = self.prev_period(period_type='Q', skip=j + (4 * i)).mnemonic
                if qtr_mnemonic not in prev_periods:
                    prev_periods.append(qtr_mnemonic)

        return prev_periods

    def get_period_boundaries(self, period):
        backwards = 24
        forwards = 24

        prev_periods = [[self.component_periods(self.get_prevq_mnem_safe(period, skip=x + 1))] for x in range(backwards)]
        curr_periods = [self.component_periods(period)]
        next_periods = [[self.component_periods(self.get_nextq_mnem_safe(period, skip=x + 1))] for x in range(forwards)]

        period_boundaries = []
        for period in flatten_to_list(prev_periods + curr_periods + next_periods):
            beg, end = self.period_rng_from_mnem(period)
            period_boundaries.append((TenantDateTime.epoch(self.tenant_utils.timezone, beg).as_xldate(),
                                      TenantDateTime.epoch(self.tenant_utils.timezone, end).as_xldate(), period))

        return sorted(period_boundaries, key=lambda x: x[0])

    def get_prevq_mnem_safe(self, mnem, skip=1):
        """
        get prev quarter mnemonic from current quarter mnemonic
        """
        all_prds = self.get_all_periods('Y') if len(mnem) == 4 else self.get_all_periods('Q')
        for (curr_q, _curr_beg, _curr_end), (prev_q, _prev_beg, _prev_end) in zip(all_prds[::-1],
                                                                                   all_prds[::-1][skip:]):
            if curr_q == mnem:
                return prev_q
        return ''

    def get_period_boundaries_weekly(self, period):
        """
        get period boundaries for periods surrounding given period

        Arguments:
            period {str} -- period mnemonic                                          '2020Q2'

        Returns:
            list -- [(prd beg ts, prd end ts, prd mnem)] sorted by prd beg ts
        """

        backwards = 24
        forwards = 24

        prev_periods = [[self.get_prevq_mnem_safe(period, skip=x + 1)] for x in range(backwards)]
        curr_periods = [period]
        next_periods = [[self.get_nextq_mnem_safe(period, skip=x + 1)] for x in range(forwards)]

        period_boundaries = []

        for period in flatten_to_list(prev_periods + curr_periods + next_periods):
            beg, end = self.period_rng_from_mnem(period)
            weekly_periods = self.period_details_range(TenantDateTime.epoch(self.tenant_utils.timezone, beg).as_datetime(), TenantDateTime.epoch(self.tenant_utils.timezone, end).as_datetime())

            for weekly_period in weekly_periods:
                period_boundaries.append((TenantDateTime.epoch(self.tenant_utils.timezone,weekly_period.begin).as_xldate(),
                                          TenantDateTime.epoch(self.tenant_utils.timezone, weekly_period.end).as_xldate(),
                                          weekly_period.mnemonic))

        return sorted(period_boundaries, key=lambda x: x[0])

    def get_period_and_component_periods(self,
                                         period,
                                         config=None):
        """
        get period and its component periods

        Arguments:
            period {str} -- period mnemonic                                          '2020Q2'

        Keyword Arguments:
            config {PeriodsConfig} -- instance of PeriodsConfig                      ...?

        Returns:
            tuple -- (period, [close periods])
        """
        if len(period) == 4:
            if self.period_config.monthly_fm:
                return period, [mnemonic for (mnemonic, _, _) in self.monthly_periods(period, 'Y')]
            else:
                return period, list(
                    set([self.current_period(begin).mnemonic for (mnemonic, begin, _) in self.monthly_periods(period, 'Y')]))

        if not self.period_config.monthly_fm or period[-2] != 'Q':
            return period, [period]

        return period, [mnemonic for (mnemonic, _, _) in self.monthly_periods(period)]

    def get_periods_editable(self, future_qtr_editable=1, past_qtr_editable=0):
        """
        get_periods_editable in app

        Arguments:
            config {PeriodsConfig} -- instance of PeriodsConfig                      ...?

        Returns:
            set -- {period mnemonics}
        """
        now_dt = self.get_now().as_datetime()
        required_periods = {self.current_period(now_dt)[0]}
        if past_qtr_editable:
            required_periods |= {self.prev_period(now_dt, skip=i + 1)[0] for i in range(past_qtr_editable)}
        required_periods |= {self.next_period(now_dt, skip=i + 1)[0] for i in range(future_qtr_editable)}
        return required_periods
