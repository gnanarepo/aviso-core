"""DateTime utilities for Aviso SDK - modernized and optimized.

This module provides timezone-aware datetime handling with conversions between
various formats commonly used in business and data analytics applications.

Key features:
- TenantDateTime: Main class for timezone-aware datetime operations
- Seamless conversion between Unix timestamps, Excel dates, and datetime objects
- Support for arithmetic operations with time durations
- Proper handling of daylight saving time transitions

The EpochClass name is maintained as an alias for backward compatibility.
"""

import datetime
import time
import re
from datetime import timedelta
from typing import Any, Optional, Union

import pytz
from dateutil.relativedelta import relativedelta

# Constants
# Excel dates are days since December 30, 1899
EXCEL_BASE = datetime.datetime(1899, 12, 30, 0, 0, 0)
# Unix epoch is January 1, 1970 UTC
EPOCH_BASE = datetime.datetime(1970, 1, 1, tzinfo=pytz.utc)


class TenantDateTime:
    """Timezone-aware datetime wrapper optimized for business analytics.

    This class provides seamless conversion between various datetime formats
    commonly used in data processing: Unix timestamps, Excel dates, and
    timezone-aware datetime objects. All operations maintain timezone integrity.

    Args:
        timezone: pytz timezone object for datetime display and calculations
        timestamp: Unix timestamp in seconds (defaults to current time)

    Examples:
    ```python
        import pytz
        tz = pytz.timezone('America/New_York')
        dt = TenantDateTime(tz, 1609459200)
        # 2021-01-01 00:00:00 UTC
        str(dt)
        '2020-12-31 19:00:00-05:00'
    ```

    Note:
        Internal storage uses Unix timestamps for precision and performance.
        Display and calculations respect the specified timezone.
    """

    def __init__(self, timezone: pytz.BaseTzInfo, timestamp: Optional[float] = None):
        """Initialize TenantDateTime.

        Args:
            timezone: pytz timezone object for datetime display and operations
            timestamp: Unix timestamp in seconds (defaults to current time)
        """
        self.timezone = timezone

        if timestamp is None:
            timestamp = time.time()
        self.timestamp = timestamp

    def __str__(self) -> str:
        """String representation showing datetime in specified timezone."""
        return str(self.as_datetime())

    __repr__ = __str__

    def as_datetime(self) -> datetime.datetime:
        """Convert to timezone-aware datetime object.

        Returns:
            datetime.datetime: A timezone-aware datetime in the instance's timezone
        """
        return datetime.datetime.fromtimestamp(self.timestamp, self.timezone)

    def as_xldate(self) -> float:
        """Convert to Excel serial date format.

        Excel represents dates as the number of days since December 30, 1899,
        with fractional parts representing time within the day. This format
        is widely used in business applications and data interchange.

        Returns:
            float: Excel-compatible serial date number

        Note:
            Conversion is performed in UTC to ensure consistency across timezones.
            Microseconds are truncated to match Excel's precision limitations.

        Examples:
        ```python
            dt = TenantDateTime(pytz.utc, 1609459200)  # 2021-01-01 00:00:00 UTC
            dt.as_xldate()
            44197.0
        ```
        """
        dt = self.as_datetime().astimezone(pytz.utc)
        excel_dt = datetime.datetime(
            dt.year, dt.month, dt.day, dt.hour, dt.minute, dt.second, dt.microsecond
        )
        delta = excel_dt - EXCEL_BASE
        return delta.days + (float(delta.seconds) / (3600 * 24))

    def as_tenant_xl_int(self) -> int:
        """Convert to tenant Excel date as integer (useful for holidays).

        Returns Excel date as integer using the tenant's timezone (not UTC).
        This format is particularly useful when working with holiday calendars
        which are typically defined as integer Excel dates.

        Note:
            Unlike as_xldate() which converts to UTC first, this method preserves
            the tenant timezone context. This difference is intentional for
            compatibility with holiday calendars that expect dates in local timezone.

        Returns:
            int: Excel date integer in current timezone
        """
        dt = self.as_datetime()
        excel_dt = datetime.datetime(
            dt.year, dt.month, dt.day, dt.hour, dt.minute, dt.second, dt.microsecond
        )
        delta = excel_dt - EXCEL_BASE
        return delta.days

    def as_pytime(self) -> float:
        """Get raw timestamp (seconds since epoch).

        Returns:
            float: Unix timestamp (seconds since epoch)

        Examples:
        ```python
            import time
            now = time.time()
            tz = pytz.timezone('America/Los_Angeles')
            dt = TenantDateTime(tz, now)
            dt.as_pytime() == now
            True
        ```
        """
        return self.timestamp

    def as_epoch(self) -> int:
        """Get epoch timestamp in milliseconds.

        Returns:
            int: Milliseconds since epoch (Unix timestamp * 1000)

        Examples:
        ```python
            dt = TenantDateTime(pytz.utc, 1609459200.0)  # 2021-01-01 00:00:00 UTC
            dt.as_epoch()
            1609459200000
        ```
        """
        return int(self.timestamp * 1000)

    def __eq__(self, other) -> bool:
        """Check equality with another datetime object.

        Args:
            other: Object to compare with. Can be a TenantDateTime,
                  int (epoch milliseconds), or timezone-aware datetime.

        Returns:
            bool: True if objects represent the same moment in time

        Raises:
            Exception: If comparing with a datetime without timezone info
        """
        if isinstance(other, TenantDateTime):
            return self.timestamp == other.timestamp
        elif isinstance(other, int):
            return self.as_epoch() == other
        elif isinstance(other, datetime.datetime):
            if not other.tzinfo:
                raise Exception("Comparison to datetime without tzinfo not allowed")
            return self.as_datetime() == other
        return False

    def __ne__(self, other) -> bool:
        """Check inequality with another datetime object.

        Args:
            other: Object to compare with

        Returns:
            bool: True if objects represent different moments in time
        """
        return not self.__eq__(other)

    def __lt__(self, other) -> bool:
        """Check if this datetime is less than (earlier than) another.

        Args:
            other: Object to compare with. Can be a TenantDateTime,
                  int (epoch milliseconds), or timezone-aware datetime.

        Returns:
            bool: True if this datetime is earlier

        Raises:
            Exception: If comparing with a datetime without timezone info
        """
        if isinstance(other, TenantDateTime):
            return self.timestamp < other.timestamp
        elif isinstance(other, int):
            return self.as_epoch() < other
        elif isinstance(other, datetime.datetime):
            if not other.tzinfo:
                raise Exception("Comparison to datetime without tzinfo not allowed")
            return self.as_datetime() < other
        return False

    def __le__(self, other) -> bool:
        """Check if this datetime is less than or equal to another.

        Args:
            other: Object to compare with. Can be a TenantDateTime,
                  int (epoch milliseconds), or timezone-aware datetime.

        Returns:
            bool: True if this datetime is earlier or equal

        Raises:
            Exception: If comparing with a datetime without timezone info
        """
        if isinstance(other, TenantDateTime):
            return self.timestamp <= other.timestamp
        elif isinstance(other, int):
            return self.as_epoch() <= other
        elif isinstance(other, datetime.datetime):
            if not other.tzinfo:
                raise Exception("Comparison to datetime without tzinfo not allowed")
            return self.as_datetime() <= other
        return False

    def __gt__(self, other) -> bool:
        """Check if this datetime is greater than (later than) another.

        Args:
            other: Object to compare with. Can be a TenantDateTime,
                  int (epoch milliseconds), or timezone-aware datetime.

        Returns:
            bool: True if this datetime is later

        Raises:
            Exception: If comparing with a datetime without timezone info
        """
        if isinstance(other, TenantDateTime):
            return self.timestamp > other.timestamp
        elif isinstance(other, int):
            return self.as_epoch() > other
        elif isinstance(other, datetime.datetime):
            if not other.tzinfo:
                raise Exception("Comparison to datetime without tzinfo not allowed")
            return self.as_datetime() > other
        return False

    def __ge__(self, other) -> bool:
        """Check if this datetime is greater than or equal to another.

        Args:
            other: Object to compare with. Can be a TenantDateTime,
                  int (epoch milliseconds), or timezone-aware datetime.

        Returns:
            bool: True if this datetime is later or equal

        Raises:
            Exception: If comparing with a datetime without timezone info
        """
        if isinstance(other, TenantDateTime):
            return self.timestamp >= other.timestamp
        elif isinstance(other, int):
            return self.as_epoch() >= other
        elif isinstance(other, datetime.datetime):
            if not other.tzinfo:
                raise Exception("Comparison to datetime without tzinfo not allowed")
            return self.as_datetime() >= other
        return False

    def __add__(self, other) -> 'TenantDateTime':
        """Add time duration to this datetime.

        Args:
            other: Duration to add. Can be:
                - int: milliseconds to add
                - timedelta: Python timedelta object
                - relativedelta: dateutil relativedelta for month/year arithmetic

        Returns:
            TenantDateTime: New instance with added duration

        Raises:
            Exception: If other is an unsupported type

        Note:
            relativedelta operations handle daylight saving time transitions
            by preserving the local time when possible.
        """
        if isinstance(other, int):
            return TenantDateTime(self.timezone, self.timestamp + other / 1000.0)
        elif isinstance(other, timedelta):
            return TenantDateTime(self.timezone, self.timestamp + other.total_seconds())
        elif isinstance(other, relativedelta):
            current_dt = self.as_datetime()
            new_datetime = current_dt + other
            time_delta = new_datetime - current_dt

            # Handle daylight saving time transitions
            whole_days_seconds = time_delta.days * 86400
            seconds = time_delta.seconds
            microseconds = time_delta.microseconds

            # Create intermediate result to check for DST shifts
            intermediate = TenantDateTime(self.timezone, self.timestamp + whole_days_seconds)

            # Calculate hour difference due to DST changes
            hour_diff = (intermediate.as_datetime().hour - current_dt.hour) % 24
            if hour_diff > 12:
                hour_diff = hour_diff - 24

            # Apply the full calculation with DST correction
            total_seconds_adjustment = (
                    whole_days_seconds + seconds + microseconds / 1000000.0 - hour_diff * 3600
            )
            return TenantDateTime(self.timezone, self.timestamp + total_seconds_adjustment)
        else:
            raise Exception(
                f"Unsupported type {type(other).__name__}. "
                "TenantDateTime supports int, timedelta, and relativedelta"
            )

    def __sub__(self, other) -> Union['TenantDateTime', timedelta]:
        """Subtract time duration or another datetime from this datetime.

        Args:
            other: Object to subtract. Can be:
                - int: milliseconds to subtract
                - timedelta: Python timedelta object
                - TenantDateTime: another datetime (returns duration between them)
                - relativedelta: dateutil relativedelta for month/year arithmetic

        Returns:
            TenantDateTime: New instance with subtracted duration (for int, timedelta, relativedelta)
            timedelta: Duration between datetimes (for TenantDateTime)

        Raises:
            Exception: If other is an unsupported type
        """
        if isinstance(other, int):
            return TenantDateTime(self.timezone, self.timestamp - other / 1000.0)
        elif isinstance(other, timedelta):
            return TenantDateTime(self.timezone, self.timestamp - other.total_seconds())
        elif isinstance(other, TenantDateTime):
            return timedelta(seconds=self.timestamp - other.timestamp)
        elif isinstance(other, relativedelta):
            current_dt = self.as_datetime()
            new_datetime = current_dt - other
            time_delta = new_datetime - current_dt

            # Handle daylight saving time transitions
            whole_days_seconds = time_delta.days * 86400
            seconds = time_delta.seconds
            microseconds = time_delta.microseconds

            # Create intermediate result to check for DST shifts
            intermediate = TenantDateTime(self.timezone, self.timestamp + whole_days_seconds)

            # Calculate hour difference due to DST changes
            hour_diff = (intermediate.as_datetime().hour - current_dt.hour) % 24
            if hour_diff > 12:
                hour_diff = hour_diff - 24

            # Apply the full calculation with DST correction
            total_seconds_adjustment = (
                    whole_days_seconds + seconds + microseconds / 1000000.0 - hour_diff * 3600
            )
            return TenantDateTime(self.timezone, self.timestamp + total_seconds_adjustment)
        else:
            raise Exception(
                f"Unsupported type {type(other).__name__}. "
                "TenantDateTime supports int, TenantDateTime, timedelta, and relativedelta"
            )

    def __hash__(self) -> int:
        """Return hash of the timestamp for use in sets and dictionaries.

        Returns:
            int: Hash of the internal timestamp
        """
        return hash(self.timestamp)

    @classmethod
    def from_pytime(cls, timezone: pytz.BaseTzInfo, timestamp: float) -> 'TenantDateTime':
        """Create TenantDateTime from Unix timestamp.

        Args:
            timezone: pytz timezone for the new instance
            timestamp: Unix timestamp in seconds

        Returns:
            TenantDateTime: New instance
        """
        return cls(timezone, timestamp)

    @classmethod
    def from_datetime(cls, timezone: pytz.BaseTzInfo, dt: datetime.datetime) -> 'TenantDateTime':
        """Create TenantDateTime from timezone-aware datetime.

        Args:
            timezone: pytz timezone for the new instance (used for display)
            dt: Timezone-aware datetime object

        Returns:
            TenantDateTime: New instance

        Raises:
            Exception: If dt is naive (lacks timezone info)
        """
        if not dt.tzinfo:
            raise Exception("Using naive datetime is very confusing with epoch")

        utc_time = dt.astimezone(pytz.utc)
        delta = utc_time - EPOCH_BASE
        return cls(timezone, delta.total_seconds())

    @classmethod
    def from_xldate(cls, timezone: pytz.BaseTzInfo, xl_float: float, utc: bool = True) -> 'TenantDateTime':
        """Create TenantDateTime from Excel serial date.

        Args:
            timezone: pytz timezone for the new instance
            xl_float: Excel serial date (days since Dec 30, 1899)
            utc: If True, interpret Excel date as UTC; otherwise as tenant timezone

        Returns:
            TenantDateTime: New instance
        """
        days = int(xl_float)
        seconds_float = (xl_float - days) * 3600 * 24
        seconds = int(seconds_float)
        microseconds = int((seconds_float - seconds) * 1000000)

        naive_dt = EXCEL_BASE + timedelta(days, seconds, microseconds)

        if utc:
            dt = pytz.utc.localize(naive_dt)
        else:
            dt = timezone.localize(naive_dt, timezone.dst(naive_dt))

        return cls.from_datetime(timezone, dt)

    @classmethod
    def from_epoch(cls, timezone: pytz.BaseTzInfo, epoch_ms: int) -> 'TenantDateTime':
        """Create TenantDateTime from epoch milliseconds.

        Args:
            timezone: pytz timezone for the new instance
            epoch_ms: Milliseconds since epoch (Unix timestamp * 1000)

        Returns:
            TenantDateTime: New instance
        """
        return cls(timezone, float(epoch_ms) / 1000)

    @classmethod
    def from_string(cls, timezone: pytz.BaseTzInfo, date_string: str,
                    format_string: str, tz_hint: str = 'utc') -> 'TenantDateTime':
        """Create TenantDateTime from formatted string.

        Args:
            timezone: pytz timezone for the new instance
            date_string: Date string to parse
            format_string: strptime format string
            tz_hint: Timezone to interpret the string in ('utc', 'tenant', or timezone name)

        Returns:
            TenantDateTime: New instance

        Examples:
        ```python
            tz = pytz.timezone('America/New_York')
            dt = TenantDateTime.from_string(tz, '2021-01-01 15:30', '%Y-%m-%d %H:%M', 'utc')
        ```
        """
        if tz_hint == 'utc':
            tzinfo = pytz.utc
        elif tz_hint == 'tenant':
            tzinfo = timezone
        else:
            tzinfo = pytz.timezone(tz_hint)

        naive_dt = datetime.datetime.strptime(date_string, format_string)
        localized_dt = tzinfo.localize(naive_dt, is_dst=tzinfo.dst(naive_dt))
        return cls.from_datetime(timezone, localized_dt)

    @classmethod
    def epoch(
        cls,
        timezone: pytz.BaseTzInfo,
        desc: Any = "NOW",
        month: Optional[int] = None,
        day: int = 0,
        hour: int = 0,
        minute: int = 0,
        second: int = 0,
        utc: bool = True
    ) -> "TenantDateTime":
        """Factory for creating TenantDateTime from various input types.

        This versatile factory method can create TenantDateTime instances from
        multiple input formats commonly encountered in data processing workflows.

        Args:
            timezone: pytz timezone for the new instance
            desc: Input value, can be:
                - "NOW" (str): current time
                - datetime.datetime: a timezone-aware datetime
                - int: Excel date (<100000) or epoch milliseconds (>=100000)
                - float: Excel date (<100000) or seconds since epoch (>=100000)
                - int with month param: year for date construction
                - str: 14-digit timestamp (YYYYMMDDhhmmss)
            month: Month component when desc is a year (1-12)
            day: Day component when desc is a year (1-31)
            hour: Hour component when desc is a year (0-23)
            minute: Minute component when desc is a year (0-59)
            second: Second component when desc is a year (0-59)
            utc: Whether to interpret Excel dates as UTC vs tenant timezone

        Returns:
            TenantDateTime: New instance representing the specified time

        Raises:
            ValueError: If desc is None or an unrecognized string format
            Exception: If datetime lacks timezone info

        Examples:
        ```python
            tz = pytz.timezone('America/New_York')
            # Current time
            now = TenantDateTime.epoch(tz, "NOW")
            # From 14-digit string
            dt1 = TenantDateTime.epoch(tz, "20210101150000")
            # From Excel date
            dt2 = TenantDateTime.epoch(tz, 44197.0)
            # From year/month/day
            dt3 = TenantDateTime.epoch(tz, 2021, 1, 15, 14, 30, 0)
        ```
    """
        if desc is None:
            raise ValueError("Ambiguous value to epoch()")

        if isinstance(desc, str):
            if desc == "NOW":
                return cls(timezone)
            if re.fullmatch(r"\d{14}", desc):
                dt = datetime.datetime.strptime(desc, "%Y%m%d%H%M%S")
                return cls.from_datetime(timezone, timezone.localize(dt))
            raise Exception("epoch() accepts only 'NOW' or YYYYMMDDhhmmss format")

        if isinstance(desc, datetime.datetime):
            return cls.from_datetime(timezone, desc)

        if isinstance(desc, int) and month is None:
            # Distinguish between Excel date and epoch milliseconds
            if desc < 100000:
                return cls.from_xldate(timezone, desc, utc=utc)
            return cls.from_epoch(timezone, desc)

        if isinstance(desc, float):
            # Distinguish between Excel date and seconds since epoch
            if desc < 100000:
                return cls.from_xldate(timezone, desc, utc=utc)
            return cls.from_pytime(timezone, desc)

        # Fallback: treat desc as year for date construction
        dt = datetime.datetime(int(desc), month, day, hour, minute, second)
        return cls.from_datetime(timezone, timezone.localize(dt))


# Backward compatibility alias
EpochClass = TenantDateTime