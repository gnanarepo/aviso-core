import json
import time
import logging
from typing import Any, Dict, Optional, Tuple

from .tenant_utils import TenantUtils
from .datetime_utils import TenantDateTime
from .utils import tracer

class TraceUtils:
    def __init__(self, tenant_utils: "TenantUtils", redis_client=None, logger: Optional[logging.Logger] = None, cname: str = None):
        """
        Utility class for managing tenant molecule flags and traces.

        Args:
            tenant_utils (TenantUtils): Instance of TenantUtils for flag management.
            logger (Optional[logging.Logger]): Optional custom logger.
        """
        if logger:
            self.logger = logger
        else:
            self.logger = logging.getLogger(__name__)
            logging.basicConfig(level=logging.INFO)
        self.tenant_utils = tenant_utils
        self.cname = cname or "preprod"
        self.redis_client = redis_client

    def update_rtfm_flag(
        self,
        last_exec_time: Optional[int] = None,
        fastlane_sync_until: Optional[int] = None,
        chipotle_last_exec_time: Optional[int] = None,
        eoq_time: Optional[int] = None,
        period: Optional[str] = None,
        status: str = "active",
    ) -> bool:
        """Update the RTFM flag for molecule status."""
        t_fl: dict[str, Any] = self.tenant_utils.get_tenant_flag(
            "molecule_status", "rtfm", default={}
        )

        if last_exec_time:
            t_fl["last_execution_time"] = last_exec_time
            t_fl["ui_display_time"] = TenantDateTime.epoch(self.tenant_utils.timezone).as_epoch()
            self.logger.info(f"UI time updated as {t_fl['ui_display_time']}")

        if fastlane_sync_until:
            t_fl["fastlane_sync_until"] = fastlane_sync_until

        if chipotle_last_exec_time:
            t_fl["chipotle_last_execution_time"] = chipotle_last_exec_time

        if eoq_time and period:
            t_fl[f"{period}_eoq_time"] = eoq_time or {}

        t_fl["status"] = status
        self.logger.info(f"Updating the rtfm flag: {t_fl}")

        return self.tenant_utils.set_tenant_flag("molecule_status", "rtfm", t_fl)

    def check_trace(
        self,
        params: Dict[str, Any],
        trace_name: str = "chipotle_trace",
        report: str = "all_caches",
    ) -> Tuple[bool, Any]:
        """Check and update molecule trace flags for a tenant."""
        retry = 0
        caches_trace = None
        etl_time = params.get("etl_time")
        run_type = params.get("run_type", "chipotle")
        is_eoq_run = params.get("is_eoq_run", False)

        if is_eoq_run:
            return True, tracer.trace

        wait_time = self.tenant_utils.get_tenant_flag("chipotle", "wait_time_min", default=10)
        if run_type == "daily":
            wait_time = 60

        while retry <= wait_time:
            caches_trace = self.tenant_utils.get_tenant_flag("molecule", trace_name, default="finished")

            if caches_trace in ["finished", tracer.trace]:
                self.tenant_utils.set_tenant_flag("molecule", trace_name, tracer.trace)
                break

            elif trace_name == "daily_trace":
                as_of = TenantDateTime.epoch(self.tenant_utils.timezone).as_datetime()
                as_of_date = as_of.strftime("%Y-%m-%d")

                daily_run_date = self.tenant_utils.get_tenant_flag(
                    "molecule", "daily_last_execution_date", default=None
                )
                if not daily_run_date or (daily_run_date and daily_run_date < as_of_date):
                    self.tenant_utils.set_tenant_flag("molecule", "daily_last_execution_date", as_of_date)
                    self.tenant_utils.set_tenant_flag("molecule", trace_name, tracer.trace)
                    break

            elif trace_name == "snapshot_trace":
                as_of = TenantDateTime.epoch(self.tenant_utils.timezone).as_datetime()
                as_of_date = as_of.strftime("%Y-%m-%d")

                snapshot_trace_run_datetime = self.tenant_utils.get_tenant_flag(
                    "molecule", "snapshot_trace_execution_date", default=None
                )

                if snapshot_trace_run_datetime:
                    snapshot_run_date = (
                        TenantDateTime.epoch(self.tenant_utils.timezone, snapshot_trace_run_datetime)
                        .as_datetime()
                        .strftime("%Y-%m-%d")
                    )
                    if not snapshot_run_date or (snapshot_run_date and snapshot_run_date < as_of_date):
                        self.tenant_utils.set_tenant_flag(
                            "molecule",
                            "snapshot_trace_execution_date",
                            TenantDateTime.epoch(self.tenant_utils.timezone).as_epoch(),
                        )
                        self.tenant_utils.set_tenant_flag("molecule", trace_name, tracer.trace)
                        break
                else:
                    self.tenant_utils.set_tenant_flag(
                        "molecule",
                        "snapshot_trace_execution_date",
                        TenantDateTime.epoch(self.tenant_utils.timezone).as_epoch(),
                    )
                    self.tenant_utils.set_tenant_flag("molecule", trace_name, tracer.trace)
                    break

            self.logger.info(f"{report} are running by other tasks {caches_trace} waiting for 1 min")
            time.sleep(60)
            retry += 1
        else:
            self.logger.error(
                f"waited for {wait_time} min, {report} will taken care by next event, {trace_name} is {caches_trace}")
            return False, caches_trace

        return True, tracer.trace

    def update_trace(
        self,
        trace_name: str = "chipotle_trace",
        trace_id: Optional[str] = None,
        force_update: bool = False,
    ) -> None:
        """Update a tenant's molecule trace flag."""
        if force_update:
            self.tenant_utils.set_tenant_flag("molecule", trace_name, "finished")
            return

        if not trace_id:
            trace_id = tracer.trace

        current = self.tenant_utils.get_tenant_flag("molecule", trace_name, default="finished")

        if current == trace_id:
            self.tenant_utils.set_tenant_flag("molecule", trace_name, "finished")

            if trace_name == "snapshot_trace":
                self.tenant_utils.set_tenant_flag(
                    "molecule",
                    "snapshot_trace_execution_date",
                    TenantDateTime.epoch(self.tenant_utils.timezone).as_epoch(),
                )
                self.logger.info(f"Snapshot trace datetime updated for {trace_name}")

    def update_stats(
            self,
            params: dict,
            status: str = "started",
            event_type: str = "all_caches",
            etl_time: Optional[int] = None,
    ) -> None:
        """Publish ETL or cache statistics to the EventBus."""
        gbm_ctx = params.get("params", {}).get("gbm_chipotle_context", {})

        etl_time = gbm_ctx.get("etl_time")
        if not etl_time:
            self.logger.info("Stats were not published as 'etl_time' missing.")
            return

        gbm_ctx["start_time"] = etl_time
        event_trace = params["params"]["event_trace"]

        payload_data = {
            "service": self.cname,
            "stack": self.cname,
            "parent_task": "caches",
            "tenant": self.tenant_utils.tenant,
            "run_type": gbm_ctx.get("run_type", "daily"),
            "etl_time": etl_time,
            "main_id": etl_time,
            "event_type": event_type,
            "times": {"start_time": gbm_ctx["start_time"]},
            "time_taken": 0,
            "status": status,
            "trace_id": event_trace,
        }

        if status != "started":
            payload_data["time_taken"] = (time.time() * 1000 - gbm_ctx['start_time']) / 1000

        if event_type == "all_caches" and status in ["finished", "skipped", "veto"]:
            payload_data["end_time"] = time.time() * 1000

            if status in ["finished", "veto"]:
                mol_stat = self.tenant_utils.get_tenant_flag("molecule_status", "rtfm", default={})
                payload_data["UI_time"] = mol_stat.get("last_execution_time")

        if status == "failed":
            payload_data["end_time"] = time.time() * 1000

        self.logger.info(f"Publishing stats event: {payload_data}")

        try:
            event_payload = {
                "eventname": "$Stats",
                "params": payload_data
            }
            self.redis_client.lpush("$Stats", json.dumps(event_payload))
        except Exception as exc:
            self.logger.error(f"Failed to publish stats event: {exc}")
