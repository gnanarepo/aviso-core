"""Tenant utilities for Aviso SDK configuration and feature flag management.

This module provides a unified interface for retrieving tenant-specific
configurations and feature flags from the FM (Forecast Management) API.
"""
import logging
import json
import os
import pytz
from functools import cached_property
import time
import psycopg2
from copy import deepcopy
from typing import Any, Optional
from ..connector.postgres_connector import PostgresConnectionManager
from .utils import parse_value
from psycopg2.pool import ThreadedConnectionPool

DEALS_COLL = 'deals'
ADHOC_WORKER_POOL = os.environ.get('ADHOC_WORKER_POOL', 'adhoc')
TOTALS_CACHED = 'filter_totals'


class TenantUtils:
    """Utility client for tenant-specific configuration and feature flag management.

    Provides a clean interface for fetching tenant configurations and flags
    from the FM SDK HTTP endpoints.

    This class handles all tenant-scoped operations including configuration
    retrieval, feature flag checking, and timezone management.

    Examples:
    ```python
        fm_client = connect_sdk(url)  # External SDK shell
        utils = TenantUtils('my-tenant', fm_client)
        timeout = utils.get_tenant_config('api', 'timeout', 30)
        feature_enabled = utils.get_tenant_flag('features', 'new_ui', False)
    ```
    """
    
    def __init__(self, tenant: str, 
                 fm_client: Any = None, 
                 pg_connection: Optional[psycopg2.extensions.connection] = None,
                 pg_pool: Optional[ThreadedConnectionPool] = None,
                 logger = None) -> None:
        """
        Initialize TenantUtils with tenant ID, FM client, and Postgres connection or pool.

        Args:
            tenant: Tenant identifier string for API calls
            fm_client: FM client shell from SDKConnection.connect_sdk()
            pg_connection: Single psycopg2 connection
            pg_pool: ThreadedConnectionPool instance
        """
        if logger:
            self.logger = logger
        else:
            self.logger = logging.getLogger(__name__)
            logging.basicConfig(level=logging.INFO)

        if  fm_client is None and pg_connection is None and pg_pool is None:
            raise ValueError(f"TenantUtils requires either an FM client, Postgres connection, or Postgres pool.  Tenant: {tenant}")
        
        # Initialize PostgresConnectionManager
        if pg_pool:
            if not PostgresConnectionManager.is_initialized():
                PostgresConnectionManager.initialize(pool=pg_pool)
        elif pg_connection:
            if not PostgresConnectionManager.is_initialized():
                PostgresConnectionManager.initialize(connection=pg_connection)        
        
        self._fm = fm_client
        self.tenant = tenant
        # Fetch tenant_id only if not already fetched
        self.tenant_id = self._get_or_fetch_tenant_id()
        
        
    def _get_or_fetch_tenant_id(self) -> int:
        """
        Returns the class-level tenant_id if already fetched.
        Otherwise, fetches it from Postgres and stores it at the class level.
        """
        if PostgresConnectionManager.is_initialized():
            tenant_id = self._fetch_tenant_id_from_db()
            TenantUtils._tenant_id = tenant_id
            return tenant_id
        
        return None


    def _fetch_tenant_id_from_db(self) -> int:
        """
        Fetch the tenant ID from Postgres using the tenant_name.
        Raises ValueError if tenant is not found.
        """
        
        query = "SELECT _id FROM tenant_view WHERE name = %s LIMIT 1"
        with PostgresConnectionManager.get_cursor() as cursor:
            cursor.execute(query, (self.tenant,))
            row = cursor.fetchone()
            if not row:
                raise ValueError(f"Tenant not found: {self.tenant}")
            return row[0]

    def get_tenant_config(
            self,
            category: str,
            config_name: str,
            default: Optional[Any] = None,
    ) -> Any:
        """Fetch a tenant configuration value from FM API.

        Hits the endpoint: /tenant/{tenant}/config/{category}/{config_name}

        Args:
            category: Configuration category name
            config_name: Specific configuration key
            default: Value to return if the API returns None

        Returns:
            The value returned by the FM API or postgres, or `default` if None

        Examples:
        ```python
            utils.get_tenant_config('api', 'timeout', 30)
            60
            utils.get_tenant_config('missing', 'key', 'fallback')
            'fallback'
        ```
        """
        if PostgresConnectionManager.is_initialized():
            t_id = self.tenant_id
            if not t_id:
                raise ValueError(f"Invalid tenant ID: {self.tenant}")
            
            query = """
                SELECT * FROM tenant_configs
                WHERE tenant_id = %s AND category = %s AND config_name = %s
            """
            
            with PostgresConnectionManager.get_cursor() as cursor:
                cursor.execute(query, (t_id, category, config_name))
                row = cursor.fetchall()
                return parse_value(row[0][4]) if row else default
            
        else:
            url = f"/tenant/{self.tenant}/config/{category}/{config_name}"
            try:
                result = self._fm.api(url, None)
            except Exception:
                result = None

            return default if result is None else result

    def get_tenant_flag(
            self,
            category: str,
            config_name: str,
            default: Optional[Any] = None,
    ) -> Any:
        """Fetch a tenant flag value from FM API.

        Hits the endpoint: /tenant/{tenant}/flag/{category}/{config_name}

        Args:
            category: Flag category name
            config_name: Specific flag key
            default: Value to return if the API returns None

        Returns:
            The value returned by the FM API or postgres, or `default` if None

        Examples:
        ```python
            utils.get_tenant_flag('features', 'new_ui', False)
            True
            utils.get_tenant_flag('beta', 'experimental', False)
            False
        ```
        """
        if PostgresConnectionManager.is_initialized():
            t_id = self.tenant_id
            if not t_id:
                raise ValueError(f"Invalid tenant ID: {self.tenant}")
            
            query = """
                SELECT * FROM tenant_flags
                WHERE tenant_id = %s AND category = %s AND config_name = %s
            """
            
            with PostgresConnectionManager.get_cursor() as cursor:
                cursor.execute(query, (t_id, category, config_name))
                row = cursor.fetchall()
                return parse_value(row[0][4]) if row else default
            
        else:
            url = f"/tenant/{self.tenant}/flag/{category}/{config_name}"
            try:
                result = self._fm.api(url, None)
            except Exception:
                result = None

            if result is None or (isinstance(result, dict) and "_error" in result):
                return default

            if isinstance(result, dict):
                if "value" in result:
                    return result["value"]
                if "config" in result:
                    return result["config"]

            return result

    @cached_property
    def timezone(self) -> pytz.BaseTzInfo:
        """Get the tenant's timezone, cached after first access.

        Retrieves the timezone from tenant configuration once and caches it
        for subsequent access. Defaults to 'US/Pacific' if not configured.

        Returns:
            pytz timezone object for the tenant

        Examples:
        ```python
            utils.timezone
            <DstTzInfo 'America/New_York' EST-1 day, 19:00:00 STD>
            utils.timezone.zone
            'America/New_York'
        ```
        """
        tz_name = self.get_tenant_config('forecast', 'timezone', "US/Pacific")
        return pytz.timezone(tz_name)

    def _set_timestamp(self,period, timestamp):
        self.set_tenant_flag(DEALS_COLL, '{}_update_date'.format(period), timestamp)

    def _set_expiration_flags(self,period, timestamp):
        try:
            self.set_tenant_flag('deal_svc', '{}_dlf_expiration_timestamp'.format(period), timestamp)
            self.set_tenant_flag('deal_svc', '{}_deal_expiration_timestamp'.format(period), timestamp)
        except Exception as e:
            self.logger.error(f"An Exception Ocuured {e}")

    def set_tenant_flag(self, category: str, config_name: str, value):
        
        """Set or update a tenant flag value in PostgreSQL.

        Updates the flag value for the specified tenant, category, and config name
        in the `tenant_flags` table.

        Args:
            category: The flag category name.
            config_name: The specific flag key to update.
            value: The value to set for the flag.

        Returns:
            True if the update succeeds, False otherwise.
            
        Raises:
            ValueError: If the category is invalid or if no PostgreSQL connection is initialized.

        Examples:
        ```python
            utils.set_tenant_flag('features', 'new_ui', True)
            True
            utils.set_tenant_flag('beta', 'experimental', {'enabled': False})
            True
        ```
        """
        
        if PostgresConnectionManager.is_initialized():
            try:
                value = json.dumps(value)
                t_id = self.tenant_id
                if not t_id:
                    raise ValueError(f"Invalid tenant: {self.tenant}")

                current_time = int(time.time() * 1000)  # For last_modified_time (ms)
                kind = 'domainmodel.tenant.TenantFlag'
                version = 1

                upsert_query = """
                    INSERT INTO tenant_flags (tenant_id, category, config_name, value, last_modified_time, _kind, _version)
                    VALUES (%s, %s, %s, %s, %s, %s, %s)
                    ON CONFLICT (tenant_id, category, config_name)
                    DO UPDATE SET 
                        value = EXCLUDED.value,
                        last_modified_time = EXCLUDED.last_modified_time,
                        _kind = EXCLUDED._kind,
                        _version = EXCLUDED._version;
                """

                with PostgresConnectionManager.get_cursor() as cursor:
                    
                    cursor.execute(
                        upsert_query,
                        (t_id, category, config_name, value, current_time, kind, version)
                    )                   
                
                return True
            except Exception as e:
                print(f"Error in set_tenant_flag: {e}")
                return False
        else:
            raise ValueError(f"set_tenant_flag requires  Postgres connection.")

    def set_tenant_config(self, category: str, config_name: str, value):
        
        """Set or update a tenant configuration value in PostgreSQL.

        Updates the configuration value for the specified tenant, category,
        and config name in the `tenant_configs` table.

        Args:
            category: Configuration category name (only 'micro_app' is supported).
            config_name: Specific configuration key to update.
            value: The configuration value to set.

        Returns:
            True if the update succeeds, False otherwise.

        Raises:
            ValueError: If the category is invalid or if no PostgreSQL connection is initialized.

        Examples:
        ```python
            utils.set_tenant_config('micro_app', 'refresh_interval', 300)
            True
            utils.set_tenant_config('micro_app', 'theme', {'mode': 'dark'})
            True
        ```
        """

        if PostgresConnectionManager.is_initialized():
            try:

                if category != 'micro_app' and category != 'security' and category != 'status':
                    raise ValueError(f"Invalid category: {category}")
                
                value = json.dumps(value)
                t_id = self.tenant_id
                if not t_id:
                    raise ValueError(f"Invalid tenant: {self.tenant}")

                current_time = int(time.time() * 1000)  # For last_modified_time (ms)
                kind = 'domainmodel.tenant.TenantConfig'
                version = 1

                upsert_query = """
                    INSERT INTO tenant_configs (tenant_id, category, config_name, value, last_modified_time, _kind, _version)
                    VALUES (%s, %s, %s, %s, %s, %s, %s)
                    ON CONFLICT (tenant_id, category, config_name)
                    DO UPDATE SET 
                        value = EXCLUDED.value,
                        last_modified_time = EXCLUDED.last_modified_time,
                        _kind = EXCLUDED._kind,
                        _version = EXCLUDED._version;
                """

                with PostgresConnectionManager.get_cursor() as cursor:
                    cursor.execute(upsert_query, (t_id, category, config_name, value, current_time, kind, version))
                
                return True
            except Exception as e:
                print(f"Error in set_tenant_flag: {e}")
                return False
        else:
            raise ValueError(f"set_tenant_config requires  Postgres connection.")

    def update_config(self, config_name: str, update_dict):
        
        """Update an existing tenant configuration for the 'micro_app' category.

        Fetches the current configuration, applies the updates from `update_dict`,
        and saves the updated configuration back to PostgreSQL.

        Args:
            config_name: The specific configuration key to update.
            update_dict: A dictionary containing the updates to apply.

        Returns:
            True if the configuration update succeeds, False otherwise.

        Examples:
        ```python
            utils.update_config('refresh_interval', {'interval': 600})
            True
            utils.update_config('theme', {'mode': 'dark'})
            True
        ```
        """

        
        category = 'micro_app'
        data = self.get_tenant_config(category, config_name, default=None)
        new_config = deepcopy(data)
        new_config.update(update_dict)
        return self.set_tenant_config(category='micro_app',config_name = config_name, value=new_config)
