from .utils import get_nested, inrange, try_float, try_index
from .datetime_utils import TenantDateTime
from .tenant_utils import TenantUtils
from .period_utils import PeriodUtils

NEGATION_MAP = {'$gt': '$lte', '$gte': '$lt', '$lte': '$gt', '$lt': '$gte'}

class Filter:
    """Filter class to handle different types of filters for deals.

    This class provides methods to create and apply various filters on deal data.
    Filters can be applied in raw format or converted to MongoDB query format.
    """
    def __init__(self, tenant_utils: TenantUtils, period_utils: PeriodUtils):
        self.tenant_utils = tenant_utils
        self.period_utils = period_utils
        self.OP_MAP = {'in': self._in_filter,
                  'nested_in': self._nested_in_filter,
                  'bool': self._bool_filter,
                  'has': self._has_filter,
                  'range': self._range_filter,
                  'favs': self._favs_filter,
                  'dlf': self._dlf_filter,
                  'dlf_range': self._dlf_range_filter,
                  'in_fcst': self._dlf_filter,  # NOTE: for backwards compatibility
                  'mismatch': self._mismatch_filter,
                  'dateIn': self._date_in_filter,
                  "dateInRange": self._date_in_range_filter,
                  'range_match': self._range_match_filter,
                  'range_func': self._range_func_filter,
                  'nested_in_range': self._nested_in_range_filter,
                  'search': self._search_filter}

    def _in_filter(self, fltr, filter_type):
        key = fltr.get('key')
        value = fltr.get('val')
        negate = fltr.get('negate', False)

        if filter_type == 'mongo':
            mongo_op = '$in' if not negate else '$nin'
            return {key: {mongo_op: value}}

        # sometimes possible that given key does not exist. On safer side check that 1st.
        if not negate:
            return lambda deal, favs, dlf: False if deal.get(key) is None else deal.get(key) in value

        return lambda deal, favs, dlf: False if deal.get(key) is None else deal.get(key) not in value


    def _nested_in_filter(self, fltr, filter_type):
        key = fltr.get('key')
        value = fltr.get('val')
        negate = fltr.get('negate', False)

        if filter_type == 'mongo':
            mongo_op = '$in' if not negate else '$nin'
            return {'.'.join(key): {mongo_op: value}}

        if not negate:
            return lambda deal, favs, dlf: get_nested(deal, key) in value

        return lambda deal, favs, dlf: get_nested(deal, key) not in value


    def _bool_filter(self, fltr, filter_type):
        key = fltr.get('key')
        negate = fltr.get('negate', False)

        if filter_type == 'mongo':
            mongo_op = '$eq' if not negate else '$ne'
            return {key: {mongo_op: True}}

        if not negate:
            return lambda deal, favs, dlf: bool(deal.get(key))

        return lambda deal, favs, dlf: not bool(deal.get(key))


    def _has_filter(self, fltr, filter_type):
        key = fltr.get('key')
        negate = fltr.get('negate', False)

        if filter_type == 'mongo':
            mongo_bool = True if not negate else False
            return {key: {'$exists': mongo_bool}}

        if not negate:
            return lambda deal, favs, dlf: deal.get(key) is not None

        return lambda deal, favs, dlf: key not in deal


    def _range_filter(self, fltr, filter_type):
        key = fltr.get('key')
        value = fltr.get('val')
        negate = fltr.get('negate', False)

        if filter_type == 'mongo':
            query = {}
            if value[0] is not None:
                great_op = '$gt' if try_index(value, 2) else '$gte'
                great_op = great_op if not negate else NEGATION_MAP[great_op]
                query[great_op] = value[0]
            if value[1] is not None:
                less_op = '$lt' if try_index(value, 3) else '$lte'
                less_op = less_op if not negate else NEGATION_MAP[less_op]
                query[less_op] = value[1]
            return {key: query}

        valuetuple = tuple(value)
        if not negate:
            return lambda deal, favs, dlf: inrange(try_float(deal.get(key)), valuetuple)

        return lambda deal, favs, dlf: not inrange(try_float(deal.get(key)), valuetuple)


    def _favs_filter(self, fltr, filter_type):
        key = fltr.get('key')
        negate = fltr.get('negate', False)
        is_pivot_special = fltr.get('is_pivot_special', False)

        if filter_type == 'mongo':
            mongo_op = '$in' if not negate else '$nin'
            favs_key = 'opp_id' if not is_pivot_special else 'RPM_ID'
            return {favs_key: {mongo_op: '%(favs)s'}}

        if not negate:
            return lambda deal, favs, dlf: favs is not None and deal.get(key) in favs

        return lambda deal, favs, dlf: favs is not None and deal.get(key) not in favs

    def _search_filter(self, fltr, filter_type):
        key = fltr.get('key')
        values = fltr.get('val')
        negate = fltr.get('negate', False)
        if filter_type == 'mongo':
            if negate:
                query = {"$nor": [{key: {"$regex": val, "$options": "i"}} for val in values]}
            else:
                query = {"$or": [{key : {"$regex" : val , "$options" : "i"}} for val in values]}
            return query
        return {}

    def _dlf_range_filter(self, fltr, filter_type):
        key = fltr.get('key')
        node = fltr.get('node')
        value_key = fltr.get('val')
        value = fltr.get('match_vals')
        negate = fltr.get('negate', False)
        if filter_type == 'mongo':
            dlf_cat, dlf_key = value_key.split(".")
            if node is not None:
                mongo_key = "dlf.%s.%s.%s" % (dlf_cat, node, dlf_key)
            else:
                mongo_key = "dlf.{}.%(node)s.{}".format(dlf_cat, dlf_key)
            query = {}
            if value[0] is not None:
                great_op = '$gt' if try_index(value, 2) else '$gte'
                great_op = great_op if not negate else NEGATION_MAP[great_op]
                query[great_op] = value[0]
            if value[1] is not None:
                less_op = '$lt' if try_index(value, 3) else '$lte'
                less_op = less_op if not negate else NEGATION_MAP[less_op]
                query[less_op] = value[1]
            return {mongo_key: query}

        valuetuple = tuple(value)
        if not negate:
            return lambda deal, favs, dlf: inrange(try_float(deal.get(key)), valuetuple)

        return lambda deal, favs, dlf: not inrange(try_float(deal.get(key)), valuetuple)

    def _dlf_filter(self, fltr, filter_type):
        key = fltr.get('key')
        value = fltr.get('val')
        negate = fltr.get('negate', False)
        node = fltr.get('node')
        ignore = fltr.get('ignore_above')
        match_vals = fltr.get('match_vals')
        match_vals = match_vals if match_vals else [True]

        if filter_type == 'mongo':
            mongo_op = '$in' if not negate else '$nin'
            if node is not None:
                return {'dlf.{}.{}.state'.format(value, node): {mongo_op: match_vals}}
            else:
                return {'dlf.{}.%(node)s.state'.format(value): {mongo_op: match_vals}}

        if not negate:
            return lambda deal, favs, dlf: (dlf is not None and
                                            dlf.get_latest_oride(deal.get(key), value, deal,
                                                                 node=node, ignore_above=ignore).state in match_vals)
        return lambda deal, favs, dlf: (dlf is not None and
                                        dlf.get_latest_oride(deal.get(key), value, deal,
                                                             node=node, ignore_above=ignore).state not in match_vals)


    def _mismatch_filter(self, fltr, filter_type):
        key = fltr.get('key')
        value = fltr.get('val')
        negate = fltr.get('negate', False)
        node = fltr.get('node')
        ignore = fltr.get('ignore_above')

        if filter_type == 'mongo':
            mongo_op = '$in' if not negate else '$nin'
            if isinstance(value, (list, tuple)):
                if node is not None:
                    return {"$or": [{'dlf.{}.{}.info'.format(val, node): {mongo_op: ['M']}} for val in value]}
                else:
                    return {"$or": [{'dlf.{}.%(node)s.info'.format(val): {mongo_op: ['M']}} for val in value]}
            else:
                if node is not None:
                    return {'dlf.{}.{}.info'.format(value, node): {mongo_op: ['M']}}
                else:
                    return {'dlf.{}.%(node)s.info'.format(value): {mongo_op: ['M']}}

        if not negate:
            return lambda deal, favs, dlf: (dlf is not None and
                                            dlf.get_latest_oride(deal.get(key), value, deal,
                                                                 node=node, ignore_above=ignore).info == 'M')

        return lambda deal, favs, dlf: (dlf is not None and
                                        dlf.get_latest_oride(deal.get(key), value, deal,
                                                             node=node, ignore_above=ignore).info != 'M')


    def _date_in_range_filter(self, fltr,
                              filter_type):
        key = fltr.get('key')
        if fltr.get("range"):
            value_ = fltr.get('range')
        else:
            value_ = fltr.get('val')
        value = [TenantDateTime.epoch(self.tenant_utils.timezone, value_[0]).as_xldate(),
                 TenantDateTime.epoch(self.tenant_utils.timezone, value_[1]).as_xldate()]
        negate = fltr.get('negate', False)

        if filter_type == 'mongo':
            query = {}
            if value[0] is not None:
                great_op = '$gt' if try_index(value, 2) else '$gte'
                great_op = great_op if not negate else NEGATION_MAP[great_op]
                query[great_op] = value[0]
            if value[1] is not None:
                less_op = '$lt' if try_index(value, 3) else '$lte'
                less_op = less_op if not negate else NEGATION_MAP[less_op]
                query[less_op] = value[1]
            return {key: query}

    def _date_in_filter(self, fltr, filter_type):
        key = fltr.get('key')
        value = fltr.get('val')
        negate = fltr.get('negate', False)
        filter_format = fltr.get('type', 'xldate')
        # if filter_type == 'mongo':
        custom_filter = {}
        if 'CUSTOM' in value:
            custom_filter = self._date_in_range_filter(fltr, filter_type)
            if len(value) == 1:
                return custom_filter
            index = value.index('CUSTOM')
            value.pop(index)
        option_values = ['ALL'] if 'ALL' in value else value
        range_tuples = [tuple(self.period_utils.rng_from_prd_str(prd, filter_format)) for prd in option_values]
        if filter_type == 'mongo':
            first_iteration = True
            query = {}
            for r_tuple in range_tuples:
                rquery = {}
                if r_tuple[0] is not None:
                    great_op = '$gt' if try_index(r_tuple, 2) else '$gte'
                    great_op = great_op if not negate else NEGATION_MAP[great_op]
                    rquery[great_op] = r_tuple[0]
                if r_tuple[1] is not None:
                    less_op = '$lt' if try_index(r_tuple, 3) else '$lte'
                    less_op = less_op if not negate else NEGATION_MAP[less_op]
                    rquery[less_op] = r_tuple[1]
                if rquery:
                    if first_iteration:
                        query["$or"] = []
                        first_iteration = False
                    query["$or"].append({key: rquery})
            if custom_filter:
                query["$or"].append(custom_filter)
            return query
        # range_tuples = [tuple(rng_from_prd_str(prd, 'xldate')) for prd in value]   --> Commented this code as usage is not there.
        # if not negate:
        #     return lambda deal, favs, dlf: any(inrange(deal.get(key), range_tuple)
        #                                        for range_tuple in range_tuples)
        #
        # return lambda deal, favs, dlf: not any(inrange(deal.get(key), range_tuple)
        #                                        for range_tuple in range_tuples)

        return {}


    def _range_match_filter(self, fltr, filter_type):
        key = fltr.get('key')
        value = fltr.get('val')
        rng = fltr.get('rng')
        negate = fltr.get('negate', False)

        if filter_type == 'mongo':
            return {}  # TODO: implement me

        if isinstance(rng, list):
            beg, end = rng
            if not negate:
                return lambda deal, favs, dlf: deal.get(key, [])[beg:end] == value
            return lambda deal, favs, dlf: deal.get(key, [])[beg:end] != value

        if not negate:
            return lambda deal, favs, dlf: try_index(deal.get(key, []), rng) == value
        return lambda deal, favs, dlf: try_index(deal.get(key, []), rng) != value


    def _range_func_filter(self, fltr, filter_type):
        key = fltr.get('key')
        # value = fltr.get('val')
        # rng = fltr.get('rng')
        negate = fltr.get('negate', False)

        comparator_map = {
            '<': '$lt',
            '<=': '$lte',
            '>': '$gt',
            '>=': '$gte',
        }
        import copy
        if len(fltr['val'])>0:
            temp = []
            for val in fltr['val']:
                temp_filter = {}
                temp_filter['val'] = [val]
                temp_filter['key'] = fltr['key']
                temp_filter['op'] = fltr['op']
                temp.append(temp_filter)
            fltr = copy.deepcopy(temp)

        if filter_type == 'mongo':
            queries=[]
            for i in range(len(fltr)):
                query = {}
                key_filter = {}
                if fltr[i]['val'] is not None:
                    value = fltr[i]['val']
                    if isinstance(value[0], str):
                        if value[0][0] in comparator_map:
                            if '=' in value[0]:
                                op = comparator_map[value[0][0]+'=']
                                num = value[0][2:]
                            else:
                                op = comparator_map[value[0][0]]
                                num = value[0][1:]
                            op = op if not negate else NEGATION_MAP[op]
                            key_filter[op] = float(num)/100
                    elif isinstance(value[0], list):
                        great_op = "$gte"
                        key_filter[great_op] = float(value[0][0])/100
                        less_op = "$lt"
                        key_filter[less_op] = float(value[0][1])/100
                query[key] = key_filter
                queries.append(query)

            if len(queries)>1:
                return {'$or': queries}
            else:
                return queries[0]

            # return {key:queries}  # TODO: implement me

        # if not negate:
        #         return lambda deal, favs, dlf: rng(deal.get(key, [False, 0, False, 0])) == value

        # return lambda deal, favs, dlf: rng(deal.get(key, [False, 0, False, 0])) != value


    def _nested_in_range_filter(self, fltr, filter_type):
        key = fltr.get('key')
        value = fltr.get('val')
        negate = fltr.get('negate', False)

        if filter_type == 'mongo':
            query = {}
            if value[0] is not None:
                great_op = '$gt' if try_index(value, 2) else '$gte'
                great_op = great_op if not negate else NEGATION_MAP[great_op]
                query[great_op] = value[0]
            if value[1] is not None:
                less_op = '$lt' if try_index(value, 3) else '$lte'
                less_op = less_op if not negate else NEGATION_MAP[less_op]
                query[less_op] = value[1]
            return {'.'.join(key): query}

        valuetuple = tuple(value)
        if not negate:
            return lambda deal, favs, dlf: inrange(try_float(get_nested(deal, key)), valuetuple)

        return lambda deal, favs, dlf: not inrange(try_float(get_nested(deal, key)), valuetuple)

    def passes_new_filter(self, deal_data, fltr_desc=None, favs_set=None, dlf_svc=None):
        """ Filter description: for example
            [{
                "key": "as_of_Amount_USD",
                "op": "range",
                "val": [500, 2000, false, true]
            }]
            To pass the filter, a deal must match the filter on the appropriate field,
            including one of its prefixes.
        """
        if not fltr_desc:
            return True

        for filt in fltr_desc:
            if "or" in filt or "and" in filt:
                result = []
                filter_desc = filt["or"] if "or" in filt else filt["and"]
                for filtnew in filter_desc:
                    filter_exp = self.OP_MAP[filtnew['op']]
                    if filter_exp is not None:
                        if not filter_exp(filtnew, 'raw')(deal_data, favs_set, dlf_svc):
                            result.append(False)
                    else:
                        result.append(True)
                if "or" in filt:
                    return True if any(result) else False
                else:
                    return True if all(result) else False
            filter_exp = self.OP_MAP[filt['op']]
            if filter_exp is not None:
                if not filter_exp(filt, 'raw')(deal_data, favs_set, dlf_svc):
                    return False
            else:
                return True

        return True