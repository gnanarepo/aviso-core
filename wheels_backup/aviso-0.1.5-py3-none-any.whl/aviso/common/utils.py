"""Common helper utilities for the Aviso SDK.

This module provides general-purpose utility functions for data processing,
safe operations, and common patterns used throughout the SDK.

Functions:
    get_nested: Safely retrieve values from nested dictionaries
    pairwise: Generate successive overlapping pairs from iterables
    try_index: Safely index into sequences with default values
    try_float: Safely convert values to float with defaults
    inrange: Check if values fall within dynamic ranges
    try_values: Safely retrieve dictionary values or return singleton
"""

import operator
import threading
import json
import requests
import base64
from itertools import tee
from typing import Any, Dict, Iterable, Iterator, List, Optional, Tuple, Union
from Crypto.Cipher import AES

# Cache for dynamic range predicates to improve performance
_range_lambdas: Dict[Tuple[Optional[float], Optional[float], bool, bool], Any] = {}
TRUE_VALUES = {'true', '1', 'yes', 'yeah', 'si',
               'youbet', 'good', 'positive'}


def get_nested(
        input_dict: Dict[str, Any],
        keys: List[str],
        default: Any = None
) -> Any:
    """Retrieve a value from a nested dict by a list of keys.

    Safely traverses a nested dictionary structure using a sequence of keys.
    Returns a default value if any key is missing or if traversal fails.

    Args:
        input_dict: The dictionary to traverse
        keys: Sequence of keys to follow in order
        default: Value to return if any key is missing or traversal fails

    Returns:
        The nested value at the specified path, or `default` if not found

    Examples:
    ```python
        data = {'a': {'b': {'c': 42}}}
        get_nested(data, ['a', 'b', 'c'])
        42
        get_nested(data, ['a', 'x', 'y'], 'not_found')
        'not_found'
        get_nested(data, [])
        {'a': {'b': {'c': 42}}}
    ```
    """
    if not keys:
        return input_dict

    try:
        current = input_dict
        for key in keys[:-1]:
            current = current.get(key, {})
        return current.get(keys[-1], default)
    except AttributeError:
        # Handle case where intermediate value is not a dict
        return default


def pairwise(iterable: Iterable[Any]) -> Iterator[Tuple[Any, Any]]:
    """Generate successive overlapping pairs from the input iterable.

    Creates an iterator that returns tuples of adjacent elements from the input.
    Useful for comparing consecutive items or detecting changes in sequences.

    Args:
        iterable: Any iterable sequence

    Yields:
        Tuples of (current_item, next_item) for each adjacent pair

    Examples:
    ```python
        list(pairwise([1, 2, 3, 4]))
        [(1, 2), (2, 3), (3, 4)]
        list(pairwise(['a', 'b', 'c']))
        [('a', 'b'), ('b', 'c')]
        list(pairwise([1]))
        []
    ```

    Note:
        Returns an empty iterator if the input has fewer than 2 elements.
    """
    a, b = tee(iterable)
    next(b, None)
    return zip(a, b)


def try_index(
        seq: Union[List[Any], Tuple[Any, ...], None],
        index: int,
        default: Any = None
) -> Any:
    """Safely index into a sequence with error handling.

    Attempts to retrieve an element at the specified index, returning a
    default value if the operation fails for any reason (out of bounds,
    None sequence, etc.).

    Args:
        seq: The sequence to index into, or None
        index: The index to retrieve
        default: Value to return if indexing fails

    Returns:
        The element at seq[index], or `default` if operation fails

    Examples:
    ```python
        try_index([1, 2, 3], 1)
        2
        try_index([1, 2, 3], 5, 'missing')
        'missing'
        try_index(None, 0, 'empty')
        'empty'
        try_index([], -1, 'default')
        'default'
    ```
    """
    try:
        return seq[index]
    except:
        return default


def try_float(
        maybe_float: Any,
        default: float = 0.0
) -> float:
    """Safely convert a value to float with error handling.

    Attempts to convert the input value to a float, returning a default
    value if the conversion fails for any reason.

    Args:
        maybe_float: Value to convert to float
        default: Default value to return if conversion fails

    Returns:
        float(maybe_float) if conversion succeeds, otherwise `default`

    Examples:
    ```python
        try_float("3.14")
        3.14
        try_float("invalid", 1.0)
        1.0
        try_float(None, -1.0)
        -1.0
        try_float(42)
        42.0
    ```
    """
    try:
        return float(maybe_float)
    except Exception:
        return default


def inrange(
        val: Any,
        bounds: Union[
            Tuple[Optional[float], Optional[float]],
            Tuple[Optional[float], Optional[float], bool],
            Tuple[Optional[float], Optional[float], bool, bool]
        ]
) -> bool:
    """Check if a value falls within a dynamic range specification.

    Supports flexible range checking with configurable inclusion/exclusion
    of bounds. Uses caching for performance optimization with repeated
    range checks.

    Range specification formats:
    - 2-tuple (low, high): Exclusive bounds (low < val < high)
    - 3-tuple (low, high, left_inc): Configurable left bound inclusion
    - 4-tuple (low, high, left_inc, right_inc): Full bound configuration

    None values for bounds indicate unbounded ranges on that side.

    Args:
        val: Value to test against the range
        bounds: Range specification tuple (2-4 elements)

    Returns:
        True if val is within the specified range, False otherwise

    Examples:
    ```python
        inrange(5, (1, 10))  # 1 < 5 < 10
        True
        inrange(1, (1, 10))  # 1 < 1 < 10
        False
        inrange(1, (1, 10, True))  # 1 ≤ 1 < 10
        True
        inrange(10, (1, 10, True, True))  # 1 ≤ 10 ≤ 10
        True
        inrange(5, (None, 10))  # unbounded left: 5 < 10
        True
        inrange("invalid", (1, 10))
        False
    ```

    Note:
        Values that cannot be converted to float return False.
        Malformed bounds specifications return False.
    """
    # Normalize bounds tuple and validate format
    try:
        if len(bounds) == 2:
            low, high = bounds
            left_inc, right_inc = False, False
        elif len(bounds) == 3:
            low, high, left_inc = bounds
            right_inc = False
        elif len(bounds) == 4:
            low, high, left_inc, right_inc = bounds  # type: ignore
        else:
            return False
    except (TypeError, ValueError, IndexError):
        return False

    # Use cached predicate for performance
    cache_key = (low, high, left_inc, right_inc)
    if cache_key not in _range_lambdas:
        # Build comparison operations based on bounds and inclusion flags
        operations = []

        if low is not None:
            op = operator.ge if left_inc else operator.gt
            operations.append((op, low))

        if high is not None:
            op = operator.le if right_inc else operator.lt
            operations.append((op, high))

        def range_predicate(x: Any) -> bool:
            """Check if x satisfies all range conditions."""
            try:
                float_x = float(x)
            except (TypeError, ValueError):
                return False

            return all(op(float_x, bound) for op, bound in operations)

        _range_lambdas[cache_key] = range_predicate

    return _range_lambdas[cache_key](val)


def try_values(
        mapping: Dict[Any, Any],
        key: Any
) -> Iterable[Any]:
    """Safely retrieve values from a dictionary field or return a singleton.

    Attempts to get the .values() from a nested dictionary at the specified key.
    If the operation fails (key doesn't exist, value isn't a dict, etc.),
    returns a singleton iterable containing the raw value.

    Args:
        mapping: Dictionary to query
        key: Key whose value should be a dictionary

    Returns:
        mapping[key].values() if mapping[key] is a dict,
        otherwise [mapping.get(key)] as a singleton iterable

    Examples:
    ```python
        data = {'nested': {'a': 1, 'b': 2}, 'simple': 'value'}
        list(try_values(data, 'nested'))
        [1, 2]
        list(try_values(data, 'simple'))
        ['value']
        list(try_values(data, 'missing'))
        [None]
        ```
    """
    try:
        return mapping[key].values()
    except:
        return [mapping.get(key, key)]

def create_nested(input_dict, attr_list):
    """Create a value from nested input dict by specifying the levels to go through and write it to output dict.

    Extracts a value from a nested dictionary structure by traversing the specified
    attribute path, then rebuilds a nested dictionary with the same structure.

    Args:
        input_dict: Source dictionary containing the nested value to extract
        attr_list: List of keys representing the path to the nested value

    Returns:
        Nested dictionary containing the value at the specified path with the
        same hierarchical structure as the original attribute path

    Examples:
    ```python
        # Input dictionary with nested structure
        deal = {'customer': {'info': {'name': 'Acme Corp', 'id': '12345'}}}

        # Extract and rebuild nested structure for 'customer.info.name'
        result = create_nested(deal, ['customer', 'info', 'name'])
        # Returns: {'customer': {'info': {'name': 'Acme Corp'}}}
    ```

    Note:
        Returns None if the attribute list is empty or if a traversal error occurs
        when accessing the nested value in the input dictionary.
    """
    if not attr_list:
        return None
    try:
        val = get_nested(input_dict, attr_list)
        dict_by_level = val
        for key in reversed(attr_list):
            dict_by_level = {key: dict_by_level}
        return dict_by_level
    except AttributeError:
        return None

def iter_chunks(my_list, batch_size=5):
    """
    Split a list into chunks of specified size.

    Args:
        my_list: List to split into chunks
        batch_size: Size of each chunk (default: 5)

    Yields:
        Chunks of the input list
    """
    start = 0
    more = True
    while more:
        end = start + batch_size
        if end < len(my_list):
            yield my_list[start:end]
            start = end
        else:
            more = False
            yield my_list[start:]

def flatten_to_list(*args, **kwargs):
    """
    takes arguments that may be strings or lists or lists of lists and returns flattened list
    ex:
    combine_to_list(1, 2, 3, [4, 5], 6, [[[7],8], 9])
    [1, 2, 3, 4, 5, 6, 7, 8, 9]
    """
    flat_list = kwargs.get('flat_list', [])
    for arg in args:
        if isinstance(arg, list):
            flatten_to_list(*arg, flat_list=flat_list)
        else:
            flat_list.append(arg)
    return flat_list

def is_true(bool_like):
    if (isinstance(bool_like, str)):
        return bool_like.lower() in TRUE_VALUES
    if bool_like:
        return True
    return False


class Tracer(object):

    def __init__(self):
        self.thread_local = None

    def get_trace(self):
        import uuid
        if not self.thread_local:
            self.thread_local = threading.local()
        try:
            return self.thread_local.trace_id
        except AttributeError:
            self.thread_local.trace_id = str(uuid.uuid4())
            return self.thread_local.trace_id

    def set_trace(self, trace):
        if not self.thread_local:
            self.thread_local = threading.local()
        if trace:
            self.thread_local.trace_id = trace
        else:
            try:
                del self.thread_local.trace_id
            except AttributeError:
                pass

    trace = property(get_trace, set_trace)


tracer = Tracer()

def create_payload(tenant_name, cname, separate_trace=None, **payload):
    """
    Creates a payload dictionary with additional context information.

    Args:
        separate_trace (bool, optional): If True, a new Tracer instance is created for the event trace.
                                          If False or None, the existing tracer instance is used.
        **payload: Additional key-value pairs to be included in the payload.

    Returns:
        dict: A dictionary containing the original payload with added context information
              such as tenant name, stack name, and event trace.
    """
    _tracer = tracer if not separate_trace else Tracer()

    payload.update({
        'tenant': tenant_name,
        'stack': cname,
        'event_trace': _tracer.trace
    })

    return payload


def parse_value(raw):
    
    """Parse a raw value from JSON string to Python object.

    If the input is a valid JSON string, it is converted to the corresponding
    Python data type (dict, list, etc.). If parsing fails or input is not a string,
    the original value is returned.

    Args:
        raw: The value to parse (usually a string).

    Returns:
        The parsed Python object if JSON decoding succeeds, else the original value.

    Examples:
    ```python
        parse_value('{"key": "value"}')
        {'key': 'value'}

        parse_value('[1, 2, 3]')
        [1, 2, 3]

        parse_value('invalid json')
        'invalid json'

        parse_value(None)
        None
    ```
    """

    if raw is None or not isinstance(raw, str):
        return raw
    try:
        return json.loads(raw)
    except Exception:
        return raw


def decode(aes_key, tenant_db_url):
    """
    Standard decode function
    """
    try:
        if tenant_db_url is not None:
            key = AES.new(
                base64.b64decode(aes_key),
                mode=AES.MODE_ECB)
            x = key.decrypt(base64.b64decode(tenant_db_url)).decode('utf-8').strip()
            return x.rstrip(' ')
        return None
    except Exception as e:
        raise e

def safe_parse(item: str):
    try:
        return json.loads(item)
    except Exception:
        return item

def trigger_databricks_job(host: str, token: str, event: dict, job_id: str):
    """
    Trigger the configured Databricks job via REST API.
    """
    url = f"{host}/api/2.1/jobs/run-now"
    headers = {"Authorization": f"Bearer {token}"}

    payload = {
        "job_id": job_id,
        "notebook_params": {
            # The Databricks notebook will receive the full event
            "event_payload": json.dumps(event)
        }
    }

    response = requests.post(url, headers=headers, json=payload)
    response.raise_for_status()

    run_id = response.json().get("run_id")
    return run_id
