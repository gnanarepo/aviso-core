"""Aviso SDK Common Utilities.

This package provides shared utility classes and functions used across
the Aviso SDK including period management, datetime handling, tenant
configuration, and data processing helpers.

Classes:
    PeriodUtils: Comprehensive period and fiscal calendar management
    TenantDateTime: Timezone-aware datetime wrapper with business logic
    TenantUtils: Tenant-specific configuration and feature flag management
    PeriodTuple: Named tuple for period data structures

Aliases:
    EpochClass: Backward compatibility alias for TenantDateTime

Examples:
    ```python
    from aviso.sdk.common import PeriodUtils, TenantUtils, TenantDateTime

    # Initialize utilities
    tenant_utils = TenantUtils('my-tenant', fm_client)
    period_utils = PeriodUtils(tenant_utils, period_config)

    # Work with periods and dates
    current_q = period_utils.current_period(period_type='Q')
    now = TenantDateTime.epoch(tenant_utils.timezone)
    ```
"""

from .period_utils import PeriodUtils, PeriodTuple
from .datetime_utils import TenantDateTime, EpochClass
from .filters import Filter
from .tenant_utils import TenantUtils
from .trace_utils import TraceUtils
from .utils import get_nested, pairwise, try_index, try_float, inrange, try_values, create_nested, iter_chunks, flatten_to_list, safe_parse

__all__ = [
    'PeriodUtils',
    'PeriodTuple',
    'TenantDateTime',
    'EpochClass',
    'TenantUtils',
    'Filter',
    'get_nested',
    'pairwise',
    'try_index',
    'try_float',
    'inrange',
    'try_values',
    'create_nested',
    'iter_chunks',
    'flatten_to_list',
    'TraceUtils',
    'safe_parse',
]