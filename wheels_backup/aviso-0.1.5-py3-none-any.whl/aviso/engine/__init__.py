"""Aviso SDK Business Logic Engines.

This package contains computational engine that implement core business logic
for various Aviso operations including forecasting, deal analysis, and data processing.

The engine are designed to be stateful processors that encapsulate complex
business rules and coordinate between configuration, data access, and utility layers.

Classes:
    DealLevelForecastEngine: Engine for computing Deal-Level Forecast (DLF) outputs

Examples:
    ```python
    from aviso.sdk.engine import DealLevelForecastEngine
    from aviso.sdk.config import DealConfig
    from aviso.sdk.common import PeriodUtils, TenantUtils

    # Initialize engine with dependencies
    engine = DealLevelForecastEngine(
        period='2025Q1',
        config_utils=deal_config,
        mongo_client=db_client,
        period_utils=period_utils,
        tenant_utils=tenant_utils
    )

    # Process deal forecasts
    deal_forecasts = engine.adorn_deal_forecasts(deal_data, ancestors)
    ```
"""

from .aes_engine import AESEngine
from .mongo_conn_engine import MongoConnEngine

__all__ = [
    'AESEngine',
    'MongoConnEngine',
]