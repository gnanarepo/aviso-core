import time
import os
import logging

class AESEngine:
    """
    Engine for retrieving and constructing AES keys for tenants.
    Uses injected MySQL and S3 managers for key parts.
    Implements caching and error handling.

    Example Usage:
    ```python
    from aviso.sdk.connector.mysql_connector import MySQLConnectionManager
    from aviso.sdk.connector.s3_connector import S3ConnectionManager
    from aviso.sdk.engine.aes_engine import AESEngine

    mysql_manager = MySQLConnectionManager()
    mysql_manager.initialize(connection=mysql_conn)
    s3_manager = S3ConnectionManager()
    s3_manager.initialize(client=s3_client)

    aes_engine = AESEngine(mysql_manager, s3_manager)
    aes_key = aes_engine.get_aes_key(tenant_name="my_tenant", stack="app")
    print(aes_key)
    ```
    """
    def __init__(self, mysql_manager=None, s3_manager=None, cache_lifetime=86400, keymanager_cache_lifetime=86400):
        self.mysql_manager = mysql_manager
        self.s3_manager = s3_manager
        self.CACHE_LIFETIME = cache_lifetime
        self.KEYMANAGER_CACHE_LIFETIME = keymanager_cache_lifetime
        self._aes_key_cache = {}
        self._aes_key_cache_expiry = {}
        self._keymanager_cache = {}
        self._keymanager_cache_expiry = {}
        self.logger = logging.getLogger(__name__)

    def get_aes_key(self, tenant_name, stack=None, aes_key=None):
        if tenant_name == 'administrative.domain':
            return None
        if aes_key:
            return aes_key
        stack_value = 'preprod' if stack is None else stack
        keyindex = f"{stack_value}~{tenant_name}"
        cache_key = f"{tenant_name}_{stack_value}"
        current_time = time.time()
        # Check AES key cache
        if (cache_key in self._aes_key_cache and
            current_time < self._aes_key_cache_expiry.get(cache_key, 0)):
            self.logger.debug(f"AES key cache hit for tenant: {tenant_name}, stack: {stack_value}")
            return self._aes_key_cache[cache_key]
        # Get key parts
        key_p1 = self._get_key_part_mysql(keyindex)
        key_p2 = self._get_key_part_s3(tenant_name, keyindex)
        aes_key_combined = key_p1 + key_p2
        # Cache result
        self._aes_key_cache[cache_key] = aes_key_combined
        self._aes_key_cache_expiry[cache_key] = current_time + self.CACHE_LIFETIME
        self.logger.debug(f"AES key cached for tenant: {tenant_name}, stack: {stack_value}")
        return aes_key_combined

    def _fetch_keymanager_aeskey_data(self):
        current_time = time.time()
        cache_key = 'keymanager_data'
        if (cache_key in self._keymanager_cache and
            current_time < self._keymanager_cache_expiry.get(cache_key, 0)):
            self.logger.debug("Keymanager data cache hit")
            return self._keymanager_cache[cache_key]
        # Fetch all keyindex/keypart pairs
        try:
            with self.mysql_manager.get_cursor() as cursor:
                cursor.execute("SELECT keyindex, keypart FROM keymanager_aeskey")
                results = cursor.fetchall()
                keymanager_data = {}
                for row in results:
                    if isinstance(row, dict):
                        keymanager_data[row['keyindex']] = row
                    else:
                        keymanager_data[row[0]] = row[1]
                self._keymanager_cache[cache_key] = keymanager_data
                self._keymanager_cache_expiry[cache_key] = current_time + self.KEYMANAGER_CACHE_LIFETIME
                self.logger.info(f"Successfully fetched and cached {len(results)} records from keymanager_aeskey table")
                return keymanager_data
        except Exception as e:
            self.logger.error(f"Failed to fetch keymanager data: {e}")
            raise

    def _get_key_part_mysql(self, keyindex):
        keymanager_data = self._fetch_keymanager_aeskey_data()
        k = keymanager_data.get(keyindex)
        if k:
            return k['keypart'] if isinstance(k, dict) else k
        else:
            raise Exception(f"Key not found for index: {keyindex}")

    def _get_key_part_s3(self, tenant_name, keyindex):
        bucket_name = os.environ.get('S3_BUCKET_NAME', 'gnana-tenants')
        key_path = f"{tenant_name}/keys/{keyindex}"
        try:
            response = self.s3_manager.get_object(bucket_name, key_path)
            key_p2 = response['Body'].read().decode('utf-8')
            return key_p2
        except Exception as ex:
            self.logger.error(f"Failed to get aes_key from S3 due to {ex}")
            raise ex

    def get_ms_aes_key(self, tenant_name: str, stack: str = "app") -> str:
        """Fetch single-part AES key from aviso_aeskey Postgres table."""
        from aviso.connector import PostgresConnectionManager
        keyindex = f"{stack}~{tenant_name}"
        cache_key = f"aviso_{tenant_name}_{stack}"
        current_time = time.time()
        if (cache_key in self._aes_key_cache and
                current_time < self._aes_key_cache_expiry.get(cache_key, 0)):
            self.logger.debug(f"Aviso AES key cache hit for tenant: {tenant_name}, stack: {stack}")
            return self._aes_key_cache[cache_key]
        try:
            with PostgresConnectionManager.get_cursor() as cursor:
                cursor.execute("SELECT keypart FROM aviso_aeskey WHERE keyindex = %s", (keyindex,))
                row = cursor.fetchone()
                if not row:
                    raise Exception(f"Key not found in aviso_aeskey for keyindex: {keyindex}")
                keypart = row['keypart'] if isinstance(row, dict) else row[0]
        except Exception as e:
            self.logger.error(f"Failed to get aviso aes_key for {keyindex}: {e}")
            raise
        self._aes_key_cache[cache_key] = keypart
        self._aes_key_cache_expiry[cache_key] = current_time + self.CACHE_LIFETIME
        self.logger.debug(f"Aviso AES key cached for tenant: {tenant_name}, stack: {stack}")
        return keypart