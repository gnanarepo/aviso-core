"""
MongoConnEngine — generic engine for fetching and decrypting a tenant's MongoDB URL.

Can be used by any service (FM, GBM, ETL, etc.) that needs a decrypted Mongo
connection string without coupling to the Databricks onboarding flow.
"""
import logging
import psycopg2
from urllib.parse import urlparse, urlencode, parse_qsl, urlunparse
from typing import Any, Optional

from aviso.connector import PostgresConnectionManager, MySQLConnectionManager, S3ConnectionManager
from aviso.engine.aes_engine import AESEngine
from aviso.common.utils import decode


class MongoConnEngine:
    """
    Fetches the encrypted MongoDB URL for a tenant from Postgres and
    decrypts it using AESEngine.

    Usage::

        engine = MongoConnEngine(
            tenant_name="acme.com",
            pg_connection=pg_conn,
            mysql_connection=mysql_conn,
            boto3_client=s3_client,
            cname="app",
        )
        url = engine.get_decrypted_mongo_url()
    """

    def __init__(
        self,
        tenant_name: str,
        pg_connection: psycopg2.extensions.connection = None,
        mysql_connection: Any = None,
        boto3_client: Any = None,
        cname: str = "app",
        logger: Any = None,
    ):
        self.tenant_name = tenant_name
        self.tenant_name_clean = tenant_name.split('.')[0]
        self.cname = cname
        self.logger = logger or logging.getLogger(__name__)

        if pg_connection:
            PostgresConnectionManager.initialize(connection=pg_connection)

        self.mysql_manager = MySQLConnectionManager()
        if mysql_connection:
            self.mysql_manager.initialize(connection=mysql_connection)

        self.s3_manager = S3ConnectionManager()
        if boto3_client:
            self.s3_manager.initialize(client=boto3_client)

    def _get_tenant_info_from_pg_db(self):
        """Fetches tenant_id and encrypted mongo url from Postgres."""
        tenant_id = None
        encrypted_url = None
        try:
            with PostgresConnectionManager.get_cursor() as cursor:
                cursor.execute(
                    "SELECT _id, tenant_db_url FROM tenant_view WHERE name = %s LIMIT 1",
                    (self.tenant_name,)
                )
                result = cursor.fetchone()
                if result:
                    tenant_id = result[0]
                    encrypted_url = result[1]
                else:
                    self.logger.error(f"Tenant {self.tenant_name} not found in tenant_view")
        except Exception as e:
            self.logger.error(f"Error querying Postgres: {e}")

        return tenant_id, encrypted_url

    def _decrypt_fm_mongo_url(self, encrypted_url: str) -> str:
        """
        Decrypt Mongo URL using AESEngine and apply required query parameters.
        """
        if not encrypted_url:
            self.logger.warning("No encrypted URL provided.")
            return ""

        if not self.mysql_manager or not self.s3_manager:
            self.logger.warning("Missing mysql_connection or boto3_client. Cannot decrypt Mongo URL.")
            return "mongodb://placeholder_decrypted_url"

        self.logger.info("Decrypting Mongo URL via AESEngine")

        try:
            aes_engine = AESEngine(mysql_manager=self.mysql_manager, s3_manager=self.s3_manager)
            aes_key = aes_engine.get_aes_key(tenant_name=self.tenant_name, stack=self.cname)
            decrypted_url_raw = decode(aes_key, encrypted_url)

            required_params = {
                "ssl": "true",
                "maxIdleTimeMS": "30000",
                "maxPoolSize": "100",
                "retryWrites": "false",
                "socketTimeoutMS": "900000"
            }

            parsed = urlparse(decrypted_url_raw)
            qs_dict = dict(parse_qsl(parsed.query))
            qs_dict.update(required_params)
            new_query = urlencode(qs_dict)

            final_url = urlunparse(
                (parsed.scheme, parsed.netloc, parsed.path, parsed.params, new_query, parsed.fragment)
            )
            return final_url

        except Exception as e:
            self.logger.error(f"Failed to decrypt mongo URL for tenant {self.tenant_name}: {e}")
            raise e

    def get_decrypted_fm_mongo_url(self) -> str:
        """
        Fetch and decrypt the Mongo URL for the tenant using FM key (keymanager_aeskey MySQL + S3).
        Returns the plaintext connection string with connection params applied.
        """
        _, encrypted_url = self._get_tenant_info_from_pg_db()
        return self._decrypt_fm_mongo_url(encrypted_url)

    def _decrypt_ms_mongo_url(self, encrypted_url: str) -> str:
        """
        Decrypt Mongo URL using AESEngine.get_aviso_aes_key() (aviso_aeskey Postgres table, single key part).
        Applies the same required connection params as the FM path.
        """
        if not encrypted_url:
            self.logger.warning("No encrypted URL provided.")
            return ""

        self.logger.info("Decrypting Mongo URL via AESEngine (aviso_aeskey)")

        try:
            aes_engine = AESEngine(mysql_manager=self.mysql_manager, s3_manager=self.s3_manager)
            aes_key = aes_engine.get_ms_aes_key(tenant_name=self.tenant_name, stack=self.cname)
            decrypted_url_raw = decode(aes_key, encrypted_url)

            # required_params = {
            #     "ssl": "true",
            #     "maxIdleTimeMS": "30000",
            #     "maxPoolSize": "100",
            #     "retryWrites": "false",
            #     "socketTimeoutMS": "900000"
            # }

            parsed = urlparse(decrypted_url_raw)
            qs_dict = dict(parse_qsl(parsed.query))
            # qs_dict.update(required_params)
            new_query = urlencode(qs_dict)

            final_url = urlunparse(
                (parsed.scheme, parsed.netloc, parsed.path, parsed.params, new_query, parsed.fragment)
            )
            return final_url

        except Exception as e:
            self.logger.error(f"Failed to decrypt aviso mongo URL for tenant {self.tenant_name}: {e}")
            raise e

    def get_decrypted_ms_mongo_url(self) -> str:
        """
        Fetch and decrypt the Mongo URL for the tenant using GBM key (aviso_aeskey Postgres table).
        Returns the plaintext connection string with connection params applied.
        """
        _, encrypted_url = self._get_tenant_info_from_pg_db()
        return self._decrypt_ms_mongo_url(encrypted_url)

    def get_replica_set_name(self) -> Optional[str]:
        """
        Fetch the replica set name for the tenant from the tenant_databases Postgres table.

        Looks up the tenant's pod_id from tenant_view (defaults to 'default'),
        then queries tenant_databases for the matching replica_set_name.
        """
        # Step 1: get pod_id for this tenant
        pod_id = None
        try:
            with PostgresConnectionManager.get_cursor() as cursor:
                cursor.execute(
                    "SELECT pod_id FROM tenant_view WHERE name = %s LIMIT 1",
                    (self.tenant_name,)
                )
                result = cursor.fetchone()
                if result:
                    pod_id = result['pod_id'] if isinstance(result, dict) else result[0]
        except Exception as e:
            self.logger.error(f"Error fetching pod_id for {self.tenant_name}: {e}")

        pod_id = pod_id or 'default'
        self.logger.info(f"Fetching replica_set_name for pod_id: {pod_id}")

        # Step 2: get replica_set_name from tenant_databases (direct columns)
        try:
            with PostgresConnectionManager.get_cursor() as cursor:
                cursor.execute(
                    "SELECT replica_set_name FROM tenant_databases WHERE pod_id = %s LIMIT 1",
                    (pod_id,)
                )
                result = cursor.fetchone()
                if result:
                    return result['replica_set_name'] if isinstance(result, dict) else result[0]
        except Exception as e:
            self.logger.error(f"Error fetching replica_set_name for pod_id {pod_id}: {e}")

        return None
