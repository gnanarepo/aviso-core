import threading

class S3ConnectionManager:
    """
    Thread-safe S3 client manager.

    Features:
        - Stores a boto3 S3 client
        - Thread-safe access
        - Context manager for object retrieval

    Example Usage:
    ```python
    import boto3
    from aviso.sdk.connector.s3_connector import S3ConnectionManager

    s3_client = boto3.client('s3', aws_access_key_id="...", aws_secret_access_key="...", region_name="...")
    S3ConnectionManager.initialize(client=s3_client)

    response = S3ConnectionManager.get_object("my-bucket", "my/key/path")
    data = response['Body'].read()

    S3ConnectionManager.close_connection()
    ```
    """
    """
    Thread-safe S3 client manager.
    Provides access to S3 client and object retrieval.
    """
    _client = None
    _lock = threading.Lock()

    @classmethod
    def initialize(cls, client=None):
        if not client:
            raise ValueError("You must provide a boto3 S3 client instance.")
        cls._client = client

    @classmethod
    def get_object(cls, bucket, key):
        if not cls._client:
            raise RuntimeError("S3 manager not initialized. Call initialize() first.")
        with cls._lock:
            return cls._client.get_object(Bucket=bucket, Key=key)

    @classmethod
    def close_connection(cls):
        cls._client = None
