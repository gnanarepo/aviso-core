from contextlib import contextmanager
from typing import Optional
import threading
import psycopg2
from psycopg2.pool import ThreadedConnectionPool, PoolError
import time

class PostgresConnectionManager:
    
    """
    Thread-safe PostgreSQL connection manager.

    This class provides a unified interface for working with PostgreSQL connections
    in Python applications. It supports both a single shared connection and a
    threaded connection pool. Cursors are provided as context managers to ensure
    automatic commit/rollback and proper cleanup.

    Features:
        - Single shared connection or ThreadedConnectionPool support
        - Thread-safe access to shared connection
        - Automatic commit on success, rollback on exceptions
        - Context manager for safe cursor usage
        - Graceful connection or pool closure

    Class Methods:
        initialize(connection=None, pool=None):
            Initialize the manager with a single connection or a connection pool.
            Must be called before using `get_cursor`.
        
        get_cursor():
            Context manager that yields a cursor. Handles commit/rollback and 
            thread safety automatically.

        close_connection():
            Close the shared connection or all connections in the pool.

    Example Usage:
    ```python
    from psycopg2 import connect
    from psycopg2.pool import ThreadedConnectionPool

    # Single connection
    conn = connect(host="localhost", dbname="mydb", user="user", password="pass", port=pg_port)
    PostgresConnectionManager.initialize(connection=conn)

    with PostgresConnectionManager.get_cursor() as cursor:
        cursor.execute("SELECT * FROM my_table")
        rows = cursor.fetchall()

    PostgresConnectionManager.close_connection()

    # Using connection pool
    pool = ThreadedConnectionPool(minconn=1, maxconn=5,
                                    host=pg_host, port=pg_port,
                                    database=pg_database,
                                    user=pg_username,
                                    password=pg_password)
    PostgresConnectionManager.initialize(pool=pool)

    with PostgresConnectionManager.get_cursor() as cursor:
        cursor.execute("SELECT * FROM my_table")
        rows = cursor.fetchall()

    PostgresConnectionManager.close_connection()
    ```
    """


    _conn: Optional[psycopg2.extensions.connection] = None
    _pool: Optional[ThreadedConnectionPool] = None
    _pool_closed: bool = True
    _lock = threading.Lock()  # For single-connection thread safety

    @classmethod
    def initialize(cls, connection: Optional[psycopg2.extensions.connection] = None,
                   pool: Optional[ThreadedConnectionPool] = None):
        """
        Initialize the manager.
        Provide either a single connection or a connection pool.
        """
        if connection is None and pool is None:
            raise ValueError("Provide either a connection or a connection pool.")

        if connection:
            cls._conn = connection
            cls._pool = None
            cls._pool_closed = True
        else:
            cls._pool = pool
            cls._conn = None
            cls._pool_closed = False
            
    @classmethod
    def is_initialized(cls) -> bool:
        """
        Check if the PostgresConnectionManager has an active connection or pool.

        Returns:
            bool: True if either a single open connection or an active pool exists.
        """
        conn_active = cls._conn is not None and not getattr(cls._conn, "closed", True)
        pool_active = cls._pool is not None and not cls._pool_closed
        return conn_active or pool_active

    @classmethod
    def _get_conn_with_timeout(cls, timeout=5):
        """Try to get a pool connection, waiting until available or timeout."""
        if cls._pool is None:
            raise RuntimeError("No connection pool initialized")

        start = time.time()
        while True:
            try:
                return cls._pool.getconn()
            except PoolError:
                if time.time() - start > timeout:
                    raise RuntimeError("No available connection in pool within timeout")
                time.sleep(0.1)  # wait 100ms before retry

    @classmethod
    @contextmanager
    def get_cursor(cls, timeout=5):
        """
        Context manager for a cursor.
        Commits on success, rolls back on exception.
        Works safely in multithreaded environments.
        """
        if cls._pool:  # Use a pooled connection
            conn =  cls._get_conn_with_timeout(timeout)
            cursor = conn.cursor()
            try:
                yield cursor
                conn.commit()
            except Exception:
                conn.rollback()
                raise
            finally:
                cursor.close()
                cls._pool.putconn(conn)

        elif cls._conn:  # Single shared connection
            with cls._lock:  # Ensure only one thread uses it at a time
                cursor = cls._conn.cursor()
                try:
                    yield cursor
                    cls._conn.commit()
                except Exception:
                    cls._conn.rollback()
                    raise
                finally:
                    cursor.close()
        else:
            raise RuntimeError("PostgreSQL manager not initialized. Call initialize() first.")

    @classmethod
    def close_connection(cls):
        """
        Close the shared connection or connection pool.
        """
        try:
            if cls._conn and not cls._conn.closed:
                cls._conn.close()
            if cls._pool and not cls._pool_closed:
                cls._pool.closeall()
                cls._pool_closed = True
        except Exception as e:
            print(f"Warning: Error closing Postgres connection: {e}")
        finally:
            cls._conn = None
            cls._pool = None

    @staticmethod
    def _set_short_timeout(conn, ms: int = 800) -> None:
        """Set a very small statement timeout for the health-check only."""
        with conn.cursor() as cur:
            # statement_timeout is in milliseconds
            cur.execute(f"SET LOCAL statement_timeout = {int(ms)}")

    @classmethod
    def _ping(cls, conn, timeout_ms: int = 800) -> bool:
        """
        Run a fast SELECT 1 to verify liveness.
        Returns True if the connection is usable, False otherwise.
        """
        try:
            if getattr(conn, "closed", True):
                return False
            cls._set_short_timeout(conn, timeout_ms)
            with conn.cursor() as cur:
                cur.execute("SELECT 1")
                cur.fetchone()
            return True
        except Exception:
            # Any failure here means the connection shouldn't be reused
            return False

    @classmethod
    def check_health(cls, timeout_ms: int = 800) -> bool:
        """
        Return True if we currently have a usable connection (single or via pool).
        - For a pool, this temporarily borrows a connection, pings it, and returns it
          (closing it if unhealthy).
        - For a single shared connection, it pings that connection.
        """
        # Pool case: borrow → ping → return/close
        if cls._pool is not None and not cls._pool_closed:
            conn = None
            try:
                conn = cls._get_conn_with_timeout(timeout=2)  # quick borrow
                ok = cls._ping(conn, timeout_ms)
                # Return the connection; close it if it's not OK
                cls._pool.putconn(conn, close=not ok)
                return ok
            except Exception:
                # If we couldn't even borrow, treat as unhealthy
                if conn is not None:
                    try:
                        cls._pool.putconn(conn, close=True)
                    except Exception:
                        pass
                return False

        # Single-connection case
        if cls._conn is not None and not getattr(cls._conn, "closed", True):
            # Use the same lock to avoid concurrent use while pinging
            with cls._lock:
                return cls._ping(cls._conn, timeout_ms)

        # Not initialized / nothing available
        return False

