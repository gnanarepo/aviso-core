from typing import Optional
from .postgres_connector import PostgresConnectionManager
from aviso.engine.aes_engine import AESEngine
from aviso.common.utils import decode

import os
import logging

class MongoConnectionManager:
    """
    Orchestrates retrieval of MongoDB connection string for a tenant.
    Uses Postgres, MySQL, and S3 managers.

    Example Usage:
    ```python
    import boto3, pymysql, psycopg2
    from aviso.sdk.connector.postgres_connector import PostgresConnectionManager
    from aviso.sdk.connector.mysql_connector import MySQLConnectionManager
    from aviso.sdk.connector.s3_connector import S3ConnectionManager
    from aviso.sdk.connector.mongo_connector import MongoConnectionManager

    pg_conn = psycopg2.connect(host="...", dbname="...", user="...", password="...", port=5432)
    PostgresConnectionManager.initialize(connection=pg_conn)

    mysql_conn = pymysql.connect(host="...", user="...", password="...", db="...")
    mysql_manager = MySQLConnectionManager()
    mysql_manager.initialize(connection=mysql_conn)

    s3_client = boto3.client('s3', aws_access_key_id="...", aws_secret_access_key="...", region_name="...")
    s3_manager = S3ConnectionManager()
    s3_manager.initialize(client=s3_client)

    mongo_manager = MongoConnectionManager(mysql_manager=mysql_manager, s3_manageer=s3_manager)
    mongo_url = mongo_manager.get_tenant_db(tenant_name="my_tenant", stack="app")
    print(mongo_url)
    ```
    """

    def __init__(self, mysql_manager=None, s3_manager=None):
        """
        Initializes MongoConnectionManager with MySQL and S3 managers, and creates AESEngine.
        """
        self.mysql_manager = mysql_manager
        self.s3_manager = s3_manager
        self.aes_engine = AESEngine(mysql_manager=self.mysql_manager, s3_manager=self.s3_manager)

    def get_tenant_db(self, tenant_name: str, stack: Optional[str] = None):
        """
        Retrieves the MongoDB connection string for a tenant using Postgres, MySQL, S3, and AESEngine.
        Falls back to environment variable if not found in DB.
        """
        logger = logging.getLogger(__name__)
        encrypted_url = None
        # 1. Query Postgres for encrypted MongoDB URL
        try:
            with PostgresConnectionManager.get_cursor() as cursor:
                cursor.execute("SELECT tenant_db_read_url FROM tenant WHERE name = %s", (tenant_name,))
                result = cursor.fetchone()
                if result:
                    encrypted_url = result[0]
                    logger.info(f"Retrieved database URL from PostgreSQL for tenant: {tenant_name}")
        except Exception as e:
            logger.error(f"Error retrieving database URL from PostgreSQL for tenant {tenant_name}: {str(e)}")
        # 2. If found, decode using AESEngine
        if encrypted_url:
            try:
                aes_key = self.aes_engine.get_aes_key(tenant_name=tenant_name, stack=stack)
                tenant_db_url = decode(aes_key, encrypted_url)
                return tenant_db_url
            except Exception as e:
                logger.error(f"Error decoding database URL for tenant {tenant_name}: {str(e)}")
        # 3. Fallback: Try to get database URL from environment variables
        env_var = f'TENANT_{tenant_name.upper()}_DB_URL'
        tenant_url = os.environ.get(env_var)
        if tenant_url:
            logger.info(f"Retrieved database URL from environment for tenant: {tenant_name}")
            return tenant_url
        # 4. No fallback to DEFAULT_MONGO_URL anymore
        logger.warning(f"No database URL found for tenant: {tenant_name}")
        return None
