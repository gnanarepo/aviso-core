from contextlib import contextmanager
from typing import Optional
import threading
import pymysql

class MySQLConnectionManager:
    """
    Thread-safe MySQL connection manager.

    Features:
        - Single shared connection support
        - Thread-safe access
        - Context manager for safe cursor usage
        - Automatic commit/rollback

    Example Usage:
    ```python
    import pymysql
    from aviso.sdk.connector.mysql_connector import MySQLConnectionManager

    conn = pymysql.connect(host="localhost", user="user", password="pass", db="mydb")
    MySQLConnectionManager.initialize(connection=conn)

    with MySQLConnectionManager.get_cursor() as cursor:
        cursor.execute("SELECT * FROM my_table")
        rows = cursor.fetchall()

    MySQLConnectionManager.close_connection()
    ```
    """
    """
    Thread-safe MySQL connection manager.
    Supports single connection or connection pool.
    Provides context-managed cursor access.
    """
    _conn: Optional[pymysql.connections.Connection] = None
    _pool: Optional[object] = None  # Placeholder for pool implementation
    _lock = threading.Lock()

    @classmethod
    def initialize(cls, connection: Optional[pymysql.connections.Connection] = None, pool: Optional[object] = None):
        if connection is None and pool is None:
            raise ValueError("Provide either a connection or a connection pool.")
        if connection:
            cls._conn = connection
            cls._pool = None
        else:
            cls._pool = pool
            cls._conn = None

    @classmethod
    @contextmanager
    def get_cursor(cls):
        if cls._conn:
            with cls._lock:
                cursor = cls._conn.cursor()
                try:
                    yield cursor
                    cls._conn.commit()
                except Exception:
                    cls._conn.rollback()
                    raise
                finally:
                    cursor.close()
        else:
            raise RuntimeError("MySQL manager not initialized. Call initialize() first.")

    @classmethod
    def close_connection(cls):
        try:
            if cls._conn:
                cls._conn.close()
        except Exception as e:
            print(f"Warning: Error closing MySQL connection: {e}")
        finally:
            cls._conn = None
            cls._pool = None
