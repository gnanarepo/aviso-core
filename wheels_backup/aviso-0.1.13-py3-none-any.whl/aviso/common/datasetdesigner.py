import copy
import json
import logging

from aviso.domainmodel.datameta import DSClass as Dataset
from aviso.utils import GnanaError
from aviso.settings import gnana_db, sec_context, gnana_db2
from aviso.utils import is_true, fileUtils
from aviso.utils.configUtils import config_pattern_expansion
from aviso.domainmodel.datameta import FileTypeTypes, ModelDescription, ALGORITHM_PARAMS

logger = logging.getLogger('gnana.%s' % __name__)

class DSHelpers(object):
    """Helper methods for dataset to wrap the older modify, add_path, delete_path .... to new functionality"""

    def __init__(self, ds):
        self.ds = ds

    def apply(self, stage, action, path, params):
        if 'changes' in self.ds.stages[stage]:
            if [action, path, json.dumps(params)] in self.ds.stages[stage]['changes']:
                raise GnanaError("This change is already added to stage")
            self.ds.stages[stage]['changes'].append(
                (action, path, json.dumps(params)))

    def save(self, sandbox=None, sandbox_comment = None):
        self.ds.save(sandbox=sandbox, sandbox_comment=sandbox_comment)

    def merge_stage(self, stage, delete_stage=False):
        """
        Return a new dataset where stage information is added into
        main area.

        if delete_stage is specified, original staging information
        is removed
        """
        if(stage not in self.ds.stages):
            return

        # Apply everything from stage into the dataset
        for k, v in self.ds.stages[stage].items():
            if k == 'comment':
                continue
            if k == 'creator':
                continue
            if k == 'changes':
                for change in v:
                    action = change[0]
                    path = change[1]
                    new_value = change[2]
                    params = json.loads(new_value)
                    self.apply_config(action, path, params)
        # Delete the stage if requested
        if(delete_stage):
            del self.ds.stages[stage]
            self.stage_used = None
        else:
            self.stage_used = stage

    def remove_module(self, module_type, module_name):
        module_map = getattr(self.ds, module_type)
        if module_name in module_map:
            del module_map[module_name]
        else:
            raise GnanaError('Conflicting Change made in dataset for %s[%s]'
                             % (module_type, module_name))

    def add_module(self, module_type, module_name, params):
        # Check the module is not added through another stage
        in_main = getattr(self.ds, module_type).get(module_name)
        if(in_main is not None):
            raise GnanaError('Conflicting Change made in dataset for %s[%s]'
                             % (module_type, module_name))

        # Add the module
        if module_type == 'file_types':
            if 'name' not in params:
                params['name'] = module_name
            else:
                if params['name'] != module_name:
                    raise GnanaError('Inconsistent Naming')
            if 'ctr_config' not in params:
                params['ctr_config'] = {}
            if 'type' not in params:
                raise GnanaError(
                    'Adding a file_type requires type to specified')
            self.ds.file_types[module_name] = FileTypeTypes[
                params['type']](self.ds, params)
        elif module_type == 'maps':
            self.ds.maps[module_name] = params
        elif module_type == 'discrepancy':
            self.ds.discrepancy[module_name] = params
        elif module_type == 'models':
            params1 = params.copy()
            # Add any missing maps
            for x in ('config', ALGORITHM_PARAMS, 'record_filter', 'field_map', 'history_filter'):
                if x not in params1:
                    params1[x] = {}
            params1['config'][ALGORITHM_PARAMS] = params1.pop(ALGORITHM_PARAMS)
            self.ds.models[module_name] = ModelDescription(**params1)

        elif module_type == 'params':
            self.ds.params[module_name] = params
        elif module_type == 'fields':
            self.ds.fields[module_name] = params
        else:
            raise GnanaError('Unknown module type %s ' % module_type)

    def check_path(self, action, path_list, path):
        valid_action_list = ['set_value', 'add_values', 'prepend_values', 'remove_values',
                             'add_path', 'remove_path']
        if action not in valid_action_list:
            raise GnanaError("Unknown action %s.Valid actions are %s" % (action,
                                                                         '[' + ', '.join(valid_action_list) + ']'))
        existing_dataset_value = self.ds.get_as_map()
        path_len = len(path_list)
        path_str = "existing_dataset_value"
        if action == "set_value" and path == "all":
            return path_str
        if action in ["add_path", "add_values", "remove_path", "prepend_values"]:
            if path == "all" or path_len < 2:
                raise GnanaError(
                    "Sorry. %s doesnot support this %s path" % (action, path))
        if action == "remove_values":
            if path == "all":
                raise GnanaError(
                    "Sorry.remove_values doesnot support this %s path" % path)
        if action == "add_path":
            path_last_item = path_list[-1]
            path_list = path_list[:-1]
        for i in path_list:
            if i in eval(path_str):
                path_str += "['" + i + "']"
            else:
                raise GnanaError(
                    "%s key is missing.Path %s doesnot exist" % (i, path))
        if action == "add_path":
            if path_last_item in eval(path_str):
                raise GnanaError("Path %s already exists" % path)
        return path_str

    def apply_config(self, action, path, new_value):
        path_list = path.split(".")
        path_len = len(path_list)
        existing_dataset_value = self.ds.get_as_map()
        if 'stages' in existing_dataset_value:
            existing_dataset_value.pop("stages")
        if isinstance(new_value, dict) and 'stages' in new_value:
            new_value.pop("stages")
        path_str = "existing_dataset_value"
        if action == "set_value":
            if path_len == 1:
                if path_list[0] == "all":
                    module_name = None
                    module_type = None
                    for module_type, value1 in existing_dataset_value.items():
                        if isinstance(value1, dict):
                            for module_name in value1.keys():
                                self.remove_module(module_type, module_name)
                    # creating the modules with the given values
                    for module_type, value1 in new_value.items():
                        if isinstance(value1, dict):
                            for module_name, module_value in value1.items():
                                self.add_module(
                                    module_type, module_name, module_value)
                else:
                    module_type = path_list[0]
                    if module_type in existing_dataset_value.keys():
                        module_type_value = existing_dataset_value[module_type]
                        for module_name in module_type_value.keys():
                            self.remove_module(module_type, module_name)
                        for module_name in new_value.keys():
                            self.add_module(
                                module_type, module_name, new_value[module_name])
                    else:
                        raise GnanaError("Path %s doesnot exist" % path)
            else:
                if path_len == 2:
                    module_type = path_list[0]
                    module_name = path_list[1]
                    path_str = self.check_path(action, path_list, path)
                    self.remove_module(module_type, module_name)
                    self.add_module(module_type, module_name, new_value)
                elif path_len > 2:
                    module_type = path_list[0]
                    module_name = path_list[1]
                    path_str = self.check_path(action, path_list, path)
                    eval(path_str[:path_str.rfind("[")])[
                        path_list[-1]] = new_value
                    self.remove_module(module_type, module_name)
                    self.add_module(
                        module_type, module_name, existing_dataset_value[module_type][module_name])

        if action == "add_path":
            path_str = self.check_path(action, path_list, path)
            module_type = path_list[0]
            module_name = path_list[1]
            eval(path_str)[path_list[-1]] = new_value
            if path_len > 2:
                self.remove_module(module_type, module_name)
            self.add_module(
                module_type, module_name, existing_dataset_value[module_type][module_name])

        if action == "add_values":
            path_str = self.check_path(action, path_list, path)
            value = eval(path_str)
            if not type(new_value) == type(value):
                raise GnanaError("Type doesnot match.")
            if isinstance(new_value, dict):
                for i, v in new_value.items():
                    eval(path_str)[i] = v
            elif isinstance(new_value, list):
                for i in new_value:
                    eval(path_str).append(i)
            else:
                raise GnanaError(
                    "add_values support only dict and list types.")
            self.remove_module(path_list[0], path_list[1])
            self.add_module(
                path_list[0], path_list[1], existing_dataset_value[path_list[0]][path_list[1]])

        if action == "prepend_values":
            path_str = self.check_path(action, path_list, path)
            value = eval(path_str)
            if not type(new_value) == type(value):
                raise GnanaError("Type doesnot match.")
            if isinstance(new_value, dict):
                raise GnanaError(
                    "prepend_values supports only list.Please try add_values.")
            elif isinstance(new_value, list):
                for i in new_value:
                    eval(path_str).insert(0, i)
            else:
                raise GnanaError("prepend_values support list type.")
            self.remove_module(path_list[0], path_list[1])
            self.add_module(
                path_list[0], path_list[1], existing_dataset_value[path_list[0]][path_list[1]])

        if action == "remove_path":
            path_str = self.check_path(action, path_list, path)
            module_type = path_list[0]
            module_name = path_list[1]
            if isinstance(eval(path_str[:path_str.rfind("[")]), dict):
                eval(path_str[:path_str.rfind("[")]).pop(path_list[-1])
            self.remove_module(module_type, module_name)
            if module_name in existing_dataset_value[module_type]:
                existing_dataset_value[module_type]
                self.add_module(
                    module_type, module_name, existing_dataset_value[module_type][module_name])

        if action == "remove_values":
            path_str = self.check_path(action, path_list, path)
            value = eval(path_str)
            for remove_value in new_value:
                if remove_value not in value:
                    raise GnanaError("%s key is missing" % remove_value)
                if isinstance(value, dict):
                    eval(path_str).pop(remove_value)
                elif isinstance(value, list):
                    eval(path_str).remove(remove_value)
            if path_len == 1:
                for module_name in new_value:
                    self.remove_module(path_list[0], module_name)
                for module_name, module_value in existing_dataset_value[path_list[0]]:
                    self.add_module(path_list[0], module_name, module_value)
            elif path_len > 1:
                self.remove_module(path_list[0], path_list[1])
                if path_list[1] in existing_dataset_value[path_list[0]]:
                    self.add_module(
                        path_list[0], path_list[1], existing_dataset_value[path_list[0]][path_list[1]])
        return existing_dataset_value

    def validate_record(self):
        def validate_fieldmap(fields):
            from collections import defaultdict
            sf_dic = defaultdict(set)
            uip_dic = defaultdict(set)
            for key, val in fields:
                sf_dic[key].add(val)
                uip_dic[val].add(key)
            for each in uip_dic:
                if len(uip_dic[each]) > 1:
                    raise GnanaError(
                        'Duplicates maps occured: ' + ' '.join(uip_dic[each]) + ' for ' + each)

        def dic_travers(mydic):
            for each in mydic:
                if each == 'fieldmap':
                    validate_fieldmap(mydic[each])
                if isinstance(mydic[each], dict):
                    dic_travers(mydic[each])

        ds = self.ds.get_as_map()
        dic_travers(ds)

def validate_expression(ds_temp, save_on_error, stage):
    nattrs = {}
    ds_temp.encode(nattrs)
    res = config_pattern_expansion(nattrs)
    eval_errs = res.get('eval_errs', None)
    if eval_errs:
        if save_on_error:
            tdetails = sec_context.details
            if stage:
                flag_name = ds_temp.name+'~'+stage
            else:
                flag_name = ds_temp.name
            tdetails.set_flag('save_on_error', flag_name, eval_errs.keys())
        else:
            raise GnanaError(eval_errs)


def purge_dataset(ds, dataset, ds_type=None):
    if not ds:
        raise Exception("Dataset is not found to purge")
    if ds_type and (ds.ds_type != ds_type):
        raise Exception('Incompatible dataset')
    # Remove the dataset
    ds.remove()
    # Drop all collections
    gnana_db.dropCollectionsInNamespace("%s.%s" % (sec_context.name, dataset))


def create_dataset(dataset, ds_type, attrs, save_on_error=False, excluded_modules=['name', 'stages', 'ds_type'], sandbox=None):


    ds = Dataset()
    ds_helper = DSHelpers(ds)
    common_model = ds.models.pop('common')
    ds.name = dataset
    ds.stages['__start__'] = {'changes': []}
    ds.stage_used = '__start__'
    if ds_type:
        if ds_type in ('uip', 'source'):
            ds.ds_type = ds_type
        else:
            raise Exception("Incorrect ds_type, valid values are uip or source")
    # Add all the modules
    for module_type, module_list in attrs.items():
        if module_type in (excluded_modules):
            continue
        for module_name, params in module_list.items():
            # We are creating for the first time.  If there is nothing in params, we don't need that module
            if params is None:
                raise GnanaError('%s.%s value cannot be None' % (module_type, module_name))
            if module_type == 'params' and module_name == 'general':
                ds.params.pop('general')  # Remove the existing general if we found one in the dataset
            logger.info("Creating module {0}[{1}]".format(module_name, module_type))
            ds_helper.apply('__start__', "add_path", module_type + "." + module_name, params)
    # Save the dataset
    ds_helper.merge_stage('__start__', delete_stage=True)
    if 'common' not in ds.models:
        ds.models['common'] = common_model
    validate_expression(ds, save_on_error, stage=None)
    comment = "Created " + dataset + " config"
    file_name = dataset + ".json"
    fileUtils.gitbackup_dataset(file_name, ds_helper.ds.get_as_map(), comment)
    ds_helper.save(sandbox)
    return ds


def modify_dataset(dataset, stage, path, new_value, action, comments = None, ds_type = None, 
                   username = None, save_on_error = False):
    ds = Dataset.getByNameAndStage(dataset, sandbox=stage)
    ds_helper = DSHelpers(ds)
    
    if not ds:
            raise GnanaError("No such dataset", 404) 

    if ds_type and (ds.ds_type != ds_type):
        raise GnanaError("Incompatible dataset", 404) 

    # If it is not an existing stage, add a blank stage
    if stage not in ds.stages:
        ds_helper.ds.stages[stage] = {'changes': []}

    if 'creator' not in ds.stages[stage]:
        ds_helper.ds.stages[stage]['creator'] = username
        
    ds_helper.merge_stage(stage, delete_stage=False)
    ds_helper.check_path(action, path.split("."), path)
    ds_helper.apply_config(action, path, new_value)
    ds_helper.validate_record()
    validate_expression(ds_helper.ds, save_on_error, stage)

    #print("sandbox_here is:------------", {path : new_value})
    ds_helper.save(sandbox=stage, sandbox_comment=comments)
    return {'success': True}